--X10Db_Query_GetMacrosDataSet.sql
--February 9, 2021
--Alan Wagner
--X10ManagerDesktop Project

SELECT 'Edit' AS [AddEdit],
ms.MacroID AS [MacroID],
ms.[name] AS [name],
ms.[description] AS [description],
ms.MacroInitiatorID AS [MacroInitiatorID],
ms.MacroSort AS [MacroSort],
ms.flag AS [flag],
ms.RF AS [RF],
ms.delay AS [delay],
ms.inhibitRetrigger AS [inhibitRetrigger],
mcs.MacroCommandID AS [MacroCommandID],
mcs.MacroCommandSort AS [MacroCommandSort],
mcs.command AS [command],
cbc.DisplayMember AS commandName,
mcs.prebrighten AS [prebrighten],
mcs.house AS [house],
mcs.unitcode AS [unitcode],
mcs.unitcodeMaskOdd AS [unitcodeMaskOdd],
mcs.unitcodeMaskEven AS [unitcodeMaskEven],
mcs.extendedCommand AS [extendedCommand],
mcs.extendedData AS [extendedData],
mcs.dimValue AS [dimValue]
FROM ((Macros AS ms LEFT JOIN MacroCommands AS mcs ON mcs.MacroID=ms.MacroID) LEFT JOIN ComboBoxs AS cbc ON cbc.ValueMember=mcs.command)
WHERE ms.MacroID>-1
AND cbc.Name='Command'

UNION

SELECT 'Add' AS [AddEdit],
ms.MacroID AS [MacroID],
'' AS [name],
'' AS [description],
-1 AS [MacroInitiatorID],
-1 AS [MacroSort],
-1 AS [flag],
-1 AS [RF],
-1 AS [delay],
-1 AS [inhibitRetrigger],
-1 AS [MacroCommandID],
-1 AS [MacroCommandSort],
-1 AS [command],
'' AS commandName,
-1 AS [prebrighten],
-1 AS [house],
-1 AS [unitcode],
0 AS [unitcodeMaskOdd],
0 AS [unitcodeMaskEven],
-1 AS [extendedCommand],
-1 AS [extendedData],
-1 AS [dimValue]
FROM Macros AS ms
WHERE ms.MacroID=-1

ORDER BY [AddEdit], [MacroSort], [MacroCommandSort];
