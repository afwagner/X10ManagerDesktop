--X10Db_Query_GetEventsDataSet.sql
--May 19, 2020
--Alan Wagner
--X10ManagerDesktop Project


SELECT 'Edit' AS [AddEdit],
Events.EventID, Events.ScheduleID, Events.SceneID, Events.MacroInitiatorID, Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec,
Schedules.ScheduleName AS [Schedule],
Scenes.SceneName AS [Scene],
MacroInitiators.name AS [Macro],
SWITCH(Events.Sec=0,'N', Events.Sec=1,'Y') AS [SecurityYN],
SWITCH(Events.Enabled=0,'N', Events.Enabled=1,'Y') AS [EnabledYN],
FORMAT(Events.[StartDate], 'mm/dd/yyyy') AS [StartDate],
FORMAT(Events.[StopDate], 'mm/dd/yyyy') AS [StopDate]
FROM (((Events INNER JOIN Schedules ON Schedules.ScheduleID=Events.ScheduleID) INNER JOIN Scenes ON Scenes.SceneID=Events.SceneID) INNER JOIN MacroInitiators ON MacroInitiators.MacroInitiatorID=Events.MacroInitiatorID)
WHERE Schedules.ScheduleID=3

UNION

SELECT 'Add' AS [AddEdit],
[EventID],
-1 AS [ScheduleID], -1 AS [SceneID], -1 AS [MacroInitiatorID], -1 AS [SDay], -1 AS [DOW], -1 AS [STime], -1 AS [ARise], -1 AS [ASet], -1 AS [TOD], -1 AS [Sec],
'' AS [Schedule],
'' AS [Scene],
'' AS [Macro],
'' AS [SecurityYN],
'' AS [EnabledYN],
'' AS [StartDate],
'' AS [StopDate]
FROM Events
WHERE [EventID] = -1

ORDER BY [AddEdit], [Scene], [Macro];
