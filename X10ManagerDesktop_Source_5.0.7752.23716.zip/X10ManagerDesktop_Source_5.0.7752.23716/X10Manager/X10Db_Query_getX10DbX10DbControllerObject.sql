--X10Db_Query_getX10DbX10DbControllerObject.sql
--May 17, 2020
--Alan Wagner
--X10ManagerDesktop Project

SELECT Controllers.ControllerID,Controllers.ControllerName,Controllers.ControllerTypeID,ControllerTypes.ControllerType,ControllerTypes.ControllerType,ControllerTypes.ControllerExtendedCommands,ControllerTypes.ControllerMacros,Controllers.ControllerDescription,Controllers.ControllerActive,Controllers.HouseCode,Controllers.TransceiverHouseCodes,Controllers.Port,Controllers.Hub,Controllers.AppKey,Controllers.UID,Controllers.DuskDawnResolution
FROM Controllers INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Controllers.ControllerName='Test'
AND ControllerTypes.ControllerType='CP290';

