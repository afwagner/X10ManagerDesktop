--X10Db_Query_compileUnitCommandsFromX10DbScene.sql
--June 4, 2020
--Alan Wagner
--X10ManagerDesktop Project


SELECT DISTINCT c.ControllerID,
u.UnitExtendedCommands,
u.UnitHouseNumber,
u.UnitDimmer,
su.UnitOnOff,
su.UnitLevel,
u.UnitModuleNumber,
(SWITCH (su.UnitOnOff=0,'Off',su.UnitOnOff=1 AND u.UnitDimmer=0,'On',su.UnitOnOff=1 AND u.UnitDimmer=1,TRIM(STR(su.UnitLevel)))) AS OnOff,
c.ControllerName,
c.ControllerTypeID,
ct.ControllerType,
c.ControllerDescription,
c.HouseCode,
c.[Port],
c.[Hub],
c.[AppKey],
c.[UID],
s.SceneID,
s.SceneName,
su.SceneUnitID,
u.UnitID,
u.UnitHouseCode,
u.UnitModuleCode,
u.UnitName,
u.UnitDescription,
u.UnitCode
FROM (((Units AS u INNER JOIN SceneUnits AS su ON su.UnitID=u.UnitID)
INNER JOIN Scenes AS s ON s.SceneID=su.SceneID)
INNER JOIN Controllers AS c ON c.ControllerID=u.ControllerID)
INNER JOIN ControllerTypes AS ct ON ct.ControllerTypeID=c.ControllerTypeID
WHERE s.SceneID=22
AND c.ControllerActive=1
AND u.UnitEnabled=1
ORDER BY c.ControllerID, u.UnitExtendedCommands, u.UnitHouseNumber, u.UnitDimmer, su.UnitOnOff, su.UnitLevel, u.UnitModuleNumber;
