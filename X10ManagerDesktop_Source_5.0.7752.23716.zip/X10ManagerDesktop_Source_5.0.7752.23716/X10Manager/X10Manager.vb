Imports System
Imports System.Collections
Imports System.Configuration
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Web.Services
Imports System.Web.Configuration
Imports System.Web.Security
Imports System.Diagnostics
Imports System.Data
Imports System.Data.Common
Imports System.Data.Sql
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Data.OleDb
Imports System.Data.Odbc
Imports System.IO
Imports System.IO.Ports
Imports System.Security
Imports System.Security.Principal
Imports System.Threading
Imports System.Text
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Globalization
Imports Microsoft.VisualBasic

Imports TrekkerPhotoArt.X10Include
Imports TrekkerPhotoArt.X10IncludeCM

' ** File Name: X10Manager.vb
' ** Version:   1.0
' ** Created:   November 9, 2018
' ** Author:    Alan Wagner

Namespace TrekkerPhotoArt

    Public Class RunApplication

#Region "ConstVariables"

        ' Public - would be accessible from anywhere (closest thing to global)
        ' Private - only accessible from within that class itself
        ' Protected - accessible in this class, and any class that inherits from it.

        ' Get the current configuration file.
        ' Filename looks like: D:\Lighthou\X10Manager\X10Manager.exe.config
        Private objCurrentConfigFile As System.Configuration.Configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None)
        Public CurrentConfigFile As String = objCurrentConfigFile.FilePath.ToString()

        ' Configuration File Format:
        '<?xml version="1.0" encoding="utf-8" ?>
        '<configuration>
        '   <appSettings>
        '
        '		<!-- X10Manager.vb -->
        '		<!-- When MailErrorsTo is specified, operational errors are emailed to specified email address Recipient. -->
        '		<!-- mailSettings must be specified below. -->
        '		<!-- <add key="MailErrorsFrom" value="" /> -->
        '		<add key="MailErrorsFrom" value="afwagner@trekkerphotoart.com" />
        '		<!-- <add key="MailErrorsTo" value="" /> -->
        '		<add key="MailErrorsTo" value="afwagner@trekkerphotoart.com;tjwagner@trekkerphotoart.com" />
        '		
        '		<!-- X10Include.vb -->
        '		<!-- X10IncludeCM.cs -->
        '		<add key="X10OutputTroubleShootMessages" value="Y" />
        '		<!-- <add key="X10OutputTroubleShootMessages" value="N" /> -->
        '		<add key="X10OutputConsoleMessages" value="Y" />
        '		<!-- <add key="X10OutputConsoleMessages" value="N" /> -->
        '
        '   </appSettings>
        '</configuration>

        Public MailErrorsFrom As String = System.Configuration.ConfigurationManager.AppSettings("MailErrorsFrom")
        Public MailErrorsTo As String = System.Configuration.ConfigurationManager.AppSettings("MailErrorsTo")

#End Region ' END Region - ConstVariables

#Region "Main()"
        Shared Sub Main()
            Dim nsMailToMethods As New TrekkerPhotoArt.X10Include.MailToMethods
            Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
            Dim nsSunTimeMethods As New TrekkerPhotoArt.X10Include.SunTimeMethods
            Dim nsConstVariables As New TrekkerPhotoArt.RunApplication
            Dim nsMainMethods As New TrekkerPhotoArt.RunApplication.MainMethods
            Dim nsParseCmdLineMethods As New TrekkerPhotoArt.RunApplication.ParseCmdLineMethods

            Dim strStatus As String = ""
            Dim strError As String = ""
            Dim intExitCode As Integer = 0

            Dim strOperation As String = ""         ' /O:Operation
            Dim strFilename As String = ""          ' /F:Filename
            Dim strX10ControllerName As String = "" ' /N:X10ControllerName
            Dim strX10ControllerType As String = "" ' /T:X10ControllerType [CP290|CM15A]
            Dim strX10ControllerDescription As String = "" ' /D:X10ControllerDescription
            Dim strEnabled As String = ""           ' /E:Enabled [Y/N]
            Dim strScheduleName As String = ""      ' /S:ScheduleName
            Dim strSceneName As String = ""         ' /C:SceneName
            Dim strHouseCode As String = ""         ' /H:HouseCode [A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P]
            Dim strModuleCode As String = ""        ' /M:ModuleCode, Unit/Module Number as comma delimited List within double quotes of numbers 1-16. ex: "1,3,5,7,9,16" or just a code ex: ""10".
            Dim strBrightenDim As String = ""       ' /0:BrightenDim [B|D] (B=Brighten, D=Dim) If BrightenDim not specified, Dimmer Module will pre-brighten then Dim.  Note: CP290 is not supported
            Dim strDimmer As String = ""            ' /1:Dimmer, Y - Unit/Module is Dimmer, N - Unit/Module is Switch
            Dim strOnOff As String = ""             ' /2:OnOff, For Dimmer=Y OnOff=[Off|On|100|94|88|81|75|69|63|56|50|44|38|31|25|19|13|6], For Dimmer=N OnOff=[Off|On]
            Dim strStandardExtended As String = ""  ' /3:StandardExtended, S - Standard transmission, E - Extended transmission
            Dim strExtendedData As String = ""      ' /4:ExtendedData, Extended transmission Data byte as string
            Dim strExtendedCommand As String = ""   ' /5:ExtendedCommand, Extended transmission Command byte as string
            Dim strMemoryAddrLow As String = ""     ' /6:MemoryAddrLow, MemoryAddrLow byte as string
            Dim strMemoryAddrHigh As String = ""    ' /7:MemoryAddrHigh, MemoryAddrHigh byte as string
            Dim strTransceiverHouseCodes As String = ""  ' /8:TransceiverHouseCode, ex: "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P"
            Dim strDuskDawnResolution As String = ""     ' /9:DuskDawnResolution, dusk/dawn resolution in Days. Use multiples of 8.
            Dim strPort As String = ""              ' /P:Port [COMn| for USB ex: "0003� |WIFI]
            Dim strHub As String = ""               ' /B:Hub [for USB ex: "0004"]
            Dim strAppKey As String = ""            ' /A:AppKey, ex: "26d884ce-9f25-948537"
            Dim strUID As String = ""               ' /U:UID, ex: "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"

            Dim objTimeZone As TrekkerPhotoArt.X10Include.TimeZone = Nothing
            Dim strSunriseTime As String = ""
            Dim strSunsetTime As String = ""

            Dim dtmStartTimeDate As Date = Microsoft.VisualBasic.FormatDateTime(System.DateTime.Now, vbGeneralDate)
            Dim dtmEndTimeDate As Date = Nothing
            Dim intDateTimeDiffSeconds As Integer = -1

            Dim strLighthouseParadoxFilesPath As String = ""
            Dim strLighthouseParadoxConnectionString As String = ""
            Dim strLighthouseParadoxProvider As String = ""

            Dim strDirectoryPath As String = ""
            Dim strX10DbConnectionString As String = ""
            Dim strX10DbProvider As String = ""

            Dim intRowsAffected As Integer = -1

            Dim objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting = Nothing
            Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
            Dim intControllerID As Integer = -1
            Dim intControllerTypeID As Integer = -1

            Dim intTimersCompiled As Integer = 0

            Dim strGuid As String = System.Guid.NewGuid().ToString()

            System.Console.WriteLine("X10Manager(): Copyright (c) February 2006 trekkerphotoart.com: Revised March 23, 2021")
            System.Console.WriteLine("X10Manager(): Program Version: 5" & vbCrLf & "Program Schema:" & vbCrLf & "  " & nsX10DbMethods.getSchemaVersionCopyright() & vbCrLf & "  Version: " & nsX10DbMethods.getSchemaVersion() & vbCrLf & "  Version Date: " & nsX10DbMethods.getSchemaVersionDate())
            System.Console.WriteLine("")
            System.Console.WriteLine("This entire project (including and not limited to Documentation, Images, Executables, Libraries and Scripts) is Licensed under the ""CREATIVE COMMONS PUBLIC LICENSE (CCPL)"".")
            System.Console.WriteLine("The ""CCPL"" can be found in ""X10Manager Operations Manual"", ""Licensing"" section.")
            System.Console.WriteLine("")
            System.Console.WriteLine("X10Manager(): Started at " & dtmStartTimeDate)
            System.Console.WriteLine("")

            Try

                System.Console.WriteLine("ConfigFilePath=" & nsConstVariables.CurrentConfigFile) ' EX: "D:\Lighthou\X10Manager\X10Manager.exe.Config"
                strDirectoryPath = System.IO.Path.GetDirectoryName(nsConstVariables.CurrentConfigFile)
                System.Console.WriteLine("DirectoryPath=" & strDirectoryPath) ' EX: "D:\Lighthou\X10Manager"

                System.Console.WriteLine("Command$ --> " & Command$)

                ' Command line arguments are passed into Visual Basic by way of the Command$ variable.
                ' This variable is a very long string with all the arguments written exactly as the user entered them.
                ' It does not include the .exe being executed.
                strStatus = nsParseCmdLineMethods.ParseCmdLine(Command$, strOperation, strFilename, strX10ControllerName, strX10ControllerType, strX10ControllerDescription, strEnabled, strScheduleName, strSceneName, strHouseCode, strModuleCode, strBrightenDim, strDimmer, strOnOff, strStandardExtended, strExtendedData, strExtendedCommand, strMemoryAddrLow, strMemoryAddrHigh, strTransceiverHouseCodes, strDuskDawnResolution, strPort, strHub, strAppKey, strUID)
                If (strStatus = "") Then

                    System.Console.WriteLine("Operation=" & strOperation)


                    ' https://stackoverflow.com/questions/15948333/how-to-open-the-db-paradox-file
                    ' https://docs.microsoft.com/en-us/sql/odbc/microsoft/sqlconfigdatasource-paradox-driver?view=sql-server-2017
                    '
                    ' Provider = "System.Data.Odbc"
                    ' Windows 8.1, 10
                    ' COLLATINGSEQUENCE - ASCII (default), International, Swedish-Finnish, or Norwegian-Danish.
                    ' DRIVERID
                    '   An Integer ID for the driver.
                    '     26 (Paradox 3.x)
                    '     282 (Paradox 4.x)
                    '     538 (Paradox 5.x)
                    ' FIL - File Type Paradox 3.x, Paradox 4.x, Or Paradox 5.x
                    ' PAGETIMEOUT - Specifies the period of time, in tenths of a second, that a page (if not used) remains in the buffer before being removed.
                    '   The default is 600 tenths of a second (60 seconds).
                    '   Note that this option applies to all data sources that use the ODBC driver.
                    ' PARADOXNETPATH - The full path of the directory containing a Paradox lock database, because it contains either the PDOXUSRS.net file (in Paradox 4.x) or the PARADOX.net file (in Paradox 5.x). If the directory does not contain one of these files, the Paradox driver creates one. For information about these files, see the Paradox documentation.
                    ' PARADOXNETSTYLE - For the Paradox driver, the network access style to use when accessing Paradox data: either "3.x" for Paradox 3.x or "4.x" for Paradox 4.x or 5.x. Can be set to "3.x" or "4.x" if the version is Paradox 4.x or 5.x; if the version is Paradox 3.x, the style must be "3.x".
                    ' Note: You should only specify the folder where the database resides. Not the database name itself.
                    ' <add key="LighthouseParadoxFilesPath" value="D:\Lighthou" />
                    'strLighthouseParadoxProvider = "System.Data.Odbc"
                    ' Dim strConnectionString As String = "Driver={Microsoft Paradox Driver (*.db )};READONLY=TRUE;UserCommitSync=Yes;Threads=3;SafeTransactions=0;ParadoxNetStyle=3.x;ParadoxNetPath=D:\Lighthou;PageTimeout=50;DriverID=26;Fil=Paradox 3.X;DefaultDir=D:\Lighthou;Dbq=D:\Lighthou;CollatingSequence=ASCII;"
                    'strLighthouseParadoxConnectionString = "Driver={Microsoft Paradox Driver (*.db )};READONLY=FALSE;UserCommitSync=Yes;Threads=3;SafeTransactions=0;PageTimeout=600;ParadoxNetPath=" & nsConstVariables.LighthouseParadoxFilesPath & ";ParadoxNetStyle=5.x;ParadoxNetPath=" & nsConstVariables.LighthouseParadoxFilesPath & ";DriverID=538;Fil=Paradox 5.X;DefaultDir=" & nsConstVariables.LighthouseParadoxFilesPath & ";Dbq=" & nsConstVariables.LighthouseParadoxFilesPath & ";CollatingSequence=ASCII;"

                    ' 32 bit only - vbc.exe /platform:x86
                    ' <!-- X10Manager.vb -->
                    ' <!-- Notes: -->
                    ' <!--   When specified, the Lighthouse program's Paradox data base is the master data source for some X10Manager operations. -->
                    ' <!--   You should only specify the folder where the database files reside. Not the database name itself. -->
                    ' <!-- <add key="LighthouseParadoxFilesPath" value="" /> -->
                    ' <add key="LighthouseParadoxFilesPath" value="D:\Lighthou" />
                    ' X10Include.vb
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.LighthouseParadoxFilesPath As String = System.Configuration.ConfigurationManager.AppSettings("LighthouseParadoxFilesPath")
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerDbProviderFactory As String = "System.Data.OleDb"
                    strLighthouseParadoxFilesPath = nsX10DbMethods.getLighthouseParadoxFilesPath
                    strLighthouseParadoxProvider = nsX10DbMethods.getX10ManagerDbProviderFactory()
                    strLighthouseParadoxConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & strLighthouseParadoxFilesPath & ";Extended Properties=Paradox 5.x;"


                    ' Microsoft Access Database Engine - Redistributable
                    ' https://www.microsoft.com/en-us/download/details.aspx?id=13255
                    ' X10Include.vb
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerDbProviderFactory As String = "System.Data.OleDb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDb As String = "X10Db.accdb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDbProvider = "Microsoft.ACE.OLEDB.12.0"
                    ' strX10DbConnectionString - ex: "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\X10Manager\X10Db.accdb;"
                    '
                    ' 32 bit only - vbc.exe /platform:x86
                    ' X10Include.vb
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerDbProviderFactory As String = "System.Data.OleDb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDb As String = "X10Db.mdb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDbProvider = "Microsoft.Jet.OLEDB.4.0"
                    ' strX10DbConnectionString - ex: "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\X10Manager\X10Db.mdb;"
                    strX10DbConnectionString = "Provider=" & nsX10DbMethods.getX10ManagerAccessDbProvider() & ";Data Source=" & strDirectoryPath & "\" & nsX10DbMethods.getX10ManagerAccessDb & ";"
                    strX10DbProvider = nsX10DbMethods.getX10ManagerDbProviderFactory()

                    ' https://stackoverflow.com/questions/31509299/adding-trusted-location-to-access-run-time
                    ' Adding Trusted Location to Access Run Time


                    Select Case Microsoft.VisualBasic.UCase(strOperation)
                        Case "COMPLETEX10MANAGERDESKTOPINSTALLATION"
                            ' completeX10ManagerDesktopInstallation
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.completeX10ManagerDesktopInstallation()")
                            ' nsX10DbMethods.completeX10ManagerDesktopInstallation() As String
                            strStatus = nsX10DbMethods.completeX10ManagerDesktopInstallation()
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.completeX10ManagerDesktopInstallation()

                        Case "BACKUPX10DB"
                            ' backupX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.getX10DbSettings()")
                            ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
                            strStatus = nsX10DbMethods.getX10DbSettings(strX10DbConnectionString, strX10DbProvider, objX10DbSetting)
                            If (strStatus = "") Then

                                System.Console.WriteLine("nsX10DbMethods.getX10DbTableContents()")
                                ' nsX10DbMethods.getX10DbTableContents(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strDestinationDirectoryPath As String, ByRef strMessage As String) As String
                                strStatus = nsX10DbMethods.getX10DbTableContents(strX10DbConnectionString, strX10DbProvider, objX10DbSetting.backupDirectoryPath, "")
                                If (strStatus <> "") Then
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10DbMethods.getX10DbTableContents()

                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbSettings()

                        Case "RESTOREX10DB"
                            ' restoreX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.getX10DbSettings()")
                            ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
                            strStatus = nsX10DbMethods.getX10DbSettings(strX10DbConnectionString, strX10DbProvider, objX10DbSetting)
                            If (strStatus = "") Then

                                System.Console.WriteLine("nsX10DbMethods.putX10DbTableContents()")
                                ' nsX10DbMethods.putX10DbTableContents(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strSourceDirectory As String, ByRef strMessage As String) As String
                                strStatus = nsX10DbMethods.putX10DbTableContents(strX10DbConnectionString, strX10DbProvider, objX10DbSetting.backupDirectoryPath, "")
                                If (strStatus <> "") Then
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10DbMethods.putX10DbTableContents()

                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbSettings()

                        Case "CREATEX10DBTABLES"
                            ' createX10DbTables
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.createX10DbTablesAll()")
                            ' nsX10DbMethods.createX10DbTablesAll(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String) As String
                            strStatus = nsX10DbMethods.createX10DbTablesAll(strX10DbConnectionString, strX10DbProvider)
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.createX10DbTablesAll()

                        Case "CREATEX10DBTABLEMACROS"
                            ' createX10DbTableMacros
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.createX10DbTableMacros()")
                            ' nsX10DbMethods.createX10DbTableMacros(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String) As String
                            strStatus = nsX10DbMethods.createX10DbTableMacros(strX10DbConnectionString, strX10DbProvider)
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                            End If ' END - nsX10DbMethods.createX10DbTableMacros()

                        Case "CREATEX10DBTABLETIMERS"
                            ' createX10DbTableTimers
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.createX10DbTable(Timers)")
                            ' nsX10DbMethods.createX10DbTable(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strTableName As String) As String
                            strStatus = nsX10DbMethods.createX10DbTable(strX10DbConnectionString, strX10DbProvider, "Timers")
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                            End If ' END - nsX10DbMethods.createX10DbTable(Timers)

                        Case "CREATEX10DBTABLECOMBOBOXS"
                            ' createX10DbTableComboBoxs
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.createX10DbTable(ComboBoxs)")
                            ' nsX10DbMethods.createX10DbTable(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strTableName As String) As String
                            strStatus = nsX10DbMethods.createX10DbTable(strX10DbConnectionString, strX10DbProvider, "ComboBoxs")
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                            End If ' END - nsX10DbMethods.createX10DbTable(ComboBoxs)

                        Case "UPDATESETTINGSSCHEMAVERSIONTOX10DB"
                            ' updateSettingsSchemaVersionToX10db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.updateSettingsSchemaVersionToX10db()")
                            ' nsX10DbMethods.updateSettingsSchemaVersionToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef intRowsAffected As Integer) As String
                            strStatus = nsX10DbMethods.updateSettingsSchemaVersionToX10db(strX10DbConnectionString, strX10DbProvider, intRowsAffected)
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                            End If ' END - nsX10DbMethods.updateSettingsSchemaVersionToX10db()

                        Case "PUTX10DBSUNTIMES"
                            ' putX10DbSunTimes
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.getX10DbSettings")
                            ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
                            strStatus = nsX10DbMethods.getX10DbSettings(strX10DbConnectionString, strX10DbProvider, objX10DbSetting)
                            If (strStatus = "") Then

                                System.Console.WriteLine("nsSunTimeMethods.getTimeZone")
                                ' nsSunTimeMethods.getTimeZone(ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone) As String
                                strStatus = nsSunTimeMethods.getTimeZone(objTimeZone)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsSunTimeMethods.SunTimes")
                                    ' nsSunTimeMethods.SunTimes(ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
                                    strStatus = nsSunTimeMethods.SunTimes(objTimeZone, CType(objX10DbSetting.latitude, Double), CType(objX10DbSetting.longitude, Double), strSunriseTime, strSunsetTime)
                                    If (strStatus = "") Then

                                        System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes")
                                        ' intX10SunriseTime and intX10SunsetTime as minutes after Midnight
                                        ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                        strStatus = nsX10DbMethods.putX10DbSunTimes(strX10DbConnectionString, strX10DbProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                        If (strStatus = "") Then

                                            System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes(): " & intRowsAffected.ToString() & " Schedules were affected.")

                                        Else
                                            System.Console.WriteLine(strStatus)
                                            intExitCode = -1
                                        End If ' END - nsX10DbMethods.putX10DbSunTimes()

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsSunTimeMethods.SunTimes()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsSunTimeMethods.getTimeZone()

                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbSettings()

                        Case "GETSERIALPORTSPUTX10DB"
                            ' getSerialPortsPutX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.getSerialPortsPutX10Db()")
                            ' nsX10DbMethods.getSerialPortsPutX10Db(ByVal strConnectionString As String, ByVal strProvider As String) As String
                            strStatus = nsX10DbMethods.getSerialPortsPutX10Db(strX10DbConnectionString, strX10DbProvider)
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getSerialPortsPutX10Db()

                        Case "GETUSBPORTSPUTX10DB"
                            ' getUSBPortsPutX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.getUSBPortsPutX10Db()")
                            ' nsX10DbMethods.getUSBPortsPutX10Db(ByVal strConnectionString As String, ByVal strProvider As String) As String
                            strStatus = nsX10DbMethods.getUSBPortsPutX10Db(strX10DbConnectionString, strX10DbProvider)
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getUSBPortsPutX10Db()

                        Case "COMPILETIMERSFROMX10DBEVENTSPLACEINX10DB"
                            ' compileTimersFromX10DbEventsPlaceInX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db")
                            ' nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByRef intTimersCompiled As Integer) As String
                            strStatus = nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(strX10DbConnectionString, strX10DbProvider, intTimersCompiled)
                            If (strStatus = "") Then

                                If (intTimersCompiled < 1) Then
                                    System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): No Events were found.")
                                    System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): This can be caused by No Active Schedules with Events using Scenes that include Modules attached to this Controller.")
                                    intExitCode = -1
                                End If

                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db()

                        Case "DOWNLOADEVENTSTOACTIVECONTROLLERS"
                            ' downloadEventsToActiveControllers
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("nsMainMethods.downloadEventsToActiveControllers")
                            ' nsMainMethods.downloadEventsToActiveControllers(ByVal strConnectionString As String, ByVal strProvider As String) As String
                            strStatus = nsMainMethods.downloadEventsToActiveControllers(strX10DbConnectionString, strX10DbProvider)
                            If (strStatus <> "") Then
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsMainMethods.downloadEventsToActiveControllers()

                        Case "ADDX10CONTROLLERTOX10DB"
                            ' addX10ControllerToX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("X10ControllerName=" & strX10ControllerName)
                            System.Console.WriteLine("X10ControllerType=" & strX10ControllerType)
                            System.Console.WriteLine("X10ControllerDescription=" & strX10ControllerDescription)
                            System.Console.WriteLine("Enabled=" & strEnabled)
                            System.Console.WriteLine("HouseCode=" & strHouseCode)
                            System.Console.WriteLine("Port=" & strPort)
                            System.Console.WriteLine("Hub=" & strHub)
                            System.Console.WriteLine("AppKey=" & strAppKey)
                            System.Console.WriteLine("UID=" & strUID)
                            System.Console.WriteLine("TransceiverHouseCodes=" & strTransceiverHouseCodes)
                            System.Console.WriteLine("DuskDawnResolution=" & strDuskDawnResolution)

                            objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                            objX10DbController.ControllerID = -1
                            objX10DbController.ControllerName = strX10ControllerName
                            objX10DbController.ControllerTypeID = -1
                            objX10DbController.ControllerType = strX10ControllerType    ' "CP290", "CM15A", "WM100"
                            objX10DbController.ControllerDescription = strX10ControllerDescription

                            If (strEnabled.ToUpper() = "Y") Then
                                objX10DbController.ControllerActive = 1
                            Else
                                objX10DbController.ControllerActive = 0
                            End If

                            objX10DbController.ControllerExtendedCommands = 0
                            objX10DbController.ControllerMacros = 0
                            objX10DbController.HouseCode = ""
                            objX10DbController.TransceiverHouseCodes = ""
                            objX10DbController.Port = ""
                            objX10DbController.Hub = ""
                            objX10DbController.AppKey = ""
                            objX10DbController.UID = ""
                            objX10DbController.DuskDawnResolution = 0

                            Select Case Microsoft.VisualBasic.UCase(strX10ControllerType)
                                Case "CP290"
                                    System.Console.WriteLine("X10Manager(): X10ControllerType=CP290: Home Control Interface (RS232)")

                                    objX10DbController.ControllerExtendedCommands = 0      ' 0 - Controller accepts Standard tranmission Function Commands only, 1 - Controller can also accept Extended transmission Function Commands
                                    objX10DbController.ControllerMacros = 0                ' 0 - Controller does not support Macros, 1 - Controller does support Macros
                                    objX10DbController.HouseCode = strHouseCode     ' "J" Controller's Base House Code for panel Switches.
                                    objX10DbController.Port = strPort               ' "COMn"

                                Case "CM15A"
                                    System.Console.WriteLine("X10Manager(): X10ControllerType=CM15A: Active Home Professional (USB)")

                                    objX10DbController.ControllerExtendedCommands = 1      ' 0 - Controller accepts Standard tranmission Function Commands only, 1 - Controller can also accept Extended transmission Function Commands
                                    objX10DbController.ControllerMacros = 1                ' 0 - Controller does not support Macros, 1 - Controller does support Macros
                                    objX10DbController.HouseCode = strHouseCode     ' "K" House Code that Controller will monitor.
                                    objX10DbController.TransceiverHouseCodes = strTransceiverHouseCodes ' ex: "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P"

                                    ' USB Location=Port_#0003.Hub_#0004
                                    objX10DbController.Port = strPort           ' "0003"
                                    objX10DbController.Hub = strHub             ' "0004"

                                    If (strDuskDawnResolution = "") Then
                                        objX10DbController.DuskDawnResolution = 0
                                    Else
                                        objX10DbController.DuskDawnResolution = CType(strDuskDawnResolution, Byte)
                                    End If

                                Case "WM100"
                                    System.Console.WriteLine("X10Manager(): X10ControllerType=WM100: WiFi Hub (WiFi)")

                                    objX10DbController.ControllerExtendedCommands = 0      ' 0 - Controller accepts Standard tranmission Function Commands only, 1 - Controller can also accept Extended transmission Function Commands
                                    objX10DbController.ControllerMacros = 0                ' 0 - Controller does not support Macros, 1 - Controller does support Macros
                                    objX10DbController.Port = "WIFI"
                                    objX10DbController.AppKey = strAppKey            ' "26d884ce-9f25-948537"
                                    objX10DbController.UID = strUID                  ' "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"

                                Case Else
                                    System.Console.WriteLine("X10Manager(): Unknown X10ControllerType=""" & strX10ControllerType & """ or Operation=""" & strOperation & """")
                                    intExitCode = -1
                            End Select

                            If (intExitCode > -1) Then

                                System.Console.WriteLine("nsX10DbMethods.addX10ControllerToX10Db")
                                ' nsX10DbMethods.addX10ControllerToX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intRowsAffected As Integer) As String
                                strStatus = nsX10DbMethods.addX10ControllerToX10Db(strX10DbConnectionString, strX10DbProvider, strGuid, objX10DbController, intRowsAffected)
                                If (strStatus <> "") Then
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10DbMethods.addX10ControllerToX10Db()

                            End If

                            objX10DbController = Nothing

                        Case "UPDATEX10CONTROLLERTOX10DB"
                            ' updateX10ControllerToX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("X10ControllerName=" & strX10ControllerName)
                            System.Console.WriteLine("X10ControllerType=" & strX10ControllerType)
                            System.Console.WriteLine("X10ControllerDescription=" & strX10ControllerDescription)
                            System.Console.WriteLine("Enabled=" & strEnabled)
                            System.Console.WriteLine("HouseCode=" & strHouseCode)
                            System.Console.WriteLine("Port=" & strPort)
                            System.Console.WriteLine("Hub=" & strHub)
                            System.Console.WriteLine("AppKey=" & strAppKey)
                            System.Console.WriteLine("UID=" & strUID)
                            System.Console.WriteLine("TransceiverHouseCodes=" & strTransceiverHouseCodes)
                            System.Console.WriteLine("DuskDawnResolution=" & strDuskDawnResolution)

                            System.Console.WriteLine("nsX10DbMethods.addUpdateControllerToX10db")
                            ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strControllerName As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                            strStatus = nsX10DbMethods.getX10DbController(strX10DbConnectionString, strX10DbProvider, strX10ControllerName, objX10DbController)
                            If (strStatus = "") Then

                                ' Does Controller Exist.
                                If (Not objX10DbController Is Nothing) Then
                                    ' Controller Exists.

                                    If (objX10DbController.ControllerType.ToUpper() = strX10ControllerType.ToUpper()) Then

                                        intControllerID = objX10DbController.ControllerID
                                        intControllerTypeID = objX10DbController.ControllerTypeID

                                        objX10DbController = Nothing

                                        objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                                        objX10DbController.ControllerID = intControllerID
                                        objX10DbController.ControllerName = strX10ControllerName
                                        objX10DbController.ControllerTypeID = intControllerTypeID
                                        objX10DbController.ControllerType = strX10ControllerType    ' "CP290", "CM15A", "WM100"
                                        objX10DbController.ControllerDescription = strX10ControllerDescription

                                        If (strEnabled.ToUpper() = "Y") Then
                                            objX10DbController.ControllerActive = 1
                                        Else
                                            objX10DbController.ControllerActive = 0
                                        End If

                                        objX10DbController.ControllerExtendedCommands = 0
                                        objX10DbController.ControllerMacros = 0
                                        objX10DbController.HouseCode = ""
                                        objX10DbController.TransceiverHouseCodes = ""
                                        objX10DbController.Port = ""
                                        objX10DbController.Hub = ""
                                        objX10DbController.AppKey = ""
                                        objX10DbController.UID = ""
                                        objX10DbController.DuskDawnResolution = 0

                                        Select Case Microsoft.VisualBasic.UCase(strX10ControllerType)
                                            Case "CP290"
                                                System.Console.WriteLine("X10Manager(): X10ControllerType=CP290: Home Control Interface (RS232)")

                                                objX10DbController.ControllerExtendedCommands = 0      ' 0 - Controller accepts Standard tranmission Function Commands only, 1 - Controller can also accept Extended transmission Function Commands
                                                objX10DbController.ControllerMacros = 0                ' 0 - Controller does not support Macros, 1 - Controller does support Macros
                                                objX10DbController.HouseCode = strHouseCode     ' "J" Controller's Base House Code for panel Switches.
                                                objX10DbController.Port = strPort               ' "COMn"

                                            Case "CM15A"
                                                System.Console.WriteLine("X10Manager(): X10ControllerType=CM15A: Active Home Professional (USB)")

                                                objX10DbController.ControllerExtendedCommands = 1      ' 0 - Controller accepts Standard tranmission Function Commands only, 1 - Controller can also accept Extended transmission Function Commands
                                                objX10DbController.ControllerMacros = 1                ' 0 - Controller does not support Macros, 1 - Controller does support Macros
                                                objX10DbController.HouseCode = strHouseCode     ' "K" House Code that Controller will monitor.
                                                objX10DbController.TransceiverHouseCodes = strTransceiverHouseCodes ' ex: "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P"

                                                ' USB Location=Port_#0003.Hub_#0004
                                                objX10DbController.Port = strPort           ' "0003"
                                                objX10DbController.Hub = strHub             ' "0004"

                                                If (strDuskDawnResolution = "") Then
                                                    objX10DbController.DuskDawnResolution = 0
                                                Else
                                                    objX10DbController.DuskDawnResolution = CType(strDuskDawnResolution, Byte)
                                                End If

                                            Case "WM100"
                                                System.Console.WriteLine("X10Manager(): X10ControllerType=WM100: WiFi Hub (WiFi)")

                                                objX10DbController.ControllerExtendedCommands = 0      ' 0 - Controller accepts Standard tranmission Function Commands only, 1 - Controller can also accept Extended transmission Function Commands
                                                objX10DbController.ControllerMacros = 0                ' 0 - Controller does not support Macros, 1 - Controller does support Macros
                                                objX10DbController.Port = "WIFI"
                                                objX10DbController.AppKey = strAppKey            ' "26d884ce-9f25-948537"
                                                objX10DbController.UID = strUID                  ' "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"

                                            Case Else
                                                System.Console.WriteLine("X10Manager(): Unknown X10ControllerType=""" & strX10ControllerType & """ or Operation=""" & strOperation & """")
                                                intExitCode = -1
                                        End Select

                                        If (intExitCode > -1) Then

                                            System.Console.WriteLine("nsX10DbMethods.addUpdateControllerToX10db")
                                            ' nsX10DbMethods.addUpdateControllerToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intRowsAffected As Integer) As String
                                            strStatus = nsX10DbMethods.addUpdateControllerToX10db(strX10DbConnectionString, strX10DbProvider, strGuid, objX10DbController, intRowsAffected)
                                            If (strStatus <> "") Then
                                                System.Console.WriteLine(strStatus)
                                                intExitCode = -1
                                            End If ' END - nsX10DbMethods.addUpdateControllerToX10db()

                                        End If

                                        objX10DbController = Nothing

                                    Else
                                        System.Console.WriteLine("nsX10DbMethods.getX10DbController(updateX10ControllerToX10Db): Unable to change ControllerType: X10ControllerType<>""" & strX10ControllerType & """")
                                        intExitCode = -1
                                    End If ' END - X10ControllerType

                                Else
                                    ' Controller does not exist.
                                    System.Console.WriteLine("nsX10DbMethods.getX10DbController(updateX10ControllerToX10Db): X10ControllerName=""" & strX10ControllerName & """ not found.")
                                    intExitCode = -1
                                End If ' END - Does Controller Exist.

                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbController(()

                        Case "IMPORTMODULESTOX10DB"
                            ' importModulesToX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("Filename=" & strFilename)

                            ' nsMainMethods.importModulesToX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByVal strFilename As String, ByRef intExitCode As Integer) As String
                            strStatus = nsMainMethods.importModulesToX10Db(strX10DbConnectionString, strX10DbProvider, strGuid, strFilename, intExitCode)

                        Case "EXPORTMODULESFROMX10DB"
                            ' exportModulesFromX10Db
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("Filename=" & strFilename)

                            ' nsMainMethods.exportModulesFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByRef intExitCode As Integer) As String
                            strStatus = nsMainMethods.exportModulesFromX10Db(strX10DbConnectionString, strX10DbProvider, strFilename, intExitCode)

                        Case "SENDALLLIGHTSON"
                            ' SendAllLightsOn
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            ' nsMainMethods.sendUnitCommands(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strOperation As String, ByVal strSceneName As String, ByRef intExitCode As Integer) As String
                            strStatus = nsMainMethods.sendUnitCommands(strX10DbConnectionString, strX10DbProvider, "AllLightsOn", strSceneName, intExitCode)

                        Case "SENDALLLIGHTSOFF"
                            ' SendAllLightsOff
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            ' nsMainMethods.sendUnitCommands(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strOperation As String, ByVal strSceneName As String, ByRef intExitCode As Integer) As String
                            strStatus = nsMainMethods.sendUnitCommands(strX10DbConnectionString, strX10DbProvider, "AllLightsOff", strSceneName, intExitCode)

                        Case "SENDALLUNITSON"
                            ' SendAllUnitsOn
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            ' nsMainMethods.sendUnitCommands(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strOperation As String, ByVal strSceneName As String, ByRef intExitCode As Integer) As String
                            strStatus = nsMainMethods.sendUnitCommands(strX10DbConnectionString, strX10DbProvider, "AllUnitsOn", strSceneName, intExitCode)

                        Case "SENDALLUNITSOFF"
                            ' SendAllUnitsOff
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            ' nsMainMethods.sendUnitCommands(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strOperation As String, ByVal strSceneName As String, ByRef intExitCode As Integer) As String
                            strStatus = nsMainMethods.sendUnitCommands(strX10DbConnectionString, strX10DbProvider, "AllUnitsOff", strSceneName, intExitCode)

                        Case "SENDSCENEUNITCOMMANDS"
                            ' sendSceneUnitCommands
                            System.Console.WriteLine("X10Manager(): " & strOperation)

                            System.Console.WriteLine("SceneName=" & strSceneName)

                            ' nsMainMethods.sendUnitCommands(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strOperation As String, ByVal strSceneName As String, ByRef intExitCode As Integer) As String
                            strStatus = nsMainMethods.sendUnitCommands(strX10DbConnectionString, strX10DbProvider, "Scene", strSceneName, intExitCode)

                        Case Else

                            System.Console.WriteLine("X10ControllerName=" & strX10ControllerName)
                            System.Console.WriteLine("ScheduleName=" & strScheduleName)
                            System.Console.WriteLine("HouseCode=" & strHouseCode)
                            System.Console.WriteLine("ModuleCode=" & strModuleCode)
                            System.Console.WriteLine("Dimmer=" & strDimmer)
                            System.Console.WriteLine("OnOff=" & strOnOff)

                            System.Console.WriteLine("nsX10DbMethods.getX10DbSettings")
                            ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
                            strStatus = nsX10DbMethods.getX10DbSettings(strX10DbConnectionString, strX10DbProvider, objX10DbSetting)
                            If (strStatus = "") Then

                                System.Console.WriteLine("nsSunTimeMethods.getTimeZone")
                                ' nsSunTimeMethods.getTimeZone(ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone) As String
                                strStatus = nsSunTimeMethods.getTimeZone(objTimeZone)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsSunTimeMethods.SunTimes")
                                    ' nsSunTimeMethods.SunTimes(ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
                                    strStatus = nsSunTimeMethods.SunTimes(objTimeZone, CType(objX10DbSetting.latitude, Double), CType(objX10DbSetting.longitude, Double), strSunriseTime, strSunsetTime)
                                    If (strStatus = "") Then

                                        Select Case Microsoft.VisualBasic.UCase(strX10ControllerType)
                                            Case "CP290"
                                                System.Console.WriteLine("X10Manager(): X10ControllerType=CP290: Home Control Interface (RS232)")

                                                System.Console.WriteLine("Filename=" & strFilename)

                                                ' nsMainMethods.executeOperationX10CP290(ByVal strOperation As String, ByVal strFilename As String, ByVal strGuid As String, ByVal strScheduleName As String, ByVal strHouseCode As String, ByVal strModuleCode As String, ByVal strDimmer As String, ByVal strOnOff As String, ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strLighthouseParadoxFilesPath As String, ByVal strLighthouseParadoxConnectionString As String, ByVal strLighthouseParadoxProvider As String, ByVal strX10ControllerType As String, ByVal strX10ControllerName As String, ByRef intExitCode As Integer) As String
                                                strStatus = nsMainMethods.executeOperationX10CP290(strOperation, strFilename, strGuid, strScheduleName, strHouseCode, strModuleCode, strDimmer, strOnOff, objTimeZone, strSunriseTime, strSunsetTime, strX10DbConnectionString, strX10DbProvider, strLighthouseParadoxFilesPath, strLighthouseParadoxConnectionString, strLighthouseParadoxProvider, "CP290", strX10ControllerName, intExitCode)

                                            Case "CM15A"
                                                System.Console.WriteLine("X10Manager(): X10ControllerType=CM15A: Active Home Professional (USB)")

                                                System.Console.WriteLine("Filename=" & strFilename)
                                                System.Console.WriteLine("BrightenDim=" & strBrightenDim)
                                                System.Console.WriteLine("StandardExtended=" & strStandardExtended)
                                                System.Console.WriteLine("ExtendedData=" & strExtendedData)
                                                System.Console.WriteLine("ExtendedCommand=" & strExtendedCommand)
                                                System.Console.WriteLine("MemoryAddrLow=" & strMemoryAddrLow)
                                                System.Console.WriteLine("MemoryAddrHigh=" & strMemoryAddrHigh)

                                                ' nsMainMethods.executeOperationX10CM15A(ByVal strOperation As String, ByVal strFilename As String, ByVal strGuid As String, ByVal strScheduleName As String, ByVal strHouseCode As String, ByVal strModuleCode As String, ByVal strDimmer As String, ByVal strOnOff As String, ByVal strBrightenDim As String, ByVal strStandardExtended As String, ByVal strExtendedData As String, ByVal strExtendedCommand As String, ByVal strMemoryAddrLow As String, ByVal strMemoryAddrHigh As String, ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strX10ControllerType As String, ByVal strX10ControllerName As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting, ByRef intExitCode As Integer) As String
                                                strStatus = nsMainMethods.executeOperationX10CM15A(strOperation, strFilename, strGuid, strScheduleName, strHouseCode, strModuleCode, strDimmer, strOnOff, strBrightenDim, strStandardExtended, strExtendedData, strExtendedCommand, strMemoryAddrLow, strMemoryAddrHigh, objTimeZone, strSunriseTime, strSunsetTime, strX10DbConnectionString, strX10DbProvider, "CM15A", strX10ControllerName, objX10DbSetting, intExitCode)

                                            Case "WM100"
                                                System.Console.WriteLine("X10Manager(): X10ControllerType=WM100: WiFi Hub (WiFi)")

                                                ' nsMainMethods.executeOperationX10WM100(ByVal strOperation As String, ByVal strGuid As String, ByVal strScheduleName As String, ByVal strHouseCode As String, ByVal strModuleCode As String, ByVal strDimmer As String, ByVal strOnOff As String, ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strX10ControllerType As String, ByVal strX10ControllerName As String, ByRef intExitCode As Integer) As String
                                                strStatus = nsMainMethods.executeOperationX10WM100(strOperation, strGuid, strScheduleName, strHouseCode, strModuleCode, strDimmer, strOnOff, objTimeZone, strSunriseTime, strSunsetTime, strX10DbConnectionString, strX10DbProvider, "WM100", strX10ControllerName, intExitCode)

                                            Case Else
                                                System.Console.WriteLine("X10Manager(): Unknown X10ControllerType=""" & strX10ControllerType & """ or Operation=""" & strOperation & """")
                                                intExitCode = -1
                                        End Select

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsSunTimeMethods.SunTimes()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsSunTimeMethods.getTimeZone()

                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbSettings()

                    End Select

                Else
                    System.Console.WriteLine(strStatus)
                    intExitCode = -1
                End If ' END - nsParseCmdLineMethods.ParseCmdLine()

            Catch ex As Exception
                strError = "X10Manager(): Exception: " & ex.Message
                If (strStatus.Length = 0) Then
                    strStatus = strError
                Else
                    strStatus &= vbCRLF & strError
                End If
                System.Console.WriteLine(strError)
                intExitCode = -1
            Finally
                objX10DbController = Nothing
                objX10DbSetting = Nothing
            End Try

            dtmEndTimeDate = Microsoft.VisualBasic.FormatDateTime(System.DateTime.Now, vbGeneralDate)
            intDateTimeDiffSeconds = Microsoft.VisualBasic.DateDiff("s", dtmStartTimeDate, dtmEndTimeDate, vbSunday, vbFirstJan1)
            System.Console.WriteLine("X10Manager(" & CStr(intExitCode) & "): Completed at " & dtmEndTimeDate & ": Elapsed Time " & CStr(intDateTimeDiffSeconds \ 60) & " minutes " & CStr(intDateTimeDiffSeconds Mod 60) & " seconds.")

            ' Were there operational errors?
            ' If so send an email alert.
            If (intExitCode < 0 And nsConstVariables.MailErrorsFrom.Length > 5 And nsConstVariables.MailErrorsTo.Length > 5) Then

                ' nsMailToMethods.MailTo(ByVal dtmTodaysDate As Date, ByVal strFromEMailaddress As String, ByVal strToEMailaddress As String, ByVal strCCEMailAddress As String, ByVal strBCCEMailAddress As String, ByVal strSubject As String, ByVal strMessage As String, ByVal strAttachFile As String, ByVal strBodyType As String) As String
                strError = nsMailToMethods.MailTo(dtmEndTimeDate, nsConstVariables.MailErrorsFrom, nsConstVariables.MailErrorsTo, "", "", "X10Manager-" & strOperation & "-ERROR", "Command Line: " & Command$ & vbCRLF & " " & vbCRLF & strStatus, "", "TEXT")
                If (strError = "") Then
                    System.Console.WriteLine("X10Manager(): Email indicating failure was sent. ")
                Else
                    System.Console.WriteLine("X10Manager(): Problem Sending Email indicating failure: " & strError)
                End If

            End If

            System.Environment.ExitCode = CStr(intExitCode)

        End Sub ' End Main()
#End Region ' END Region - Main()

#Region "MainMethods"
        Public Class MainMethods

            '=====================================================================================
            ' Function sendUnitCommands()
            ' Alan Wagner
            '
            ' strOperation
            '  AllLightsOn | AllLightsOff | AllUnitsOn | AllUnitsOff | Scene
            '
            Public Function sendUnitCommands(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strOperation As String, ByVal strSceneName As String, ByRef intExitCode As Integer) As String
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
                Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
                Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

                Dim strStatus As String = ""
                Dim strError As String = ""
                Dim intX10Status As Integer = 0

                Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

                Dim objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene = Nothing
                Dim intSceneID As Integer = -1
                Dim objX10DbCompiledUnitCommands As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10DbCompiledUnitCommand) = Nothing
                Dim objX10DbCompiledUnitCommand As TrekkerPhotoArt.X10Include.X10DbCompiledUnitCommand = Nothing
                Dim strStandardExtended As String = ""

                Dim objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload) = Nothing
                Dim objX10CP290CommandUpload As TrekkerPhotoArt.X10Include.X10CP290CommandUpload = Nothing

                Dim objSendUnitCommandSceneClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendUnitCommandSceneClass = Nothing
                Dim objSendAddressCommandPowerLineClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendAddressCommandPowerLineClass = Nothing
                Dim objSendFunctionCommandPowerLineClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendFunctionCommandPowerLineClass = Nothing
                Dim objX10ExtendedCommand As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.x10ExtendedCommand = Nothing

                Try

                    If (strOperation.ToUpper() = "SCENE") Then

                        System.Console.WriteLine("nsX10DbMethods.getX10DbScene")
                        ' nsX10DbMethods.getX10DbScene(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSceneName As String, ByRef objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene) As String
                        strStatus = nsX10DbMethods.getX10DbScene(strX10DbConnectionString, strX10DbProvider, strSceneName, objX10DbScene)
                        If (strStatus = "") Then

                            If (objX10DbScene Is Nothing) Then
                                strStatus = "sendUnitCommands(): Operation """ & strOperation & """: getX10DbScene(): Scene named """ & strSceneName & """ not found in X10Db."
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            Else
                                System.Console.WriteLine("  Scene Name: " & objX10DbScene.SceneName)
                                intSceneID = objX10DbScene.SceneID
                            End If
                        Else
                            System.Console.WriteLine(strStatus)
                            intExitCode = -1
                        End If ' END - nsX10DbMethods.getX10DbScene()

                    End If

                    If (intExitCode = 0) Then

                        System.Console.WriteLine("nsX10DbMethods.compileUnitCommandsFromX10Db(" & strOperation & ")")
                        ' strOperation
                        '  AllLightsOn | AllLightsOff | AllUnitsOn | AllUnitsOff | Scene
                        ' nsX10DbMethods.compileUnitCommandsFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strOperation As String, ByVal intSceneID As Integer, ByRef objX10DbCompiledUnitCommands As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10DbCompiledUnitCommand)) As String
                        strStatus = nsX10DbMethods.compileUnitCommandsFromX10Db(strX10DbConnectionString, strX10DbProvider, strOperation, intSceneID, objX10DbCompiledUnitCommands)
                        If (strStatus = "") Then

                            If (Not objX10DbCompiledUnitCommands Is Nothing AndAlso objX10DbCompiledUnitCommands.Count > 0) Then

                                For Each objX10DbCompiledUnitCommand In objX10DbCompiledUnitCommands

                                    objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController
                                    objX10DbController = objX10DbCompiledUnitCommand.objX10DbController

                                    Select Case objX10DbController.ControllerType.ToUpper()
                                        Case "CP290"

                                            System.Console.WriteLine("nsX10CP290Methods.sendUnitCommand")
                                            ' nsX10CP290Methods.sendUnitCommand(ByVal strPortName As String, ByVal strUnitHouseCode As String, ByVal strUnitModuleCodes As String, ByVal strDimmer As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer, ByRef intX10Status As Integer, ByRef objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload)) As String
                                            strError = nsX10CP290Methods.sendUnitCommand(objX10DbController.Port, objX10DbCompiledUnitCommand.strUnitHouseCode, objX10DbCompiledUnitCommand.strUnitModuleCodes, objX10DbCompiledUnitCommand.strDimmer, objX10DbCompiledUnitCommand.intUnitOnOff, objX10DbCompiledUnitCommand.intUnitLevel, intX10Status, objX10CP290CommandUploads)
                                            If (strError = "") Then

                                                System.Console.WriteLine("  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]")
                                                System.Console.WriteLine("    UnitHouseCode: " & objX10DbCompiledUnitCommand.strUnitHouseCode)
                                                System.Console.WriteLine("    UnitModuleCodes: " & objX10DbCompiledUnitCommand.strUnitModuleCodes)

                                                Select Case objX10DbCompiledUnitCommand.strDimmer.ToUpper()
                                                    Case "Y"
                                                        System.Console.WriteLine("    Set Dimmer to " & objX10DbCompiledUnitCommand.strOnOff)
                                                    Case "N"
                                                        System.Console.WriteLine("    Set Switch to " & objX10DbCompiledUnitCommand.strOnOff)
                                                End Select

                                                If (Not objX10CP290CommandUploads Is Nothing AndAlso objX10CP290CommandUploads.Count > 0) Then

                                                    For Each objX10CP290CommandUpload In objX10CP290CommandUploads

                                                        System.Console.WriteLine("    CommandUpload[" & objX10CP290CommandUpload.CommandUploadID.ToString() & "]:")
                                                        System.Console.WriteLine("      Function=" & objX10CP290CommandUpload.strFunction)
                                                        System.Console.WriteLine("      Housecode=" & objX10CP290CommandUpload.strHousecode)
                                                        System.Console.WriteLine("      X10UnitCodes18=" & objX10CP290CommandUpload.strX10UnitCodes18)
                                                        System.Console.WriteLine("      X10UnitCodes916=" & objX10CP290CommandUpload.strX10UnitCodes916)
                                                        System.Console.WriteLine("      BaseHousecode=" & objX10CP290CommandUpload.strBaseHousecode)
                                                        System.Console.WriteLine("      X10Status=" & objX10CP290CommandUpload.strX10Status)

                                                    Next

                                                End If

                                                System.Console.WriteLine("    Controller Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status))

                                            Else
                                                strStatus = "Problem sending Command to Module:" & vbCrLf & "Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]" & vbCrLf & strError
                                                System.Console.WriteLine(strStatus)
                                                intExitCode = -1
                                                Exit For
                                            End If ' END - nsX10CP290Methods.sendUnitCommand()

                                        Case "CM15A"

                                            Select Case objX10DbCompiledUnitCommand.intSendUnitExtendedCommand
                                                Case 0
                                                    strStandardExtended = "S"
                                                Case 1
                                                    strStandardExtended = "E"
                                            End Select

                                            System.Console.WriteLine("nsX10CM15AMethods.sendUnitCommand")
                                            ' sendUnitCommandSceneClass sendUnitCommandScene(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strX10DbConnectionString, string strX10DbProvider, string strStandardExtended, string strUnitHouseCodeLetter, string strUnitModuleCodes, string strUnitDimmerYN, int intUnitOnOff, int intUnitLevel, byte bytExtendedData, byte bytExtendedCommand)
                                            objSendUnitCommandSceneClass = nsX10CM15AMethods.sendUnitCommandScene(objX10DbController, objX10DbCompiledUnitCommand.objX10DbUSBPort, strX10DbConnectionString, strX10DbProvider, strStandardExtended, objX10DbCompiledUnitCommand.strUnitHouseCode, objX10DbCompiledUnitCommand.strUnitModuleCodes, objX10DbCompiledUnitCommand.strDimmer, objX10DbCompiledUnitCommand.intUnitOnOff, objX10DbCompiledUnitCommand.intUnitLevel, objX10DbCompiledUnitCommand.bytExtendedData, objX10DbCompiledUnitCommand.bytExtendedCommand)
                                            If (objSendUnitCommandSceneClass.status = "") Then

                                                System.Console.WriteLine("  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]")
                                                System.Console.WriteLine("    UnitHouseCode: " & objSendUnitCommandSceneClass.unitHouseCodeLetter)
                                                System.Console.WriteLine("    UnitModuleCodes: " & objSendUnitCommandSceneClass.unitModuleCodes)

                                                Select Case strStandardExtended.ToUpper()
                                                    Case "S"
                                                        System.Console.WriteLine("    Standard Powerline Command:")
                                                        Select Case objX10DbCompiledUnitCommand.strDimmer.ToUpper()
                                                            Case "Y"
                                                                System.Console.WriteLine("      Set Dimmer to " & objX10DbCompiledUnitCommand.strOnOff)

                                                                Select Case objX10DbCompiledUnitCommand.intUnitOnOff
                                                                    Case 0
                                                                        System.Console.WriteLine("      Unit On/Off: Off")
                                                                    Case 1
                                                                        System.Console.WriteLine("      Unit On/Off: On")
                                                                End Select

                                                                System.Console.WriteLine("      Dimmer Level: " & objX10DbCompiledUnitCommand.intUnitLevel.ToString())
                                                            Case "N"
                                                                System.Console.WriteLine("      Set Switch to " & objX10DbCompiledUnitCommand.strOnOff)

                                                                Select Case objX10DbCompiledUnitCommand.intUnitOnOff
                                                                    Case 0
                                                                        System.Console.WriteLine("      Unit On/Off: Off")
                                                                    Case 1
                                                                        System.Console.WriteLine("      Unit On/Off: On")
                                                                End Select

                                                        End Select
                                                    Case "E"
                                                        ' x10ExtendedCommand getX10ExtendedCommandFromCode(byte byteCommandCode)
                                                        objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(objX10DbCompiledUnitCommand.bytExtendedCommand)

                                                        System.Console.WriteLine("    Extended Powerline Command:")
                                                        System.Console.WriteLine("    ExtendedCommand=0x" & objX10DbCompiledUnitCommand.bytExtendedCommand.ToString("X02").ToLower())
                                                        System.Console.WriteLine("    Extended Command Description: " & objX10ExtendedCommand.commandDescription)
                                                        System.Console.WriteLine("    ExtendedData=0x" & objX10DbCompiledUnitCommand.bytExtendedData.ToString("X02").ToLower())
                                                End Select

                                                If (objSendUnitCommandSceneClass.objSendAddressCommandPowerLineClasses.Count > 0) Then

                                                    For Each objSendAddressCommandPowerLineClass In objSendUnitCommandSceneClass.objSendAddressCommandPowerLineClasses
                                                        If (objSendAddressCommandPowerLineClass.retryReason <> "") Then
                                                            System.Console.WriteLine("    sendAddressCommandPowerLineClass " & nsX10CM15AMethods.x10BinaryValueToHouseCode(objSendAddressCommandPowerLineClass.unitHouseCode) & nsX10CM15AMethods.x10BinaryValueToDeviceCode(objSendAddressCommandPowerLineClass.unitModuleCode) & ":")
                                                            System.Console.WriteLine("      retryReason: " & objSendAddressCommandPowerLineClass.retryReason)
                                                        End If
                                                    Next

                                                    If (objSendUnitCommandSceneClass.objSendFunctionCommandPowerLineClasses.Count > 0) Then
                                                        For Each objSendFunctionCommandPowerLineClass In objSendUnitCommandSceneClass.objSendFunctionCommandPowerLineClasses
                                                            System.Console.WriteLine("    sendFunctionCommandPowerLine: ")
                                                            System.Console.WriteLine("      newUnitLastCommand: " & objSendFunctionCommandPowerLineClass.newUnitLastCommand)
                                                            System.Console.WriteLine("      newUnitLastBrightDimAmount: " & objSendFunctionCommandPowerLineClass.newUnitLastBrightDimAmount.ToString())
                                                            If (objSendFunctionCommandPowerLineClass.retryReason <> "") Then
                                                                System.Console.WriteLine("      retryReason:" & objSendFunctionCommandPowerLineClass.retryReason)
                                                            End If
                                                        Next
                                                    End If

                                                End If ' END - ObjectSendAddressCommandPowerLineClassesCount

                                            Else
                                                strStatus = "sendUnitCommands(): Problem sending Command to Module:" & vbCrLf & "Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]" & vbCrLf & objSendUnitCommandSceneClass.status
                                                System.Console.WriteLine(strStatus)
                                                intExitCode = -1
                                                Exit For
                                            End If ' END - nsX10CM15AMethods.sendUnitCommand()

                                        Case "WM100"


                                        Case Else
                                            strStatus = "sendUnitCommands(): Missing or Unknown Controller Model """ & objX10DbController.ControllerType & """."
                                            System.Console.WriteLine(strStatus)
                                            intExitCode = -1
                                            Exit For
                                    End Select

                                    objX10DbController = Nothing
                                Next ' END - ForEachX10DbCompiledUnitCommand

                                If (strStatus = "") Then
                                    System.Console.WriteLine("sendUnitCommands(): Success")
                                End If

                            Else
                                strStatus = "sendUnitCommands(): compileUnitCommandsFromX10Db(): No Compiled Units were returned for Operation """ & strOperation & """."
                                If (strOperation.ToUpper() = "SCENE") Then
                                    strStatus &= vbCrLf & "Are any Controllers for Modules in Scene """ & strSceneName & """ set to Active?"
                                End If
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If

                        Else
                            System.Console.WriteLine(strStatus)
                            intExitCode = -1
                        End If ' END - nsX10DbMethods.compileUnitCommandsFromX10Db()

                    End If ' END - ExitCode

                Catch ex As Exception
                    strError = "sendUnitCommands(): Exception: Operation """ & strOperation & """: " & ex.Message.ToString()
                    If (strStatus.Length = 0) Then
                        strStatus = strError
                    Else
                        strStatus &= vbCRLF & strError
                    End If
                    System.Console.WriteLine(strError)
                    intExitCode = -1
                Finally
                    objX10DbScene = Nothing
                    objX10ExtendedCommand = Nothing
                    objSendFunctionCommandPowerLineClass = Nothing
                    objSendAddressCommandPowerLineClass = Nothing
                    objX10DbCompiledUnitCommand = Nothing
                    objX10CP290CommandUploads = Nothing
                    objX10CP290CommandUpload = Nothing
                    objSendUnitCommandSceneClass = Nothing
                    objX10DbController = Nothing
                End Try

                Return strStatus

            End Function ' END - sendUnitCommands()

            '=====================================================================================
            ' Function importModulesToX10Db()
            ' Alan Wagner
            '
            ' Header Row:
            ' "ControllerName","UnitCode","UnitName","UnitDescription","UnitEnabledYN","UnitDimmerYN","UnitLightingYN","UnitExtendedCommandsYN"
            '
            ' Example Record Rows:
            ' "House Lighting CP290","J1","OutGar","Outside Garage Lights","Y","N","Y","N"
            ' "Test CP290","J16","Den Test Dimmer Module","Dimmer LED Test Light in Dimmer Module","Y","Y","Y","N"
            '
            Public Function importModulesToX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByVal strFilename As String, ByRef intExitCode As Integer) As String
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

                Dim strStatus As String = ""
                Dim strError As String = ""

                Dim intRecordCount As Integer = 0
                Dim intModulesAddedCount As Integer = 0
                Dim intModulesUpdatedCount As Integer = 0
                Dim strModulesAddedList As String = ""
                Dim strModulesUpdatedList As String = ""

                Try

                    System.Console.WriteLine("importModulesToX10Db(): Verifying Import file """ & strFilename & """")
                    System.Console.WriteLine("nsX10DbMethods.importModulesFromCSVFileToX10db(Verify):")
                    ' nsX10DbMethods.importModulesFromCSVFileToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByVal strFilename As String, ByVal bVerifyOnly As Boolean, ByRef intRecordCount As Integer, ByRef intModulesAddedCount As Integer, ByRef intModulesUpdatedCount As Integer, ByRef strModulesAddedList As String, ByRef strModulesUpdatedList As String) As String
                    strError = nsX10DbMethods.importModulesFromCSVFileToX10db(strConnectionString, strProvider, strGuid, strFilename, True, intRecordCount, intModulesAddedCount, intModulesUpdatedCount, strModulesAddedList, strModulesUpdatedList)
                    If (strError = "") Then

                        System.Console.WriteLine("importModulesToX10Db(): Successful Verify:")

                        System.Console.WriteLine(" RecordCount=" & intRecordCount.ToString())
                        System.Console.WriteLine(" ModulesToBeAddedCount=" & intModulesAddedCount.ToString())
                        If (strModulesAddedList.Length() > 0) Then
                            System.Console.WriteLine(strModulesAddedList)
                        End If
                        System.Console.WriteLine(" ModulesToBeUpdatedCount=" & intModulesUpdatedCount.ToString())
                        If (strModulesUpdatedList.Length() > 0) Then
                            System.Console.WriteLine(strModulesUpdatedList)
                        End If

                        System.Console.WriteLine("importModulesToX10Db(): Importing file """ & strFilename & """")
                        System.Console.WriteLine("nsX10DbMethods.importModulesFromCSVFileToX10db(Import):")
                        ' nsX10DbMethods.importModulesFromCSVFileToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByVal strFilename As String, ByVal bVerifyOnly As Boolean, ByRef intRecordCount As Integer, ByRef intModulesAddedCount As Integer, ByRef intModulesUpdatedCount As Integer, ByRef strModulesAddedList As String, ByRef strModulesUpdatedList As String) As String
                        strError = nsX10DbMethods.importModulesFromCSVFileToX10db(strConnectionString, strProvider, strGuid, strFilename, False, intRecordCount, intModulesAddedCount, intModulesUpdatedCount, strModulesAddedList, strModulesUpdatedList)
                        If (strError = "") Then

                            System.Console.WriteLine("importModulesToX10Db(): Successful Import:")

                            System.Console.WriteLine(" RecordCount=" & intRecordCount.ToString())
                            System.Console.WriteLine(" ModulesAddedCount=" & intModulesAddedCount.ToString())
                            If (strModulesAddedList.Length() > 0) Then
                                System.Console.WriteLine(strModulesAddedList)
                            End If
                            System.Console.WriteLine(" ModulesUpdatedCount=" & intModulesUpdatedCount.ToString())
                            If (strModulesUpdatedList.Length() > 0) Then
                                System.Console.WriteLine(strModulesUpdatedList)
                            End If

                        Else
                            strStatus = "importModulesToX10Db(): Problem with Import: " & strError
                            System.Console.WriteLine(strStatus)
                            intExitCode = -1
                        End If ' END - nsX10DbMethods.importModulesFromCSVFileToX10db(Import)

                    Else
                        strStatus = "importModulesToX10Db(): Problem with Verify: " & strError
                        System.Console.WriteLine(strStatus)
                        intExitCode = -1
                    End If ' END - nsX10DbMethods.importModulesFromCSVFileToX10db(Verify)

                Catch ex As Exception
                    strError = "importModulesToX10Db(): Exception: Filename=""" & strFilename & """: " & ex.Message.ToString()
                    If (strStatus.Length = 0) Then
                        strStatus = strError
                    Else
                        strStatus &= vbCRLF & strError
                    End If
                    System.Console.WriteLine(strError)
                    intExitCode = -1
                End Try

                Return strStatus

            End Function ' END - importModulesToX10Db()

            '=====================================================================================
            ' Function exportModulesFromX10Db()
            ' Alan Wagner
            '
            ' Header Row:
            ' "ControllerName","UnitCode","UnitName","UnitDescription","UnitEnabledYN","UnitDimmerYN","UnitLightingYN","UnitExtendedCommandsYN"
            '
            ' Example Record Rows:
            ' "House Lighting CP290","J1","OutGar","Outside Garage Lights","Y","N","Y","N"
            ' "Test CP290","J16","Den Test Dimmer Module","Dimmer LED Test Light in Dimmer Module","Y","Y","Y","N"
            '
            Public Function exportModulesFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByRef intExitCode As Integer) As String
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

                Dim strStatus As String = ""
                Dim strError As String = ""

                Dim intRecordCount As Integer = 0

                Try

                    System.Console.WriteLine("exportModulesFromX10Db(): Exporting to file """ & strFilename & """")
                    System.Console.WriteLine("nsX10DbMethods.exportModulesFromX10dbToCSVFile():")
                    ' nsX10DbMethods.exportModulesFromX10dbToCSVFile(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByRef intRecordCount As Integer) As String
                    strError = nsX10DbMethods.exportModulesFromX10dbToCSVFile(strConnectionString, strProvider, strFilename, intRecordCount)
                    If (strError = "") Then

                        System.Console.WriteLine("exportModulesFromX10Db(): Successful Export:")

                        System.Console.WriteLine(" RecordCount=" & intRecordCount.ToString())

                    Else
                        strStatus = "exportModulesFromX10Db(): Problem with Export: " & strError
                        System.Console.WriteLine(strStatus)
                        intExitCode = -1
                    End If ' END - nsX10DbMethods.exportModulesFromX10dbToCSVFile()

                Catch ex As Exception
                    strError = "exportModulesFromX10Db(): Exception: Filename=""" & strFilename & """: " & ex.Message.ToString()
                    If (strStatus.Length = 0) Then
                        strStatus = strError
                    Else
                        strStatus &= vbCRLF & strError
                    End If
                    System.Console.WriteLine(strError)
                    intExitCode = -1
                End Try

                Return strStatus

            End Function ' END - exportModulesFromX10Db()

            '=====================================================================================
            ' Function downloadEventsToActiveControllers()
            ' Alan Wagner
            '
            Public Function downloadEventsToActiveControllers(ByVal strConnectionString As String, ByVal strProvider As String) As String
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

                Dim strStatus As String = ""
                Dim strError As String = ""
                Dim strTryStep As String = ""
                Dim bAllOK As Boolean = True

                Dim objFactory As System.Data.Common.DbProviderFactory = Nothing
                Dim sqlString As String = ""

                Dim objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting = Nothing
                Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

                Dim bPutX10DbSunTimes As Boolean = True

                Try

                    strTryStep = "nsX10DbMethods.getX10DbSettings"
                    ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
                    strError = nsX10DbMethods.getX10DbSettings(strConnectionString, strProvider, objX10DbSetting)
                    If (strError = "") Then

                        strTryStep = "GetFactory"
                        objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

                        strTryStep = "CreateConnection"
                        Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                            strTryStep = "ConnectionString"
                            objDbConnection.ConnectionString = strConnectionString

                            strTryStep = "Connection.Open"
                            objDbConnection.Open()

                            strTryStep = "CreateCommand"
                            Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                                strTryStep = "sqlStringControllerID"
                                sqlString = "SELECT Controllers.ControllerID,Controllers.ControllerName,Controllers.ControllerTypeID,ControllerTypes.ControllerType,ControllerTypes.ControllerType,ControllerTypes.ControllerExtendedCommands,ControllerTypes.ControllerMacros,Controllers.ControllerDescription,Controllers.ControllerActive,Controllers.HouseCode,Controllers.TransceiverHouseCodes,Controllers.Port,Controllers.Hub,Controllers.AppKey,Controllers.UID,Controllers.DuskDawnResolution " &
                                    "FROM Controllers INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID " &
                                    "WHERE Controllers.ControllerActive=1 " &
                                    "ORDER BY Controllers.ControllerName, ControllerTypes.ControllerType ASC;"

                                strTryStep = "CommandText"
                                objDbCommand.CommandText = sqlString

                                strTryStep = "CommandTimeout"
                                objDbCommand.CommandTimeout = 30 ' Seconds

                                strTryStep = "CommandType"
                                ' Text              - An SQL text command (default).
                                ' StoredProcedure   - To call a stored procedure.
                                ' TableDirect       - All rows and columns of the named table or tables will be returned.
                                objDbCommand.CommandType() = CommandType.Text

                                strTryStep = "ExecuteReader"
                                Using objDbDataReader As System.Data.Common.DbDataReader = objDbCommand.ExecuteReader(System.Data.CommandBehavior.Default)

                                    strTryStep = "HasRows"
                                    If objDbDataReader.HasRows() Then

                                        strTryStep = "Read"
                                        While (objDbDataReader.Read() And bAllOK)

                                            strTryStep = "NewX10DbControllerObject"
                                            objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                                            objX10DbController.ControllerID = CType(objDbDataReader("ControllerID"), Integer)

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("ControllerName"))) Then
                                                objX10DbController.ControllerName = ""
                                            Else
                                                objX10DbController.ControllerName = objDbDataReader("ControllerName").ToString()
                                            End If

                                            objX10DbController.ControllerTypeID = CType(objDbDataReader("ControllerTypeID"), Integer)

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("ControllerType"))) Then
                                                objX10DbController.ControllerType = ""
                                            Else
                                                objX10DbController.ControllerType = objDbDataReader("ControllerType").ToString()
                                            End If

                                            ' 0 - Controller accepts Standard tranmission Function Commands only, 1 - Controller can also accept Extended transmission Function Commands
                                            objX10DbController.ControllerExtendedCommands = CType(objDbDataReader("ControllerExtendedCommands"), Integer)

                                            ' 0 - Controller does not support Macros, 1 - Controller does support Macros
                                            objX10DbController.ControllerMacros = CType(objDbDataReader("ControllerMacros"), Integer)

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("ControllerDescription"))) Then
                                                objX10DbController.ControllerDescription = ""
                                            Else
                                                objX10DbController.ControllerDescription = objDbDataReader("ControllerDescription").ToString()
                                            End If

                                            objX10DbController.ControllerActive = CType(objDbDataReader("ControllerActive"), Integer)

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("HouseCode"))) Then
                                                objX10DbController.HouseCode = ""
                                            Else
                                                objX10DbController.HouseCode = objDbDataReader("HouseCode").ToString()
                                            End If

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("TransceiverHouseCodes"))) Then
                                                objX10DbController.TransceiverHouseCodes = ""

                                                objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                                                objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                                                objX10DbController.TransceiverHouseCodeMap.byte2 = 0

                                            Else
                                                objX10DbController.TransceiverHouseCodes = objDbDataReader("TransceiverHouseCodes").ToString()
                                                objX10DbController.TransceiverHouseCodeMap = nsX10DbMethods.x10HouseCodesToHouseCodeMap(objX10DbController.TransceiverHouseCodes)
                                            End If

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("Port"))) Then
                                                objX10DbController.Port = ""
                                            Else
                                                objX10DbController.Port = objDbDataReader("Port").ToString()
                                            End If

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("Hub"))) Then
                                                objX10DbController.Hub = ""
                                            Else
                                                objX10DbController.Hub = objDbDataReader("Hub").ToString()
                                            End If

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("AppKey"))) Then
                                                objX10DbController.AppKey = ""
                                            Else
                                                objX10DbController.AppKey = objDbDataReader("AppKey").ToString()
                                            End If

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("UID"))) Then
                                                objX10DbController.UID = ""
                                            Else
                                                objX10DbController.UID = objDbDataReader("UID").ToString()
                                            End If

                                            objX10DbController.DuskDawnResolution = CType(objDbDataReader("DuskDawnResolution"), Byte)

                                            strTryStep = "downloadEventsToController"
                                            ' downloadEventsToController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strBackupDirectoryPath As String, ByVal bPutX10DbSunTimes As Boolean, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                                            strError = downloadEventsToController(strConnectionString, strProvider, objX10DbSetting.backupDirectoryPath, bPutX10DbSunTimes, CType(objX10DbSetting.latitude, Double), CType(objX10DbSetting.longitude, Double), objX10DbController)
                                            If (strError = "") Then

                                                ' Only need to do this once.
                                                bPutX10DbSunTimes = False

                                            Else
                                                strStatus = "downloadEventsToActiveControllers(): " & strError
                                                bAllOK = False
                                            End If ' END - downloadEventsToController()

                                            objX10DbController = Nothing
                                        End While ' END - Read

                                    Else
                                        strStatus = "downloadEventsToActiveControllers(): No Active Controllers were found in X10Db."
                                    End If ' END - HasRows

                                    strTryStep = "DbDataReader.Close"
                                    objDbDataReader.Close()

                                End Using 'END - ExecuteReader

                            End Using ' END - CreateCommand

                            strTryStep = "Connection.Close"
                            objDbConnection.Close()

                        End Using ' END - CreateConnection

                    Else
                        strStatus = "downloadEventsToActiveControllers(): " & strError
                    End If ' END - nsX10DbMethods.getX10DbSettings()

                Catch ex As Exception
                    If (strStatus = "") Then
                        strStatus = "downloadEventsToActiveControllers(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & sqlString
                    Else
                        strStatus &= vbCrLf & "downloadEventsToActiveControllers(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & sqlString
                    End If
                Finally
                    objX10DbController = Nothing
                    objX10DbSetting = Nothing
                    objFactory = Nothing
                End Try

                Return strStatus

            End Function ' END - downloadEventsToActiveControllers()

            '=====================================================================================
            ' Function downloadEventsToController()
            ' Alan Wagner
            '
            Private Function downloadEventsToController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strBackupDirectoryPath As String, ByVal bPutX10DbSunTimes As Boolean, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
                Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
                Dim nsSunTimeMethods As New TrekkerPhotoArt.X10Include.SunTimeMethods
                Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
                Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
                Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

                Dim strStatus As String = ""
                Dim strError As String = ""
                Dim strTryStep As String = ""

                Dim sqlString As String = ""
                Dim intRowsAffected As Integer = -1

                Dim intHousecode As Integer = -1

                Dim intX10Status As Integer = -1
                Dim intMINUTES As Integer = -1
                Dim intHOURS As Integer = -1
                Dim intHourAMPM As Integer = -1
                Dim strAMPM As String = ""
                Dim intBday As Integer = -1
                Dim intHC As Integer = -1

                Dim objDateTimeNow As System.DateTime = System.DateTime.Now()

                Dim objTimeZone As TrekkerPhotoArt.X10Include.TimeZone = Nothing
                Dim strSunriseTime As String = ""
                Dim strSunsetTime As String = ""

                Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing
                Dim objSetX10TimeClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.setX10TimeClass = Nothing
                Dim objPutX10TransceiverSetupClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putX10TransceiverSetupClass = Nothing
                Dim bClearTransceiverSetup As Boolean = False
                Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
                Dim objPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putToX10MemoryClass = Nothing
                Dim objVerifyPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.verifyPutToX10MemoryClass = Nothing
                Dim strMemoryOutputFilename As String = ""

                Dim objDayOfYearDate As System.DateTime = System.DateTime.MinValue

                Dim intTimersCompiled As Integer = 0
                Dim intX10DbTimersCount As Integer = 0
                Dim intX10TimerCount As Integer = 0
                Dim intTimerMatchedCount As Integer = 0

                Try

                    System.Console.WriteLine("downloadEventsToController(): Start download to Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]")

                    strTryStep = "bPutX10DbSunTimes"
                    If bPutX10DbSunTimes Then

                        strTryStep = "nsSunTimeMethods.getTimeZone"
                        ' nsSunTimeMethods.getTimeZone(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone) As String
                        strError = nsSunTimeMethods.getTimeZone(objTimeZone)
                        If (strError = "") Then

                            strTryStep = "nsX10DbMethods.putX10DbSunTimes"
                            ' nsSunTimeMethods.SunTimes(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
                            strError = nsSunTimeMethods.SunTimes(objTimeZone, dblLatitude, dblLongitude, strSunriseTime, strSunsetTime)
                            If (strError = "") Then

                                System.Console.WriteLine("downloadEventsToController(): Put X10Db Sun Times:" & vbCrLf & "  SunriseTime=" & strSunriseTime & " SunsetTime=" & strSunsetTime)

                                strTryStep = "nsX10DbMethods.putX10DbSunTimes"
                                ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                strError = nsX10DbMethods.putX10DbSunTimes(strConnectionString, strProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                If (strError <> "") Then
                                    strStatus = "downloadEventsToController(): " & strError
                                End If ' END - nsX10DbMethods.putX10DbSunTimes()

                            Else
                                strStatus = "downloadEventsToController(): " & strError
                            End If ' END - nsSunTimeMethods.SunTimes()

                        Else
                            strStatus = "downloadEventsToController(): " & strError
                        End If ' END - nsSunTimeMethods.getTimeZone()

                    End If ' END - bPutX10DbSunTimes

                    strTryStep = "StatusOK"
                    If (strStatus = "") Then

                        strTryStep = "ControllerActive"
                        If (objX10DbController.ControllerActive = 1) Then

                            System.Console.WriteLine("downloadEventsToController(): Compile " & objX10DbController.ControllerType.ToUpper() & " Timers from X10Db Events, place in X10Db.")

                            strTryStep = "nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db"
                            ' nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal intLimitToControllerID As Integer, ByRef intTimersCompiled As Integer) As String
                            strError = nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(strConnectionString, strProvider, objX10DbController.ControllerID, intTimersCompiled)
                            If (strError = "") Then

                                strTryStep = "TimersCompiled"
                                If (intTimersCompiled > 0) Then

                                    System.Console.WriteLine("  " & intTimersCompiled.ToString() & " Timers Compiled from Active Schedules and their Events.")

                                    strTryStep = "ControllerType"
                                    Select Case objX10DbController.ControllerType.ToUpper()
                                        Case "CP290"

                                            System.Console.WriteLine("downloadEventsToController(): Update to X10 Db Controllers table:")
                                            System.Console.WriteLine("  Base House Code: " & objX10DbController.HouseCode)

                                            strTryStep = "CP290_nsX10DbMethods.executeNonQueryX10db"
                                            sqlString = "UPDATE Controllers SET HouseCode='" & objX10DbController.HouseCode & "',TransceiverHouseCodes='',DuskDawnResolution=0 WHERE ControllerID=" & objX10DbController.ControllerID.ToString() & ";"
                                            ' nsX10DbMethods.executeNonQueryX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal sqlString As String, ByRef intRowsAffected As Integer) As String
                                            strError = nsX10DbMethods.executeNonQueryX10db(strConnectionString, strProvider, sqlString, intRowsAffected)
                                            If (strError = "" And intRowsAffected > 0) Then

                                                strTryStep = "CP290_nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble"
                                                ' nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(ByVal strHouseCode As String, ByRef intHousecode As Integer) As String
                                                strError = nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(objX10DbController.HouseCode, intHousecode)
                                                If (strError = "") Then

                                                    System.Console.WriteLine("downloadEventsToController(): Download X10 Base Housecode")

                                                    strTryStep = "CP290_nsX10CP290Methods.downloadX10BaseHousecode"
                                                    ' nsX10CP290Methods.downloadX10BaseHousecode(ByVal strPortName As String, ByVal intHousecode As Integer) As String
                                                    strError = nsX10CP290Methods.downloadX10BaseHousecode(objX10DbController.Port, intHousecode)
                                                    If (strError = "") Then

                                                        System.Console.WriteLine("downloadEventsToController(): Set CP290 Clock to: " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & " " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") ")

                                                        strTryStep = "CP290_nsX10CP290Methods.setX10Time"
                                                        ' nsX10CP290Methods.setX10Time(ByVal strPortName As String, ByVal dtmNow As System.DateTime, ByRef intgX10Status As Integer, ByRef intgMINUTES As Integer, ByRef intgHOURS As Integer, ByRef intgBday As Integer, ByRef intgHC As Integer) As String
                                                        strError = nsX10CP290Methods.setX10Time(objX10DbController.Port, objDateTimeNow, intX10Status, intMINUTES, intHOURS, intBday, intHC)
                                                        If (strError = "") Then

                                                            If (intHOURS = 12) Then
                                                                ' PM
                                                                strAMPM = "PM"
                                                                intHourAMPM = intHOURS
                                                            ElseIf (intHOURS > 12) Then
                                                                ' PM
                                                                strAMPM = "PM"
                                                                intHourAMPM = intHOURS - 12
                                                            ElseIf (intHOURS = 0) Then
                                                                ' AM
                                                                strAMPM = "AM"
                                                                intHourAMPM = 12
                                                            Else
                                                                ' AM
                                                                strAMPM = "AM"
                                                                intHourAMPM = intHOURS
                                                            End If

                                                            System.Console.WriteLine("  Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status))
                                                            System.Console.WriteLine("  Time: " & nsX10DbMethods.DayCodeToStringOfFullDays(intBday) & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString, 2) & " " & strAMPM)
                                                            System.Console.WriteLine("  Base House Code: " & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHC))

                                                            System.Console.WriteLine("downloadEventsToController(): Get X10Db Timers Put X10.")

                                                            strTryStep = "CP290_nsX10CP290Methods.getX10DbTimersPutX10"
                                                            ' Note: nsX10CP290Methods.getX10DbTimersPutX10() calls nsX10CP290Methods.downloadX10BaseHousecode()
                                                            ' nsX10CP290Methods.getX10DbTimersPutX10(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intX10DbTimersCount As Integer) As String
                                                            strError = nsX10CP290Methods.getX10DbTimersPutX10(strConnectionString, strProvider, "", -1, intHousecode, objX10DbController, intX10DbTimersCount)
                                                            If (strError = "") Then

                                                                System.Console.WriteLine("  " & intX10DbTimersCount.ToString() & " Timers downladed from X10db to Controller.")
                                                                System.Console.WriteLine("downloadEventsToController(): Compare X10 Timers To X10Db.")

                                                                strTryStep = "CP290_nsX10CP290Methods.compareX10TimersToX10Db"
                                                                ' nsX10CP290Methods.compareX10TimersToX10Db(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef intX10TimerCount As Integer, ByRef intTimerMatchedCount As Integer) As String
                                                                strError = nsX10CP290Methods.compareX10TimersToX10Db(objX10DbController, strConnectionString, strProvider, "", -1, intX10TimerCount, intTimerMatchedCount)
                                                                If (strError = "") Then

                                                                    strTryStep = "TimerMatchedCount"
                                                                    If (intX10TimerCount = intTimerMatchedCount) Then
                                                                        System.Console.WriteLine("  Out of " & intX10TimerCount.ToString() & " Timers read from X10 Controller,")
                                                                        System.Console.WriteLine("  " & intTimerMatchedCount.ToString() & " X10Db Timers were matched.")
                                                                        System.Console.WriteLine("downloadEventsToController(): Download completed Successfully!")
                                                                    Else
                                                                        strStatus = "downloadEventsToController(): X10 Controller TimerCount=" & intX10TimerCount.ToString() & " <> TimerMatchedCount=" & intTimerMatchedCount.ToString() & "."
                                                                    End If

                                                                Else
                                                                    strStatus = "downloadEventsToController(): " & strError
                                                                End If ' END - CP290_nsX10CP290Methods.compareX10TimersToX10Db()

                                                            Else
                                                                strStatus = "downloadEventsToController(): " & strError
                                                            End If ' END - CP290_nsX10CP290Methods.getX10DbTimersPutX10()

                                                        Else
                                                            strStatus = "downloadEventsToController(): " & strError
                                                        End If ' END - CP290_nsX10CP290Methods.setX10Time()

                                                    Else
                                                        strStatus = "downloadEventsToController(): " & strError
                                                    End If ' END - CP290_nsX10CP290Methods.downloadX10BaseHousecode()

                                                Else
                                                    strStatus = "downloadEventsToController(): " & strError
                                                End If ' END - CP290_nsX10CP290Methods.x10HouseCodeAsStringToBinary()

                                            Else
                                                strStatus = "downloadEventsToController(): " & strError
                                            End If ' END - CP290_nsX10DbMethods.executeNonQueryX10db()

                                        Case "CM15A"

                                            strTryStep = "CM15A_DuskDawnResolution"
                                            ' Dusk Dawn Resolution for CM15A X10 Controller must be in Multiples of 8 (ex: 8 or 16 or 32).
                                            If (objX10DbController.DuskDawnResolution = 0) Then
                                                strStatus = "downloadEventsToController(): Missing Controller's Dusk/Dawn Resolution"
                                            Else

                                                strTryStep = "CM15A_nsX10DbMethods.getX10DbUSBPort"
                                                ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                                                strError = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                                                If (strError = "") Then

                                                    strTryStep = "CM15A_USBPortCheck"
                                                    If (objX10DbUSBPort Is Nothing) Then
                                                        strStatus = "downloadEventsToController(): getX10DbUSBPort(): USB Port=""" & objX10DbController.Port & """ Hub=""" & objX10DbController.Hub & """ not found in X10Db."
                                                    Else

                                                        strTryStep = "CM15A_TransceiverHouseCodeMap"
                                                        If (objX10DbController.TransceiverHouseCodeMap.status = "") Then

                                                            System.Console.WriteLine("downloadEventsToController(): Update to X10 Db Controllers table:")
                                                            System.Console.WriteLine("  Monitored House Code: " & objX10DbController.HouseCode)
                                                            System.Console.WriteLine("  Transceiver House Codes: " & objX10DbController.TransceiverHouseCodes)
                                                            System.Console.WriteLine("  Dusk/Dawn Resolution: " & objX10DbController.DuskDawnResolution.ToString())

                                                            strTryStep = "CM15A_nsX10DbMethods.executeNonQueryX10db"
                                                            sqlString = "UPDATE Controllers SET HouseCode='" & objX10DbController.HouseCode & "',TransceiverHouseCodes='" & objX10DbController.TransceiverHouseCodes & "',DuskDawnResolution=" & objX10DbController.DuskDawnResolution.ToString() & " WHERE ControllerID=" & objX10DbController.ControllerID.ToString() & ";"
                                                            ' nsX10DbMethods.executeNonQueryX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal sqlString As String, ByRef intRowsAffected As Integer) As String
                                                            strError = nsX10DbMethods.executeNonQueryX10db(strConnectionString, strProvider, sqlString, intRowsAffected)
                                                            If (strError = "" And intRowsAffected > 0) Then

                                                                System.Console.WriteLine("downloadEventsToController(): Set CM15A Clock to:")
                                                                System.Console.WriteLine("  " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & "  " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") ")
                                                                System.Console.WriteLine("    With:" & vbCrLf & "      Purge Timers")

                                                                strTryStep = "CM15A_nsX10CM15AMethods.setX10Time"
                                                                ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                                                objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "Y", "N", "N")
                                                                If (objSetX10TimeClass.status = "") Then

                                                                    System.Console.WriteLine("downloadEventsToController() :  Get CM15A Controller Status:")

                                                                    strTryStep = "CM15A_nsX10CM15AMethods.getX10ControllerStatus"
                                                                    ' getX10ControllerStatusClass nsX10CM15AMethods.getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                                    objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                                                    If (objGetX10ControllerStatusClass.status = "") Then

                                                                        If (objGetX10ControllerStatusClass.currentTimeHours = 12) Then
                                                                            ' PM
                                                                            strAMPM = "PM"
                                                                            intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                                        ElseIf (objGetX10ControllerStatusClass.currentTimeHours > 12) Then
                                                                            ' PM
                                                                            strAMPM = "PM"
                                                                            intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours - 12
                                                                        ElseIf (objGetX10ControllerStatusClass.currentTimeHours = 0) Then
                                                                            ' AM
                                                                            strAMPM = "AM"
                                                                            intHourAMPM = 12
                                                                        Else
                                                                            ' AM
                                                                            strAMPM = "AM"
                                                                            intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                                        End If

                                                                        System.Console.WriteLine("  Controller Status: OK")
                                                                        System.Console.WriteLine("  Time: " & objGetX10ControllerStatusClass.currentTimeDayOfWeek & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeMinutes.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeSeconds.ToString, 2) & " " & strAMPM)
                                                                        System.Console.WriteLine("  Year Day Date: " & objGetX10ControllerStatusClass.objDayOfYearDate.ToString("dddd, MMMM dd, yyyy"))
                                                                        System.Console.WriteLine("  Monitored House Code: " & objGetX10ControllerStatusClass.monitoredHouseCode)

                                                                        System.Console.WriteLine("downloadEventsToController(): Download to Controller... Please wait.......")

                                                                        strTryStep = "CM15A_nsX10CM15AMethods.putToX10Memory"
                                                                        ' putToX10MemoryClass putToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, double dblLatitude, double dblLongitude, string strScheduleName, int intScheduleID, string strX10DbConnectionString, string strX10DbProvider, bool bClearOnly)
                                                                        objPutToX10MemoryClass = nsX10CM15AMethods.putToX10Memory(objX10DbController, objX10DbUSBPort, dblLatitude, dblLongitude, "", -1, strConnectionString, strProvider, False)
                                                                        If (objPutToX10MemoryClass.status = "") Then

                                                                            System.Console.WriteLine("downloadEventsToController(): Success Loading Timers and Macros to Controller Memory!")
                                                                            System.Console.WriteLine("  Memory Version:")
                                                                            System.Console.WriteLine("    " & objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp.ToLongDateString() & " " & objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp.ToLocalTime().ToString("HH:mm:ss") & " (UTC" & System.TimeZoneInfo.Local.GetUtcOffset(objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp).TotalHours.ToString() & ")")

                                                                            System.Console.WriteLine("  Daylight Savings:")
                                                                            objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objPutToX10MemoryClass.objX10DuskDawnClass.dayOfYearDaylightSavingsTurnForward)
                                                                            System.Console.WriteLine("    Turn Forward: " & objDayOfYearDate.ToString("dddd, MMMM dd, yyyy"))

                                                                            objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objPutToX10MemoryClass.objX10DuskDawnClass.dayOfYearDaylightSavingsTurnBackward)
                                                                            System.Console.WriteLine("    Turn Backward: " & objDayOfYearDate.ToString("dddd, MMMM dd, yyyy"))

                                                                            System.Console.WriteLine("  Dusk Dawn Resolution: " + objPutToX10MemoryClass.objX10DuskDawnClass.duskDawnResolution.ToString() & " days")
                                                                            If (objPutToX10MemoryClass.objX10DuskDawnClass.startOfDuskDawnTableMemoryAddress = 0) Then
                                                                                System.Console.WriteLine("    ERROR: startOfDuskDawnTableMemoryAddress not set.")
                                                                            Else
                                                                                System.Console.WriteLine("    Number of Dusk/Dawn table entries: " & objPutToX10MemoryClass.objX10DuskDawnClass.objX10DuskDawnTableEntryClasses.Count.ToString())
                                                                            End If

                                                                            System.Console.WriteLine("  Transceive on Housecodes: " & objPutToX10MemoryClass.objX10TransceiverSetupClass.TransceiverHouseCodes)
                                                                            System.Console.WriteLine("  Timer Initiators count: " & objPutToX10MemoryClass.objX10InitiatorsClass.objX10TimerInitiatorsClass.Count)
                                                                            System.Console.WriteLine("            Macros count: " & objPutToX10MemoryClass.objX10InitiatorsClass.timerInitiatorMacroBlockCount)
                                                                            System.Console.WriteLine("  Macro Initiators count: " & objPutToX10MemoryClass.objX10InitiatorsClass.objX10MacroInitiatorsClass.Count)
                                                                            System.Console.WriteLine("            Macros count: " & objPutToX10MemoryClass.objX10InitiatorsClass.macroInitiatorMacroBlockCount)

                                                                            System.Console.WriteLine("downloadEventsToController(): Starting Verify")

                                                                            strTryStep = "CM15A_nsX10CM15AMethods.verifyPutToX10Memory"
                                                                            strMemoryOutputFilename = strBackupDirectoryPath & "putTimersAndMacrosToX10Memory_" & objX10DbController.ControllerType & "_" & objX10DbController.ControllerName.Replace(" ", "") & ".txt"
                                                                            ' verifyPutToX10MemoryClass verifyPutToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, ref putToX10MemoryClass objPutToX10MemoryClass, bool bClearOnly, string strFilename)
                                                                            objVerifyPutToX10MemoryClass = nsX10CM15AMethods.verifyPutToX10Memory(objX10DbController, objX10DbUSBPort, objPutToX10MemoryClass, False, strMemoryOutputFilename)
                                                                            If (objVerifyPutToX10MemoryClass.status = "") Then
                                                                                System.Console.WriteLine("downloadEventsToController(): Controller Memory loacations have matched!")
                                                                                System.Console.WriteLine("Controller Memory Annotations found in file:" & strMemoryOutputFilename)
                                                                                System.Console.WriteLine("Download completed Successfully!")
                                                                            Else
                                                                                strStatus = "downloadEventsToController(): " & objVerifyPutToX10MemoryClass.status
                                                                            End If ' END - CM15A_nsX10CM15AMethods.verifyPutToX10Memory()

                                                                        Else
                                                                            strStatus = "downloadEventsToController(): " & objPutToX10MemoryClass.status
                                                                        End If ' END - CM15A_nsX10CM15AMethods.putToX10Memory()

                                                                    Else
                                                                        strStatus = "downloadEventsToController(): " & objGetX10ControllerStatusClass.status
                                                                    End If ' END - CM15A_nsX10CM15AMethods.getX10ControllerStatus()

                                                                Else
                                                                    strStatus = "downloadEventsToController(): " & objSetX10TimeClass.status
                                                                End If ' END - CM15A_nsX10CM15AMethods.setX10Time()

                                                            Else
                                                                If (strStatus <> "") Then
                                                                    strStatus = "downloadEventsToController(): " & strError
                                                                Else
                                                                    strStatus = "downloadEventsToController(): executeNonQueryX10db(): No rows were affected for X10 Db Controllers table Update of TransceiverHouseCodes."
                                                                End If
                                                            End If ' END - CM15A_nsX10DbMethods.executeNonQueryX10db(UpdateControllersTable)

                                                        Else
                                                            strStatus = "downloadEventsToController(): Problem with Controller's selected Transceiver House Code(s): " & objX10DbController.TransceiverHouseCodeMap.status
                                                        End If ' END - CM15A_TransceiverHouseCodeMap

                                                    End If ' END - CM15A_USBPortCheck

                                                Else
                                                    strStatus = "downloadEventsToController(): " & strError
                                                End If ' END - CM15A_nsX10DbMethods.getX10DbUSBPort()

                                            End If ' END - CM15A_DuskDawnResolution

                                        Case "WM100"

                                            System.Console.WriteLine("downloadEventsToController(): No Events have been downloaded!")

                                        Case Else
                                            strStatus = "downloadEventsToController(): Unknown Controller Type: """ & objX10DbController.ControllerType & """"
                                    End Select ' END  - ControllerType

                                Else
                                    System.Console.WriteLine("downloadEventsToController(): No Events were found for Controller """ & objX10DbController.ControllerName & """.")
                                    System.Console.WriteLine("  This can be caused by No Active Schedules with Events")
                                    System.Console.WriteLine("  using Scenes that include Modules attached to this Controller.")
                                    System.Console.WriteLine("No Events have been downloaded!")
                                End If ' END - TimersCompiled

                            Else
                                strStatus = "downloadEventsToController(): " & strError
                            End If ' END - nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db()

                        Else
                            System.Console.WriteLine("downloadEventsToController(): Controller """ & objX10DbController.ControllerName & """ is not Active.")
                            System.Console.WriteLine("No Events have been downloaded!")
                        End If ' END - ControllerActive

                    End If ' END - StatusOK

                Catch ex As Exception
                    If (strStatus = "") Then
                        strStatus = "downloadEventsToController(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & sqlString
                    Else
                        strStatus &= vbCrLf & "downloadEventsToController(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & sqlString
                    End If
                Finally
                    objDayOfYearDate = Nothing
                    objVerifyPutToX10MemoryClass = Nothing
                    objPutToX10MemoryClass = Nothing
                    objGetX10ControllerStatusClass = Nothing
                    objSetX10TimeClass = Nothing
                    objX10DbUSBPort = Nothing
                    objPutX10TransceiverSetupClass = Nothing
                    objDateTimeNow = Nothing
                    objTimeZone = Nothing
                End Try

                Return strStatus

            End Function ' END - downloadEventsToController()

            '=====================================================================================
            ' Function executeOperationX10CP290()
            ' Alan Wagner
            '
            Public Function executeOperationX10CP290(ByVal strOperation As String, ByVal strFilename As String, ByVal strGuid As String, ByVal strScheduleName As String, ByVal strHouseCode As String, ByVal strModuleCode As String, ByVal strDimmer As String, ByVal strOnOff As String, ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strLighthouseParadoxFilesPath As String, ByVal strLighthouseParadoxConnectionString As String, ByVal strLighthouseParadoxProvider As String, ByVal strX10ControllerType As String, ByVal strX10ControllerName As String, ByRef intExitCode As Integer) As String
                Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
                Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

                Dim strStatus As String = ""
                Dim strError As String = ""

                Dim intRowsAffected As Integer = -1

                Dim intX10Status As Integer = -1
                Dim intMINUTES As Integer = -1
                Dim intHOURS As Integer = -1
                Dim strTime As String = ""
                Dim intDay As Integer = -1
                Dim intHousecode As Integer = -1

                Dim intUnitOnOff As Integer = 0
                Dim intUnitLevel As Integer = 0

                Dim intScheduleID As Integer = -1

                Dim intTimerEventCount As Integer = 0
                Dim intTimersCompiled As Integer = 0

                Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

                Dim objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload) = Nothing
                Dim objX10CP290CommandUpload As TrekkerPhotoArt.X10Include.X10CP290CommandUpload = Nothing

                Dim objDateTimeNow As System.DateTime = System.DateTime.Now

                Dim strCSVFilename As String = ""

                Try

                    ' Get Controller Information
                    Select Case strOperation.ToUpper()
                        Case "SETX10TIME", "GETCONTROLLERSTATUS", "DOWNLOADX10BASEHOUSECODE", "RESETSUNRISESUNSETTIMERTIMES", "GETX10TIMERSPUTX10DB", "GETX10DBTIMERSPUTX10", "COMPAREX10TIMERSTOX10DB", "GETLIGHTHOUSEDBPUTX10DB", "SENDUNITCOMMAND", "GETX10MEMORYPUTTOFILE"

                            System.Console.WriteLine("nsX10DbMethods.getX10DbController")
                            ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strControllerName As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                            strStatus = nsX10DbMethods.getX10DbController(strX10DbConnectionString, strX10DbProvider, strX10ControllerName, objX10DbController)
                            If (strStatus = "") Then

                                If (objX10DbController Is Nothing) Then
                                    strStatus = "executeOperationX10CP290(): getX10DbController(): Controller named """ & strX10ControllerName & """ not found in X10Db."
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If
                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbController()

                    End Select

                    If (strStatus = "") Then

                        Select Case strOperation.ToUpper()
                            Case "SETX10TIME"
                                ' setX10Time on CP290 Controller.
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10CP290Methods.setX10Time")
                                ' objX10DbController.Port --> ex: "COM3"
                                ' Note: nsX10CP290Methods.setX10Time() calls nsX10CP290Methods.getX10Time() to verify time was set and get X10 Controller Status.
                                ' nsX10CP290Methods.setX10Time(ByVal strPortName As String, ByVal dtmNow As System.DateTime, ByRef intgX10Status As Integer, ByRef intgMINUTES As Integer, ByRef intgHOURS As Integer, ByRef intgBday As Integer, ByRef intgHC As Integer) As String
                                strStatus = nsX10CP290Methods.setX10Time(objX10DbController.Port, objDateTimeNow, intX10Status, intMINUTES, intHOURS, intDay, Nothing)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes")
                                    ' intX10SunriseTime and intX10SunsetTime as minutes after Midnight
                                    ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                    strStatus = nsX10DbMethods.putX10DbSunTimes(strX10DbConnectionString, strX10DbProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                    If (strStatus = "") Then

                                        System.Console.WriteLine("nsX10CP290Methods.putX10DbSunTimes(): " & intRowsAffected.ToString() & " Schedules were affected.")

                                        ' Is there a Lighthouse Paradox Db?
                                        If (strLighthouseParadoxFilesPath <> "") Then

                                            System.Console.WriteLine("nsX10CP290Methods.putLighthouseSunTimes")
                                            ' nsX10CP290Methods.putLighthouseSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                            strStatus = nsX10CP290Methods.putLighthouseSunTimes(strLighthouseParadoxConnectionString, strLighthouseParadoxProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                            If (strStatus = "") Then

                                                System.Console.WriteLine("nsX10CP290Methods.putLighthouseSunTimes(): " & intRowsAffected.ToString() & " Schedules were affected.")

                                            Else
                                                System.Console.WriteLine(strStatus)
                                                intExitCode = -1
                                            End If ' END - nsX10CP290Methods.putLighthouseSunTimes()

                                        End If

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsX10DbMethods.putX10DbSunTimes()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10CP290Methods.setX10Time()

                            Case "GETCONTROLLERSTATUS"
                                ' getControllerStatus from CP290 Controller.
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10CP290Methods.getX10Time")
                                ' objX10DbController.Port --> ex: "COM3"
                                ' nsX10CP290Methods.getX10Time(ByVal strPortName As String, ByRef intX10Status As Integer, ByRef intMINUTES As Integer, ByRef intHOURS As Integer, ByRef intBday As Integer, ByRef intHC As Integer) As String
                                strStatus = nsX10CP290Methods.getX10Time(objX10DbController.Port, intX10Status, intMINUTES, intHOURS, intDay, Nothing)
                                If (strStatus = "") Then

                                    Select Case intHOURS
                                        Case 0, 24
                                            strTime = "12:" & nsStringMethods.addLeadingZeros(intMINUTES.ToString(), 2) & " AM"
                                        Case 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11
                                            strTime = nsStringMethods.addLeadingZeros(intHOURS.ToString(), 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString(), 2) & " AM"
                                        Case 12
                                            strTime = "12:" & nsStringMethods.addLeadingZeros(intMINUTES.ToString(), 2) & " PM"
                                        Case 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23
                                            strTime = nsStringMethods.addLeadingZeros((intHOURS - 12).ToString(), 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString(), 2) & " PM"
                                    End Select

                                    Select Case intX10Status
                                        Case 0
                                            System.Console.WriteLine("nsX10CP290Methods.getX10Time(): X10 Unit is NOT Programmed: Status(" & intX10Status.ToString() & ")=" & nsX10CP290Methods.x10StatusCodeToString(intX10Status) & " Time=" & strTime & " Day= BaseHousecode=" & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHousecode))
                                        Case 1

                                            System.Console.WriteLine("nsX10CP290Methods.getX10TimersCount")
                                            ' objX10DbController.Port --> ex: "COM3"
                                            ' nsX10CP290Methods.getX10TimersCount(ByVal strPortName As String, ByRef intTimerEvent As Integer) As String
                                            strStatus = nsX10CP290Methods.getX10TimersCount(objX10DbController.Port, intTimerEventCount)
                                            If (strStatus = "") Then
                                                System.Console.WriteLine("nsX10CP290Methods.getX10Time(): X10 Unit IS Programmed: Status(" & intX10Status.ToString() & ")=" & nsX10CP290Methods.x10StatusCodeToString(intX10Status) & " Time=" & strTime & " Day=" & nsX10CP290Methods.x10DaysOfWeekFromMaskToFullStringOfDays(intDay) & " BaseHousecode=" & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHousecode) & " Timers=" & intTimerEventCount.ToString())
                                            Else
                                                System.Console.WriteLine(strStatus)
                                            End If ' END - getX10TimersCount()

                                        Case Else
                                            System.Console.WriteLine("nsX10CP290Methods.getX10Time(): Unknown X10 Status Code=" & intX10Status.ToString() & " was returned.")
                                    End Select

                                Else
                                    System.Console.WriteLine(strStatus)
                                End If ' END - nsX10CP290Methods.getX10Time()

                            Case "PUTLIGHTHOUSESUNTIMES"
                                ' putLighthouseSunTimes in Lighthouse PARADOX db.
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10CP290Methods.putLighthouseSunTimes")
                                ' intX10SunriseTime and intX10SunsetTime as minutes after Midnight
                                ' nsX10CP290Methods.putLighthouseSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                strStatus = nsX10CP290Methods.putLighthouseSunTimes(strLighthouseParadoxConnectionString, strLighthouseParadoxProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsX10CP290Methods.putLighthouseSunTimes(): " & intRowsAffected.ToString() & " Schedules were affected.")

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10CP290Methods.putLighthouseSunTimes()

                            Case "DOWNLOADX10BASEHOUSECODE"
                                ' downloadX10BaseHousecode to CP290 Controller.
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble")
                                ' nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(ByVal strHouseCode As String, ByRef intHousecode As Integer) As String
                                strStatus = nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(strHouseCode, intHousecode)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsX10CP290Methods.downloadX10BaseHousecode")
                                    ' objX10DbController.Port --> ex: "COM3"
                                    ' nsX10CP290Methods.downloadX10BaseHousecode(ByVal strPortName As String, ByVal intHousecode As Integer) As String
                                    strStatus = nsX10CP290Methods.downloadX10BaseHousecode(objX10DbController.Port, intHousecode)
                                    If (strStatus = "") Then

                                        objX10DbController.HouseCode = strHouseCode

                                        System.Console.WriteLine("nsX10DbMethods.addUpdateControllerToX10db(HouseCode)")
                                        ' nsX10DbMethods.addUpdateControllerToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intRowsAffected As Integer) As String
                                        strStatus = nsX10DbMethods.addUpdateControllerToX10db(strX10DbConnectionString, strX10DbProvider, strGuid, objX10DbController, intRowsAffected)
                                        If (strStatus = "") Then

                                            If (intRowsAffected > 0) Then
                                                System.Console.WriteLine("nsX10DbMethods.addUpdateControllerToX10db(): House Code Updated to X10 Controller """ & objX10DbController.ControllerName & """ in X10Db Controllers table.")
                                            Else
                                                System.Console.WriteLine("nsX10DbMethods.addUpdateControllerToX10db(): Problem Updating House Code to X10 Controller """ & objX10DbController.ControllerName & """ in X10Db Controllers table.")
                                                intExitCode = -1
                                            End If

                                        Else
                                            System.Console.WriteLine(strStatus)
                                            intExitCode = -1
                                        End If ' END - nsX10DbMethods.addUpdateControllerToX10db()

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsX10CP290Methods.downloadX10BaseHousecode()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble()

                            Case "RESETSUNRISESUNSETTIMERTIMES"
                                ' resetSunriseSunsetTimerTimes
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble")
                                ' nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(ByVal strHouseCode As String, ByRef intHousecode As Integer) As String
                                strStatus = nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(objX10DbController.HouseCode, intHousecode)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsX10CP290Methods.setX10Time")
                                    ' objX10DbController.Port --> ex: "COM3"
                                    ' Note: nsX10CP290Methods.setX10Time() calls nsX10CP290Methods.getX10Time() to verify time was set and get X10 Controller Status.
                                    ' nsX10CP290Methods.setX10Time(ByVal strPortName As String, ByVal dtmNow As System.DateTime, ByRef intgX10Status As Integer, ByRef intgMINUTES As Integer, ByRef intgHOURS As Integer, ByRef intgBday As Integer, ByRef intgHC As Integer) As String
                                    strStatus = nsX10CP290Methods.setX10Time(objX10DbController.Port, objDateTimeNow, intX10Status, intMINUTES, intHOURS, intDay, Nothing)
                                    If (strStatus = "") Then

                                        System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes")
                                        ' intX10SunriseTime and intX10SunsetTime as minutes after Midnight.
                                        ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                        strStatus = nsX10DbMethods.putX10DbSunTimes(strX10DbConnectionString, strX10DbProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                        If (strStatus = "") Then

                                            System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes(): " & intRowsAffected.ToString() & " Schedules were affected.")

                                            ' Is there a Lighthouse Paradox Db?
                                            If (strLighthouseParadoxFilesPath <> "") Then

                                                System.Console.WriteLine("nsX10CP290Methods.putLighthouseSunTimes")
                                                ' nsX10CP290Methods.putLighthouseSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                                strStatus = nsX10CP290Methods.putLighthouseSunTimes(strLighthouseParadoxConnectionString, strLighthouseParadoxProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                                If (strStatus = "") Then

                                                    System.Console.WriteLine("nsX10CP290Methods.putLighthouseSunTimes(): " & intRowsAffected.ToString() & " Schedules were affected.")

                                                Else
                                                    System.Console.WriteLine(strStatus)
                                                    intExitCode = -1
                                                End If ' END - nsX10CP290Methods.putLighthouseSunTimes()

                                            End If

                                        Else
                                            System.Console.WriteLine(strStatus)
                                            intExitCode = -1
                                        End If ' END - nsX10DbMethods.putX10DbSunTimes()

                                        If (intExitCode > -1) Then

                                            System.Console.WriteLine("nsX10DbMethods.getX10DbScheduleID")
                                            ' nsX10DbMethods.getX10DbScheduleID(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByRef intScheduleID As Integer) As String
                                            strStatus = nsX10DbMethods.getX10DbScheduleID(strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID)
                                            If (strStatus = "") Then

                                                System.Console.WriteLine("nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db")
                                                ' nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByRef intTimersCompiled As Integer) As String
                                                strStatus = nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(strX10DbConnectionString, strX10DbProvider, intTimersCompiled)
                                                If (strStatus = "") Then

                                                    If (intTimersCompiled > 0) Then

                                                        System.Console.WriteLine("nsX10CP290Methods.getX10DbTimersPutX10")
                                                        ' Note: nsX10CP290Methods.getX10DbTimersPutX10() calls nsX10CP290Methods.downloadX10BaseHousecode()
                                                        ' nsX10CP290Methods.getX10DbTimersPutX10(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intX10DbTimersCount As Integer) As String
                                                        strStatus = nsX10CP290Methods.getX10DbTimersPutX10(strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID, intHousecode, objX10DbController, 0)
                                                        If (strStatus = "") Then

                                                            System.Console.WriteLine("nsX10CP290Methods.compareX10TimersToX10Db")
                                                            ' nsX10CP290Methods.compareX10TimersToX10Db(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef intX10TimerCount As Integer, ByRef intTimerMatchedCount As Integer) As String
                                                            strStatus = nsX10CP290Methods.compareX10TimersToX10Db(objX10DbController, strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID, 0, 0)
                                                            If (strStatus <> "") Then
                                                                System.Console.WriteLine(strStatus)
                                                                intExitCode = -1
                                                            End If ' END - nsX10CP290Methods.compareX10TimersToX10Db()

                                                        Else
                                                            System.Console.WriteLine(strStatus)
                                                            intExitCode = -1
                                                        End If ' END - nsX10CP290Methods.getX10DbTimersPutX10()

                                                    Else
                                                        System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): No Events were found for Controller """ & objX10DbController.ControllerName & """.")
                                                        System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): This can be caused by No Active Schedules with Events using Scenes that include Modules attached to this Controller.")
                                                        intExitCode = -1
                                                    End If

                                                Else
                                                    System.Console.WriteLine(strStatus)
                                                    intExitCode = -1
                                                End If ' END - nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db()

                                            Else
                                                System.Console.WriteLine(strStatus)
                                                intExitCode = -1
                                            End If ' END - nsX10DbMethods.getX10DbScheduleID()

                                        End If

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsX10CP290Methods.setX10Time()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END -nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble()

                            Case "GETX10TIMERSPUTX10DB"
                                ' getX10TimersPutX10Db
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10DbMethods.getX10DbScheduleID")
                                ' nsX10DbMethods.getX10DbScheduleID() will return intScheduleID=-1 if no Schedule name.
                                ' nsX10DbMethods.getX10DbScheduleID(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByRef intScheduleID As Integer) As String
                                strStatus = nsX10DbMethods.getX10DbScheduleID(strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID)
                                If (strStatus = "") Then

                                    If (intScheduleID >= 0) Then

                                        System.Console.WriteLine("nsX10DbMethods.removeTimersFromX10Db")
                                        ' nsX10DbMethods.removeTimersFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String) As String
                                        strStatus = nsX10DbMethods.removeTimersFromX10Db(strX10DbConnectionString, strX10DbProvider)
                                        If (strStatus = "") Then

                                            System.Console.WriteLine("nsX10CP290Methods.getX10TimersPutX10Db")
                                            ' nsX10CP290Methods.getX10TimersPutX10Db(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer) As String
                                            strStatus = nsX10CP290Methods.getX10TimersPutX10Db(objX10DbController, strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID)
                                            If (strStatus = "") Then

                                                System.Console.WriteLine("nsX10CP290Methods.compareX10TimersToX10Db")
                                                ' nsX10CP290Methods.compareX10TimersToX10Db(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef intX10TimerCount As Integer, ByRef intTimerMatchedCount As Integer) As String
                                                strStatus = nsX10CP290Methods.compareX10TimersToX10Db(objX10DbController, strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID, 0, 0)
                                                If (strStatus <> "") Then
                                                    System.Console.WriteLine(strStatus)
                                                    intExitCode = -1
                                                End If ' END - nsX10CP290Methods.compareX10TimersToX10Db()

                                            Else
                                                System.Console.WriteLine(strStatus)
                                                intExitCode = -1
                                            End If ' END - nsX10CP290Methods.getX10TimersPutX10Db()

                                        Else
                                            System.Console.WriteLine(strStatus)
                                            intExitCode = -1
                                        End If ' END nsX10DbMethods.removeTimersFromX10Db()

                                    Else
                                        strStatus = "nsX10DbMethods.getX10DbScheduleID(): Unknown ScheduleName=""" & strScheduleName & """ was specified."
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10DbMethods.getX10DbScheduleID()

                            Case "GETX10DBTIMERSPUTX10"
                                ' getX10DbTimersPutX10
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10CP290Methods.setX10Time")
                                ' objX10DbController.Port --> ex: "COM3"
                                ' nsX10CP290Methods.setX10Time(ByVal strPortName As String, ByVal dtmNow As System.DateTime, ByRef intgX10Status As Integer, ByRef intgMINUTES As Integer, ByRef intgHOURS As Integer, ByRef intgBday As Integer, ByRef intgHC As Integer) As String
                                strStatus = nsX10CP290Methods.setX10Time(objX10DbController.Port, objDateTimeNow, intX10Status, intMINUTES, intHOURS, intDay, Nothing)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes")
                                    ' intX10SunriseTime and intX10SunsetTime as minutes after Midnight.
                                    ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                    strStatus = nsX10DbMethods.putX10DbSunTimes(strX10DbConnectionString, strX10DbProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                    If (strStatus = "") Then

                                        System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes(): " & intRowsAffected.ToString() & " Schedules were affected.")

                                        System.Console.WriteLine("nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db")
                                        ' nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByRef intTimersCompiled As Integer) As String
                                        strStatus = nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(strX10DbConnectionString, strX10DbProvider, intTimersCompiled)
                                        If (strStatus = "") Then

                                            If (intTimersCompiled > 0) Then

                                                System.Console.WriteLine("nsX10DbMethods.getX10DbScheduleID")
                                                ' nsX10DbMethods.getX10DbScheduleID() will return intScheduleID=-1 if no Schedule name.
                                                ' nsX10DbMethods.getX10DbScheduleID(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByRef intScheduleID As Integer) As String
                                                strStatus = nsX10DbMethods.getX10DbScheduleID(strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID)
                                                If (strStatus = "") Then

                                                    System.Console.WriteLine("nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble")
                                                    ' nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(ByVal strHouseCode As String, ByRef intHousecode As Integer) As String
                                                    strStatus = nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(objX10DbController.HouseCode, intHousecode)
                                                    If (strStatus = "") Then

                                                        System.Console.WriteLine("nsX10CP290Methods.getX10DbTimersPutX10")
                                                        ' Note: nsX10CP290Methods.getX10DbTimersPutX10() calls nsX10CP290Methods.downloadX10BaseHousecode()
                                                        ' If intScheduleID=-1, then all Active Schedules are used.
                                                        ' nsX10CP290Methods.getX10DbTimersPutX10(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByVal intHousecode As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intX10DbTimersCount As Integer) As String
                                                        strStatus = nsX10CP290Methods.getX10DbTimersPutX10(strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID, intHousecode, objX10DbController, 0)
                                                        If (strStatus = "") Then

                                                            System.Console.WriteLine("nsX10CP290Methods.compareX10TimersToX10Db")
                                                            ' If intScheduleID=-1, then all Active Schedules are used.
                                                            ' nsX10CP290Methods.compareX10TimersToX10Db(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef intX10TimerCount As Integer, ByRef intTimerMatchedCount As Integer) As String
                                                            strStatus = nsX10CP290Methods.compareX10TimersToX10Db(objX10DbController, strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID, 0, 0)
                                                            If (strStatus <> "") Then
                                                                System.Console.WriteLine(strStatus)
                                                                intExitCode = -1
                                                            End If ' END - nsX10CP290Methods.compareX10TimersToX10Db()

                                                        Else
                                                            System.Console.WriteLine(strStatus)
                                                            intExitCode = -1
                                                        End If ' END - nsX10CP290Methods.getX10DbTimersPutX10()

                                                    Else
                                                        System.Console.WriteLine(strStatus)
                                                        intExitCode = -1
                                                    End If ' END -nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble()

                                                Else
                                                    System.Console.WriteLine(strStatus)
                                                    intExitCode = -1
                                                End If ' END - nsX10DbMethods.getX10DbScheduleID()

                                            Else
                                                System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): No Events were found for Controller """ & objX10DbController.ControllerName & """.")
                                                System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): This can be caused by No Active Schedules with Events using Scenes that include Modules attached to this Controller.")
                                                intExitCode = -1
                                            End If

                                        Else
                                            System.Console.WriteLine(strStatus)
                                            intExitCode = -1
                                        End If ' END - nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db()

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsX10DbMethods.putX10DbSunTimes()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10CP290Methods.setX10Time

                            Case "COMPAREX10TIMERSTOX10DB"
                                ' compareX10TimersToX10Db
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10DbMethods.getX10DbScheduleID")
                                ' nsX10DbMethods.getX10DbScheduleID() will return intScheduleID=-1 if no Schedule name.
                                ' nsX10DbMethods.getX10DbScheduleID(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByRef intScheduleID As Integer) As String
                                strStatus = nsX10DbMethods.getX10DbScheduleID(strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsX10CP290Methods.compareX10TimersToX10Db")
                                    ' If intScheduleID=-1, then all Active Schedules are used.
                                    ' nsX10CP290Methods.compareX10TimersToX10Db(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef intX10TimerCount As Integer, ByRef intTimerMatchedCount As Integer) As String
                                    strStatus = nsX10CP290Methods.compareX10TimersToX10Db(objX10DbController, strX10DbConnectionString, strX10DbProvider, strScheduleName, intScheduleID, 0, 0)
                                    If (strStatus <> "") Then
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsX10CP290Methods.compareX10TimersToX10Db()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10DbMethods.getX10DbScheduleID()

                            Case "SENDUNITCOMMAND"
                                ' sendUnitCommand
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues")
                                ' nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(ByVal strDimmer As String, ByVal strOnOff As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer) As String
                                strStatus = nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(strDimmer, strOnOff, intUnitOnOff, intUnitLevel)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("nsX10CP290Methods.sendUnitCommand")
                                    ' nsX10CP290Methods.sendUnitCommand(ByVal strPortName As String, ByVal strUnitHouseCode As String, ByVal strUnitModuleCodes As String, ByVal strDimmer As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer, ByRef intX10Status As Integer, ByRef objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload)) As String
                                    strStatus = nsX10CP290Methods.sendUnitCommand(objX10DbController.Port, strHouseCode, strModuleCode, strDimmer, intUnitOnOff, intUnitLevel, intX10Status, objX10CP290CommandUploads)
                                    If (strStatus = "") Then

                                        System.Console.WriteLine("executeOperationX10CP290(): Success sending Unit Command to X10 Controller.")
                                        System.Console.WriteLine("  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]")
                                        System.Console.WriteLine("  UnitHouseCode: " & strHouseCode)
                                        System.Console.WriteLine("  UnitModuleCodes: " & strModuleCode)

                                        Select Case strDimmer.ToUpper()
                                            Case "Y"
                                                System.Console.WriteLine("  Set Dimmer to " & strOnOff)
                                            Case "N"
                                                System.Console.WriteLine("  Set Switch to " & strOnOff)
                                        End Select

                                        If (Not objX10CP290CommandUploads Is Nothing AndAlso objX10CP290CommandUploads.Count > 0) Then

                                            For Each objX10CP290CommandUpload In objX10CP290CommandUploads

                                                System.Console.WriteLine("  CommandUpload[" & objX10CP290CommandUpload.CommandUploadID.ToString() & "]:")
                                                System.Console.WriteLine("    Function=" & objX10CP290CommandUpload.strFunction)
                                                System.Console.WriteLine("    Housecode=" & objX10CP290CommandUpload.strHousecode)
                                                System.Console.WriteLine("    X10UnitCodes18=" & objX10CP290CommandUpload.strX10UnitCodes18)
                                                System.Console.WriteLine("    X10UnitCodes916=" & objX10CP290CommandUpload.strX10UnitCodes916)
                                                System.Console.WriteLine("    BaseHousecode=" & objX10CP290CommandUpload.strBaseHousecode)
                                                System.Console.WriteLine("    X10Status=" & objX10CP290CommandUpload.strX10Status)

                                            Next

                                        End If

                                        System.Console.WriteLine("executeOperationX10CP290(sendUnitCommand): Success")

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsX10CP290Methods.sendUnitCommand()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If

                            Case "GETX10MEMORYPUTTOFILE"
                                ' getX10MemoryPutToFile from the CP290 Controller.
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10CP290Methods.getX10TimersPutToFile")
                                ' nsX10CP290Methods.getX10TimersPutToFile(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strFilename As String, ByRef strCSVFilename As String) As String
                                strStatus = nsX10CP290Methods.getX10TimersPutToFile(objX10DbController, strFilename, strCSVFilename)
                                If (strStatus = "") Then

                                    System.Console.WriteLine("executeOperationX10CP290(): Success with CP290 Memory Put to file " & strCSVFilename)

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10CP290Methods.getX10TimersPutToFile()

                            Case "GETLIGHTHOUSEDBPUTX10DB"
                                ' getLighthouseDbPutX10Db
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10CP290Methods.getLighthouseDbPutX10Db()")
                                ' <add key="LighthouseParadoxFilesPath" value="D:\Lighthou" />
                                ' nsX10CP290Methods.getLighthouseDbPutX10Db(ByVal strLighthouseParadoxFilesPath As String, ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                                strStatus = nsX10CP290Methods.getLighthouseDbPutX10Db(strLighthouseParadoxFilesPath, strX10DbConnectionString, strX10DbProvider, objX10DbController)
                                If (strStatus <> "") Then
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10CP290Methods.getLighthouseDbPutX10Db()

                            Case "GETLIGHTHOUSETABLECONTENTS"
                                ' getLighthouseTableContents
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                System.Console.WriteLine("nsX10CP290Methods.getLighthouseTableContents()")
                                ' <add key="LighthouseParadoxFilesPath" value="D:\Lighthou" />
                                ' nsX10CP290Methods.getLighthouseTableContents(ByVal strLighthouseParadoxFilesPath As String) As String
                                strStatus = nsX10CP290Methods.getLighthouseTableContents(strLighthouseParadoxFilesPath)
                                If (strStatus <> "") Then
                                    System.Console.WriteLine(strStatus)
                                End If ' END - nsX10CP290Methods.getLighthouseTableContents()

                            Case "GETLIGHTHOUSETABLECONTENTSSCENE"
                                ' getLighthouseTableContentsScene
                                System.Console.WriteLine("executeOperationX10CP290(): " & strOperation)

                                'System.Console.WriteLine("nsX10CP290Methods.getLighthouseTableContentsParadoxReaderSequentialRead(SCENE)")
                                ' <add key="LighthouseParadoxFilesPath" value="D:\Lighthou" />
                                ' nsX10CP290Methods.getLighthouseTableContentsParadoxReaderSequentialRead(ByVal strLighthouseParadoxFilesPath As String, ByVal strTableName As String, ByVal strFilename As String) As String
                                'strStatus = nsX10CP290Methods.getLighthouseTableContentsParadoxReaderSequentialRead(strLighthouseParadoxFilesPath, "SCENE", "LighthouseDb_SCENE.csv")
                                'If (strStatus <> "") Then
                                'System.Console.WriteLine(strStatus)
                                'End If ' END - nsX10CP290Methods.getLighthouseTableContentsParadoxReaderSequentialRead()

                                System.Console.WriteLine("nsX10CP290Methods.getLighthouseTableContentsParadoxReaderReadByIndex(SCENE)")
                                ' <add key="LighthouseParadoxFilesPath" value="D:\Lighthou" />
                                ' nsX10CP290Methods.getLighthouseTableContentsParadoxReaderReadByIndex(ByVal strLighthouseParadoxFilesPath As String, ByVal strTableName As String, ByVal intIndexStart As Integer, ByVal intIndexEnd As Integer, ByVal strFilename As String) As String
                                strStatus = nsX10CP290Methods.getLighthouseTableContentsParadoxReaderReadByIndex(strLighthouseParadoxFilesPath, "SCENE", 0, 99999, "LighthouseDb_SCENE.csv")
                                If (strStatus <> "") Then
                                    System.Console.WriteLine(strStatus)
                                End If ' END - nsX10CP290Methods.getLighthouseTableContentsParadoxReaderReadByIndex()

                            Case Else
                                strStatus = "executeOperationX10CP290(): Unknown Operation=""" & strOperation & """ was specified."
                                System.Console.WriteLine("executeOperationX10CP290(): Unknown Operation=""" & strOperation & """ was specified.")
                                intExitCode = -1
                        End Select

                    End If ' End - If strStatus = ""

                Catch ex As Exception
                    strError = "executeOperationX10CP290(): Exception: Operation=""" & strOperation & """: " & ex.Message.ToString()
                    If (strStatus.Length = 0) Then
                        strStatus = strError
                    Else
                        strStatus &= vbCRLF & strError
                    End If
                    System.Console.WriteLine(strError)
                    intExitCode = -1
                Finally
                    objX10DbController = Nothing
                    objX10CP290CommandUploads = Nothing
                    objX10CP290CommandUpload = Nothing
                    objDateTimeNow = Nothing
                End Try

                Return strStatus

            End Function ' END - executeOperationX10CP290()

            '=====================================================================================
            ' Function executeOperationX10CM15A()
            ' Alan Wagner
            '
            Public Function executeOperationX10CM15A(ByVal strOperation As String, ByVal strFilename As String, ByVal strGuid As String, ByVal strScheduleName As String, ByVal strHouseCode As String, ByVal strModuleCode As String, ByVal strDimmer As String, ByVal strOnOff As String, ByVal strBrightenDim As String, ByVal strStandardExtended As String, ByVal strExtendedData As String, ByVal strExtendedCommand As String, ByVal strMemoryAddrLow As String, ByVal strMemoryAddrHigh As String, ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strX10ControllerType As String, ByVal strX10ControllerName As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting, ByRef intExitCode As Integer) As String
                Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

                Dim strStatus As String = ""
                Dim strError As String = ""

                Dim intRowsAffected As Integer = -1

                Dim intScheduleID As Integer = -1
                Dim intTimersCompiled As Integer = 0

                Dim intUnitOnOff As Integer = 0
                Dim intUnitLevel As Integer = 0
                Dim bytExtendedData As Byte = 0
                Dim bytExtendedCommand As Byte = 0
                Dim bytStartAddressLow As Byte = 0
                Dim bytStartAddressHigh As Byte = 0
                Dim int16MemoryAddressStart As Int16 = 0
                Dim int16MemoryAddressEnd As Int16 = 0

                Dim objSetX10TimeClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.setX10TimeClass = Nothing
                Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
                Dim objGetX10TransceiverSetupClassClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10TransceiverSetupClass = Nothing
                Dim objPutX10TransceiverSetupClassClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putX10TransceiverSetupClass = Nothing

                Dim objSendMacroInitiatorTriggerClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendMacroInitiatorTriggerClass = Nothing
                Dim objSendUnitCommandClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendUnitCommandClass = Nothing
                Dim objSendFunctionCommandPowerLineClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendFunctionCommandPowerLineClass = Nothing
                Dim objX10ExtendedCommand As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.x10ExtendedCommand = Nothing
                Dim objGetX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10MemoryClass = Nothing
                Dim objGetX10DuskDawnClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10DuskDawnClass = Nothing
                Dim objGetX10MemoryVersionStampClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10MemoryVersionStampClass = Nothing
                Dim objGetX10MemoryPutToFileClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10MemoryPutToFileClass = Nothing
                Dim objPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putToX10MemoryClass = Nothing
                Dim objVerifyPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.verifyPutToX10MemoryClass = Nothing

                Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
                Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing

                Dim objDateTimeNow As System.DateTime = System.DateTime.Now

                Try

                    ' Get Controller Information
                    Select Case strOperation.ToUpper()
                        Case "GETCONTROLLERSTATUS", "GETX10TRANSCEIVERSETUP", "PUTX10TRANSCEIVERSETUP", "SETX10TIME", "SETX10TIMEPURGETIMERS", "SETX10TIMECLEARBATTERYTIMERS", "SETX10TIMECLEARMONITOREDSTATUS", "SENDMACROINITIATORTRIGGER", "SENDUNITCOMMAND", "SENDUNITEXTENDEDCOMMAND", "GETX10MEMORY", "GETX10DUSKDAWN", "GETX10MEMORYVERSIONSTAMP", "GETX10MEMORYPUTTOFILE", "CLEARX10MEMORY", "PUTTIMERSANDMACROSTOX10MEMORY"

                            System.Console.WriteLine("nsX10DbMethods.getX10DbController")
                            ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strControllerName As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                            strStatus = nsX10DbMethods.getX10DbController(strX10DbConnectionString, strX10DbProvider, strX10ControllerName, objX10DbController)
                            If (strStatus = "") Then

                                If (objX10DbController Is Nothing) Then
                                    strStatus = "executeOperationX10CM15A(): getX10DbController(): Controller named """ & strX10ControllerName & """ not found in X10Db."
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                Else

                                    System.Console.WriteLine("nsX10DbMethods.getX10DbUSBPort")
                                    ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                                    strStatus = nsX10DbMethods.getX10DbUSBPort(strX10DbConnectionString, strX10DbProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                                    If (strStatus = "") Then

                                        Select Case strOperation.ToUpper()
                                            Case "GETX10TRANSCEIVERSETUP", "PUTX10TRANSCEIVERSETUP", "SENDMACROINITIATORTRIGGER", "SENDUNITCOMMAND", "SENDUNITEXTENDEDCOMMAND", "GETX10MEMORY", "GETX10DUSKDAWN", "GETX10MEMORYVERSIONSTAMP", "GETX10MEMORYPUTTOFILE", "CLEARX10MEMORY", "PUTTIMERSANDMACROSTOX10MEMORY"

                                                ' This flushes USB Receive Buffer from X10 Controller.
                                                ' getX10ControllerStatusClass getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                                If (objGetX10ControllerStatusClass.status = "") Then

                                                    If (objGetX10ControllerStatusClass.retryReason.Length > 0) Then
                                                        System.Console.WriteLine("GetX10ControllerStatus(flush): retryReason=" & objGetX10ControllerStatusClass.retryReason)
                                                    End If

                                                Else
                                                    System.Console.WriteLine("GetX10ControllerStatus(flush): " & objGetX10ControllerStatusClass.status)
                                                    intExitCode = -1
                                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()
                                                objGetX10ControllerStatusClass = Nothing

                                        End Select

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If

                                End If ' END - objX10DbController Is Nothing

                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbController()

                    End Select

                    If (strStatus = "") Then

                        Select Case strOperation.ToUpper()
                            Case "GETCONTROLLERSTATUS"
                                ' getControllerStatus from CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                System.Console.WriteLine("nsX10CM15AMethods.getX10ControllerStatus")
                                ' getX10ControllerStatusClass nsX10CM15AMethods.getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                If (objGetX10ControllerStatusClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success getting CM15A Status.")

                                Else
                                    System.Console.WriteLine(objGetX10ControllerStatusClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            Case "GETX10TRANSCEIVERSETUP"
                                ' getX10TransceiverSetup from CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                System.Console.WriteLine("nsX10CM15AMethods.getX10TransceiverSetup")
                                ' getX10TransceiverSetupClass getX10TransceiverSetup(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                objGetX10TransceiverSetupClassClass = nsX10CM15AMethods.getX10TransceiverSetup(objX10DbController, objX10DbUSBPort)
                                If (objGetX10TransceiverSetupClassClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success getting Transceiver Setup.")

                                Else
                                    System.Console.WriteLine(objGetX10TransceiverSetupClassClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10TransceiverSetup()

                            Case "PUTX10TRANSCEIVERSETUP"
                                ' putX10TransceiverSetup from CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                System.Console.WriteLine("nsX10CM15AMethods.putX10TransceiverSetup")
                                ' putX10TransceiverSetupClass putX10TransceiverSetup(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, bool bClearTransceiverSetup)
                                objPutX10TransceiverSetupClassClass = nsX10CM15AMethods.putX10TransceiverSetup(objX10DbController, objX10DbUSBPort, False)
                                If (objPutX10TransceiverSetupClassClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success putting Transceiver Setup.")

                                Else
                                    System.Console.WriteLine(objPutX10TransceiverSetupClassClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.putX10TransceiverSetup()

                            Case "SETX10TIME"
                                ' setX10Time on CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                'strDateTime = "7/17/2020 6:17 AM"
                                'objDateTime = New System.DateTime
                                'objDateTime = Convert.ToDateTime(strDateTime)
                                'System.Console.WriteLine("executeOperationX10CM15A(): " & strDateTime & " (DayOfWeek=" & objDateTime.DayOfWeek & " DayOfYear=" & objDateTime.DayOfYear & ") " & objDateTime.DayOfWeek.ToString() & ", " & objDateTime.Hour & ":" & objDateTime.Minute & ":" & objDateTime.Second)
                                'objDateTime = Nothing

                                ' example: "executeOperationX10CM15A(): Set CM15A Clock to Wednesday, July 29, 2020 (DayOfWeek=3 DayOfYear=211) Wednesday, 18:39:12"
                                System.Console.WriteLine("executeOperationX10CM15A(): Set CM15A Clock to " & New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objDateTimeNow.DayOfYear - 1).ToString("dddd, MMMM dd, yyyy") & " (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") " & objDateTimeNow.DayOfWeek.ToString() & ", " & objDateTimeNow.Hour & ":" & objDateTimeNow.Minute & ":" & objDateTimeNow.Second)

                                System.Console.WriteLine("nsX10CM15AMethods.setX10Time")
                                ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "N", "N", "N")
                                If (objSetX10TimeClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success setting CM15A Clock.")

                                    System.Console.WriteLine("nsX10CM15AMethods.getX10ControllerStatus")
                                    ' getX10ControllerStatusClass nsX10CM15AMethods.getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                    objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                    If (objGetX10ControllerStatusClass.status = "") Then

                                        System.Console.WriteLine("executeOperationX10CM15A(): Success getting CM15A Status.")

                                    Else
                                        System.Console.WriteLine(objGetX10ControllerStatusClass.status)
                                        intExitCode = -1
                                    End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                                Else
                                    System.Console.WriteLine(objSetX10TimeClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            Case "SETX10TIMEPURGETIMERS"
                                ' setX10TimePurgeTimers on CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                'strDateTime = "7/17/2020 6:17 AM"
                                'objDateTime = New System.DateTime
                                'objDateTime = Convert.ToDateTime(strDateTime)
                                'System.Console.WriteLine("executeOperationX10CM15A(): " & strDateTime & " (DayOfWeek=" & objDateTime.DayOfWeek & " DayOfYear=" & objDateTime.DayOfYear & ") " & objDateTime.DayOfWeek.ToString() & ", " & objDateTime.Hour & ":" & objDateTime.Minute & ":" & objDateTime.Second)
                                'objDateTime = Nothing

                                ' example: "executeOperationX10CM15A(): Purge Timers and Set CM15A Clock to (DayOfWeek=0 DayOfYear=187) Sunday, 17:39:32"
                                System.Console.WriteLine("executeOperationX10CM15A(): Purge Timers and Set CM15A Clock to (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") " & objDateTimeNow.DayOfWeek.ToString() & ", " & objDateTimeNow.Hour & ":" & objDateTimeNow.Minute & ":" & objDateTimeNow.Second)

                                System.Console.WriteLine("nsX10CM15AMethods.setX10Time")
                                ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "Y", "N", "N")
                                If (objSetX10TimeClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success setting CM15A Clock.")

                                Else
                                    System.Console.WriteLine(objSetX10TimeClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            Case "SETX10TIMECLEARBATTERYTIMERS"
                                ' setX10TimeClearBatteryTimers on CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                'strDateTime = "7/17/2020 6:17 AM"
                                'objDateTime = New System.DateTime
                                'objDateTime = Convert.ToDateTime(strDateTime)
                                'System.Console.WriteLine("executeOperationX10CM15A(): " & strDateTime & " (DayOfWeek=" & objDateTime.DayOfWeek & " DayOfYear=" & objDateTime.DayOfYear & ") " & objDateTime.DayOfWeek.ToString() & ", " & objDateTime.Hour & ":" & objDateTime.Minute & ":" & objDateTime.Second)
                                'objDateTime = Nothing

                                ' example: "executeOperationX10CM15A(): Clear Battery Timers and Set CM15A Clock to (DayOfWeek=0 DayOfYear=187) Sunday, 17:39:32"
                                System.Console.WriteLine("executeOperationX10CM15A(): Clear Battery Timers and Set CM15A Clock to (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") " & objDateTimeNow.DayOfWeek.ToString() & ", " & objDateTimeNow.Hour & ":" & objDateTimeNow.Minute & ":" & objDateTimeNow.Second)

                                System.Console.WriteLine("nsX10CM15AMethods.setX10Time")
                                ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "N", "Y", "N")
                                If (objSetX10TimeClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success setting CM15A Clock.")

                                Else
                                    System.Console.WriteLine(objSetX10TimeClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            Case "SETX10TIMECLEARMONITOREDSTATUS"
                                ' setX10TimeClearMonitoredStatus on CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                'strDateTime = "7/17/2020 6:17 AM"
                                'objDateTime = New System.DateTime
                                'objDateTime = Convert.ToDateTime(strDateTime)
                                'System.Console.WriteLine("executeOperationX10CM15A(): " & strDateTime & " (DayOfWeek=" & objDateTime.DayOfWeek & " DayOfYear=" & objDateTime.DayOfYear & ") " & objDateTime.DayOfWeek.ToString() & ", " & objDateTime.Hour & ":" & objDateTime.Minute & ":" & objDateTime.Second)
                                'objDateTime = Nothing

                                ' example: "executeOperationX10CM15A(): Clear Monitored Status and Set CM15A Clock to (DayOfWeek=0 DayOfYear=187) Sunday, 17:39:32"
                                System.Console.WriteLine("executeOperationX10CM15A(): Clear Monitored Status and Set CM15A Clock to (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") " & objDateTimeNow.DayOfWeek.ToString() & ", " & objDateTimeNow.Hour & ":" & objDateTimeNow.Minute & ":" & objDateTimeNow.Second)

                                System.Console.WriteLine("nsX10CM15AMethods.setX10Time")
                                ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "N", "N", "Y")
                                If (objSetX10TimeClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success setting CM15A Clock.")

                                Else
                                    System.Console.WriteLine(objSetX10TimeClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            Case "SENDMACROINITIATORTRIGGER"
                                ' sendMacroInitiatorTrigger to CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                Select Case strOnOff.ToUpper()
                                    Case "OFF"
                                        intUnitOnOff = 0
                                    Case "ON"
                                        intUnitOnOff = 1
                                End Select

                                System.Console.WriteLine("nsX10CM15AMethods.sendMacroInitiatorTrigger")
                                ' sendMacroInitiatorTriggerClass sendMacroInitiatorTrigger(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strX10DbConnectionString, string strX10DbProvider, string strUnitHouseCodeLetter, string strUnitModuleCode, int intUnitOnOff)
                                objSendMacroInitiatorTriggerClass = nsX10CM15AMethods.sendMacroInitiatorTrigger(objX10DbController, objX10DbUSBPort, strX10DbConnectionString, strX10DbProvider, strHouseCode, strModuleCode, intUnitOnOff)
                                If (objSendMacroInitiatorTriggerClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success sending MacroInitiator Trigger to X10 Controller.")
                                    System.Console.WriteLine("    Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]")
                                    System.Console.WriteLine("    Trigger: " & objSendMacroInitiatorTriggerClass.unitHouseCodeLetter & objSendMacroInitiatorTriggerClass.unitModuleCode)

                                    Select Case objSendMacroInitiatorTriggerClass.unitOnOff
                                        Case 0
                                            System.Console.WriteLine("    Function: Off")
                                        Case 1
                                            System.Console.WriteLine("    Function: On")
                                    End Select

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.sendMacroInitiatorTrigger()

                            Case "SENDUNITCOMMAND", "SENDUNITEXTENDEDCOMMAND"
                                ' sendUnitCommand to CM15A Controller.
                                ' sendUnitExtendedCommand to CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                System.Console.WriteLine("nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues")
                                ' nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(ByVal strDimmer As String, ByVal strOnOff As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer) As String
                                strStatus = nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(strDimmer, strOnOff, intUnitOnOff, intUnitLevel)
                                If (strStatus = "") Then

                                    Select Case strStandardExtended.ToUpper()
                                        Case "S"
                                            bytExtendedData = 0
                                            bytExtendedCommand = 0
                                        Case "E"

                                            If (strExtendedData = "") Then
                                                bytExtendedData = 0
                                            Else
                                                bytExtendedData = CType(strExtendedData, Byte)
                                            End If

                                            If (strExtendedCommand = "") Then
                                                bytExtendedCommand = 0
                                            Else
                                                bytExtendedCommand = CType(strExtendedCommand, Byte)
                                            End If

                                    End Select

                                    System.Console.WriteLine("nsX10CM15AMethods.sendUnitCommand")
                                    ' sendUnitCommandClass sendUnitCommand(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strX10DbConnectionString, string strX10DbProvider, string strStandardExtended, string strUnitHouseCodeLetter, string strUnitModuleCode, string strUnitDimmerYN, string strBrightenDim, int intUnitOnOff, int intUnitLevel, byte bytExtendedData, byte bytExtendedCommand)
                                    objSendUnitCommandClass = nsX10CM15AMethods.sendUnitCommand(objX10DbController, objX10DbUSBPort, strX10DbConnectionString, strX10DbProvider, strStandardExtended, strHouseCode, strModuleCode, strDimmer, strBrightenDim, intUnitOnOff, intUnitLevel, bytExtendedData, bytExtendedCommand)
                                    If (objSendUnitCommandClass.status = "") Then

                                        System.Console.WriteLine("executeOperationX10CM15A(): Success sending Unit Command to X10 Controller.")
                                        System.Console.WriteLine("    Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]")
                                        System.Console.WriteLine("    Standard/Extended: " & objSendUnitCommandClass.standardExtended)
                                        System.Console.WriteLine("    UnitHouseCode: " & objSendUnitCommandClass.unitHouseCodeLetter)
                                        System.Console.WriteLine("    UnitModuleCode: " & objSendUnitCommandClass.unitModuleCode)

                                        Select Case strStandardExtended.ToUpper()
                                            Case "S"
                                                Select Case strDimmer.ToUpper()
                                                    Case "Y"
                                                        Select Case strOnOff.ToUpper()
                                                            Case "ON", "OFF"
                                                                System.Console.WriteLine("    Set Dimmer Module to " & strOnOff)
                                                            Case Else

                                                                Select Case strBrightenDim.ToUpper()
                                                                    Case "B"
                                                                        System.Console.WriteLine("    Set Dimmer Module to BRIGHT " & strOnOff)
                                                                    Case "D"
                                                                        System.Console.WriteLine("    Set Dimmer Module to DIM " & strOnOff)
                                                                    Case Else
                                                                        System.Console.WriteLine("    Set Dimmer Module to " & strOnOff)
                                                                End Select

                                                        End Select

                                                    Case "N"
                                                        System.Console.WriteLine("    Set Switch Module to " & strOnOff)
                                                End Select
                                            Case "E"
                                                ' x10ExtendedCommand getX10ExtendedCommandFromCode(byte byteCommandCode)
                                                objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(bytExtendedCommand)

                                                System.Console.WriteLine("    ExtendedCommand=0x" + bytExtendedCommand.ToString("X02").ToLower())
                                                System.Console.WriteLine("    Extended Command Description: " & objX10ExtendedCommand.commandDescription)
                                                System.Console.WriteLine("    ExtendedData=0x" + bytExtendedData.ToString("X02").ToLower())
                                        End Select

                                        If (Not objSendUnitCommandClass.objSendAddressCommandPowerLineClass Is Nothing AndAlso objSendUnitCommandClass.objSendFunctionCommandPowerLineClasses.Count > 0) Then

                                            If (objSendUnitCommandClass.objSendAddressCommandPowerLineClass.retryReason <> "") Then
                                                System.Console.WriteLine("    sendAddressCommandPowerLineClass.retryReason[" & nsX10CM15AMethods.x10BinaryValueToHouseCode(objSendUnitCommandClass.objSendAddressCommandPowerLineClass.unitHouseCode) & nsX10CM15AMethods.x10BinaryValueToDeviceCode(objSendUnitCommandClass.objSendAddressCommandPowerLineClass.unitModuleCode) & "]: " & objSendUnitCommandClass.objSendAddressCommandPowerLineClass.retryReason)
                                            End If

                                            For Each objSendFunctionCommandPowerLineClass In objSendUnitCommandClass.objSendFunctionCommandPowerLineClasses

                                                System.Console.WriteLine("")
                                                System.Console.WriteLine("    Function/Command Codes:")
                                                System.Console.WriteLine("      Function Code: 0x" & objSendFunctionCommandPowerLineClass.unitFunctionCode.ToString("X02").ToLower())
                                                System.Console.WriteLine("      Function Name: " & nsX10CM15AMethods.x10FunctionCodeToString(objSendFunctionCommandPowerLineClass.unitFunctionCode))
                                                Select Case objSendUnitCommandClass.standardExtended.ToUpper()
                                                    Case "S"
                                                        If (strDimmer.ToUpper() = "Y") Then
                                                            System.Console.WriteLine("    Previous saved Command: " & objSendFunctionCommandPowerLineClass.previousUnitLastCommand)
                                                            System.Console.WriteLine("    Previous saved Bright/Dim Ammount: " & objSendFunctionCommandPowerLineClass.previousUnitLastBrightDimAmount.ToString() & " = 0x" & objSendFunctionCommandPowerLineClass.previousUnitLastBrightDimAmount.ToString("X02").ToLower())
                                                            System.Console.WriteLine("    Specified Dim Amount: " & objSendUnitCommandClass.dimAmount.ToString() & " = 0x" & objSendUnitCommandClass.dimAmount.ToString("X02").ToLower())
                                                            System.Console.WriteLine("    Bright/Dim Amount sent to Unit: " & objSendFunctionCommandPowerLineClass.unitBrightDimAmount.ToString() & " = 0x" & objSendFunctionCommandPowerLineClass.unitBrightDimAmount.ToString("X02").ToLower())
                                                            System.Console.WriteLine("    New saved Command: " & objSendFunctionCommandPowerLineClass.newUnitLastCommand)
                                                            System.Console.WriteLine("    New saved Bright/Dim Ammount: " & objSendFunctionCommandPowerLineClass.newUnitLastBrightDimAmount.ToString() & " = 0x" & objSendFunctionCommandPowerLineClass.newUnitLastBrightDimAmount.ToString("X02").ToLower())
                                                        End If
                                                    Case "E"
                                                        ' x10ExtendedCommand getX10ExtendedCommandFromCode(byte byteCommandCode)
                                                        objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(objSendFunctionCommandPowerLineClass.unitExtendedCommand)

                                                        System.Console.WriteLine("    Extended Command: 0x" & objSendFunctionCommandPowerLineClass.unitExtendedCommand.ToString("X02").ToLower())
                                                        System.Console.WriteLine("    Extended Command Description: " & objX10ExtendedCommand.commandDescription)
                                                        System.Console.WriteLine("    Extended Data: 0x" & objSendFunctionCommandPowerLineClass.unitExtendedData.ToString("X02").ToLower())
                                                End Select

                                                If (objSendFunctionCommandPowerLineClass.retryReason <> "") Then
                                                    System.Console.WriteLine("    sendFunctionCommandPowerLine.retryReason: " & objSendFunctionCommandPowerLineClass.retryReason)
                                                End If

                                            Next ' END - ForEachObjectSendFunctionCommandPowerLineClasses.Count

                                        Else
                                            System.Console.WriteLine("")
                                            System.Console.WriteLine("No Operation Sending Powerline Command.")
                                        End If ' END - CheckForNOOP

                                    Else
                                        System.Console.WriteLine(objSendUnitCommandClass.status)
                                        intExitCode = -1
                                    End If ' END - nsX10CM15AMethods.sendUnitCommand()

                                Else
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If ' END - nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues()

                            Case "GETX10MEMORY"
                                ' getX10Memory from the CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                If (strMemoryAddrLow = "") Then
                                    bytStartAddressLow = 0
                                Else
                                    bytStartAddressLow = CType(strMemoryAddrLow, Byte)
                                End If

                                If (strMemoryAddrHigh = "") Then
                                    bytStartAddressHigh = 0
                                Else
                                    bytStartAddressHigh = CType(strMemoryAddrHigh, Byte)
                                End If

                                System.Console.WriteLine("nsX10CM15AMethods.getX10Memory")
                                ' getX10MemoryClass getX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, byte bytStartAddressLow, byte bytStartAddressHigh)
                                objGetX10MemoryClass = nsX10CM15AMethods.getX10Memory(objX10DbController, objX10DbUSBPort, bytStartAddressLow, bytStartAddressHigh)
                                If (objGetX10MemoryClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success getting CM15A Memory.")

                                    If (objGetX10MemoryClass.retryReason <> "") Then
                                        System.Console.WriteLine("    getX10MemoryClass.retryReason: " & objGetX10MemoryClass.retryReason)
                                    End If

                                Else
                                    System.Console.WriteLine(objGetX10MemoryClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10Memory()

                            Case "GETX10DUSKDAWN"
                                ' getX10DuskDawn information from the CM15A Controller.

                                System.Console.WriteLine("nsX10CM15AMethods.getX10DuskDawn")
                                ' getX10DuskDawnClass getX10DuskDawn(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                objGetX10DuskDawnClass = nsX10CM15AMethods.getX10DuskDawn(objX10DbController, objX10DbUSBPort)
                                If (objGetX10DuskDawnClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success with CM15A get Dusk Dawn information.")

                                Else
                                    System.Console.WriteLine(objGetX10DuskDawnClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10DuskDawn()

                            Case "GETX10MEMORYVERSIONSTAMP"
                                ' getX10MemoryVersionStamp information from the CM15A Controller.

                                System.Console.WriteLine("nsX10CM15AMethods.getX10MemoryVersionStamp")
                                ' getX10MemoryVersionStampClass getX10MemoryVersionStamp(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                objGetX10MemoryVersionStampClass = nsX10CM15AMethods.getX10MemoryVersionStamp(objX10DbController, objX10DbUSBPort)
                                If (objGetX10MemoryVersionStampClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success with CM15A get Memory Version Stamp information.")

                                Else
                                    System.Console.WriteLine(objGetX10MemoryVersionStampClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10MemoryVersionStamp()

                            Case "GETX10MEMORYPUTTOFILE"
                                ' getX10MemoryPutToFile from the CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                System.Console.WriteLine("nsX10CM15AMethods.getX10MemoryPutToFile")
                                ' getX10MemoryPutToFileClass getX10MemoryPutToFile(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strFilename)
                                objGetX10MemoryPutToFileClass = nsX10CM15AMethods.getX10MemoryPutToFile(objX10DbController, objX10DbUSBPort, strFilename)
                                If (objGetX10MemoryPutToFileClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success with CM15A Memory Put to file " & strFilename)

                                Else
                                    System.Console.WriteLine(objGetX10MemoryPutToFileClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10MemoryPutToFile()

                            Case "CLEARX10MEMORY"
                                ' clearX10Memory in CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                ' example: "executeOperationX10CM15A(): Purge Timers and Set CM15A Clock to (DayOfWeek=0 DayOfYear=187) Sunday, 17:39:32"
                                System.Console.WriteLine("executeOperationX10CM15A(): Purge Timers, Clear Monitored Status and Set CM15A Clock to (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") " & objDateTimeNow.DayOfWeek.ToString() & ", " & objDateTimeNow.Hour & ":" & objDateTimeNow.Minute & ":" & objDateTimeNow.Second)

                                System.Console.WriteLine("nsX10CM15AMethods.setX10Time")
                                ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "Y", "N", "Y")
                                If (objSetX10TimeClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success setting CM15A Clock.")

                                    System.Console.WriteLine("nsX10CM15AMethods.putToX10Memory")
                                    ' putToX10MemoryClass putToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, double dblLatitude, double dblLongitude, string strScheduleName, int intScheduleID, string strX10DbConnectionString, string strX10DbProvider, bool bClearOnly)
                                    objPutToX10MemoryClass = nsX10CM15AMethods.putToX10Memory(objX10DbController, objX10DbUSBPort, CType(objX10DbSetting.latitude, Double), CType(objX10DbSetting.longitude, Double), strScheduleName, intScheduleID, strX10DbConnectionString, strX10DbProvider, True)
                                    If (objPutToX10MemoryClass.status = "") Then

                                        System.Console.WriteLine("nsX10CM15AMethods.verifyPutToX10Memory")
                                        ' verifyPutToX10MemoryClass verifyPutToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, ref putToX10MemoryClass objPutToX10MemoryClass, bool bClearOnly, string strFilename)
                                        objVerifyPutToX10MemoryClass = nsX10CM15AMethods.verifyPutToX10Memory(objX10DbController, objX10DbUSBPort, objPutToX10MemoryClass, True, strFilename)
                                        If (objVerifyPutToX10MemoryClass.status = "") Then

                                            System.Console.WriteLine("executeOperationX10CM15A(): Success with clear CM15A Memory.")

                                        Else
                                            System.Console.WriteLine(objVerifyPutToX10MemoryClass.status)
                                            intExitCode = -1
                                        End If ' END - verifyPutToX10Memory()

                                    Else
                                        System.Console.WriteLine(objPutToX10MemoryClass.status)
                                        intExitCode = -1
                                    End If ' END - nsX10CM15AMethods.putToX10Memory()

                                Else
                                    System.Console.WriteLine(objSetX10TimeClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            Case "PUTTIMERSANDMACROSTOX10MEMORY"
                                ' putTimersAndMacrosToX10Memory in CM15A Controller.
                                System.Console.WriteLine("executeOperationX10CM15A(): " & strOperation)

                                ' example: "executeOperationX10CM15A(): Purge Timers and Set CM15A Clock to (DayOfWeek=0 DayOfYear=187) Sunday, 17:39:32"
                                System.Console.WriteLine("executeOperationX10CM15A(): Purge Timers and Set CM15A Clock to (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") " & objDateTimeNow.DayOfWeek.ToString() & ", " & objDateTimeNow.Hour & ":" & objDateTimeNow.Minute & ":" & objDateTimeNow.Second)

                                System.Console.WriteLine("nsX10CM15AMethods.setX10Time")
                                ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "Y", "N", "N")
                                If (objSetX10TimeClass.status = "") Then

                                    System.Console.WriteLine("executeOperationX10CM15A(): Success setting CM15A Clock.")

                                    System.Console.WriteLine("nsX10DbMethods.putX10DbSunTimes")
                                    ' intX10SunriseTime and intX10SunsetTime as minutes after Midnight.
                                    ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                                    strStatus = nsX10DbMethods.putX10DbSunTimes(strX10DbConnectionString, strX10DbProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                                    If (strStatus = "") Then

                                        System.Console.WriteLine("nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db")
                                        ' nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByRef intTimersCompiled As Integer) As String
                                        strStatus = nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(strX10DbConnectionString, strX10DbProvider, intTimersCompiled)
                                        If (strStatus = "") Then

                                            If (intTimersCompiled > 0) Then

                                                System.Console.WriteLine("nsX10CM15AMethods.putToX10Memory")
                                                ' putToX10MemoryClass putToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, double dblLatitude, double dblLongitude, string strScheduleName, int intScheduleID, string strX10DbConnectionString, string strX10DbProvider, bool bClearOnly)
                                                objPutToX10MemoryClass = nsX10CM15AMethods.putToX10Memory(objX10DbController, objX10DbUSBPort, CType(objX10DbSetting.latitude, Double), CType(objX10DbSetting.longitude, Double), "", -1, strX10DbConnectionString, strX10DbProvider, False)
                                                If (objPutToX10MemoryClass.status = "") Then

                                                    System.Console.WriteLine("nsX10CM15AMethods.verifyPutToX10Memory")
                                                    ' verifyPutToX10MemoryClass verifyPutToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, ref putToX10MemoryClass objPutToX10MemoryClass, bool bClearOnly, string strFilename)
                                                    objVerifyPutToX10MemoryClass = nsX10CM15AMethods.verifyPutToX10Memory(objX10DbController, objX10DbUSBPort, objPutToX10MemoryClass, False, strFilename)
                                                    If (objVerifyPutToX10MemoryClass.status = "") Then

                                                        System.Console.WriteLine("executeOperationX10CM15A(): Success with put Timers and Macros to CM15A Memory.")

                                                    Else
                                                        System.Console.WriteLine(objVerifyPutToX10MemoryClass.status)
                                                        intExitCode = -1
                                                    End If ' END - verifyPutToX10Memory()

                                                Else
                                                    System.Console.WriteLine(objPutToX10MemoryClass.status)
                                                    intExitCode = -1
                                                End If ' END - nsX10CM15AMethods.putToX10Memory()

                                            Else
                                                System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): No Events were found for Controller """ & objX10DbController.ControllerName & """.")
                                                System.Console.WriteLine("compileTimersFromX10DbEventsPlaceInX10Db(): This can be caused by No Active Schedules with Events using Scenes that include Modules attached to this Controller.")
                                                intExitCode = -1
                                            End If

                                        Else
                                            System.Console.WriteLine(strStatus)
                                            intExitCode = -1
                                        End If ' END - nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db()

                                    Else
                                        System.Console.WriteLine(strStatus)
                                        intExitCode = -1
                                    End If ' END - nsX10DbMethods.putX10DbSunTimes()

                                Else
                                    System.Console.WriteLine(objSetX10TimeClass.status)
                                    intExitCode = -1
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            Case Else
                                strStatus = "executeOperationX10CM15A(): Unknown Operation=""" & strOperation & """ was specified."
                                System.Console.WriteLine("executeOperationX10CM15A(): Unknown Operation=""" & strOperation & """ was specified.")
                                intExitCode = -1
                        End Select

                    End If ' End - If strStatus = ""

                Catch ex As Exception
                    strError = "executeOperationX10CM15A(): Exception: Operation=""" & strOperation & """: " & ex.Message.ToString()
                    If (strStatus.Length = 0) Then
                        strStatus = strError
                    Else
                        strStatus &= vbCRLF & strError
                    End If
                    System.Console.WriteLine(strError)
                    intExitCode = -1
                Finally
                    objSetX10TimeClass = Nothing
                    objGetX10ControllerStatusClass = Nothing
                    objGetX10TransceiverSetupClassClass = Nothing
                    objPutX10TransceiverSetupClassClass = Nothing
                    objSendMacroInitiatorTriggerClass = Nothing
                    objSendUnitCommandClass = Nothing
                    objX10ExtendedCommand = Nothing
                    objSendFunctionCommandPowerLineClass = Nothing
                    objGetX10MemoryClass = Nothing
                    objGetX10DuskDawnClass = Nothing
                    objGetX10MemoryVersionStampClass = Nothing
                    objPutToX10MemoryClass = Nothing
                    objVerifyPutToX10MemoryClass = Nothing
                    objX10DbUSBPort = Nothing
                    objX10DbController = Nothing
                    objDateTimeNow = Nothing
                End Try

                Return strStatus

            End Function ' END - executeOperationX10CM15A()

            '=====================================================================================
            ' Function executeOperationX10WM100()
            ' Alan Wagner
            '
            Public Function executeOperationX10WM100(ByVal strOperation As String, ByVal strGuid As String, ByVal strScheduleName As String, ByVal strHouseCode As String, ByVal strModuleCode As String, ByVal strDimmer As String, ByVal strOnOff As String, ByRef objTimeZone As TrekkerPhotoArt.X10Include.TimeZone, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strX10ControllerType As String, ByVal strX10ControllerName As String, ByRef intExitCode As Integer) As String
                Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods
                Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

                Dim strStatus As String = ""
                Dim strError As String = ""

                Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

                Dim objDateTimeNow As System.DateTime = System.DateTime.Now

                Try

                    ' Get Controller Information
                    Select Case strOperation.ToUpper()
                        Case "SETX10TIME", "GETCONTROLLERSTATUS"

                            System.Console.WriteLine("nsX10DbMethods.getX10DbController")
                            ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strControllerName As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                            strStatus = nsX10DbMethods.getX10DbController(strX10DbConnectionString, strX10DbProvider, strX10ControllerName, objX10DbController)
                            If (strStatus = "") Then

                                If (objX10DbController Is Nothing) Then
                                    strStatus = "executeOperationX10WM100(): getX10DbController(): Controller named """ & strX10ControllerName & """ not found in X10Db."
                                    System.Console.WriteLine(strStatus)
                                    intExitCode = -1
                                End If
                            Else
                                System.Console.WriteLine(strStatus)
                                intExitCode = -1
                            End If ' END - nsX10DbMethods.getX10DbController()

                    End Select

                    If (strStatus = "") Then

                        Select Case strOperation.ToUpper()
                            Case "SETX10TIME"
                                ' setX10Time
                                System.Console.WriteLine("executeOperationX10WM100(): " & strOperation)

                            Case "GETCONTROLLERSTATUS"
                                ' getControllerStatus
                                System.Console.WriteLine("executeOperationX10WM100(): " & strOperation)

                            Case Else
                                strStatus = "executeOperationX10WM100(): Unknown Operation=""" & strOperation & """ was specified."
                                System.Console.WriteLine("executeOperationX10WM100(): Unknown Operation=""" & strOperation & """ was specified.")
                                intExitCode = -1
                        End Select

                    End If ' End - If strStatus = ""

                Catch ex As Exception
                    strError = "executeOperationX10WM100(): Exception: Operation=""" & strOperation & """: " & ex.Message.ToString()
                    If (strStatus.Length = 0) Then
                        strStatus = strError
                    Else
                        strStatus &= vbCRLF & strError
                    End If
                    System.Console.WriteLine(strError)
                    intExitCode = -1
                Finally
                    objX10DbController = Nothing
                    objDateTimeNow = Nothing
                End Try

                Return strStatus

            End Function ' END - executeOperationX10WM100()

        End Class ' END - Class MainMethods
#End Region ' END Region - MainMethods

#Region "ParseCmdLineMethods"
        Public Class ParseCmdLineMethods

            '=====================================================================================
            ' Function ParseCommandLine()
            ' Alan Wagner
            '
            ' Command line arguments are passed into Visual Basic by way of the Command$ variable.
            ' This variable is a very long string with all the arguments written exactly as the user entered them.
            ' It does not include the .exe being executed.
            '
            Public Function ParseCmdLine(ByRef strCommandLine As String, ByRef strOperation As String, ByRef strFilename As String, ByRef strX10ControllerName As String, ByRef strX10ControllerType As String, ByRef strX10ControllerDescription As String, ByRef strEnabled As String, ByRef strScheduleName As String, ByRef strSceneName As String, ByRef strHouseCode As String, ByRef strModuleCode As String, ByRef strBrighten As String, ByRef strDimmer As String, ByRef strOnOff As String, ByRef strStandardExtended As String, ByRef strExtendedData As String, ByRef strExtendedCommand As String, ByRef strMemoryAddrLow As String, ByRef strMemoryAddrHigh As String, ByRef strTransceiverHouseCodes As String, ByRef strDuskDawnResolution As String, ByRef strPort As String, ByRef strHub As String, ByRef strAppKey As String, ByRef strUID As String) As String
                Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods

                Dim strStatus As String = ""
                Dim strTryStep As String = ""

                Dim arrArgumentArray() As String
                Dim arrPropertyArray() As String
                Dim arrPropertyValueArray() As String
                Dim strFlag As String = ""
                Dim i As Integer = 0
                Dim j As Integer = 0

                Try
                    strTryStep = "Initialize"

                    ' Seperate the fields in the CSV record.
                    ' Where Delimiter and Text Qualifier:
                    '    pipe  = | = 124 decimal
                    '    quote = " =  34 decimal
                    '    comma = , =  44 decimal
                    ' nsStringMethods.splitString( strStringIn, strDelimiter, strTextQualifier, intCompare )
                    arrArgumentArray = nsStringMethods.splitString(strCommandLine.Replace(Chr(9), Chr(32)).Trim(), " ", """", vbTextCompare)

                    strFlag = arrArgumentArray(0)

                    strOperation = ""
                    strFilename = ""
                    strX10ControllerType = ""
                    strX10ControllerName = ""
                    strX10ControllerDescription = ""
                    strEnabled = ""
                    strScheduleName = ""
                    strSceneName = ""
                    strHouseCode = ""
                    strModuleCode = ""
                    strBrighten = ""
                    strDimmer = ""
                    strOnOff = ""
                    strStandardExtended = ""
                    strExtendedData = ""
                    strExtendedCommand = ""
                    strMemoryAddrLow = ""
                    strMemoryAddrHigh = ""
                    strTransceiverHouseCodes = ""
                    strDuskDawnResolution = ""
                    strPort = ""
                    strHub = ""
                    strAppKey = ""
                    strUID = ""

                    ReDim arrPropertyArray(0)
                    arrPropertyArray(0) = ""

                    ReDim arrPropertyValueArray(0)
                    arrPropertyValueArray(0) = ""

                    strTryStep = "CheckFlag"
                    ' 1st see if help is needed
                    If (strFlag = "help") Or (strFlag = "/h") Or (strFlag = "\h") Or (strFlag = "-h") Or (strFlag.Length = 0) _
                    Or (strFlag = "\?") Or (strFlag = "/?") Or (strFlag = "?") Or (strFlag = "h") Or (strFlag = "/") _
                    Or (arrArgumentArray.Length < 1) Then
                        strStatus = "ParseCmdLine(): Arguments are missing."
                        strStatus &= vbCRLF & "X10Manager.exe /O:Operation" &
                                    vbCRLF & "Operations common to all Controllers" &
                                    vbCRLF & "  [addX10ControllerToX10Db|backupX10Db|compileTimersFromX10DbEventsPlaceInX10Db|" &
                                    vbCRLF & "  createX10DbTables|createX10DbTableTimers|downloadEventsToActiveControllers|exportModulesFromX10Db|" &
                                    vbCRLF & "  getControllerStatus|getX10MemoryPutToFile|getSerialPortsPutX10Db|getUSBPortsPutX10Db|" &
                                    vbCRLF & "  importModulesToX10Db|putX10DbSunTimes|restoreX10Db|" &
                                    vbCRLF & "  sendAllLightsOff|sendAllLightsOn|sendAllUnitsOff|sendAllUnitsOn|sendSceneUnitCommands|" &
                                    vbCRLF & "  sendUnitCommand|setX10Time|updateX10ControllerToX10Db]" &
                                    vbCRLF & "CM15A Controller specific Operations" &
                                    vbCRLF & "  [clearX10Memory|getX10DuskDawn|getX10MemoryVersionStamp|" &
                                    vbCRLF & "  getX10TransceiverSetup|putX10TransceiverSetup|putTimersAndMacrosToX10Memory|sendUnitExtendedCommand|" &
                                    vbCRLF & "  setX10TimeClearBatteryTimers|setX10TimeClearMonitoredStatus|setX10TimePurgeTimers]" &
                                    vbCRLF & "CP290 Controller specific Operations" &
                                    vbCRLF & "  [compareX10TimersToX10Db|downloadX10BaseHousecode|getX10DbTimersPutX10|getX10TimersPutX10Db|resetSunriseSunsetTimerTimes]" &
                                    vbCRLF & "/F:Filename" &
                                    vbCRLF & "/N:X10ControllerName" &
                                    vbCRLF & "/T:X10ControllerType [CP290|CM15A|WM100]" &
                                    vbCRLF & "/D:X10ControllerDescription" &
                                    vbCRLF & "/E:Enabled [Y/N]" &
                                    vbCRLF & "/P:Port [COMn| for USB ex: ""0003"" |WIFI]" &
                                    vbCRLF & "/B:Hub [for USB ex: ""0004""]" &
                                    vbCRLF & "/A:AppKey [ex: ""26d884ce-9f25-948537""]" &
                                    vbCRLF & "/U:UID [ex: ""Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u""]" &
                                    vbCRLF & "/S:ScheduleName" &
                                    vbCRLF & "/C:SceneName" &
                                    vbCRLF & "/H:HouseCode [A|B|C|D|E|F|G|H|I|J|K|L|M|N|O|P]" &
                                    vbCRLF & "/M:ModuleCode [comma delimited List within double quotes of numbers 1-16. ex: ""1,3,5,7,9,16"" or just a code ex: ""10""]" &
                                    vbCRLF & "/1:Dimmer [Y]" &
                                    vbCRLF & "  /2:OnOff [Off|On|100|94|88|81|75|69|63|56|50|44|38|31|25|19|13|6]" &
                                    vbCRLF & "  /0:BrightenDim [B|D] (B=Brighten, D=Dim) If BrightenDim not specified, Dimmer Module will pre-brighten then Dim.  Note: CP290 is not supported" &
                                    vbCRLF & "/1:Dimmer [N]" &
                                    vbCRLF & "  /2:OnOff [Off|On]" &
                                    vbCRLF & "/3:StandardExtended [S|E] (S=Standard transmission, E=Extended transmission)" &
                                    vbCRLF & "/4:ExtendedData [Extended transmission Data byte as string]" &
                                    vbCRLF & "/5:ExtendedCommand [Extended transmission Command byte as string]" &
                                    vbCRLF & "/6:MemoryAddrLow [byte as string]" &
                                    vbCRLF & "/7:MemoryAddrHigh [byte as string]" &
                                    vbCRLF & "/8:TransceiverHouseCodes [comma delimited List within double quotes of House Codes. ex: ""A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P""]" &
                                    vbCRLF & "/9:DuskDawnResolution [dusk/dawn resolution in Days as number. Use multiples of 8.  ex: For every 8 Days, enter ""8""]"
                    Else

                        strTryStep = "GetArguments"
                        j = 0
                        For i = 0 To arrArgumentArray.Length - 1 Step 1
                            System.Console.WriteLine("ParseCmdLine(): ArgumentArray(" & i.ToString() & ")=""" & arrArgumentArray(i) & """")

                            strTryStep = "GetArguments" & i.ToString

                            If (Microsoft.VisualBasic.InStr(1, arrArgumentArray(i), ":", vbTextCompare) > 1) Then

                                strFlag = Microsoft.VisualBasic.Left(arrArgumentArray(i), Microsoft.VisualBasic.InStr(1, arrArgumentArray(i), ":", vbTextCompare) - 1)

                                ' Chr(34) - " - Double Quotes
                                Select Case strFlag.ToLower()
                                    Case "/o"
                                        strOperation = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/f"
                                        strFilename = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/n"
                                        strX10ControllerName = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/t"
                                        strX10ControllerType = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/d"
                                        strX10ControllerDescription = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/e"
                                        strEnabled = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/s"
                                        strScheduleName = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/c"
                                        strSceneName = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/h"
                                        strHouseCode = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/m"
                                        strModuleCode = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/0"
                                        strBrighten = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/1"
                                        strDimmer = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/2"
                                        strOnOff = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/3"
                                        strStandardExtended = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/4"
                                        strExtendedData = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/5"
                                        strExtendedCommand = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/6"
                                        strMemoryAddrLow = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/7"
                                        strMemoryAddrHigh = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/8"
                                        strTransceiverHouseCodes = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/9"
                                        strDuskDawnResolution = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/p"
                                        strPort = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/b"
                                        strHub = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "").ToUpper()
                                    Case "/a"
                                        strAppKey = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case "/u"
                                        strUID = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - 3).Replace(Chr(34), "")
                                    Case Else
                                        ReDim Preserve arrPropertyArray(j), arrPropertyValueArray(j)
                                        arrPropertyArray(j) = strFlag
                                        arrPropertyValueArray(j) = Microsoft.VisualBasic.Right(arrArgumentArray(i), arrArgumentArray(i).Length - Microsoft.VisualBasic.InStr(1, arrArgumentArray(i), ":"))
                                        If (arrPropertyValueArray(j).Length = 0) Then
                                            strStatus = "ParseCmdLine(): Property """ & strFlag & """ does not have a value."
                                        Else
                                            strStatus = "ParseCmdLine(): Unknown Property """ & strFlag & """"
                                        End If
                                        j = j + 1
                                End Select

                            Else
                                strStatus = "ParseCmdLine(): Property """ & arrArgumentArray(i) & """ does not have a value delimiter "":"""
                            End If

                        Next

                    End If

                Catch ex As Exception
                    If (strStatus.Length = 0) Then
                        strStatus = "ParseCmdLine(" & strTryStep & "): Exception: " & ex.Message
                    Else
                        strStatus &= vbCRLF & "ParseCmdLine(" & strTryStep & "): Exception: " & ex.Message
                    End If
                End Try

                Return strStatus

            End Function ' END - ParseCmdLine()

        End Class ' END Class - ParseCmdLineMethods
#End Region ' END Region - ParseCmdLineMethods

    End Class ' END - Class RunApplication

End Namespace ' END - Namespace TrekkerPhotoArt