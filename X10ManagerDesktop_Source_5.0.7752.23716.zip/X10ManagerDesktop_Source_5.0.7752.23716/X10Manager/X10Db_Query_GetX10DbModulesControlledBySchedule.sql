--X10Db_Query_GetX10DbModulesControlledBySchedule.sql
--May 20, 2020
--Alan Wagner
--X10ManagerDesktop Project



SELECT DISTINCT Units.UnitID, Units.UnitCode, Units.UnitName, Scenes.SceneName
FROM ((((Units INNER JOIN SceneUnits ON Units.UnitID = SceneUnits.UnitID) INNER JOIN Events ON SceneUnits.SceneID = Events.SceneID) INNER JOIN Schedules ON Events.ScheduleID = Schedules.ScheduleID) INNER JOIN Scenes ON Scenes.SceneID = SceneUnits.SceneID)
WHERE Schedules.ScheduleID=3
ORDER BY Units.UnitID;
