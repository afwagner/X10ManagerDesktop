--X10Db_Query_fillX10MacroInitiators.sql
--February 24, 2021
--Alan Wagner
--X10ManagerDesktop Project

SELECT mi.[MacroInitiatorID],
mi.[name] AS [macroInitiatorName],
mi.[description] AS [macroInitiatorDescription],
mi.[triggerHouseCode] AS [triggerHouseCode],
mi.[triggerModuleCode] AS [triggerModuleCode],
mi.[function] AS [function],
mi.[conditions] AS [conditions],
mi.[Enabled] AS [Enabled],
mi.[StartDate] AS [StartDate],
mi.[StopDate] AS [StopDate],

ms.[MacroID],
ms.[name] AS [macroName],
ms.[description] AS [macroDescription],
ms.MacroSort AS [MacroSort],
ms.flag AS [flag],
ms.RF AS [RF],
ms.delay AS [delay],
ms.inhibitRetrigger AS [inhibitRetrigger],

mcs.[MacroCommandID],
mcs.MacroCommandSort AS [MacroCommandSort],
mcs.command AS [command],
mcs.prebrighten AS [prebrighten],
mcs.house AS [house],
mcs.unitcode AS [unitcode],
mcs.unitcodeMaskOdd AS [unitcodeMaskOdd],
mcs.unitcodeMaskEven AS [unitcodeMaskEven],
mcs.extendedCommand AS [extendedCommand],
mcs.extendedData AS [extendedData],
mcs.dimValue AS [dimValue]

FROM ((((MacroInitiators AS mi)
INNER JOIN Macros AS ms ON mi.[MacroInitiatorID]=ms.[MacroInitiatorID])
INNER JOIN MacroCommands AS mcs ON mcs.[MacroID]=ms.[MacroID])
INNER JOIN Controllers ON Controllers.[ControllerID]=mi.[ControllerID])
INNER JOIN ControllerTypes ON ControllerTypes.[ControllerTypeID]=Controllers.[ControllerTypeID]
WHERE mi.[MacroInitiatorID]>-1
AND ms.[MacroID]>-1
AND mcs.[MacroCommandID]>-1

AND mi.[Enabled]=1
AND mi.[StartDate]<=NOW()
AND mi.[StopDate]>=NOW()

AND mi.[ControllerID]=10003
AND Controllers.[ControllerActive]=1
AND ControllerTypes.[ControllerMacros]=1

ORDER BY mi.[MacroInitiatorID], ms.[MacroID], mcs.[MacroCommandID];
