--X10Db_Query_GetSceneModulesDataSet.sql
--May 11, 2020
--Alan Wagner
--X10ManagerDesktop Project

--Notes:
--	All House Codes in Scene.
--    Wildcard in MS Access GUI is *
--    Wildcard via System.Data.OleDb.OleDbConnection is %


SELECT Units.UnitCode As [Code],
IIf(Controllers.ControllerID Is Null,'', Controllers.ControllerName+' ['+ControllerTypes.ControllerType+']') AS [Controller], IIf(Controllers.ControllerID Is Null,'', SWITCH (Controllers.ControllerActive=0,'N',Controllers.ControllerActive=1,'Y')) AS [ControllerActive],
Units.UnitName AS [Name], Units.UnitDescription AS [Description],
SWITCH (Units.UnitDimmer=0,'N',Units.UnitDimmer=1,'Y') AS [Dimmer],
SWITCH( SceneUnits.UnitOnOff=0, 'Off', SceneUnits.UnitOnOff=1 AND Units.UnitDimmer=0, 'On', SceneUnits.UnitOnOff=1 AND Units.UnitDimmer=1 AND SceneUnits.UnitLevel=17, 'On', SceneUnits.UnitOnOff=1 AND Units.UnitDimmer=1 AND SceneUnits.UnitLevel>-1 AND SceneUnits.UnitLevel<16, TRIM(STR(SceneUnits.UnitLevel)) ) AS [On/Off],
SceneUnits.UnitOnOff,
SceneUnits.UnitLevel,
SceneUnits.SceneUnitID AS [ID],
Units.UnitHouseNumber AS [HN],
Units.UnitModuleNumber AS [MN],
Units.UnitID,
SWITCH (Units.UnitEnabled=0,'N',Units.UnitEnabled=1,'Y') AS [ModuleEnabled]
FROM ((((Units INNER JOIN SceneUnits ON SceneUnits.UnitID=Units.UnitID) INNER JOIN Scenes ON Scenes.SceneID=SceneUnits.SceneID) LEFT JOIN Controllers ON Controllers.ControllerID=Units.ControllerID) LEFT JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID)
WHERE Scenes.SceneID=10004
AND Units.UnitHouseCode Like 'J'

UNION

SELECT Units.UnitCode AS [Code],
IIf(Controllers.ControllerID Is Null,'', Controllers.ControllerName+' ['+ControllerTypes.ControllerType+']') AS [Controller], IIf(Controllers.ControllerID Is Null,'', SWITCH (Controllers.ControllerActive=0,'N',Controllers.ControllerActive=1,'Y')) AS [ControllerActive],
Units.UnitName AS [Name], Units.UnitDescription AS [Description],
SWITCH (Units.UnitDimmer=0,'N',Units.UnitDimmer=1,'Y') AS [Dimmer],
'' AS [On/Off],
-1 AS [UnitOnOff],
-1 AS [UnitLevel],
-1 AS [ID],
Units.UnitHouseNumber AS [HN],
Units.UnitModuleNumber AS [MN],
Units.UnitID,
SWITCH (Units.UnitEnabled=0,'N',Units.UnitEnabled=1,'Y') AS [ModuleEnabled]
FROM ((Units LEFT JOIN Controllers ON Controllers.ControllerID=Units.ControllerID) LEFT JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID)
WHERE NOT Units.UnitID IN (SELECT Units.UnitID FROM ((Units INNER JOIN SceneUnits ON SceneUnits.UnitID=Units.UnitID) INNER JOIN Scenes ON Scenes.SceneID=SceneUnits.SceneID) WHERE SceneUnits.SceneID=10004)
AND Units.UnitHouseCode Like 'J'
ORDER BY [HN], [MN], [Controller];