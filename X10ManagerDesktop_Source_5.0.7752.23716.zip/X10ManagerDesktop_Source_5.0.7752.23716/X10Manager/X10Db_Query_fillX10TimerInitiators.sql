--X10Db_Query_fillX10TimerInitiators.sql
--February 24, 2021
--Alan Wagner
--X10ManagerDesktop Project


-- Active Schedules
SELECT Timers.TimerID, Timers.ControllerTimerNumber, Timers.tHour, Timers.tMinute, Timers.tDaysS,
Timers.tHouseCodeS, Timers.tCodes916S, Timers.tCodes18S, Timers.tDays, Timers.tHouseCode,
Timers.tCodes916, Timers.tCodes18, Timers.tMode, Timers.tLevelFunction,
Timers.tSendUnitExtendedCommand, Timers.tExtendedData, Timers.tExtendedCommand,
Events.EventID, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec

FROM Timers INNER JOIN Events ON Events.EventID=Timers.EventID

WHERE Timers.ScheduleID IN (SELECT Schedules.ScheduleID FROM Schedules WHERE Schedules.Active=1)
AND Timers.ControllerID=10003
AND Events.Enabled=1

ORDER BY Timers.ControllerTimerNumber;


-- Specific Schedule
SELECT Timers.TimerID, Timers.ControllerTimerNumber, Timers.tHour, Timers.tMinute, Timers.tDaysS,
Timers.tHouseCodeS, Timers.tCodes916S, Timers.tCodes18S, Timers.tDays, Timers.tHouseCode,
Timers.tCodes916, Timers.tCodes18, Timers.tMode, Timers.tLevelFunction,
Timers.tSendUnitExtendedCommand, Timers.tExtendedData, Timers.tExtendedCommand,
Events.EventID, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec

FROM Timers INNER JOIN Events ON Events.EventID=Timers.EventID

WHERE Timers.ScheduleID=10000
AND Timers.ControllerID=10003
AND Events.Enabled=1

ORDER BY Timers.ControllerTimerNumber;

