--X10Db_Query_GetMacroInitiatorsDataSet.sql
--February 3, 2021
--Alan Wagner
--X10ManagerDesktop Project


--INSERT INTO NextIDs (tblname,fldname,minUniq,maxUniq,nextUniq,GUIDlock) VALUES ('MacroInitiators','MacroInitiatorID',10000,2147483640,10000,null);

--INSERT INTO NextIDs (tblname,fldname,minUniq,maxUniq,nextUniq,GUIDlock) VALUES ('Macros','MacroID',10000,2147483640,10000,null);

--INSERT INTO NextIDs (tblname,fldname,minUniq,maxUniq,nextUniq,GUIDlock) VALUES ('MacroCommands','MacroCommandID',10000,2147483640,10000,null);


--SELECT *" &
--FROM ((MacroInitiators INNER JOIN Macros ON MacroInitiators.MacroInitiatorID=Macros.MacroInitiatorID) INNER JOIN MacroCommands ON MacroCommands.MacroID=Macros.MacroID)
--ORDER BY MacroInitiators.name ASC;
			

SELECT 'Edit' AS [AddEdit],
mi.[name] AS [Name],
mi.[description] AS [Description],
mi.[triggerHouseCode]+mi.[triggerModuleCode] AS [Trigger],
SWITCH(mi.[function]=0,'Off', mi.[function]=1,'On') AS [Function],
mi.[conditions] AS [conditions],
SWITCH(mi.[Enabled]=0,'N', mi.[Enabled]=1,'Y') AS [Enabled],
FORMAT(mi.[StartDate], 'mm/dd/yyyy') AS [StartDate],
FORMAT(mi.[StopDate], 'mm/dd/yyyy') AS [StopDate],
mi.[MacroInitiatorID] AS [MacroInitiatorID]

FROM MacroInitiators AS mi
WHERE mi.[MacroInitiatorID]>-1

UNION

SELECT 'Add' AS [AddEdit],
'' AS [name],
'' AS [description],
'' AS [trigger],
'' AS [FunctionOffOn],
'' AS [conditions],
'' AS [EnabledYN],
'' AS [StartDate],
'' AS [StopDate],
mi.[MacroInitiatorID] AS [MacroInitiatorID]

FROM MacroInitiators AS mi
WHERE mi.[MacroInitiatorID]=-1
ORDER BY [AddEdit], [name];
