--X10Db_Query_compileX10TimersPlaceInX10Db.sql
--May 17, 2020
--Alan Wagner
--X10ManagerDesktop Project

======================================================================================
SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

Scenes.SceneName AS SceneName, Scenes.SceneDescription AS SceneDescription, Scenes.SceneHouseCodeNumber AS SceneHouseCodeNumber, Scenes.SceneHouseCodeLetter AS SceneHouseCodeLetter,
Scenes.SceneRestrictHouseCode AS SceneRestrictHouseCode,
SceneUnits.SceneUnitID AS SceneUnitID, SceneUnits.UnitOnOff AS UnitOnOff, SceneUnits.UnitLevel AS UnitLevel,
Units.UnitID AS UnitID, Units.UnitHouseNumber AS UnitHouseNumber, Units.UnitHouseCode AS UnitHouseCode,
Units.UnitModuleNumber AS UnitModuleNumber, Units.UnitModuleCode AS UnitModuleCode, Units.UnitCode AS UnitCode,
Units.UnitName AS UnitName, Units.UnitDescription AS UnitDescription, Units.UnitDimmer AS UnitDimmer, Units.UnitExtendedCommands AS UnitExtendedCommands,

'' AS MacroInitiatorName, '' AS MacroInitiatorDescription

FROM (((((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN Scenes ON Scenes.SceneID=Events.SceneID)
INNER JOIN SceneUnits ON SceneUnits.SceneID=Scenes.SceneID)
INNER JOIN Units ON Units.UnitID=SceneUnits.UnitID)
INNER JOIN Controllers ON Controllers.ControllerID=Units.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID>-1
AND Units.UnitEnabled=1
AND Events.MacroInitiatorID=-1
AND Controllers.ControllerID=10003

UNION

SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

'' AS SceneName, '' AS SceneDescription, 0 AS SceneHouseCodeNumber, '' AS SceneHouseCodeLetter,
0 AS SceneRestrictHouseCode,
-1 AS SceneUnitID, 0 AS UnitOnOff, 0 AS UnitLevel,
0 AS UnitID, 0 AS UnitHouseNumber, '' AS UnitHouseCode,
0 AS UnitModuleNumber, '' AS UnitModuleCode, '' AS UnitCode,
'' AS UnitName, '' AS UnitDescription, 0 AS UnitDimmer, 0 AS UnitExtendedCommands,

MacroInitiators.name AS MacroInitiatorName, MacroInitiators.description AS MacroInitiatorDescription

FROM (((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN MacroInitiators ON MacroInitiators.MacroInitiatorID=Events.MacroInitiatorID)
INNER JOIN Controllers ON Controllers.ControllerID=MacroInitiators.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID = -1
AND MacroInitiators.[Enabled]=1
AND MacroInitiators.[StartDate]<=NOW()
AND MacroInitiators.[StopDate]>=NOW()
AND Events.MacroInitiatorID>-1
AND Controllers.ControllerID=10003
AND ControllerTypes.ControllerExtendedCommands=1
AND ControllerTypes.ControllerMacros=1

ORDER BY Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, UnitHouseNumber, UnitOnOff, UnitLevel, UnitDimmer, UnitModuleNumber, Events.MacroInitiatorID;

======================================================================================
SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

Scenes.SceneName AS SceneName, Scenes.SceneDescription AS SceneDescription, Scenes.SceneHouseCodeNumber AS SceneHouseCodeNumber, Scenes.SceneHouseCodeLetter AS SceneHouseCodeLetter,
Scenes.SceneRestrictHouseCode AS SceneRestrictHouseCode,
SceneUnits.SceneUnitID AS SceneUnitID, SceneUnits.UnitOnOff AS UnitOnOff, SceneUnits.UnitLevel AS UnitLevel,
Units.UnitID AS UnitID, Units.UnitHouseNumber AS UnitHouseNumber, Units.UnitHouseCode AS UnitHouseCode,
Units.UnitModuleNumber AS UnitModuleNumber, Units.UnitModuleCode AS UnitModuleCode, Units.UnitCode AS UnitCode,
Units.UnitName AS UnitName, Units.UnitDescription AS UnitDescription, Units.UnitDimmer AS UnitDimmer, Units.UnitExtendedCommands AS UnitExtendedCommands,

'' AS MacroInitiatorName, '' AS MacroInitiatorDescription

FROM (((((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN Scenes ON Scenes.SceneID=Events.SceneID)
INNER JOIN SceneUnits ON SceneUnits.SceneID=Scenes.SceneID)
INNER JOIN Units ON Units.UnitID=SceneUnits.UnitID)
INNER JOIN Controllers ON Controllers.ControllerID=Units.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID>-1
AND Units.UnitEnabled=1

UNION

SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

'' AS SceneName, '' AS SceneDescription, 0 AS SceneHouseCodeNumber, '' AS SceneHouseCodeLetter,
0 AS SceneRestrictHouseCode,
-1 AS SceneUnitID, 0 AS UnitOnOff, 0 AS UnitLevel,
0 AS UnitID, 0 AS UnitHouseNumber, '' AS UnitHouseCode,
0 AS UnitModuleNumber, '' AS UnitModuleCode, '' AS UnitCode,
'' AS UnitName, '' AS UnitDescription, 0 AS UnitDimmer, 0 AS UnitExtendedCommands,

MacroInitiators.name AS MacroInitiatorName, MacroInitiators.description AS MacroInitiatorDescription

FROM (((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN MacroInitiators ON MacroInitiators.MacroInitiatorID=Events.MacroInitiatorID)
INNER JOIN Controllers ON Controllers.ControllerID=MacroInitiators.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID=-1
AND MacroInitiators.[Enabled]=1
AND MacroInitiators.[StartDate]<=NOW()
AND MacroInitiators.[StopDate]>=NOW()
AND Events.MacroInitiatorID>-1
AND Controllers.ControllerActive=1
AND ControllerTypes.ControllerExtendedCommands=1
AND ControllerTypes.ControllerMacros=1

ORDER BY Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, UnitHouseNumber, UnitOnOff, UnitLevel, UnitDimmer, UnitModuleNumber, Events.MacroInitiatorID;

======================================================================================
======================================================================================
SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

Scenes.SceneName AS SceneName, Scenes.SceneDescription AS SceneDescription, Scenes.SceneHouseCodeNumber AS SceneHouseCodeNumber, Scenes.SceneHouseCodeLetter AS SceneHouseCodeLetter,
Scenes.SceneRestrictHouseCode AS SceneRestrictHouseCode,
SceneUnits.SceneUnitID AS SceneUnitID, SceneUnits.UnitOnOff AS UnitOnOff, SceneUnits.UnitLevel AS UnitLevel,
Units.UnitID AS UnitID, Units.UnitHouseNumber AS UnitHouseNumber, Units.UnitHouseCode AS UnitHouseCode,
Units.UnitModuleNumber AS UnitModuleNumber, Units.UnitModuleCode AS UnitModuleCode, Units.UnitCode AS UnitCode,
Units.UnitName AS UnitName, Units.UnitDescription AS UnitDescription, Units.UnitDimmer AS UnitDimmer, Units.UnitExtendedCommands AS UnitExtendedCommands,

'' AS MacroInitiatorName, '' AS MacroInitiatorDescription,
'' AS triggerHouseCode, '' AS triggerModuleCode,
0 AS [function], 0 AS conditions,
-1 AS MacroID, '' AS MacroName, '' AS MacroDescription, 0 AS MacroSort,
0 AS flag, 0 AS RF, 0 AS delay, 0 AS inhibitRetrigger,
-1 AS MacroCommandID, 0 AS MacroCommandSort, 0 AS MacroCommandsCommand, 0 AS MacroCommandsPrebrighten,
0 AS MacroCommandsHouse, 0 AS MacroCommandsUnitcode,
0 AS MacroCommandsUnitcodeMaskOdd, 0 AS MacroCommandsUnitcodeMaskEven,
0 AS MacroCommandsExtendedCommand, 0 AS MacroCommandsExtendedData, 0 AS MacroCommandsDimValue

FROM (((((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN Scenes ON Scenes.SceneID=Events.SceneID)
INNER JOIN SceneUnits ON SceneUnits.SceneID=Scenes.SceneID)
INNER JOIN Units ON Units.UnitID=SceneUnits.UnitID)
INNER JOIN Controllers ON Controllers.ControllerID=Units.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID>-1
AND Units.UnitEnabled=1
AND Events.MacroInitiatorID=-1
AND Controllers.ControllerID=10003

UNION

SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

'' AS SceneName, '' AS SceneDescription, 0 AS SceneHouseCodeNumber, '' AS SceneHouseCodeLetter,
0 AS SceneRestrictHouseCode,
-1 AS SceneUnitID, 0 AS UnitOnOff, 0 AS UnitLevel,
0 AS UnitID, 0 AS UnitHouseNumber, '' AS UnitHouseCode,
0 AS UnitModuleNumber, '' AS UnitModuleCode, '' AS UnitCode,
'' AS UnitName, '' AS UnitDescription, 0 AS UnitDimmer, 0 AS UnitExtendedCommands,

MacroInitiators.name AS MacroInitiatorName, MacroInitiators.description AS MacroInitiatorDescription,
MacroInitiators.triggerHouseCode AS triggerHouseCode, MacroInitiators.triggerModuleCode AS triggerModuleCode,
MacroInitiators.[function] AS [function], MacroInitiators.conditions AS conditions,
Macros.MacroID AS MacroID, Macros.name AS MacroName, Macros.description AS MacroDescription, Macros.MacroSort AS MacroSort,
Macros.flag AS flag, Macros.RF AS RF, Macros.delay AS delay, Macros.inhibitRetrigger AS inhibitRetrigger,
MacroCommands.MacroCommandID AS MacroCommandID, MacroCommands.MacroCommandSort AS MacroCommandSort, MacroCommands.command AS MacroCommandsCommand, MacroCommands.prebrighten AS MacroCommandsPrebrighten,
MacroCommands.house AS MacroCommandsHouse, MacroCommands.unitcode AS MacroCommandsUnitcode,
MacroCommands.unitcodeMaskOdd AS MacroCommandsUnitcodeMaskOdd, MacroCommands.unitcodeMaskEven AS MacroCommandsUnitcodeMaskEven,
MacroCommands.extendedCommand AS MacroCommandsExtendedCommand, MacroCommands.extendedData AS MacroCommandsExtendedData, MacroCommands.dimValue AS MacroCommandsDimValue

FROM (((((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN MacroInitiators ON MacroInitiators.MacroInitiatorID=Events.MacroInitiatorID)
INNER JOIN Macros ON Macros.MacroInitiatorID=MacroInitiators.MacroInitiatorID)
INNER JOIN MacroCommands ON MacroCommands.MacroID=Macros.MacroID)
INNER JOIN Controllers ON Controllers.ControllerID=MacroInitiators.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID=-1
AND MacroInitiators.[Enabled]=1
AND MacroInitiators.[StartDate]<=NOW()
AND MacroInitiators.[StopDate]>=NOW()
AND Events.MacroInitiatorID>-1
AND Controllers.ControllerID=10003
AND ControllerTypes.ControllerExtendedCommands=1
AND ControllerTypes.ControllerMacros=1

ORDER BY Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, UnitHouseNumber, UnitOnOff, UnitLevel, UnitDimmer, UnitModuleNumber, Events.MacroInitiatorID, MacroSort, MacroCommandSort;

======================================================================================
SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

Scenes.SceneName AS SceneName, Scenes.SceneDescription AS SceneDescription, Scenes.SceneHouseCodeNumber AS SceneHouseCodeNumber, Scenes.SceneHouseCodeLetter AS SceneHouseCodeLetter,
Scenes.SceneRestrictHouseCode AS SceneRestrictHouseCode,
SceneUnits.SceneUnitID AS SceneUnitID, SceneUnits.UnitOnOff AS UnitOnOff, SceneUnits.UnitLevel AS UnitLevel,
Units.UnitID AS UnitID, Units.UnitHouseNumber AS UnitHouseNumber, Units.UnitHouseCode AS UnitHouseCode,
Units.UnitModuleNumber AS UnitModuleNumber, Units.UnitModuleCode AS UnitModuleCode, Units.UnitCode AS UnitCode,
Units.UnitName AS UnitName, Units.UnitDescription AS UnitDescription, Units.UnitDimmer AS UnitDimmer, Units.UnitExtendedCommands AS UnitExtendedCommands,

'' AS MacroInitiatorName, '' AS MacroInitiatorDescription,
'' AS triggerHouseCode, '' AS triggerModuleCode,
0 AS [function], 0 AS conditions,
-1 AS MacroID, '' AS MacroName, '' AS MacroDescription, 0 AS MacroSort,
0 AS flag, 0 AS RF, 0 AS delay, 0 AS inhibitRetrigger,
-1 AS MacroCommandID, 0 AS MacroCommandSort, 0 AS MacroCommandsCommand, 0 AS MacroCommandsPrebrighten,
0 AS MacroCommandsHouse, 0 AS MacroCommandsUnitcode,
0 AS MacroCommandsUnitcodeMaskOdd, 0 AS MacroCommandsUnitcodeMaskEven,
0 AS MacroCommandsExtendedCommand, 0 AS MacroCommandsExtendedData, 0 AS MacroCommandsDimValue

FROM (((((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN Scenes ON Scenes.SceneID=Events.SceneID)
INNER JOIN SceneUnits ON SceneUnits.SceneID=Scenes.SceneID)
INNER JOIN Units ON Units.UnitID=SceneUnits.UnitID)
INNER JOIN Controllers ON Controllers.ControllerID=Units.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID>-1
AND Units.UnitEnabled=1
AND Events.MacroInitiatorID=-1
AND Controllers.ControllerActive=1

UNION

SELECT Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, Events.MacroInitiatorID,
Controllers.ControllerName, Controllers.ControllerTypeID, ControllerTypes.ControllerType,
Schedules.ScheduleName, Schedules.ScheduleDescription, Schedules.SunriseTime, Schedules.SunsetTime, Schedules.X10SunriseTime, Schedules.X10SunsetTime,
Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec, Events.StartDate, Events.StopDate,

'' AS SceneName, '' AS SceneDescription, 0 AS SceneHouseCodeNumber, '' AS SceneHouseCodeLetter,
0 AS SceneRestrictHouseCode,
-1 AS SceneUnitID, 0 AS UnitOnOff, 0 AS UnitLevel,
0 AS UnitID, 0 AS UnitHouseNumber, '' AS UnitHouseCode,
0 AS UnitModuleNumber, '' AS UnitModuleCode, '' AS UnitCode,
'' AS UnitName, '' AS UnitDescription, 0 AS UnitDimmer, 0 AS UnitExtendedCommands,

MacroInitiators.name AS MacroInitiatorName, MacroInitiators.description AS MacroInitiatorDescription,
MacroInitiators.triggerHouseCode AS triggerHouseCode, MacroInitiators.triggerModuleCode AS triggerModuleCode,
MacroInitiators.[function] AS [function], MacroInitiators.conditions AS conditions,
Macros.MacroID AS MacroID, Macros.name AS MacroName, Macros.description AS MacroDescription, Macros.MacroSort AS MacroSort,
Macros.flag AS flag, Macros.RF AS RF, Macros.delay AS delay, Macros.inhibitRetrigger AS inhibitRetrigger,
MacroCommands.MacroCommandID AS MacroCommandID, MacroCommands.MacroCommandSort AS MacroCommandSort, MacroCommands.command AS MacroCommandsCommand, MacroCommands.prebrighten AS MacroCommandsPrebrighten,
MacroCommands.house AS MacroCommandsHouse, MacroCommands.unitcode AS MacroCommandsUnitcode,
MacroCommands.unitcodeMaskOdd AS MacroCommandsUnitcodeMaskOdd, MacroCommands.unitcodeMaskEven AS MacroCommandsUnitcodeMaskEven,
MacroCommands.extendedCommand AS MacroCommandsExtendedCommand, MacroCommands.extendedData AS MacroCommandsExtendedData, MacroCommands.dimValue AS MacroCommandsDimValue

FROM (((((Schedules INNER JOIN Events ON Events.ScheduleID=Schedules.ScheduleID)
INNER JOIN MacroInitiators ON MacroInitiators.MacroInitiatorID=Events.MacroInitiatorID)
INNER JOIN Macros ON Macros.MacroInitiatorID=MacroInitiators.MacroInitiatorID)
INNER JOIN MacroCommands ON MacroCommands.MacroID=Macros.MacroID)
INNER JOIN Controllers ON Controllers.ControllerID=MacroInitiators.ControllerID)
INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID
WHERE Schedules.Active=1
AND Events.Enabled=1
AND Events.StartDate<=NOW()
AND Events.StopDate>=NOW()
AND Events.SceneID=-1
AND MacroInitiators.[Enabled]=1
AND MacroInitiators.[StartDate]<=NOW()
AND MacroInitiators.[StopDate]>=NOW()
AND Events.MacroInitiatorID>-1
AND Controllers.ControllerActive=1
AND ControllerTypes.ControllerExtendedCommands=1
AND ControllerTypes.ControllerMacros=1

ORDER BY Schedules.ScheduleID, Controllers.ControllerID, Events.EventID, Events.SceneID, UnitHouseNumber, UnitOnOff, UnitLevel, UnitDimmer, UnitModuleNumber, Events.MacroInitiatorID, MacroSort, MacroCommandSort;

======================================================================================
