--X10Db_Query_generateOnOffComboBox.sql
--May 17, 2020
--Alan Wagner
--X10ManagerDesktop Project


SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember
FROM ((SceneUnits INNER JOIN Units ON Units.UnitID=SceneUnits.UnitID) INNER JOIN ComboBoxs ON ComboBoxs.Name=SWITCH(Units.UnitDimmer=0,'Switch', Units.UnitDimmer=1,'Dimmer') )
WHERE SceneUnits.SceneUnitID=61

UNION

SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember
FROM ComboBoxs
WHERE ComboBoxs.Name='Dimmer'

UNION

SELECT DISTINCT 'Clear' AS DisplayMember, -1 AS ValueMember
FROM ComboBoxs

ORDER BY ComboBoxs.ValueMember;
