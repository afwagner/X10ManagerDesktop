﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formMacroInitiatorAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formMacroInitiatorAddUpdate))
        Me.formMacroInitiatorAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formMacroInitiatorAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formMacroInitiatorAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formMacroInitiatorAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateIDLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox = New System.Windows.Forms.TextBox()
        Me.formMacroInitiatorAddUpdateInitiatorNameLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.formMacroInitiatorAddUpdateDescriptionLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateMacrosLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateMacrosDataGridView = New System.Windows.Forms.DataGridView()
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateStopDateLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateStopDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.formMacroInitiatorAddUpdateStartDateLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateStartDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroInitiatorAddUpdateTriggerLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateHouseCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroInitiatorAddUpdateModuleCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroInitiatorAddUpdateFunctionLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateFunctionPanel = New System.Windows.Forms.Panel()
        Me.formMacroInitiatorAddUpdateOffRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroInitiatorAddUpdateOnRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroInitiatorAddUpdateControllerLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateControllerComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroInitiatorAddUpdateControllerActiveLabel = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdateControllerActiveLabelText = New System.Windows.Forms.Label()
        Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton = New System.Windows.Forms.Button()
        CType(Me.formMacroInitiatorAddUpdateMacrosDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.formMacroInitiatorAddUpdateFunctionPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'formMacroInitiatorAddUpdate_StatusLabel
        '
        Me.formMacroInitiatorAddUpdate_StatusLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formMacroInitiatorAddUpdate_StatusLabel.Location = New System.Drawing.Point(173, 602)
        Me.formMacroInitiatorAddUpdate_StatusLabel.Name = "formMacroInitiatorAddUpdate_StatusLabel"
        Me.formMacroInitiatorAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formMacroInitiatorAddUpdate_StatusLabel.TabIndex = 25
        Me.formMacroInitiatorAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formMacroInitiatorAddUpdate_CancelButton
        '
        Me.formMacroInitiatorAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formMacroInitiatorAddUpdate_CancelButton.Location = New System.Drawing.Point(537, 599)
        Me.formMacroInitiatorAddUpdate_CancelButton.Name = "formMacroInitiatorAddUpdate_CancelButton"
        Me.formMacroInitiatorAddUpdate_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formMacroInitiatorAddUpdate_CancelButton.TabIndex = 24
        Me.formMacroInitiatorAddUpdate_CancelButton.Text = "Cancel"
        Me.formMacroInitiatorAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formMacroInitiatorAddUpdate_AddUpdateButton
        '
        Me.formMacroInitiatorAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(79, 599)
        Me.formMacroInitiatorAddUpdate_AddUpdateButton.Name = "formMacroInitiatorAddUpdate_AddUpdateButton"
        Me.formMacroInitiatorAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(88, 23)
        Me.formMacroInitiatorAddUpdate_AddUpdateButton.TabIndex = 23
        Me.formMacroInitiatorAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formMacroInitiatorAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formMacroInitiatorAddUpdate_DeleteButton
        '
        Me.formMacroInitiatorAddUpdate_DeleteButton.Location = New System.Drawing.Point(537, 43)
        Me.formMacroInitiatorAddUpdate_DeleteButton.Name = "formMacroInitiatorAddUpdate_DeleteButton"
        Me.formMacroInitiatorAddUpdate_DeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.formMacroInitiatorAddUpdate_DeleteButton.TabIndex = 30
        Me.formMacroInitiatorAddUpdate_DeleteButton.Text = "Delete"
        Me.formMacroInitiatorAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formMacroInitiatorAddUpdateIDLabelText
        '
        Me.formMacroInitiatorAddUpdateIDLabelText.AutoSize = True
        Me.formMacroInitiatorAddUpdateIDLabelText.Location = New System.Drawing.Point(168, 48)
        Me.formMacroInitiatorAddUpdateIDLabelText.Name = "formMacroInitiatorAddUpdateIDLabelText"
        Me.formMacroInitiatorAddUpdateIDLabelText.Size = New System.Drawing.Size(203, 13)
        Me.formMacroInitiatorAddUpdateIDLabelText.TabIndex = 29
        Me.formMacroInitiatorAddUpdateIDLabelText.Text = "formMacroInitiatorAddUpdateIDLabelText"
        '
        'formMacroInitiatorAddUpdateIDLabel
        '
        Me.formMacroInitiatorAddUpdateIDLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateIDLabel.Location = New System.Drawing.Point(143, 48)
        Me.formMacroInitiatorAddUpdateIDLabel.Name = "formMacroInitiatorAddUpdateIDLabel"
        Me.formMacroInitiatorAddUpdateIDLabel.Size = New System.Drawing.Size(24, 13)
        Me.formMacroInitiatorAddUpdateIDLabel.TabIndex = 28
        Me.formMacroInitiatorAddUpdateIDLabel.Text = "ID: "
        '
        'formMacroInitiatorAddUpdateInitiatorNameTextBox
        '
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox.Location = New System.Drawing.Point(168, 16)
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox.MaxLength = 40
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox.Name = "formMacroInitiatorAddUpdateInitiatorNameTextBox"
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox.Size = New System.Drawing.Size(392, 20)
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox.TabIndex = 27
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox.Text = "formMacroInitiatorAddUpdateInitiatorNameTextBox"
        Me.formMacroInitiatorAddUpdateInitiatorNameTextBox.WordWrap = False
        '
        'formMacroInitiatorAddUpdateInitiatorNameLabel
        '
        Me.formMacroInitiatorAddUpdateInitiatorNameLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateInitiatorNameLabel.Location = New System.Drawing.Point(54, 19)
        Me.formMacroInitiatorAddUpdateInitiatorNameLabel.Name = "formMacroInitiatorAddUpdateInitiatorNameLabel"
        Me.formMacroInitiatorAddUpdateInitiatorNameLabel.Size = New System.Drawing.Size(108, 13)
        Me.formMacroInitiatorAddUpdateInitiatorNameLabel.TabIndex = 26
        Me.formMacroInitiatorAddUpdateInitiatorNameLabel.Text = "Macro Initiator Name:"
        '
        'formMacroInitiatorAddUpdateDescriptionTextBox
        '
        Me.formMacroInitiatorAddUpdateDescriptionTextBox.Location = New System.Drawing.Point(168, 72)
        Me.formMacroInitiatorAddUpdateDescriptionTextBox.MaxLength = 100
        Me.formMacroInitiatorAddUpdateDescriptionTextBox.Name = "formMacroInitiatorAddUpdateDescriptionTextBox"
        Me.formMacroInitiatorAddUpdateDescriptionTextBox.Size = New System.Drawing.Size(392, 20)
        Me.formMacroInitiatorAddUpdateDescriptionTextBox.TabIndex = 44
        '
        'formMacroInitiatorAddUpdateDescriptionLabel
        '
        Me.formMacroInitiatorAddUpdateDescriptionLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateDescriptionLabel.Location = New System.Drawing.Point(99, 75)
        Me.formMacroInitiatorAddUpdateDescriptionLabel.Name = "formMacroInitiatorAddUpdateDescriptionLabel"
        Me.formMacroInitiatorAddUpdateDescriptionLabel.Size = New System.Drawing.Size(63, 13)
        Me.formMacroInitiatorAddUpdateDescriptionLabel.TabIndex = 43
        Me.formMacroInitiatorAddUpdateDescriptionLabel.Text = "Description:"
        '
        'formMacroInitiatorAddUpdateMacrosLabel
        '
        Me.formMacroInitiatorAddUpdateMacrosLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateMacrosLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formMacroInitiatorAddUpdateMacrosLabel.Location = New System.Drawing.Point(6, 291)
        Me.formMacroInitiatorAddUpdateMacrosLabel.Name = "formMacroInitiatorAddUpdateMacrosLabel"
        Me.formMacroInitiatorAddUpdateMacrosLabel.Size = New System.Drawing.Size(54, 17)
        Me.formMacroInitiatorAddUpdateMacrosLabel.TabIndex = 46
        Me.formMacroInitiatorAddUpdateMacrosLabel.Text = "Macros"
        '
        'formMacroInitiatorAddUpdateMacrosDataGridView
        '
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.AllowDrop = True
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.AllowUserToAddRows = False
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.AllowUserToDeleteRows = False
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.AllowUserToResizeColumns = False
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.AllowUserToResizeRows = False
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.Location = New System.Drawing.Point(0, 311)
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.Name = "formMacroInitiatorAddUpdateMacrosDataGridView"
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.ShowCellToolTips = False
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.ShowEditingIcon = False
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.Size = New System.Drawing.Size(705, 263)
        Me.formMacroInitiatorAddUpdateMacrosDataGridView.TabIndex = 45
        '
        'formMacroInitiatorAddUpdate_BringToFrontLabel
        '
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel.Location = New System.Drawing.Point(12, 325)
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel.Name = "formMacroInitiatorAddUpdate_BringToFrontLabel"
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel.TabIndex = 47
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel.Text = "Y | N"
        Me.formMacroInitiatorAddUpdate_BringToFrontLabel.Visible = False
        '
        'formMacroInitiatorAddUpdateStopDateLabel
        '
        Me.formMacroInitiatorAddUpdateStopDateLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateStopDateLabel.Location = New System.Drawing.Point(226, 197)
        Me.formMacroInitiatorAddUpdateStopDateLabel.Name = "formMacroInitiatorAddUpdateStopDateLabel"
        Me.formMacroInitiatorAddUpdateStopDateLabel.Size = New System.Drawing.Size(58, 13)
        Me.formMacroInitiatorAddUpdateStopDateLabel.TabIndex = 75
        Me.formMacroInitiatorAddUpdateStopDateLabel.Text = "Stop Date:"
        '
        'formMacroInitiatorAddUpdateStopDateDateTimePicker
        '
        Me.formMacroInitiatorAddUpdateStopDateDateTimePicker.Location = New System.Drawing.Point(287, 194)
        Me.formMacroInitiatorAddUpdateStopDateDateTimePicker.Name = "formMacroInitiatorAddUpdateStopDateDateTimePicker"
        Me.formMacroInitiatorAddUpdateStopDateDateTimePicker.Size = New System.Drawing.Size(207, 20)
        Me.formMacroInitiatorAddUpdateStopDateDateTimePicker.TabIndex = 74
        Me.formMacroInitiatorAddUpdateStopDateDateTimePicker.Value = New Date(2020, 12, 12, 15, 34, 57, 0)
        '
        'formMacroInitiatorAddUpdateStartDateLabel
        '
        Me.formMacroInitiatorAddUpdateStartDateLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateStartDateLabel.Location = New System.Drawing.Point(226, 171)
        Me.formMacroInitiatorAddUpdateStartDateLabel.Name = "formMacroInitiatorAddUpdateStartDateLabel"
        Me.formMacroInitiatorAddUpdateStartDateLabel.Size = New System.Drawing.Size(58, 13)
        Me.formMacroInitiatorAddUpdateStartDateLabel.TabIndex = 73
        Me.formMacroInitiatorAddUpdateStartDateLabel.Text = "Start Date:"
        '
        'formMacroInitiatorAddUpdateStartDateDateTimePicker
        '
        Me.formMacroInitiatorAddUpdateStartDateDateTimePicker.Location = New System.Drawing.Point(287, 168)
        Me.formMacroInitiatorAddUpdateStartDateDateTimePicker.Name = "formMacroInitiatorAddUpdateStartDateDateTimePicker"
        Me.formMacroInitiatorAddUpdateStartDateDateTimePicker.Size = New System.Drawing.Size(207, 20)
        Me.formMacroInitiatorAddUpdateStartDateDateTimePicker.TabIndex = 72
        Me.formMacroInitiatorAddUpdateStartDateDateTimePicker.Value = New Date(2020, 12, 12, 15, 34, 49, 0)
        '
        'formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox
        '
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.AutoSize = True
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Location = New System.Drawing.Point(68, 182)
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Name = "formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox"
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Size = New System.Drawing.Size(135, 17)
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.TabIndex = 71
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Text = "Macro Initiator Enabled"
        Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.UseVisualStyleBackColor = True
        '
        'formMacroInitiatorAddUpdateTriggerLabel
        '
        Me.formMacroInitiatorAddUpdateTriggerLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateTriggerLabel.Location = New System.Drawing.Point(119, 231)
        Me.formMacroInitiatorAddUpdateTriggerLabel.Name = "formMacroInitiatorAddUpdateTriggerLabel"
        Me.formMacroInitiatorAddUpdateTriggerLabel.Size = New System.Drawing.Size(43, 13)
        Me.formMacroInitiatorAddUpdateTriggerLabel.TabIndex = 76
        Me.formMacroInitiatorAddUpdateTriggerLabel.Text = "Trigger:"
        '
        'formMacroInitiatorAddUpdateHouseCodeComboBox
        '
        Me.formMacroInitiatorAddUpdateHouseCodeComboBox.FormattingEnabled = True
        Me.formMacroInitiatorAddUpdateHouseCodeComboBox.Location = New System.Drawing.Point(171, 228)
        Me.formMacroInitiatorAddUpdateHouseCodeComboBox.Name = "formMacroInitiatorAddUpdateHouseCodeComboBox"
        Me.formMacroInitiatorAddUpdateHouseCodeComboBox.Size = New System.Drawing.Size(119, 21)
        Me.formMacroInitiatorAddUpdateHouseCodeComboBox.TabIndex = 77
        Me.formMacroInitiatorAddUpdateHouseCodeComboBox.Text = "Select House Code"
        '
        'formMacroInitiatorAddUpdateModuleCodeComboBox
        '
        Me.formMacroInitiatorAddUpdateModuleCodeComboBox.FormattingEnabled = True
        Me.formMacroInitiatorAddUpdateModuleCodeComboBox.Location = New System.Drawing.Point(296, 228)
        Me.formMacroInitiatorAddUpdateModuleCodeComboBox.Name = "formMacroInitiatorAddUpdateModuleCodeComboBox"
        Me.formMacroInitiatorAddUpdateModuleCodeComboBox.Size = New System.Drawing.Size(121, 21)
        Me.formMacroInitiatorAddUpdateModuleCodeComboBox.TabIndex = 78
        Me.formMacroInitiatorAddUpdateModuleCodeComboBox.Text = "Select Module Code"
        '
        'formMacroInitiatorAddUpdateFunctionLabel
        '
        Me.formMacroInitiatorAddUpdateFunctionLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateFunctionLabel.Location = New System.Drawing.Point(111, 263)
        Me.formMacroInitiatorAddUpdateFunctionLabel.Name = "formMacroInitiatorAddUpdateFunctionLabel"
        Me.formMacroInitiatorAddUpdateFunctionLabel.Size = New System.Drawing.Size(51, 13)
        Me.formMacroInitiatorAddUpdateFunctionLabel.TabIndex = 79
        Me.formMacroInitiatorAddUpdateFunctionLabel.Text = "Function:"
        '
        'formMacroInitiatorAddUpdateFunctionPanel
        '
        Me.formMacroInitiatorAddUpdateFunctionPanel.Controls.Add(Me.formMacroInitiatorAddUpdateOffRadioButton)
        Me.formMacroInitiatorAddUpdateFunctionPanel.Controls.Add(Me.formMacroInitiatorAddUpdateOnRadioButton)
        Me.formMacroInitiatorAddUpdateFunctionPanel.Location = New System.Drawing.Point(171, 255)
        Me.formMacroInitiatorAddUpdateFunctionPanel.Name = "formMacroInitiatorAddUpdateFunctionPanel"
        Me.formMacroInitiatorAddUpdateFunctionPanel.Size = New System.Drawing.Size(100, 29)
        Me.formMacroInitiatorAddUpdateFunctionPanel.TabIndex = 80
        '
        'formMacroInitiatorAddUpdateOffRadioButton
        '
        Me.formMacroInitiatorAddUpdateOffRadioButton.AutoSize = True
        Me.formMacroInitiatorAddUpdateOffRadioButton.Location = New System.Drawing.Point(50, 6)
        Me.formMacroInitiatorAddUpdateOffRadioButton.Name = "formMacroInitiatorAddUpdateOffRadioButton"
        Me.formMacroInitiatorAddUpdateOffRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.formMacroInitiatorAddUpdateOffRadioButton.TabIndex = 63
        Me.formMacroInitiatorAddUpdateOffRadioButton.TabStop = True
        Me.formMacroInitiatorAddUpdateOffRadioButton.Text = "Off"
        Me.formMacroInitiatorAddUpdateOffRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroInitiatorAddUpdateOnRadioButton
        '
        Me.formMacroInitiatorAddUpdateOnRadioButton.AutoSize = True
        Me.formMacroInitiatorAddUpdateOnRadioButton.Location = New System.Drawing.Point(3, 6)
        Me.formMacroInitiatorAddUpdateOnRadioButton.Name = "formMacroInitiatorAddUpdateOnRadioButton"
        Me.formMacroInitiatorAddUpdateOnRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.formMacroInitiatorAddUpdateOnRadioButton.TabIndex = 39
        Me.formMacroInitiatorAddUpdateOnRadioButton.TabStop = True
        Me.formMacroInitiatorAddUpdateOnRadioButton.Text = "On"
        Me.formMacroInitiatorAddUpdateOnRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroInitiatorAddUpdateControllerLabel
        '
        Me.formMacroInitiatorAddUpdateControllerLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateControllerLabel.Location = New System.Drawing.Point(108, 109)
        Me.formMacroInitiatorAddUpdateControllerLabel.Name = "formMacroInitiatorAddUpdateControllerLabel"
        Me.formMacroInitiatorAddUpdateControllerLabel.Size = New System.Drawing.Size(54, 13)
        Me.formMacroInitiatorAddUpdateControllerLabel.TabIndex = 81
        Me.formMacroInitiatorAddUpdateControllerLabel.Text = "Controller:"
        '
        'formMacroInitiatorAddUpdateControllerComboBox
        '
        Me.formMacroInitiatorAddUpdateControllerComboBox.FormattingEnabled = True
        Me.formMacroInitiatorAddUpdateControllerComboBox.Location = New System.Drawing.Point(168, 106)
        Me.formMacroInitiatorAddUpdateControllerComboBox.Name = "formMacroInitiatorAddUpdateControllerComboBox"
        Me.formMacroInitiatorAddUpdateControllerComboBox.Size = New System.Drawing.Size(310, 21)
        Me.formMacroInitiatorAddUpdateControllerComboBox.TabIndex = 82
        '
        'formMacroInitiatorAddUpdateControllerActiveLabel
        '
        Me.formMacroInitiatorAddUpdateControllerActiveLabel.AutoSize = True
        Me.formMacroInitiatorAddUpdateControllerActiveLabel.Location = New System.Drawing.Point(75, 140)
        Me.formMacroInitiatorAddUpdateControllerActiveLabel.Name = "formMacroInitiatorAddUpdateControllerActiveLabel"
        Me.formMacroInitiatorAddUpdateControllerActiveLabel.Size = New System.Drawing.Size(87, 13)
        Me.formMacroInitiatorAddUpdateControllerActiveLabel.TabIndex = 83
        Me.formMacroInitiatorAddUpdateControllerActiveLabel.Text = "Controller Active:"
        '
        'formMacroInitiatorAddUpdateControllerActiveLabelText
        '
        Me.formMacroInitiatorAddUpdateControllerActiveLabelText.AutoSize = True
        Me.formMacroInitiatorAddUpdateControllerActiveLabelText.Location = New System.Drawing.Point(165, 140)
        Me.formMacroInitiatorAddUpdateControllerActiveLabelText.Name = "formMacroInitiatorAddUpdateControllerActiveLabelText"
        Me.formMacroInitiatorAddUpdateControllerActiveLabelText.Size = New System.Drawing.Size(237, 13)
        Me.formMacroInitiatorAddUpdateControllerActiveLabelText.TabIndex = 84
        Me.formMacroInitiatorAddUpdateControllerActiveLabelText.Text = "formModuleAddUpdateControllerActiveLabelText"
        '
        'formMacroInitiatorAddUpdate_TestMacroInitiatorButton
        '
        Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Location = New System.Drawing.Point(499, 241)
        Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Name = "formMacroInitiatorAddUpdate_TestMacroInitiatorButton"
        Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Size = New System.Drawing.Size(113, 23)
        Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton.TabIndex = 85
        Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Text = "Test Macro Initiator"
        Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton.UseVisualStyleBackColor = True
        '
        'formMacroInitiatorAddUpdate
        '
        Me.AcceptButton = Me.formMacroInitiatorAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formMacroInitiatorAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(705, 647)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdate_TestMacroInitiatorButton)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateControllerActiveLabelText)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateControllerActiveLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateControllerComboBox)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateControllerLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateFunctionPanel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateFunctionLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateModuleCodeComboBox)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateHouseCodeComboBox)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateTriggerLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateStopDateLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateStopDateDateTimePicker)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateStartDateLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateStartDateDateTimePicker)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdate_BringToFrontLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateMacrosLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateMacrosDataGridView)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateDescriptionTextBox)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateDescriptionLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdate_DeleteButton)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateIDLabelText)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateIDLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateInitiatorNameTextBox)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdateInitiatorNameLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdate_CancelButton)
        Me.Controls.Add(Me.formMacroInitiatorAddUpdate_AddUpdateButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formMacroInitiatorAddUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Macro Initiator Add / Update"
        CType(Me.formMacroInitiatorAddUpdateMacrosDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.formMacroInitiatorAddUpdateFunctionPanel.ResumeLayout(False)
        Me.formMacroInitiatorAddUpdateFunctionPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formMacroInitiatorAddUpdate_StatusLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdate_CancelButton As Button
    Friend WithEvents formMacroInitiatorAddUpdate_AddUpdateButton As Button
    Friend WithEvents formMacroInitiatorAddUpdate_DeleteButton As Button
    Friend WithEvents formMacroInitiatorAddUpdateIDLabelText As Label
    Friend WithEvents formMacroInitiatorAddUpdateIDLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateInitiatorNameTextBox As TextBox
    Friend WithEvents formMacroInitiatorAddUpdateInitiatorNameLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateDescriptionTextBox As TextBox
    Friend WithEvents formMacroInitiatorAddUpdateDescriptionLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateMacrosLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateMacrosDataGridView As DataGridView
    Friend WithEvents formMacroInitiatorAddUpdate_BringToFrontLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateStopDateLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateStopDateDateTimePicker As DateTimePicker
    Friend WithEvents formMacroInitiatorAddUpdateStartDateLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateStartDateDateTimePicker As DateTimePicker
    Friend WithEvents formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox As CheckBox
    Friend WithEvents formMacroInitiatorAddUpdateTriggerLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateHouseCodeComboBox As ComboBox
    Friend WithEvents formMacroInitiatorAddUpdateModuleCodeComboBox As ComboBox
    Friend WithEvents formMacroInitiatorAddUpdateFunctionLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateFunctionPanel As Panel
    Friend WithEvents formMacroInitiatorAddUpdateOffRadioButton As RadioButton
    Friend WithEvents formMacroInitiatorAddUpdateOnRadioButton As RadioButton
    Friend WithEvents formMacroInitiatorAddUpdateControllerLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateControllerComboBox As ComboBox
    Friend WithEvents formMacroInitiatorAddUpdateControllerActiveLabel As Label
    Friend WithEvents formMacroInitiatorAddUpdateControllerActiveLabelText As Label
    Friend WithEvents formMacroInitiatorAddUpdate_TestMacroInitiatorButton As Button
End Class
