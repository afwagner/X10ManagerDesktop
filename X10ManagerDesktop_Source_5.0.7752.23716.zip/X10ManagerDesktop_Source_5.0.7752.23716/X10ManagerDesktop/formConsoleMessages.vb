﻿' Name: formConsoleMessages.vb
' By: Alan Wagner
' Date: March 2020

Public Class formConsoleMessages

#Region "X10ManagerDesktopConsoleMessagesMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Try

            strTryStep = "formConsoleMessages_BringToFrontLabel"
            If (formConsoleMessages_BringToFrontLabel.Text() = "Y") Then
                Me.BringToFront()
            End If

            strTryStep = "formConsoleMessages_FormRestore"
            ' formConsoleMessages_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formConsoleMessages_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then
                formConsoleMessagesRichTextBox.Visible = True
            Else
                formConsoleMessagesRichTextBox.Visible = False
                Windows.Forms.MessageBox.Show("Main(formControllerAddUpdate): " & strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - formConsoleMessages_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formConsoleMessages): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formConsoleMessages)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try

    End Sub ' END Sub - Main(formConsoleMessages)

    Private Sub formConsoleMessages_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formConsoleMessages_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formConsoleMessages_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formConsoleMessages_FormClosingHandler(): " & strStatus, "formConsoleMessages_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formConsoleMessages_FormSave()

    End Sub ' END Sub - formConsoleMessages_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopConsoleMessagesMainMethods

#Region "formMethods"

    Public Sub DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods

        Dim strStatus As String = ""

        Dim objformConsoleMessages As formConsoleMessages = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim bFormAlreadyOpen As Boolean = False

        Try

            objformConsoleMessages = New formConsoleMessages

            ' Get existing instance of form.
            If objFormCollection.OfType(Of formConsoleMessages).Any Then
                objformConsoleMessages = objFormCollection.Item("formConsoleMessages")
                bFormAlreadyOpen = True
            End If

            objformConsoleMessages.Text() = "Messages - " & nsStringMethods.ReplaceNonPrintChars(strTitle)

            objformConsoleMessages.formConsoleMessages_BringToFrontLabel.Text() = "Y"

            objformConsoleMessages.formConsoleMessagesRichTextBox.Clear()
            objformConsoleMessages.formConsoleMessagesRichTextBox.Visible = True
            objformConsoleMessages.formConsoleMessagesRichTextBox.BringToFront()
            objformConsoleMessages.formConsoleMessagesRichTextBox.BackColor = System.Drawing.Color.White
            objformConsoleMessages.formConsoleMessagesRichTextBox.Multiline = True
            objformConsoleMessages.formConsoleMessagesRichTextBox.ReadOnly = True
            objformConsoleMessages.formConsoleMessagesRichTextBox.WordWrap = True

            objformConsoleMessages.formConsoleMessagesRichTextBox.Font = New System.Drawing.Font(System.Drawing.FontFamily.GenericMonospace, 8, System.Drawing.FontStyle.Regular)

            objformConsoleMessages.formConsoleMessagesRichTextBox.Text() = strTitle
            objformConsoleMessages.formConsoleMessagesRichTextBox.SelectionStart = 0
            objformConsoleMessages.formConsoleMessagesRichTextBox.SelectionLength = strTitle.Length
            objformConsoleMessages.formConsoleMessagesRichTextBox.SelectionFont = New System.Drawing.Font(System.Drawing.FontFamily.GenericMonospace, 10, System.Drawing.FontStyle.Bold)
            objformConsoleMessages.formConsoleMessagesRichTextBox.SelectionLength = 0

            ' Hide selection so AppendText will auto scroll to the end.
            objformConsoleMessages.formConsoleMessagesRichTextBox.HideSelection = False

            objformConsoleMessages.formConsoleMessagesRichTextBox.AppendText(System.Environment.NewLine)

            objformConsoleMessages.formConsoleMessagesRichTextBox.AppendText(strMessage)

            objformConsoleMessages.Show()
            objformConsoleMessages.Refresh()
            objformConsoleMessages.BringToFront()

        Catch ex As Exception
            strStatus = "DisplayMessage(): " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "DisplayMessage()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objformConsoleMessages = Nothing
        End Try

    End Sub ' END - DisplayMessage()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formConsoleMessages_CopyToClipboardButton_Click(sender As System.Object, e As System.EventArgs) Handles formConsoleMessages_CopyToClipboardButton.Click

        System.Windows.Forms.Clipboard.SetText(formConsoleMessagesRichTextBox.Text())

    End Sub ' END - formControllerAddUpdate_CancelButton_Click()

    Private Sub formConsoleMessages_CloseButton_Click(sender As System.Object, e As System.EventArgs) Handles formConsoleMessages_CloseButton.Click

        Me.Close()

    End Sub ' END - formControllerAddUpdate_CancelButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formConsoleMessages_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationConsoleMessages" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formConsoleMessages_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objX10ManagerDesktop As X10ManagerDesktop = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objLocation = New System.Drawing.Point

                ' Get form's initial location as set by Main Form (System.Drawing.Point(x, y).
                If objFormCollection.OfType(Of X10ManagerDesktop).Any Then
                    objX10ManagerDesktop = New X10ManagerDesktop
                    objX10ManagerDesktop = objFormCollection.Item("X10ManagerDesktop")
                    objLocation = objX10ManagerDesktop.Location
                Else
                    objLocation = Me.Location
                End If

                ' Set additional offset
                objLocation.Offset(460, 100)

                objSize = New System.Drawing.Size(480, 450)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationConsoleMessages Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationConsoleMessages.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationConsoleMessages.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 2) Then
                            objLocation = New System.Drawing.Point(Integer.Parse(arrInitialLocationSize(0)), Integer.Parse(arrInitialLocationSize(1)))
                        End If

                        'If (arrInitialLocationSize.Length >= 4) Then
                        'objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        'End If

                    End If

                End If

                Me.Location = objLocation

            End If

            Me.BringToFront()

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formConsoleMessages_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formConsoleMessages_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
            objX10ManagerDesktop = Nothing
            objFormCollection = Nothing
        End Try

        Return strStatus

    End Function ' END - formConsoleMessages_FormRestore()

    '=====================================================================================
    ' Function formConsoleMessages_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationConsoleMessages" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formConsoleMessages_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationConsoleMessages = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationConsoleMessages = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formConsoleMessages_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formConsoleMessages_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formConsoleMessages_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class