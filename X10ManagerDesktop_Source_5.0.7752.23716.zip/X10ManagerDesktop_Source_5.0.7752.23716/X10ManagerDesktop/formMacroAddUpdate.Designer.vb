﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formMacroAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formMacroAddUpdate))
        Me.formMacroAddUpdateMacroInitatorIDLabelText = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroInInitatorNameLabelText = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateCallingFormLabelText = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroInitatorNameLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroIDLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formMacroAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formMacroAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formMacroAddUpdate_BringToFrontLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroCommandsLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroCommandsDataGridView = New System.Windows.Forms.DataGridView()
        Me.formMacroAddUpdateRfLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateRfOffRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroAddUpdateRfOnRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroAddUpdateRfFunctionPanel = New System.Windows.Forms.Panel()
        Me.formMacroAddUpdateInhibitRetriggerLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroAddUpdateInhibitRetriggerPanel = New System.Windows.Forms.Panel()
        Me.formMacroAddUpdateDelayDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.formMacroAddUpdateDelayLabelFormat = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateDelayLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroSortOrderLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroSortOrderComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroAddUpdateDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.formMacroAddUpdateDescriptionLabel = New System.Windows.Forms.Label()
        Me.formMacroAddUpdateMacroNameTextBox = New System.Windows.Forms.TextBox()
        Me.formMacroAddUpdateMacroNameLabel = New System.Windows.Forms.Label()
        CType(Me.formMacroAddUpdateMacroCommandsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.formMacroAddUpdateRfFunctionPanel.SuspendLayout()
        Me.formMacroAddUpdateInhibitRetriggerPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'formMacroAddUpdateMacroInitatorIDLabelText
        '
        Me.formMacroAddUpdateMacroInitatorIDLabelText.AutoSize = True
        Me.formMacroAddUpdateMacroInitatorIDLabelText.Location = New System.Drawing.Point(161, 553)
        Me.formMacroAddUpdateMacroInitatorIDLabelText.Name = "formMacroAddUpdateMacroInitatorIDLabelText"
        Me.formMacroAddUpdateMacroInitatorIDLabelText.Size = New System.Drawing.Size(80, 13)
        Me.formMacroAddUpdateMacroInitatorIDLabelText.TabIndex = 70
        Me.formMacroAddUpdateMacroInitatorIDLabelText.Text = "MacroInitatorID"
        Me.formMacroAddUpdateMacroInitatorIDLabelText.Visible = False
        '
        'formMacroAddUpdateMacroInInitatorNameLabelText
        '
        Me.formMacroAddUpdateMacroInInitatorNameLabelText.AutoSize = True
        Me.formMacroAddUpdateMacroInInitatorNameLabelText.Location = New System.Drawing.Point(148, 114)
        Me.formMacroAddUpdateMacroInInitatorNameLabelText.Name = "formMacroAddUpdateMacroInInitatorNameLabelText"
        Me.formMacroAddUpdateMacroInInitatorNameLabelText.Size = New System.Drawing.Size(105, 13)
        Me.formMacroAddUpdateMacroInInitatorNameLabelText.TabIndex = 69
        Me.formMacroAddUpdateMacroInInitatorNameLabelText.Text = "macroInInitatorName"
        '
        'formMacroAddUpdateCallingFormLabelText
        '
        Me.formMacroAddUpdateCallingFormLabelText.AutoSize = True
        Me.formMacroAddUpdateCallingFormLabelText.Location = New System.Drawing.Point(65, 553)
        Me.formMacroAddUpdateCallingFormLabelText.Name = "formMacroAddUpdateCallingFormLabelText"
        Me.formMacroAddUpdateCallingFormLabelText.Size = New System.Drawing.Size(64, 13)
        Me.formMacroAddUpdateCallingFormLabelText.TabIndex = 68
        Me.formMacroAddUpdateCallingFormLabelText.Text = "Calling Form"
        Me.formMacroAddUpdateCallingFormLabelText.Visible = False
        '
        'formMacroAddUpdateMacroInitatorNameLabel
        '
        Me.formMacroAddUpdateMacroInitatorNameLabel.AutoSize = True
        Me.formMacroAddUpdateMacroInitatorNameLabel.Location = New System.Drawing.Point(35, 114)
        Me.formMacroAddUpdateMacroInitatorNameLabel.Name = "formMacroAddUpdateMacroInitatorNameLabel"
        Me.formMacroAddUpdateMacroInitatorNameLabel.Size = New System.Drawing.Size(108, 13)
        Me.formMacroAddUpdateMacroInitatorNameLabel.TabIndex = 67
        Me.formMacroAddUpdateMacroInitatorNameLabel.Text = "Macro Initiator Name:"
        '
        'formMacroAddUpdate_StatusLabel
        '
        Me.formMacroAddUpdate_StatusLabel.AutoSize = True
        Me.formMacroAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formMacroAddUpdate_StatusLabel.Location = New System.Drawing.Point(148, 582)
        Me.formMacroAddUpdate_StatusLabel.Name = "formMacroAddUpdate_StatusLabel"
        Me.formMacroAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formMacroAddUpdate_StatusLabel.TabIndex = 66
        Me.formMacroAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formMacroAddUpdateIDLabelText
        '
        Me.formMacroAddUpdateIDLabelText.AutoSize = True
        Me.formMacroAddUpdateIDLabelText.Location = New System.Drawing.Point(148, 53)
        Me.formMacroAddUpdateIDLabelText.Name = "formMacroAddUpdateIDLabelText"
        Me.formMacroAddUpdateIDLabelText.Size = New System.Drawing.Size(169, 13)
        Me.formMacroAddUpdateIDLabelText.TabIndex = 65
        Me.formMacroAddUpdateIDLabelText.Text = "formMacroAddUpdateIDLabelText"
        '
        'formMacroAddUpdateMacroIDLabel
        '
        Me.formMacroAddUpdateMacroIDLabel.AutoSize = True
        Me.formMacroAddUpdateMacroIDLabel.Location = New System.Drawing.Point(91, 53)
        Me.formMacroAddUpdateMacroIDLabel.Name = "formMacroAddUpdateMacroIDLabel"
        Me.formMacroAddUpdateMacroIDLabel.Size = New System.Drawing.Size(51, 13)
        Me.formMacroAddUpdateMacroIDLabel.TabIndex = 64
        Me.formMacroAddUpdateMacroIDLabel.Text = "MacroID:"
        '
        'formMacroAddUpdate_DeleteButton
        '
        Me.formMacroAddUpdate_DeleteButton.Location = New System.Drawing.Point(526, 48)
        Me.formMacroAddUpdate_DeleteButton.Name = "formMacroAddUpdate_DeleteButton"
        Me.formMacroAddUpdate_DeleteButton.Size = New System.Drawing.Size(79, 23)
        Me.formMacroAddUpdate_DeleteButton.TabIndex = 63
        Me.formMacroAddUpdate_DeleteButton.Text = "Delete"
        Me.formMacroAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formMacroAddUpdate_AddUpdateButton
        '
        Me.formMacroAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(56, 579)
        Me.formMacroAddUpdate_AddUpdateButton.Name = "formMacroAddUpdate_AddUpdateButton"
        Me.formMacroAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(86, 23)
        Me.formMacroAddUpdate_AddUpdateButton.TabIndex = 62
        Me.formMacroAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formMacroAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formMacroAddUpdate_CancelButton
        '
        Me.formMacroAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formMacroAddUpdate_CancelButton.Location = New System.Drawing.Point(526, 579)
        Me.formMacroAddUpdate_CancelButton.Name = "formMacroAddUpdate_CancelButton"
        Me.formMacroAddUpdate_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formMacroAddUpdate_CancelButton.TabIndex = 61
        Me.formMacroAddUpdate_CancelButton.Text = "Cancel"
        Me.formMacroAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formMacroAddUpdate_BringToFrontLabel
        '
        Me.formMacroAddUpdate_BringToFrontLabel.AutoSize = True
        Me.formMacroAddUpdate_BringToFrontLabel.Location = New System.Drawing.Point(11, 301)
        Me.formMacroAddUpdate_BringToFrontLabel.Name = "formMacroAddUpdate_BringToFrontLabel"
        Me.formMacroAddUpdate_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formMacroAddUpdate_BringToFrontLabel.TabIndex = 73
        Me.formMacroAddUpdate_BringToFrontLabel.Text = "Y | N"
        Me.formMacroAddUpdate_BringToFrontLabel.Visible = False
        '
        'formMacroAddUpdateMacroCommandsLabel
        '
        Me.formMacroAddUpdateMacroCommandsLabel.AutoSize = True
        Me.formMacroAddUpdateMacroCommandsLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formMacroAddUpdateMacroCommandsLabel.Location = New System.Drawing.Point(6, 267)
        Me.formMacroAddUpdateMacroCommandsLabel.Name = "formMacroAddUpdateMacroCommandsLabel"
        Me.formMacroAddUpdateMacroCommandsLabel.Size = New System.Drawing.Size(121, 17)
        Me.formMacroAddUpdateMacroCommandsLabel.TabIndex = 72
        Me.formMacroAddUpdateMacroCommandsLabel.Text = "Macro Commands"
        '
        'formMacroAddUpdateMacroCommandsDataGridView
        '
        Me.formMacroAddUpdateMacroCommandsDataGridView.AllowDrop = True
        Me.formMacroAddUpdateMacroCommandsDataGridView.AllowUserToAddRows = False
        Me.formMacroAddUpdateMacroCommandsDataGridView.AllowUserToDeleteRows = False
        Me.formMacroAddUpdateMacroCommandsDataGridView.AllowUserToResizeColumns = False
        Me.formMacroAddUpdateMacroCommandsDataGridView.AllowUserToResizeRows = False
        Me.formMacroAddUpdateMacroCommandsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formMacroAddUpdateMacroCommandsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formMacroAddUpdateMacroCommandsDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.formMacroAddUpdateMacroCommandsDataGridView.Location = New System.Drawing.Point(0, 287)
        Me.formMacroAddUpdateMacroCommandsDataGridView.Name = "formMacroAddUpdateMacroCommandsDataGridView"
        Me.formMacroAddUpdateMacroCommandsDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.formMacroAddUpdateMacroCommandsDataGridView.ShowCellToolTips = False
        Me.formMacroAddUpdateMacroCommandsDataGridView.ShowEditingIcon = False
        Me.formMacroAddUpdateMacroCommandsDataGridView.Size = New System.Drawing.Size(779, 263)
        Me.formMacroAddUpdateMacroCommandsDataGridView.TabIndex = 71
        '
        'formMacroAddUpdateRfLabel
        '
        Me.formMacroAddUpdateRfLabel.AutoSize = True
        Me.formMacroAddUpdateRfLabel.Location = New System.Drawing.Point(118, 176)
        Me.formMacroAddUpdateRfLabel.Name = "formMacroAddUpdateRfLabel"
        Me.formMacroAddUpdateRfLabel.Size = New System.Drawing.Size(24, 13)
        Me.formMacroAddUpdateRfLabel.TabIndex = 81
        Me.formMacroAddUpdateRfLabel.Text = "RF:"
        '
        'formMacroAddUpdateRfOffRadioButton
        '
        Me.formMacroAddUpdateRfOffRadioButton.AutoSize = True
        Me.formMacroAddUpdateRfOffRadioButton.Location = New System.Drawing.Point(50, 6)
        Me.formMacroAddUpdateRfOffRadioButton.Name = "formMacroAddUpdateRfOffRadioButton"
        Me.formMacroAddUpdateRfOffRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.formMacroAddUpdateRfOffRadioButton.TabIndex = 63
        Me.formMacroAddUpdateRfOffRadioButton.TabStop = True
        Me.formMacroAddUpdateRfOffRadioButton.Text = "Off"
        Me.formMacroAddUpdateRfOffRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroAddUpdateRfOnRadioButton
        '
        Me.formMacroAddUpdateRfOnRadioButton.AutoSize = True
        Me.formMacroAddUpdateRfOnRadioButton.Location = New System.Drawing.Point(3, 6)
        Me.formMacroAddUpdateRfOnRadioButton.Name = "formMacroAddUpdateRfOnRadioButton"
        Me.formMacroAddUpdateRfOnRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.formMacroAddUpdateRfOnRadioButton.TabIndex = 39
        Me.formMacroAddUpdateRfOnRadioButton.TabStop = True
        Me.formMacroAddUpdateRfOnRadioButton.Text = "On"
        Me.formMacroAddUpdateRfOnRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroAddUpdateRfFunctionPanel
        '
        Me.formMacroAddUpdateRfFunctionPanel.Controls.Add(Me.formMacroAddUpdateRfOffRadioButton)
        Me.formMacroAddUpdateRfFunctionPanel.Controls.Add(Me.formMacroAddUpdateRfOnRadioButton)
        Me.formMacroAddUpdateRfFunctionPanel.Location = New System.Drawing.Point(152, 168)
        Me.formMacroAddUpdateRfFunctionPanel.Name = "formMacroAddUpdateRfFunctionPanel"
        Me.formMacroAddUpdateRfFunctionPanel.Size = New System.Drawing.Size(100, 29)
        Me.formMacroAddUpdateRfFunctionPanel.TabIndex = 82
        '
        'formMacroAddUpdateInhibitRetriggerLabel
        '
        Me.formMacroAddUpdateInhibitRetriggerLabel.AutoSize = True
        Me.formMacroAddUpdateInhibitRetriggerLabel.Location = New System.Drawing.Point(57, 237)
        Me.formMacroAddUpdateInhibitRetriggerLabel.Name = "formMacroAddUpdateInhibitRetriggerLabel"
        Me.formMacroAddUpdateInhibitRetriggerLabel.Size = New System.Drawing.Size(84, 13)
        Me.formMacroAddUpdateInhibitRetriggerLabel.TabIndex = 83
        Me.formMacroAddUpdateInhibitRetriggerLabel.Text = "Inhibit Retrigger:"
        '
        'formMacroAddUpdateInhibitRetriggerOffRadioButton
        '
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.AutoSize = True
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.Location = New System.Drawing.Point(50, 6)
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.Name = "formMacroAddUpdateInhibitRetriggerOffRadioButton"
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.TabIndex = 63
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.TabStop = True
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.Text = "Off"
        Me.formMacroAddUpdateInhibitRetriggerOffRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroAddUpdateInhibitRetriggerOnRadioButton
        '
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.AutoSize = True
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.Location = New System.Drawing.Point(3, 6)
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.Name = "formMacroAddUpdateInhibitRetriggerOnRadioButton"
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.TabIndex = 39
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.TabStop = True
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.Text = "On"
        Me.formMacroAddUpdateInhibitRetriggerOnRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroAddUpdateInhibitRetriggerPanel
        '
        Me.formMacroAddUpdateInhibitRetriggerPanel.Controls.Add(Me.formMacroAddUpdateInhibitRetriggerOffRadioButton)
        Me.formMacroAddUpdateInhibitRetriggerPanel.Controls.Add(Me.formMacroAddUpdateInhibitRetriggerOnRadioButton)
        Me.formMacroAddUpdateInhibitRetriggerPanel.Location = New System.Drawing.Point(151, 229)
        Me.formMacroAddUpdateInhibitRetriggerPanel.Name = "formMacroAddUpdateInhibitRetriggerPanel"
        Me.formMacroAddUpdateInhibitRetriggerPanel.Size = New System.Drawing.Size(100, 29)
        Me.formMacroAddUpdateInhibitRetriggerPanel.TabIndex = 84
        '
        'formMacroAddUpdateDelayDateTimePicker
        '
        Me.formMacroAddUpdateDelayDateTimePicker.CustomFormat = "HH:mm:ss"
        Me.formMacroAddUpdateDelayDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.formMacroAddUpdateDelayDateTimePicker.Location = New System.Drawing.Point(151, 203)
        Me.formMacroAddUpdateDelayDateTimePicker.Name = "formMacroAddUpdateDelayDateTimePicker"
        Me.formMacroAddUpdateDelayDateTimePicker.Size = New System.Drawing.Size(70, 20)
        Me.formMacroAddUpdateDelayDateTimePicker.TabIndex = 86
        Me.formMacroAddUpdateDelayDateTimePicker.Value = New Date(2021, 2, 10, 0, 0, 0, 0)
        '
        'formMacroAddUpdateDelayLabelFormat
        '
        Me.formMacroAddUpdateDelayLabelFormat.AutoSize = True
        Me.formMacroAddUpdateDelayLabelFormat.Location = New System.Drawing.Point(227, 205)
        Me.formMacroAddUpdateDelayLabelFormat.Name = "formMacroAddUpdateDelayLabelFormat"
        Me.formMacroAddUpdateDelayLabelFormat.Size = New System.Drawing.Size(199, 13)
        Me.formMacroAddUpdateDelayLabelFormat.TabIndex = 85
        Me.formMacroAddUpdateDelayLabelFormat.Text = "Maximum 4 hours, 30 minutes (hh:mm:ss)"
        '
        'formMacroAddUpdateDelayLabel
        '
        Me.formMacroAddUpdateDelayLabel.AutoSize = True
        Me.formMacroAddUpdateDelayLabel.Location = New System.Drawing.Point(105, 205)
        Me.formMacroAddUpdateDelayLabel.Name = "formMacroAddUpdateDelayLabel"
        Me.formMacroAddUpdateDelayLabel.Size = New System.Drawing.Size(37, 13)
        Me.formMacroAddUpdateDelayLabel.TabIndex = 87
        Me.formMacroAddUpdateDelayLabel.Text = "Delay:"
        '
        'formMacroAddUpdateMacroSortOrderLabel
        '
        Me.formMacroAddUpdateMacroSortOrderLabel.AutoSize = True
        Me.formMacroAddUpdateMacroSortOrderLabel.Location = New System.Drawing.Point(51, 144)
        Me.formMacroAddUpdateMacroSortOrderLabel.Name = "formMacroAddUpdateMacroSortOrderLabel"
        Me.formMacroAddUpdateMacroSortOrderLabel.Size = New System.Drawing.Size(91, 13)
        Me.formMacroAddUpdateMacroSortOrderLabel.TabIndex = 88
        Me.formMacroAddUpdateMacroSortOrderLabel.Text = "Macro Sort Order:"
        '
        'formMacroAddUpdateMacroSortOrderComboBox
        '
        Me.formMacroAddUpdateMacroSortOrderComboBox.FormattingEnabled = True
        Me.formMacroAddUpdateMacroSortOrderComboBox.Location = New System.Drawing.Point(152, 141)
        Me.formMacroAddUpdateMacroSortOrderComboBox.Name = "formMacroAddUpdateMacroSortOrderComboBox"
        Me.formMacroAddUpdateMacroSortOrderComboBox.Size = New System.Drawing.Size(69, 21)
        Me.formMacroAddUpdateMacroSortOrderComboBox.TabIndex = 89
        '
        'formMacroAddUpdateDescriptionTextBox
        '
        Me.formMacroAddUpdateDescriptionTextBox.Location = New System.Drawing.Point(149, 79)
        Me.formMacroAddUpdateDescriptionTextBox.MaxLength = 100
        Me.formMacroAddUpdateDescriptionTextBox.Name = "formMacroAddUpdateDescriptionTextBox"
        Me.formMacroAddUpdateDescriptionTextBox.Size = New System.Drawing.Size(392, 20)
        Me.formMacroAddUpdateDescriptionTextBox.TabIndex = 95
        '
        'formMacroAddUpdateDescriptionLabel
        '
        Me.formMacroAddUpdateDescriptionLabel.AutoSize = True
        Me.formMacroAddUpdateDescriptionLabel.Location = New System.Drawing.Point(80, 82)
        Me.formMacroAddUpdateDescriptionLabel.Name = "formMacroAddUpdateDescriptionLabel"
        Me.formMacroAddUpdateDescriptionLabel.Size = New System.Drawing.Size(63, 13)
        Me.formMacroAddUpdateDescriptionLabel.TabIndex = 94
        Me.formMacroAddUpdateDescriptionLabel.Text = "Description:"
        '
        'formMacroAddUpdateMacroNameTextBox
        '
        Me.formMacroAddUpdateMacroNameTextBox.Location = New System.Drawing.Point(149, 20)
        Me.formMacroAddUpdateMacroNameTextBox.MaxLength = 40
        Me.formMacroAddUpdateMacroNameTextBox.Name = "formMacroAddUpdateMacroNameTextBox"
        Me.formMacroAddUpdateMacroNameTextBox.Size = New System.Drawing.Size(392, 20)
        Me.formMacroAddUpdateMacroNameTextBox.TabIndex = 93
        Me.formMacroAddUpdateMacroNameTextBox.Text = "formMacroAddUpdateMacroNameTextBox"
        Me.formMacroAddUpdateMacroNameTextBox.WordWrap = False
        '
        'formMacroAddUpdateMacroNameLabel
        '
        Me.formMacroAddUpdateMacroNameLabel.AutoSize = True
        Me.formMacroAddUpdateMacroNameLabel.Location = New System.Drawing.Point(72, 23)
        Me.formMacroAddUpdateMacroNameLabel.Name = "formMacroAddUpdateMacroNameLabel"
        Me.formMacroAddUpdateMacroNameLabel.Size = New System.Drawing.Size(71, 13)
        Me.formMacroAddUpdateMacroNameLabel.TabIndex = 92
        Me.formMacroAddUpdateMacroNameLabel.Text = "Macro Name:"
        '
        'formMacroAddUpdate
        '
        Me.AcceptButton = Me.formMacroAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formMacroAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(780, 627)
        Me.Controls.Add(Me.formMacroAddUpdateDescriptionTextBox)
        Me.Controls.Add(Me.formMacroAddUpdateDescriptionLabel)
        Me.Controls.Add(Me.formMacroAddUpdateMacroNameTextBox)
        Me.Controls.Add(Me.formMacroAddUpdateMacroNameLabel)
        Me.Controls.Add(Me.formMacroAddUpdateMacroSortOrderComboBox)
        Me.Controls.Add(Me.formMacroAddUpdateMacroSortOrderLabel)
        Me.Controls.Add(Me.formMacroAddUpdateDelayLabel)
        Me.Controls.Add(Me.formMacroAddUpdateDelayDateTimePicker)
        Me.Controls.Add(Me.formMacroAddUpdateDelayLabelFormat)
        Me.Controls.Add(Me.formMacroAddUpdateInhibitRetriggerLabel)
        Me.Controls.Add(Me.formMacroAddUpdateInhibitRetriggerPanel)
        Me.Controls.Add(Me.formMacroAddUpdateRfLabel)
        Me.Controls.Add(Me.formMacroAddUpdateRfFunctionPanel)
        Me.Controls.Add(Me.formMacroAddUpdate_BringToFrontLabel)
        Me.Controls.Add(Me.formMacroAddUpdateMacroCommandsLabel)
        Me.Controls.Add(Me.formMacroAddUpdateMacroCommandsDataGridView)
        Me.Controls.Add(Me.formMacroAddUpdateMacroInitatorIDLabelText)
        Me.Controls.Add(Me.formMacroAddUpdateMacroInInitatorNameLabelText)
        Me.Controls.Add(Me.formMacroAddUpdateCallingFormLabelText)
        Me.Controls.Add(Me.formMacroAddUpdateMacroInitatorNameLabel)
        Me.Controls.Add(Me.formMacroAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formMacroAddUpdateIDLabelText)
        Me.Controls.Add(Me.formMacroAddUpdateMacroIDLabel)
        Me.Controls.Add(Me.formMacroAddUpdate_DeleteButton)
        Me.Controls.Add(Me.formMacroAddUpdate_AddUpdateButton)
        Me.Controls.Add(Me.formMacroAddUpdate_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formMacroAddUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Macro Add / Update"
        CType(Me.formMacroAddUpdateMacroCommandsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.formMacroAddUpdateRfFunctionPanel.ResumeLayout(False)
        Me.formMacroAddUpdateRfFunctionPanel.PerformLayout()
        Me.formMacroAddUpdateInhibitRetriggerPanel.ResumeLayout(False)
        Me.formMacroAddUpdateInhibitRetriggerPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formMacroAddUpdateMacroInitatorIDLabelText As Label
    Friend WithEvents formMacroAddUpdateMacroInInitatorNameLabelText As Label
    Friend WithEvents formMacroAddUpdateCallingFormLabelText As Label
    Friend WithEvents formMacroAddUpdateMacroInitatorNameLabel As Label
    Friend WithEvents formMacroAddUpdate_StatusLabel As Label
    Friend WithEvents formMacroAddUpdateIDLabelText As Label
    Friend WithEvents formMacroAddUpdateMacroIDLabel As Label
    Friend WithEvents formMacroAddUpdate_DeleteButton As Button
    Friend WithEvents formMacroAddUpdate_AddUpdateButton As Button
    Friend WithEvents formMacroAddUpdate_CancelButton As Button
    Friend WithEvents formMacroAddUpdate_BringToFrontLabel As Label
    Friend WithEvents formMacroAddUpdateMacroCommandsLabel As Label
    Friend WithEvents formMacroAddUpdateMacroCommandsDataGridView As DataGridView
    Friend WithEvents formMacroAddUpdateRfLabel As Label
    Friend WithEvents formMacroAddUpdateRfOffRadioButton As RadioButton
    Friend WithEvents formMacroAddUpdateRfOnRadioButton As RadioButton
    Friend WithEvents formMacroAddUpdateRfFunctionPanel As Panel
    Friend WithEvents formMacroAddUpdateInhibitRetriggerLabel As Label
    Friend WithEvents formMacroAddUpdateInhibitRetriggerOffRadioButton As RadioButton
    Friend WithEvents formMacroAddUpdateInhibitRetriggerOnRadioButton As RadioButton
    Friend WithEvents formMacroAddUpdateInhibitRetriggerPanel As Panel
    Friend WithEvents formMacroAddUpdateDelayDateTimePicker As DateTimePicker
    Friend WithEvents formMacroAddUpdateDelayLabelFormat As Label
    Friend WithEvents formMacroAddUpdateDelayLabel As Label
    Friend WithEvents formMacroAddUpdateMacroSortOrderLabel As Label
    Friend WithEvents formMacroAddUpdateMacroSortOrderComboBox As ComboBox
    Friend WithEvents formMacroAddUpdateDescriptionTextBox As TextBox
    Friend WithEvents formMacroAddUpdateDescriptionLabel As Label
    Friend WithEvents formMacroAddUpdateMacroNameTextBox As TextBox
    Friend WithEvents formMacroAddUpdateMacroNameLabel As Label
End Class
