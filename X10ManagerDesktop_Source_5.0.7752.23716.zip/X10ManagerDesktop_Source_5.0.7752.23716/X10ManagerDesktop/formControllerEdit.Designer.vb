﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formControllerEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.formControllerEditDataGridView = New System.Windows.Forms.DataGridView()
        Me.formControllerEdit_BringToFrontLabel = New System.Windows.Forms.Label()
        CType(Me.formControllerEditDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'formControllerEditDataGridView
        '
        Me.formControllerEditDataGridView.AllowUserToAddRows = False
        Me.formControllerEditDataGridView.AllowUserToDeleteRows = False
        Me.formControllerEditDataGridView.AllowUserToResizeRows = False
        Me.formControllerEditDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formControllerEditDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formControllerEditDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.formControllerEditDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.formControllerEditDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.formControllerEditDataGridView.Name = "formControllerEditDataGridView"
        Me.formControllerEditDataGridView.ReadOnly = True
        Me.formControllerEditDataGridView.ShowCellToolTips = False
        Me.formControllerEditDataGridView.ShowEditingIcon = False
        Me.formControllerEditDataGridView.Size = New System.Drawing.Size(675, 358)
        Me.formControllerEditDataGridView.TabIndex = 1
        '
        'formControllerEdit_BringToFrontLabel
        '
        Me.formControllerEdit_BringToFrontLabel.AutoSize = True
        Me.formControllerEdit_BringToFrontLabel.Location = New System.Drawing.Point(12, 9)
        Me.formControllerEdit_BringToFrontLabel.Name = "formControllerEdit_BringToFrontLabel"
        Me.formControllerEdit_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formControllerEdit_BringToFrontLabel.TabIndex = 2
        Me.formControllerEdit_BringToFrontLabel.Text = "Y | N"
        Me.formControllerEdit_BringToFrontLabel.Visible = False
        '
        'formControllerEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(675, 358)
        Me.Controls.Add(Me.formControllerEdit_BringToFrontLabel)
        Me.Controls.Add(Me.formControllerEditDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formControllerEdit"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Controller Edit"
        CType(Me.formControllerEditDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents formControllerEditDataGridView As DataGridView
    Friend WithEvents formControllerEdit_BringToFrontLabel As Label
End Class
