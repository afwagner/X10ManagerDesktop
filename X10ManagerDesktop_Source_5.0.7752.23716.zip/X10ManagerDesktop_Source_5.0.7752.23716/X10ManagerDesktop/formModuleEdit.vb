﻿
' Name: formModuleEdit.vb
' By: Alan Wagner
' Date: March 2020

Public Class formModuleEdit

#Region "X10ManagerDesktopModuleEditMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Try

            strTryStep = "formModuleEdit_BringToFrontLabel"
            If (formModuleEdit_BringToFrontLabel.Text() = "Y") Then
                Me.BringToFront()
            Else
                formModuleEdit_BringToFrontLabel.Text() = "Y"
            End If

            strTryStep = "formModuleEdit_FormRestore"
            ' formModuleAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formModuleEdit_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                ' formModuleEdit_GetModulesDataSet() As String
                strStatus = formModuleEdit_GetModulesDataSet()
                If (strStatus <> "") Then
                    Windows.Forms.MessageBox.Show("Main(formModuleEdit): " & strStatus, "Main(formModuleEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formModuleEdit_GetModulesDataSet()

            Else
                Windows.Forms.MessageBox.Show("Main(formModuleEdit): " & strStatus, "Main(formModuleEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - formModuleEdit_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formModuleEdit): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try

    End Sub ' END Sub - Main(formModuleEdit)

    Private Sub formModuleEdit_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formModuleEdit_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formModuleEdit_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formModuleEdit_FormClosingHandler(): " & strStatus, "formModuleEdit_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formModuleEdit_FormSave()

    End Sub ' END Sub - formModuleEdit_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopModuleEditMainMethods

#Region "formMethods"

    '=====================================================================================
    ' formModuleEdit_GetModulesDataSet()
    ' Alan Wagner
    '
    ' vb.net set current row datagridview
    '
    ' https://stackoverflow.com/questions/22304743/data-grid-view-programmatically-setting-the-select-row-index-doesnt-set-the-c
    ' Data Grid View…programmatically setting the select row index doesn't set the CurrentRow.Index to the same?
    '
    ' https://stackoverflow.com/questions/2442419/how-to-save-position-after-reload-datagridview
    ' How to save position after reload DataGridView 
    '
    Public Function formModuleEdit_GetModulesDataSet() As String
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim intCurrentCellRowIndex As Integer = -1
        Dim intFirstDisplayedCellRowIndex As Integer = -1

        Dim objDataSetModules As New System.Data.DataSet
        Dim sqlString As String = ""

        Dim intColumnID As Integer = 10     ' Column that contains UnitID.
        Dim intColumnHN As Integer = 11    ' Column that contains HN - UnitHouseNumber.
        Dim intColumnMN As Integer = 12    ' Column that contains MN - UnitModuleNumbr.

        Dim bShowAdvancedInformation As Boolean = False

        strTryStep = "bShowAdvancedInformation"
        Select Case X10ManagerDesktop.showAdvancedInformation
            Case 0
                bShowAdvancedInformation = False
            Case 1
                bShowAdvancedInformation = True
        End Select

        Try

            strTryStep = "sqlStringDataSetModules"
            sqlString = "SELECT 'Edit' AS [AddEdit]," &
                        "IIf(Controllers.ControllerID Is Null,'', Controllers.ControllerName+' ['+ControllerTypes.ControllerType+']') AS [Controller]," &
                        "Units.UnitCode AS [Code], Units.UnitName AS [Name], Units.UnitDescription AS [Description]," &
                        "SWITCH (Units.UnitEnabled=0,'N',Units.UnitEnabled=1,'Y') AS [Enabled]," &
                        "SWITCH (Units.UnitDimmer=0,'N',Units.UnitDimmer=1,'Y') AS [Dimmer]," &
                        "SWITCH (Units.UnitLighting=0,'N',Units.UnitLighting=1,'Y') AS [Lighting]," &
                        "SWITCH (Units.UnitExtendedCommands=0,'N',Units.UnitExtendedCommands=1,'Y') AS [Extended]," &
                        "SWITCH (ControllerActive=0,'N',ControllerActive=1,'Y') AS [ControllerActive]," &
                        "Units.UnitID AS [ID]," &
                        "Units.UnitHouseNumber AS [HN]," &
                        "Units.UnitModuleNumber AS [MN] " &
                        "FROM ((Units LEFT JOIN Controllers ON Controllers.ControllerID=Units.ControllerID) LEFT JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID) " &
                        "WHERE Units.UnitID > -1 " &
                        "UNION " &
                        "SELECT 'Add' AS [AddEdit], '' AS [Controller], '' AS [Code], '' AS [Name], '' AS [Description], '' AS [Enabled], '' AS [Dimmer], '' AS [Lighting], '' AS [Extended], '' AS [ControllerActive], UnitID AS [ID], -1 AS [HN], -1 AS [MN] " &
                        "FROM Units " &
                        "WHERE UnitID = -1 " &
                        "ORDER BY [AddEdit], [Controller], [HN], [MN];"

            strTryStep = "UsingConnection"
            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString)

                strTryStep = "Open"
                objConnection.Open()

                strTryStep = "OleDbDataAdapter"
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)

                strTryStep = "Fill"
                objOleDbDataAdapter.Fill(objDataSetModules)

                strTryStep = "Close"
                objConnection.Close()
                objOleDbDataAdapter = Nothing

            End Using

            strTryStep = "TablesDataSetModules"
            formModuleEditDataGridView.DataSource = objDataSetModules.Tables(0)

            strTryStep = "SelectCaseShowAdvancedInformation"
            Select Case bShowAdvancedInformation
                Case True

                    strTryStep = "IDVisibleTrue"
                    formModuleEditDataGridView.Columns(intColumnID).Visible = True

                    strTryStep = "HNVisibleTrue"
                    formModuleEditDataGridView.Columns(intColumnHN).Visible = True

                    strTryStep = "MNVisibleTrue"
                    formModuleEditDataGridView.Columns(intColumnMN).Visible = True

                Case False

                    strTryStep = "IDVisibleFalse"
                    formModuleEditDataGridView.Columns(intColumnID).Visible = False

                    strTryStep = "HNVisibleFalse"
                    formModuleEditDataGridView.Columns(intColumnHN).Visible = False

                    strTryStep = "MNVisibleFalse"
                    formModuleEditDataGridView.Columns(intColumnMN).Visible = False

            End Select

            strTryStep = "DataGridViewCurrentCellRowIndexFormModuleEdit"
            intCurrentCellRowIndex = X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormModuleEdit

            strTryStep = "DataGridViewFirstDisplayedCellRowIndexFormModuleEdit"
            intFirstDisplayedCellRowIndex = X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormModuleEdit

            strTryStep = "CheckForRestoreCursorPostion"
            If (intCurrentCellRowIndex > -1 And intFirstDisplayedCellRowIndex > -1) Then
                formModuleEditDataGridView.FirstDisplayedScrollingRowIndex = intFirstDisplayedCellRowIndex
                formModuleEditDataGridView.CurrentCell = formModuleEditDataGridView.Rows(intCurrentCellRowIndex).Cells(0) ' Always restore to the first column.
            End If

        Catch ex As Exception
            strStatus = "formModuleEdit_GetModulesDataSet(): Exception: TryStep=" & strTryStep & ": " & ex.Message
        Finally
            objDataSetModules = Nothing
        End Try

        Return strStatus

    End Function ' END - formModuleEdit_GetModulesDataSet()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formModuleEditDataGridView_CellClick(ByVal objSender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles formModuleEditDataGridView.CellClick
        Dim strStatus As String = ""

        Dim strIDText As String = ""
        Dim bActiveFormFound = False
        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormModuleAddUpdate As formModuleAddUpdate = Nothing

        Dim objLocation As System.Drawing.Point = Nothing

        Dim intColumnID As Integer = 10    ' Column that contains UnitID.
        Dim intCurrentRow As Integer = -1

        Try

            ' Save current Cursor Position.
            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormModuleEdit = formModuleEditDataGridView.CurrentCell.RowIndex
            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormModuleEdit = formModuleEditDataGridView.FirstDisplayedCell.RowIndex

            intCurrentRow = formModuleEditDataGridView.CurrentRow.Index

            ' Including e.RowIndex >= 0 stops this from responding when Header Row is clicked.
            If (intCurrentRow >= 0 And e.RowIndex >= 0) Then
                ' Item(column, row)

                ' Get UnitID
                strIDText = formModuleEditDataGridView.Item(intColumnID, intCurrentRow).Value.ToString()

                If objFormCollection.OfType(Of formModuleAddUpdate).Any Then

                    If (strIDText = "-1") Then
                        ' Looking for already open Add form.

                        For Each objFormModuleAddUpdate In objFormCollection.OfType(Of formModuleAddUpdate)
                            If (objFormModuleAddUpdate.formModuleAddUpdateIDLabelText.Text() = "") Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    Else

                        For Each objFormModuleAddUpdate In objFormCollection.OfType(Of formModuleAddUpdate)
                            If (objFormModuleAddUpdate.formModuleAddUpdateIDLabelText.Text() = strIDText) Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    End If

                End If

                If bActiveFormFound Then
                    objFormModuleAddUpdate.Activate()
                Else

                    objFormModuleAddUpdate = Nothing
                    objFormModuleAddUpdate = New formModuleAddUpdate

                    objFormModuleAddUpdate.formModuleAddUpdateIDLabelText.Text() = strIDText

                    ' Opens as seperate form.
                    objFormModuleAddUpdate.TopLevel = True

                    ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                    objLocation = Parent.Location

                    ' Set additional offset
                    objLocation.Offset(50, 100)

                    ' Set default Location for new form to be Shown.
                    objFormModuleAddUpdate.Location = objLocation

                    objFormModuleAddUpdate.Show()

                End If

                objFormModuleAddUpdate.BringToFront()

            End If

        Catch ex As Exception
            strStatus = "formModuleEditDataGridView_CellClick(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formModuleEditDataGridView_CellClick()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormModuleAddUpdate = Nothing
            objFormCollection = Nothing
        End Try


    End Sub ' END - formModuleEditDataGridView_CellClick()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formModuleEdit_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleEdit" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formModuleEdit_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                ' Get form's initial location as set by calling Method (System.Drawing.Point(x, y).
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(1, 25)

                objSize = New System.Drawing.Size(660, 380)
                'objSize = Me.Size

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationModuleEdit Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationModuleEdit.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationModuleEdit.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 2) Then
                            objLocation = New System.Drawing.Point(Integer.Parse(arrInitialLocationSize(0)), Integer.Parse(arrInitialLocationSize(1)))
                        End If

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Location = objLocation
                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formModuleEdit_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formModuleEdit_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formModuleEdit_FormRestore()

    '=====================================================================================
    ' Function formModuleEdit_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleEdit" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formModuleEdit_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationModuleEdit = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationModuleEdit = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formModuleEdit_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formModuleEdit_FormSave(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formModuleEdit_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class