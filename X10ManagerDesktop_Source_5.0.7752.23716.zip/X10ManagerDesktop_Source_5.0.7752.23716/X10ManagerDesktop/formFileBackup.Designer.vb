﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formFileBackup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formFileBackup))
        Me.formFileBackup_CancelButton = New System.Windows.Forms.Button()
        Me.formFileBackupLocationLabelText = New System.Windows.Forms.Label()
        Me.formFileBackupLocationLabelNote = New System.Windows.Forms.Label()
        Me.formFileBackupLocationLabel = New System.Windows.Forms.Label()
        Me.formFileBackup_BackupButton = New System.Windows.Forms.Button()
        Me.formFileBackup_StatusLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'formFileBackup_CancelButton
        '
        Me.formFileBackup_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formFileBackup_CancelButton.Location = New System.Drawing.Point(317, 246)
        Me.formFileBackup_CancelButton.Name = "formFileBackup_CancelButton"
        Me.formFileBackup_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formFileBackup_CancelButton.TabIndex = 0
        Me.formFileBackup_CancelButton.Text = "Cancel"
        Me.formFileBackup_CancelButton.UseVisualStyleBackColor = True
        '
        'formFileBackupLocationLabelText
        '
        Me.formFileBackupLocationLabelText.AutoSize = True
        Me.formFileBackupLocationLabelText.Location = New System.Drawing.Point(9, 21)
        Me.formFileBackupLocationLabelText.Name = "formFileBackupLocationLabelText"
        Me.formFileBackupLocationLabelText.Size = New System.Drawing.Size(129, 13)
        Me.formFileBackupLocationLabelText.TabIndex = 1
        Me.formFileBackupLocationLabelText.Text = "Backup/Restore location:"
        '
        'formFileBackupLocationLabelNote
        '
        Me.formFileBackupLocationLabelNote.AutoSize = True
        Me.formFileBackupLocationLabelNote.Location = New System.Drawing.Point(9, 67)
        Me.formFileBackupLocationLabelNote.Name = "formFileBackupLocationLabelNote"
        Me.formFileBackupLocationLabelNote.Size = New System.Drawing.Size(264, 13)
        Me.formFileBackupLocationLabelNote.TabIndex = 2
        Me.formFileBackupLocationLabelNote.Text = "Note: Location can be changed via ""File"" - ""Settings""."
        '
        'formFileBackupLocationLabel
        '
        Me.formFileBackupLocationLabel.AutoSize = True
        Me.formFileBackupLocationLabel.Location = New System.Drawing.Point(9, 44)
        Me.formFileBackupLocationLabel.Name = "formFileBackupLocationLabel"
        Me.formFileBackupLocationLabel.Size = New System.Drawing.Size(147, 13)
        Me.formFileBackupLocationLabel.TabIndex = 3
        Me.formFileBackupLocationLabel.Text = "formFileBackupLocationLabel"
        '
        'formFileBackup_BackupButton
        '
        Me.formFileBackup_BackupButton.Location = New System.Drawing.Point(12, 246)
        Me.formFileBackup_BackupButton.Name = "formFileBackup_BackupButton"
        Me.formFileBackup_BackupButton.Size = New System.Drawing.Size(75, 23)
        Me.formFileBackup_BackupButton.TabIndex = 4
        Me.formFileBackup_BackupButton.Text = "Backup"
        Me.formFileBackup_BackupButton.UseVisualStyleBackColor = True
        '
        'formFileBackup_StatusLabel
        '
        Me.formFileBackup_StatusLabel.AutoSize = True
        Me.formFileBackup_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formFileBackup_StatusLabel.Location = New System.Drawing.Point(93, 249)
        Me.formFileBackup_StatusLabel.Name = "formFileBackup_StatusLabel"
        Me.formFileBackup_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formFileBackup_StatusLabel.TabIndex = 7
        Me.formFileBackup_StatusLabel.Text = "Success | Fail"
        '
        'formFileBackup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formFileBackup_CancelButton
        Me.ClientSize = New System.Drawing.Size(405, 282)
        Me.Controls.Add(Me.formFileBackup_StatusLabel)
        Me.Controls.Add(Me.formFileBackup_BackupButton)
        Me.Controls.Add(Me.formFileBackupLocationLabel)
        Me.Controls.Add(Me.formFileBackupLocationLabelNote)
        Me.Controls.Add(Me.formFileBackupLocationLabelText)
        Me.Controls.Add(Me.formFileBackup_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formFileBackup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Backup Database and Settings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formFileBackup_CancelButton As Button
    Friend WithEvents formFileBackupLocationLabelText As Label
    Friend WithEvents formFileBackupLocationLabelNote As Label
    Friend WithEvents formFileBackupLocationLabel As Label
    Friend WithEvents formFileBackup_BackupButton As Button
    Friend WithEvents formFileBackup_StatusLabel As Label
End Class
