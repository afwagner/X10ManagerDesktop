﻿
' Name: formControllerEdit.vb
' By: Alan Wagner
' Date: March 2020

Public Class formControllerEdit

#Region "X10ManagerDesktopControllerEditMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Try

            strTryStep = "formControllerEdit_BringToFrontLabel"
            If (formControllerEdit_BringToFrontLabel.Text() = "Y") Then
                Me.BringToFront()
            Else
                formControllerEdit_BringToFrontLabel.Text() = "Y"
            End If

            strTryStep = "formControllerEdit_FormRestore"
            ' formControllerAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formControllerEdit_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                ' formControllerEdit_GetControllersDataSet() As String
                strStatus = formControllerEdit_GetControllersDataSet()
                If (strStatus <> "") Then
                    Windows.Forms.MessageBox.Show("Main(formControllerEdit): " & strStatus, "Main(formControllerEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formControllerEdit_GetControllersDataSet()

            Else
                Windows.Forms.MessageBox.Show("Main(formControllerEdit): " & strStatus, "Main(formControllerEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - formControllerEdit_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formControllerEdit): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try

    End Sub ' END Sub - Main(formControllerEdit)

    Private Sub formControllerEdit_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formControllerEdit_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formControllerEdit_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formControllerEdit_FormClosingHandler(): " & strStatus, "formControllerEdit_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formControllerEdit_FormSave()

    End Sub ' END Sub - formControllerEdit_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopControllerEditMainMethods

#Region "formMethods"

    '=====================================================================================
    ' formControllerEdit_GetControllersDataSet()
    ' Alan Wagner
    '
    ' vb.net set current row datagridview
    '
    ' https://stackoverflow.com/questions/22304743/data-grid-view-programmatically-setting-the-select-row-index-doesnt-set-the-c
    ' Data Grid View…programmatically setting the select row index doesn't set the CurrentRow.Index to the same?
    '
    ' https://stackoverflow.com/questions/2442419/how-to-save-position-after-reload-datagridview
    ' How to save position after reload DataGridView 
    '
    Public Function formControllerEdit_GetControllersDataSet() As String
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim intCurrentCellRowIndex As Integer = -1
        Dim intFirstDisplayedCellRowIndex As Integer = -1

        Dim objDataSetControllers As New System.Data.DataSet
        Dim sqlString As String = ""

        Dim intControllerExtendedCommands As Integer = 12    ' Column that contains ControllerExtendedCommands.
        Dim intControllerMacros As Integer = 13    ' Column that contains ControllerMacros.
        Dim intColumnID As Integer = 14    ' Column that contains ControllerID.

        Dim bShowAdvancedInformation As Boolean = False

        Try

            strTryStep = "bShowAdvancedInformation"
            Select Case X10ManagerDesktop.showAdvancedInformation
                Case 0
                    bShowAdvancedInformation = False
                Case 1
                    bShowAdvancedInformation = True
            End Select

            strTryStep = "sqlStringDataSetControllers"
            sqlString = "SELECT 'Edit' AS [AddEdit], ControllerName AS [Name], ControllerType AS [Type], SWITCH (ControllerActive=0,'N',ControllerActive=1,'Y') AS [Active], ControllerDescription AS [Description], HouseCode, Port, Hub, AppKey, UID, TransceiverHouseCodes, DuskDawnResolution, SWITCH (ControllerExtendedCommands=0,'N',ControllerExtendedCommands=1,'Y') AS [ExtendedCommands], SWITCH (ControllerMacros=0,'N',ControllerMacros=1,'Y') AS [Macros], ControllerID AS [ID] " &
                "FROM (Controllers INNER JOIN ControllerTypes ON Controllers.ControllerTypeID=ControllerTypes.ControllerTypeID) " &
                "WHERE ControllerID > -1 " &
                "UNION " &
                "SELECT 'Add' AS [AddEdit], '' AS [Name], '' AS [Type], '' AS [Active], '' AS [Description], '' AS HouseCode, '' AS Port, '' AS Hub, '' AS AppKey, '' AS UID, '' AS TransceiverHouseCodes, -1 AS DuskDawnResolution, '' AS [ExtendedCommands], '' AS [Macros], ControllerID AS [ID] " &
                "FROM Controllers " &
                "WHERE ControllerID = -1 " &
                "ORDER BY [AddEdit], [Name], [Type] ASC;"

            strTryStep = "UsingConnection"
            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString)

                strTryStep = "Open"
                objConnection.Open()

                strTryStep = "OleDbDataAdapter"
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)

                strTryStep = "Fill"
                objOleDbDataAdapter.Fill(objDataSetControllers)

                strTryStep = "Close"
                objConnection.Close()
                objOleDbDataAdapter = Nothing

            End Using

            strTryStep = "TablesDataSetControllers"
            formControllerEditDataGridView.DataSource = objDataSetControllers.Tables(0)

            strTryStep = "SelectCaseShowAdvancedInformation"
            Select Case bShowAdvancedInformation
                Case True
                    strTryStep = "IDVisibleTrue"
                    formControllerEditDataGridView.Columns(intControllerExtendedCommands).Visible = True
                    formControllerEditDataGridView.Columns(intControllerMacros).Visible = True
                    formControllerEditDataGridView.Columns(intColumnID).Visible = True
                Case False
                    strTryStep = "IDVisibleFalse"
                    formControllerEditDataGridView.Columns(intControllerExtendedCommands).Visible = False
                    formControllerEditDataGridView.Columns(intControllerMacros).Visible = False
                    formControllerEditDataGridView.Columns(intColumnID).Visible = False
            End Select

            strTryStep = "DataGridViewCurrentCellRowIndexFormControllerEdit"
            intCurrentCellRowIndex = X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormControllerEdit

            strTryStep = "DataGridViewFirstDisplayedCellRowIndexFormControllerEdit"
            intFirstDisplayedCellRowIndex = X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormControllerEdit

            strTryStep = "CheckForRestoreCursorPostion"
            If (intCurrentCellRowIndex > -1 And intFirstDisplayedCellRowIndex > -1) Then
                formControllerEditDataGridView.FirstDisplayedScrollingRowIndex = intFirstDisplayedCellRowIndex
                formControllerEditDataGridView.CurrentCell = formControllerEditDataGridView.Rows(intCurrentCellRowIndex).Cells(0) ' Always restore to the first column.
            End If

        Catch ex As Exception
            strStatus = "formControllerEdit_GetControllersDataSet(): Exception: TryStep=" & strTryStep & ": " & ex.Message
        Finally
            objDataSetControllers = Nothing
        End Try

        Return strStatus

    End Function ' END - formControllerEdit_GetControllersDataSet()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formControllerEditDataGridView_CellClick(ByVal objSender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles formControllerEditDataGridView.CellClick
        Dim strStatus As String = ""

        Dim strIDText As String = ""
        Dim bActiveFormFound = False
        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormControllerAddUpdate As formControllerAddUpdate = Nothing

        Dim objLocation As System.Drawing.Point = Nothing

        Dim intColumnID As Integer = 14    ' Column that contains ControllerID.
        Dim intCurrentRow As Integer = -1

        Dim strMessage As String = ""

        Try

            ' Save current Cursor Position.
            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormControllerEdit = formControllerEditDataGridView.CurrentCell.RowIndex
            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormControllerEdit = formControllerEditDataGridView.FirstDisplayedCell.RowIndex

            intCurrentRow = formControllerEditDataGridView.CurrentRow.Index

            ' Including e.RowIndex >= 0 stops this from responding when Header Row is clicked.
            If (intCurrentRow >= 0 And e.RowIndex >= 0) Then
                ' Item(column, row)

                ' Get ControllerID
                strIDText = formControllerEditDataGridView.Item(intColumnID, intCurrentRow).Value.ToString()

                If objFormCollection.OfType(Of formControllerAddUpdate).Any Then

                    If (strIDText = "-1") Then
                        ' Looking for already open Add form.

                        For Each objFormControllerAddUpdate In objFormCollection.OfType(Of formControllerAddUpdate)
                            If (objFormControllerAddUpdate.formControllerAddUpdateIDLabelText.Text() = "") Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    Else

                        For Each objFormControllerAddUpdate In objFormCollection.OfType(Of formControllerAddUpdate)
                            If (objFormControllerAddUpdate.formControllerAddUpdateIDLabelText.Text() = strIDText) Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    End If

                End If

                If bActiveFormFound Then
                    objFormControllerAddUpdate.Activate()
                Else

                    If (strIDText.Length <> 0 And strIDText <> "-1") Then
                        strMessage = "  Geting Controller..Please wait......."
                        Call formConsoleMessages.DisplayMessage(strMessage, "Edit Controller")
                    End If

                    objFormControllerAddUpdate = Nothing
                    objFormControllerAddUpdate = New formControllerAddUpdate

                    objFormControllerAddUpdate.formControllerAddUpdateIDLabelText.Text() = strIDText

                    ' Opens as seperate form.
                    objFormControllerAddUpdate.TopLevel = True

                    ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                    objLocation = Parent.Location

                    ' Set additional offset
                    objLocation.Offset(50, 100)

                    ' Set default Location for new form to be Shown.
                    objFormControllerAddUpdate.Location = objLocation

                    objFormControllerAddUpdate.Show()

                End If

                objFormControllerAddUpdate.BringToFront()

            End If

        Catch ex As Exception
            strStatus = "formControllerEditDataGridView_CellClick(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerEditDataGridView_CellClick()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormControllerAddUpdate = Nothing
            objFormCollection = Nothing
        End Try


    End Sub ' END - formControllerEditDataGridView_CellClick()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formControllerEdit_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationControllerEdit" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formControllerEdit_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                ' Get form's initial location as set by calling Method (System.Drawing.Point(x, y).
                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(1, 25)

                objSize = New System.Drawing.Size(660, 380)
                'objSize = Me.Size

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationControllerEdit Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationControllerEdit.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationControllerEdit.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 2) Then
                            objLocation = New System.Drawing.Point(Integer.Parse(arrInitialLocationSize(0)), Integer.Parse(arrInitialLocationSize(1)))
                        End If

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Location = objLocation
                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formControllerEdit_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formControllerEdit_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formControllerEdit_FormRestore()

    '=====================================================================================
    ' Function formControllerEdit_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationControllerEdit" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formControllerEdit_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationControllerEdit = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationControllerEdit = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formControllerEdit_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formControllerEdit_FormSave(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formControllerEdit_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formControllerEdit
