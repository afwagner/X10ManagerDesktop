﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formFileSettings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formFileSettings))
        Me.formFileSettings_CancelButton = New System.Windows.Forms.Button()
        Me.formFileSettings_UpdateButton = New System.Windows.Forms.Button()
        Me.formFileSettingsLongitudeLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsLatitudeLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsLongitudeTextBox = New System.Windows.Forms.TextBox()
        Me.formFileSettingsLatitudeTextBox = New System.Windows.Forms.TextBox()
        Me.formFileSettings_StatusLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsX10DbConnectionStringLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsX10DbConnectionStringTextBox = New System.Windows.Forms.TextBox()
        Me.formFileSettingsLongitudeExampleLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsLatitudeExampleLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsX10DbConnectionStringExampleLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsLongitudeLatitudeDescriptionLabel = New System.Windows.Forms.Label()
        Me.formFileSettingsVerifyOnProgramExitCheckBox = New System.Windows.Forms.CheckBox()
        Me.formFileSettingsBackupDirectoryPathLabelExample = New System.Windows.Forms.Label()
        Me.formFileSettingsBackupDirectoryPathTextBox = New System.Windows.Forms.TextBox()
        Me.formFileSettingsBackupDirectoryPathLabel = New System.Windows.Forms.Label()
        Me.formFileSettings_BrowseButton = New System.Windows.Forms.Button()
        Me.formFileSettings_FolderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.formFileSettingsShowAdvancedInformationCheckBox = New System.Windows.Forms.CheckBox()
        Me.formFileSettingsVerifyOnProgramExitPanel = New System.Windows.Forms.Panel()
        Me.formFileSettingsShowAdvancedInformationPanel = New System.Windows.Forms.Panel()
        Me.formFileSettings_ResetButton = New System.Windows.Forms.Button()
        Me.formFileSettingsVerifyOnProgramExitPanel.SuspendLayout()
        Me.formFileSettingsShowAdvancedInformationPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'formFileSettings_CancelButton
        '
        Me.formFileSettings_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formFileSettings_CancelButton.Location = New System.Drawing.Point(485, 353)
        Me.formFileSettings_CancelButton.Name = "formFileSettings_CancelButton"
        Me.formFileSettings_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formFileSettings_CancelButton.TabIndex = 0
        Me.formFileSettings_CancelButton.Text = "Cancel"
        Me.formFileSettings_CancelButton.UseVisualStyleBackColor = True
        '
        'formFileSettings_UpdateButton
        '
        Me.formFileSettings_UpdateButton.Location = New System.Drawing.Point(35, 353)
        Me.formFileSettings_UpdateButton.Name = "formFileSettings_UpdateButton"
        Me.formFileSettings_UpdateButton.Size = New System.Drawing.Size(75, 23)
        Me.formFileSettings_UpdateButton.TabIndex = 1
        Me.formFileSettings_UpdateButton.Text = "Update"
        Me.formFileSettings_UpdateButton.UseVisualStyleBackColor = True
        '
        'formFileSettingsLongitudeLabel
        '
        Me.formFileSettingsLongitudeLabel.AutoSize = True
        Me.formFileSettingsLongitudeLabel.Location = New System.Drawing.Point(72, 124)
        Me.formFileSettingsLongitudeLabel.Name = "formFileSettingsLongitudeLabel"
        Me.formFileSettingsLongitudeLabel.Size = New System.Drawing.Size(57, 13)
        Me.formFileSettingsLongitudeLabel.TabIndex = 2
        Me.formFileSettingsLongitudeLabel.Text = "Longitude:"
        '
        'formFileSettingsLatitudeLabel
        '
        Me.formFileSettingsLatitudeLabel.AutoSize = True
        Me.formFileSettingsLatitudeLabel.Location = New System.Drawing.Point(81, 150)
        Me.formFileSettingsLatitudeLabel.Name = "formFileSettingsLatitudeLabel"
        Me.formFileSettingsLatitudeLabel.Size = New System.Drawing.Size(48, 13)
        Me.formFileSettingsLatitudeLabel.TabIndex = 3
        Me.formFileSettingsLatitudeLabel.Text = "Latitude:"
        '
        'formFileSettingsLongitudeTextBox
        '
        Me.formFileSettingsLongitudeTextBox.Location = New System.Drawing.Point(132, 121)
        Me.formFileSettingsLongitudeTextBox.Name = "formFileSettingsLongitudeTextBox"
        Me.formFileSettingsLongitudeTextBox.Size = New System.Drawing.Size(79, 20)
        Me.formFileSettingsLongitudeTextBox.TabIndex = 4
        '
        'formFileSettingsLatitudeTextBox
        '
        Me.formFileSettingsLatitudeTextBox.Location = New System.Drawing.Point(132, 147)
        Me.formFileSettingsLatitudeTextBox.Name = "formFileSettingsLatitudeTextBox"
        Me.formFileSettingsLatitudeTextBox.Size = New System.Drawing.Size(79, 20)
        Me.formFileSettingsLatitudeTextBox.TabIndex = 5
        '
        'formFileSettings_StatusLabel
        '
        Me.formFileSettings_StatusLabel.AutoSize = True
        Me.formFileSettings_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formFileSettings_StatusLabel.Location = New System.Drawing.Point(116, 356)
        Me.formFileSettings_StatusLabel.Name = "formFileSettings_StatusLabel"
        Me.formFileSettings_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formFileSettings_StatusLabel.TabIndex = 6
        Me.formFileSettings_StatusLabel.Text = "Success | Fail"
        '
        'formFileSettingsX10DbConnectionStringLabel
        '
        Me.formFileSettingsX10DbConnectionStringLabel.AutoSize = True
        Me.formFileSettingsX10DbConnectionStringLabel.Location = New System.Drawing.Point(7, 256)
        Me.formFileSettingsX10DbConnectionStringLabel.Name = "formFileSettingsX10DbConnectionStringLabel"
        Me.formFileSettingsX10DbConnectionStringLabel.Size = New System.Drawing.Size(124, 13)
        Me.formFileSettingsX10DbConnectionStringLabel.TabIndex = 7
        Me.formFileSettingsX10DbConnectionStringLabel.Text = "X10DbConnectionString:"
        '
        'formFileSettingsX10DbConnectionStringTextBox
        '
        Me.formFileSettingsX10DbConnectionStringTextBox.Location = New System.Drawing.Point(132, 253)
        Me.formFileSettingsX10DbConnectionStringTextBox.Name = "formFileSettingsX10DbConnectionStringTextBox"
        Me.formFileSettingsX10DbConnectionStringTextBox.Size = New System.Drawing.Size(447, 20)
        Me.formFileSettingsX10DbConnectionStringTextBox.TabIndex = 8
        '
        'formFileSettingsLongitudeExampleLabel
        '
        Me.formFileSettingsLongitudeExampleLabel.AutoSize = True
        Me.formFileSettingsLongitudeExampleLabel.Location = New System.Drawing.Point(217, 124)
        Me.formFileSettingsLongitudeExampleLabel.Name = "formFileSettingsLongitudeExampleLabel"
        Me.formFileSettingsLongitudeExampleLabel.Size = New System.Drawing.Size(78, 13)
        Me.formFileSettingsLongitudeExampleLabel.TabIndex = 9
        Me.formFileSettingsLongitudeExampleLabel.Text = "ex: -88.201175"
        '
        'formFileSettingsLatitudeExampleLabel
        '
        Me.formFileSettingsLatitudeExampleLabel.AutoSize = True
        Me.formFileSettingsLatitudeExampleLabel.Location = New System.Drawing.Point(217, 150)
        Me.formFileSettingsLatitudeExampleLabel.Name = "formFileSettingsLatitudeExampleLabel"
        Me.formFileSettingsLatitudeExampleLabel.Size = New System.Drawing.Size(75, 13)
        Me.formFileSettingsLatitudeExampleLabel.TabIndex = 10
        Me.formFileSettingsLatitudeExampleLabel.Text = "ex: 43.031488"
        '
        'formFileSettingsX10DbConnectionStringExampleLabel
        '
        Me.formFileSettingsX10DbConnectionStringExampleLabel.AutoSize = True
        Me.formFileSettingsX10DbConnectionStringExampleLabel.Location = New System.Drawing.Point(132, 276)
        Me.formFileSettingsX10DbConnectionStringExampleLabel.Name = "formFileSettingsX10DbConnectionStringExampleLabel"
        Me.formFileSettingsX10DbConnectionStringExampleLabel.Size = New System.Drawing.Size(402, 13)
        Me.formFileSettingsX10DbConnectionStringExampleLabel.TabIndex = 11
        Me.formFileSettingsX10DbConnectionStringExampleLabel.Text = "ex: Provider=Microsoft.Jet.OLEDB.4.0;Data Source=""C:\X10Manager\X10Db.mdb"""
        '
        'formFileSettingsLongitudeLatitudeDescriptionLabel
        '
        Me.formFileSettingsLongitudeLatitudeDescriptionLabel.AutoSize = True
        Me.formFileSettingsLongitudeLatitudeDescriptionLabel.Location = New System.Drawing.Point(72, 96)
        Me.formFileSettingsLongitudeLatitudeDescriptionLabel.Name = "formFileSettingsLongitudeLatitudeDescriptionLabel"
        Me.formFileSettingsLongitudeLatitudeDescriptionLabel.Size = New System.Drawing.Size(437, 13)
        Me.formFileSettingsLongitudeLatitudeDescriptionLabel.TabIndex = 12
        Me.formFileSettingsLongitudeLatitudeDescriptionLabel.Text = "Longitude and Latitude are used for calculating current location's Sunrise and Su" &
    "nset times."
        '
        'formFileSettingsVerifyOnProgramExitCheckBox
        '
        Me.formFileSettingsVerifyOnProgramExitCheckBox.AutoSize = True
        Me.formFileSettingsVerifyOnProgramExitCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.formFileSettingsVerifyOnProgramExitCheckBox.Location = New System.Drawing.Point(3, 3)
        Me.formFileSettingsVerifyOnProgramExitCheckBox.Name = "formFileSettingsVerifyOnProgramExitCheckBox"
        Me.formFileSettingsVerifyOnProgramExitCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.formFileSettingsVerifyOnProgramExitCheckBox.Size = New System.Drawing.Size(131, 17)
        Me.formFileSettingsVerifyOnProgramExitCheckBox.TabIndex = 13
        Me.formFileSettingsVerifyOnProgramExitCheckBox.Text = "Verify On Program Exit"
        Me.formFileSettingsVerifyOnProgramExitCheckBox.UseVisualStyleBackColor = True
        '
        'formFileSettingsBackupDirectoryPathLabelExample
        '
        Me.formFileSettingsBackupDirectoryPathLabelExample.AutoSize = True
        Me.formFileSettingsBackupDirectoryPathLabelExample.Location = New System.Drawing.Point(132, 212)
        Me.formFileSettingsBackupDirectoryPathLabelExample.Name = "formFileSettingsBackupDirectoryPathLabelExample"
        Me.formFileSettingsBackupDirectoryPathLabelExample.Size = New System.Drawing.Size(180, 13)
        Me.formFileSettingsBackupDirectoryPathLabelExample.TabIndex = 16
        Me.formFileSettingsBackupDirectoryPathLabelExample.Text = "ex: C:\X10Manager\X10DbBackup\"
        '
        'formFileSettingsBackupDirectoryPathTextBox
        '
        Me.formFileSettingsBackupDirectoryPathTextBox.Location = New System.Drawing.Point(132, 189)
        Me.formFileSettingsBackupDirectoryPathTextBox.Name = "formFileSettingsBackupDirectoryPathTextBox"
        Me.formFileSettingsBackupDirectoryPathTextBox.Size = New System.Drawing.Size(447, 20)
        Me.formFileSettingsBackupDirectoryPathTextBox.TabIndex = 15
        '
        'formFileSettingsBackupDirectoryPathLabel
        '
        Me.formFileSettingsBackupDirectoryPathLabel.AutoSize = True
        Me.formFileSettingsBackupDirectoryPathLabel.Location = New System.Drawing.Point(14, 192)
        Me.formFileSettingsBackupDirectoryPathLabel.Name = "formFileSettingsBackupDirectoryPathLabel"
        Me.formFileSettingsBackupDirectoryPathLabel.Size = New System.Drawing.Size(117, 13)
        Me.formFileSettingsBackupDirectoryPathLabel.TabIndex = 14
        Me.formFileSettingsBackupDirectoryPathLabel.Text = "Backup Directory Path:"
        '
        'formFileSettings_BrowseButton
        '
        Me.formFileSettings_BrowseButton.Location = New System.Drawing.Point(35, 207)
        Me.formFileSettings_BrowseButton.Name = "formFileSettings_BrowseButton"
        Me.formFileSettings_BrowseButton.Size = New System.Drawing.Size(75, 23)
        Me.formFileSettings_BrowseButton.TabIndex = 17
        Me.formFileSettings_BrowseButton.Text = "Browse"
        Me.formFileSettings_BrowseButton.UseVisualStyleBackColor = True
        '
        'formFileSettingsShowAdvancedInformationCheckBox
        '
        Me.formFileSettingsShowAdvancedInformationCheckBox.AutoSize = True
        Me.formFileSettingsShowAdvancedInformationCheckBox.CheckAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.formFileSettingsShowAdvancedInformationCheckBox.Location = New System.Drawing.Point(3, 2)
        Me.formFileSettingsShowAdvancedInformationCheckBox.Name = "formFileSettingsShowAdvancedInformationCheckBox"
        Me.formFileSettingsShowAdvancedInformationCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.formFileSettingsShowAdvancedInformationCheckBox.Size = New System.Drawing.Size(160, 17)
        Me.formFileSettingsShowAdvancedInformationCheckBox.TabIndex = 18
        Me.formFileSettingsShowAdvancedInformationCheckBox.Text = "Show Advanced Information"
        Me.formFileSettingsShowAdvancedInformationCheckBox.UseVisualStyleBackColor = True
        '
        'formFileSettingsVerifyOnProgramExitPanel
        '
        Me.formFileSettingsVerifyOnProgramExitPanel.Controls.Add(Me.formFileSettingsVerifyOnProgramExitCheckBox)
        Me.formFileSettingsVerifyOnProgramExitPanel.Location = New System.Drawing.Point(75, 29)
        Me.formFileSettingsVerifyOnProgramExitPanel.Name = "formFileSettingsVerifyOnProgramExitPanel"
        Me.formFileSettingsVerifyOnProgramExitPanel.Size = New System.Drawing.Size(304, 22)
        Me.formFileSettingsVerifyOnProgramExitPanel.TabIndex = 19
        '
        'formFileSettingsShowAdvancedInformationPanel
        '
        Me.formFileSettingsShowAdvancedInformationPanel.Controls.Add(Me.formFileSettingsShowAdvancedInformationCheckBox)
        Me.formFileSettingsShowAdvancedInformationPanel.Location = New System.Drawing.Point(75, 55)
        Me.formFileSettingsShowAdvancedInformationPanel.Name = "formFileSettingsShowAdvancedInformationPanel"
        Me.formFileSettingsShowAdvancedInformationPanel.Size = New System.Drawing.Size(304, 21)
        Me.formFileSettingsShowAdvancedInformationPanel.TabIndex = 20
        '
        'formFileSettings_ResetButton
        '
        Me.formFileSettings_ResetButton.Location = New System.Drawing.Point(35, 309)
        Me.formFileSettings_ResetButton.Name = "formFileSettings_ResetButton"
        Me.formFileSettings_ResetButton.Size = New System.Drawing.Size(229, 23)
        Me.formFileSettings_ResetButton.TabIndex = 21
        Me.formFileSettings_ResetButton.Text = "Reset Your Program Window Layouts"
        Me.formFileSettings_ResetButton.UseVisualStyleBackColor = True
        '
        'formFileSettings
        '
        Me.AcceptButton = Me.formFileSettings_UpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formFileSettings_CancelButton
        Me.ClientSize = New System.Drawing.Size(590, 397)
        Me.Controls.Add(Me.formFileSettings_ResetButton)
        Me.Controls.Add(Me.formFileSettingsShowAdvancedInformationPanel)
        Me.Controls.Add(Me.formFileSettingsVerifyOnProgramExitPanel)
        Me.Controls.Add(Me.formFileSettings_BrowseButton)
        Me.Controls.Add(Me.formFileSettingsBackupDirectoryPathLabelExample)
        Me.Controls.Add(Me.formFileSettingsBackupDirectoryPathTextBox)
        Me.Controls.Add(Me.formFileSettingsBackupDirectoryPathLabel)
        Me.Controls.Add(Me.formFileSettingsLongitudeLatitudeDescriptionLabel)
        Me.Controls.Add(Me.formFileSettingsX10DbConnectionStringExampleLabel)
        Me.Controls.Add(Me.formFileSettingsLatitudeExampleLabel)
        Me.Controls.Add(Me.formFileSettingsLongitudeExampleLabel)
        Me.Controls.Add(Me.formFileSettingsX10DbConnectionStringTextBox)
        Me.Controls.Add(Me.formFileSettingsX10DbConnectionStringLabel)
        Me.Controls.Add(Me.formFileSettings_StatusLabel)
        Me.Controls.Add(Me.formFileSettingsLatitudeTextBox)
        Me.Controls.Add(Me.formFileSettingsLongitudeTextBox)
        Me.Controls.Add(Me.formFileSettingsLatitudeLabel)
        Me.Controls.Add(Me.formFileSettingsLongitudeLabel)
        Me.Controls.Add(Me.formFileSettings_UpdateButton)
        Me.Controls.Add(Me.formFileSettings_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formFileSettings"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Settings"
        Me.formFileSettingsVerifyOnProgramExitPanel.ResumeLayout(False)
        Me.formFileSettingsVerifyOnProgramExitPanel.PerformLayout()
        Me.formFileSettingsShowAdvancedInformationPanel.ResumeLayout(False)
        Me.formFileSettingsShowAdvancedInformationPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formFileSettings_CancelButton As Button
    Friend WithEvents formFileSettings_UpdateButton As Button
    Friend WithEvents formFileSettingsLongitudeLabel As Label
    Friend WithEvents formFileSettingsLatitudeLabel As Label
    Friend WithEvents formFileSettingsLongitudeTextBox As TextBox
    Friend WithEvents formFileSettingsLatitudeTextBox As TextBox
    Friend WithEvents formFileSettings_StatusLabel As Label
    Friend WithEvents formFileSettingsX10DbConnectionStringLabel As Label
    Friend WithEvents formFileSettingsX10DbConnectionStringTextBox As TextBox
    Friend WithEvents formFileSettingsLongitudeExampleLabel As Label
    Friend WithEvents formFileSettingsLatitudeExampleLabel As Label
    Friend WithEvents formFileSettingsX10DbConnectionStringExampleLabel As Label
    Friend WithEvents formFileSettingsLongitudeLatitudeDescriptionLabel As Label
    Friend WithEvents formFileSettingsVerifyOnProgramExitCheckBox As CheckBox
    Friend WithEvents formFileSettingsBackupDirectoryPathLabelExample As Label
    Friend WithEvents formFileSettingsBackupDirectoryPathTextBox As TextBox
    Friend WithEvents formFileSettingsBackupDirectoryPathLabel As Label
    Friend WithEvents formFileSettings_BrowseButton As Button
    Friend WithEvents formFileSettings_FolderBrowserDialog As FolderBrowserDialog
    Friend WithEvents formFileSettingsShowAdvancedInformationCheckBox As CheckBox
    Friend WithEvents formFileSettingsVerifyOnProgramExitPanel As Panel
    Friend WithEvents formFileSettingsShowAdvancedInformationPanel As Panel
    Friend WithEvents formFileSettings_ResetButton As Button
End Class
