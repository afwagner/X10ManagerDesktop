﻿
' Name: formScheduleAddUpdate.vb
' By: Alan Wagner
' Date: March 2020

Public Class formScheduleAddUpdate

#Region "X10ManagerDesktopScheduleAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objX10DbSchedule As TrekkerPhotoArt.X10Include.X10DbSchedule = Nothing
        Dim intScheduleID As Integer = -1

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Try

            strTryStep = "formScheduleAddUpdate_BringToFrontLabel"
            If (formScheduleAddUpdate_BringToFrontLabel.Text() = "Y") Then
                Me.BringToFront()
            Else
                formScheduleAddUpdate_BringToFrontLabel.Text() = "Y"
            End If

            strTryStep = "formScheduleAddUpdate_FormRestore"
            ' formScheduleAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formScheduleAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formScheduleAddUpdateIDLabelText"
                If (formScheduleAddUpdateIDLabelText.Text() = "" Or formScheduleAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddSchedule"

                    formScheduleAddUpdateIDLabelText.Text() = ""

                    ' Set the caption bar text of the form.
                    Me.Text = "Add Schedule"

                    formScheduleAddUpdate_AddUpdateButton.Text() = "Add"
                    formScheduleAddUpdate_AddUpdateButton.Select()
                    formScheduleAddUpdate_StatusLabel.Visible = True
                    formScheduleAddUpdate_StatusLabel.Text = ""

                    formScheduleAddUpdate_CancelButton.Text() = "Cancel"

                    formScheduleAddUpdate_DeleteButton.Visible = False
                    formScheduleAddUpdate_DeleteButton.Text() = "Delete"

                    formScheduleAddUpdateNameLabel.Visible = True
                    formScheduleAddUpdateNameTextBox.Visible = True
                    formScheduleAddUpdateNameTextBox.Text() = ""

                    formScheduleAddUpdateActiveCheckBox.Visible = False
                    formScheduleAddUpdateActiveCheckBox.Checked = False

                    formScheduleAddUpdateDescriptionLabel.Visible = True
                    formScheduleAddUpdateDescriptionTextBox.Visible = True
                    formScheduleAddUpdateDescriptionTextBox.Text() = ""

                    formScheduleAddUpdateSunriseTimeLabel.Visible = True
                    formScheduleAddUpdateSunriseTimeLabelText.Visible = True
                    formScheduleAddUpdateSunriseTimeLabelText.Text() = ""

                    formScheduleAddUpdateSunsetTimeLabel.Visible = True
                    formScheduleAddUpdateSunsetTimeLabelText.Visible = True
                    formScheduleAddUpdateSunsetTimeLabelText.Text() = ""

                    formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Visible = True
                    formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Text() = "Add sets Sunrise/Sunset times (also reset by Controller downloads)."

                    formScheduleAddUpdateEventsLabel.Visible = True
                    formScheduleAddUpdateEventsLabel.Text() = "Events - New Schedule must first be added."

                    strTryStep = "Add_formScheduleAddUpdate_GetEventsDataSet"
                    ' formScheduleAddUpdate_GetEventsDataSet(ByVal intScheduleID As Integer) As String
                    strStatus = formScheduleAddUpdate_GetEventsDataSet(-1)
                    If (strStatus = "") Then
                        formScheduleAddUpdateEventsDataGridView.Rows.Clear()
                        formScheduleAddUpdateEventsDataGridView.Visible = True
                        formScheduleAddUpdateEventsDataGridView.Enabled = False
                    Else
                        Windows.Forms.MessageBox.Show("Main(formScheduleAddUpdate-Add): TryStep=" & strTryStep & ": " & strStatus, "Main(formScheduleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formScheduleAddUpdate_StatusLabel.Text = "Fail"
                        formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                    End If

                Else
                    strTryStep = "UpdateSchedule"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Schedule"

                    formScheduleAddUpdate_AddUpdateButton.Text() = "Update"
                    formScheduleAddUpdate_AddUpdateButton.Select()
                    formScheduleAddUpdate_StatusLabel.Visible = True
                    formScheduleAddUpdate_StatusLabel.Text = ""

                    formScheduleAddUpdate_CancelButton.Text() = "Done"

                    formScheduleAddUpdate_DeleteButton.Visible = True
                    formScheduleAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "ScheduleID"
                    intScheduleID = CType(formScheduleAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbSchedule"
                    ' nsX10DbMethods.getX10DbSchedule(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intScheduleID As Integer, ByRef objX10DbSchedule As TrekkerPhotoArt.X10Include.X10DbSchedule) As String
                    strStatus = nsX10DbMethods.getX10DbSchedule(strConnectionString, strProvider, intScheduleID, objX10DbSchedule)
                    If (strStatus = "") Then

                        formScheduleAddUpdateIDLabelText.Text() = objX10DbSchedule.ScheduleID.ToString()

                        formScheduleAddUpdateNameLabel.Visible = True
                        formScheduleAddUpdateNameTextBox.Visible = True
                        formScheduleAddUpdateNameTextBox.Text() = objX10DbSchedule.ScheduleName

                        formScheduleAddUpdateActiveCheckBox.Visible = True

                        Select Case objX10DbSchedule.Active
                            Case 0
                                formScheduleAddUpdateActiveCheckBox.Checked = False
                            Case 1
                                formScheduleAddUpdateActiveCheckBox.Checked = True
                        End Select

                        formScheduleAddUpdateDescriptionLabel.Visible = True
                        formScheduleAddUpdateDescriptionTextBox.Visible = True
                        formScheduleAddUpdateDescriptionTextBox.Text() = objX10DbSchedule.ScheduleDescription

                        formScheduleAddUpdateSunriseTimeLabel.Visible = True
                        formScheduleAddUpdateSunriseTimeLabelText.Visible = True
                        formScheduleAddUpdateSunriseTimeLabelText.Text() = objX10DbSchedule.SunriseTime

                        formScheduleAddUpdateSunsetTimeLabel.Visible = True
                        formScheduleAddUpdateSunsetTimeLabelText.Visible = True
                        formScheduleAddUpdateSunsetTimeLabelText.Text() = objX10DbSchedule.SunsetTime

                        formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Visible = True
                        formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Text() = "Update resets Sunrise/Sunset times (also reset by Controller downloads)."

                        formScheduleAddUpdateEventsLabel.Visible = True
                        formScheduleAddUpdateEventsLabel.Text() = "Events"

                        strTryStep = "Update_formScheduleAddUpdate_GetEventsDataSet"
                        ' formScheduleAddUpdate_GetEventsDataSet(ByVal intScheduleID As Integer) As String
                        strStatus = formScheduleAddUpdate_GetEventsDataSet(objX10DbSchedule.ScheduleID)
                        If (strStatus = "") Then
                            formScheduleAddUpdateEventsDataGridView.Visible = True
                            formScheduleAddUpdateEventsDataGridView.Enabled = True
                        Else
                            Windows.Forms.MessageBox.Show("Main(formScheduleAddUpdate-Update): TryStep=" & strTryStep & ": " & strStatus, "Main(formScheduleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formScheduleAddUpdate_StatusLabel.Text = "Fail"
                            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Schedule from X10 db." & vbCrLf & strStatus, "Main(formScheduleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formScheduleAddUpdate_StatusLabel.Text = "Fail"
                        formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getX10DbSchedule()

                End If ' END - formScheduleAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formScheduleAddUpdate): " & strStatus, "Main(formScheduleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formScheduleAddUpdate_StatusLabel.Text = "Fail"
                formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formScheduleAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formScheduleAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formScheduleAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formScheduleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formScheduleAddUpdate_StatusLabel.Text = "Fail"
            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formScheduleAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbSchedule = Nothing
        End Try

    End Sub ' END Sub - Main(formScheduleAddUpdate)

    Private Sub formScheduleAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formScheduleAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formScheduleAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formScheduleAddUpdate_FormClosingHandler(): " & strStatus, "formScheduleAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formScheduleAddUpdate_FormSave()

    End Sub ' END Sub - formScheduleAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopScheduleAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' formScheduleAddUpdate_GetEventsDataSet()
    ' Alan Wagner
    '
    Public Function formScheduleAddUpdate_GetEventsDataSet(ByVal intScheduleID As Integer) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objFactory As System.Data.Common.DbProviderFactory = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataGridViewColumn As System.Windows.Forms.DataGridViewColumn = Nothing
        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim objDataGridViewTextBoxCell As System.Windows.Forms.DataGridViewTextBoxCell = Nothing
        Dim objDataGridViewComboBoxCell As System.Windows.Forms.DataGridViewComboBoxCell = Nothing

        Dim intRowIndex As Integer = -1

        Dim strAddEdit As String = ""
        Dim intEventID As Integer = -1
        Dim intSceneID As Integer = -1
        Dim intMacroInitiatorID As Integer = -1
        Dim intSDay As Integer = -1
        Dim intDOW As Integer = -1
        Dim intSTime As Integer = -1
        Dim intARise As Integer = -1
        Dim intASet As Integer = -1
        Dim intTOD As Integer = -1
        Dim intSec As Integer = -1
        Dim strDays As String = ""
        Dim strTime As String = ""
        Dim strSceneMacro As String = ""
        Dim strSecurityYN As String = ""
        Dim strEnabledYN As String = ""
        Dim strStartDate As String = ""
        Dim strStopDate As String = ""

        Dim intHour As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intMinute As Integer = -1

        Dim intCurrentCellRowIndex As Integer = -1
        Dim intFirstDisplayedCellRowIndex As Integer = -1

        Dim intColumnSceneID As Integer = 9     ' Column that contains SceneID.
        Dim intColumnMacroInitiatorID As Integer = 10 ' Column that contains MacroInitiatorID.
        Dim intColumnSDay As Integer = 11       ' Column that contains SDay.
        Dim intColumnDOW As Integer = 12        ' Column that contains DOW.
        Dim intColumnSTime As Integer = 13      ' Column that contains STime.
        Dim intColumnARise As Integer = 14      ' Column that contains ARise.
        Dim intColumnASet As Integer = 15       ' Column that contains ASet.
        Dim intColumnTOD As Integer = 16        ' Column that contains TOD.
        Dim intColumnSec As Integer = 17        ' Column that contains Sec.

        Dim bShowAdvancedInformation As Boolean = False

        Try

            strTryStep = "bShowAdvancedInformation"
            Select Case X10ManagerDesktop.showAdvancedInformation
                Case 0
                    bShowAdvancedInformation = False
                Case 1
                    bShowAdvancedInformation = True
            End Select

            strTryStep = "Columns.Count"
            If (formScheduleAddUpdateEventsDataGridView.Columns.Count < 1) Then

                strTryStep = "WithFormSceneAddUpdateDataGridView"
                With formScheduleAddUpdateEventsDataGridView
                    .AllowDrop = True
                    .AutoGenerateColumns = False
                    .AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
                    .AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
                    .AllowUserToAddRows = False
                    .AllowUserToDeleteRows = False
                    .AllowUserToOrderColumns = False
                    .AllowUserToResizeColumns = False
                    .AllowUserToResizeRows = False
                    .ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
                    .EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
                    .ReadOnly = True
                    .RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
                    .ShowCellToolTips = False
                    .ShowEditingIcon = False

                    strTryStep = "DataGridViewColumn_AddEdit"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "AddEdit"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "AddEdit"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_EventID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "EventID"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "EventID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_SceneMacro"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Scene/Macro"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "SceneMacro"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Days"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Days"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Days"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Time"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Time"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Time"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_SecurityYN"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Security"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "SecurityYN"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_EnabledYN"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Enabled"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "EnabledYN"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_StartDate"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "StartDate"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "StartDate"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_StopDate"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "StopDate"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "StopDate"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_SceneID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "SceneID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "SceneID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroInitiatorID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "MacroInitiatorID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroInitiatorID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_SDay"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "SDay"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "SDay"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_DOW"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "DOW"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "DOW"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_STime" ' SceneUnits.SceneUnitID
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "STime"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "STime"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_ARise"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "ARise"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "ARise"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_ASet"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "ASet"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "ASet"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_TOD"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "TOD"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "TOD"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Sec"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Sec"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Sec"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                End With ' END - WithFormSceneAddUpdateDataGridView

            Else

                strTryStep = "SelectCaseShowAdvancedInformation"
                Select Case bShowAdvancedInformation
                    Case True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSceneID).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnMacroInitiatorID).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSDay).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnDOW).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSTime).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnARise).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnASet).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnTOD).Visible = True
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSec).Visible = True
                    Case False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSceneID).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnMacroInitiatorID).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSDay).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnDOW).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSTime).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnARise).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnASet).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnTOD).Visible = False
                        formScheduleAddUpdateEventsDataGridView.Columns(intColumnSec).Visible = False
                End Select

            End If ' END - Columns.Count

            strTryStep = "Rows.Count"
            If (formScheduleAddUpdateEventsDataGridView.Rows.Count > 0) Then
                strTryStep = "Rows.Clear"
                formScheduleAddUpdateEventsDataGridView.Rows.Clear()
            End If ' END - Rows.Count

            strTryStep = "ExistingOrNewScheduleID"
            If (intScheduleID > -1) Then
                strTryStep = "ExistingScheduleID"

                strTryStep = "ConnectionStrings"
                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                strTryStep = "GetFactory"
                objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

                strTryStep = "sqlString"
                sqlString = "SELECT 'Edit' AS [AddEdit]," +
                            "Events.EventID, Events.ScheduleID, Events.SceneID, Events.MacroInitiatorID, Events.SDay, Events.DOW, Events.STime, Events.ARise, Events.ASet, Events.TOD, Events.Sec," +
                            "Schedules.ScheduleName AS [Schedule]," +
                            "Scenes.SceneName AS [Scene]," +
                            "MacroInitiators.name AS [Macro]," +
                            "SWITCH(Events.Sec=0,'N', Events.Sec=1,'Y') AS [SecurityYN]," +
                            "SWITCH(Events.Enabled=0,'N', Events.Enabled=1,'Y') AS [EnabledYN]," +
                            "FORMAT(Events.[StartDate], 'mm/dd/yyyy') AS [StartDate]," +
                            "FORMAT(Events.[StopDate], 'mm/dd/yyyy') AS [StopDate] " +
                            "FROM (((Events INNER JOIN Schedules ON Schedules.ScheduleID=Events.ScheduleID) INNER JOIN Scenes ON Scenes.SceneID=Events.SceneID) INNER JOIN MacroInitiators ON MacroInitiators.MacroInitiatorID=Events.MacroInitiatorID) " +
                            "WHERE Schedules.ScheduleID=" & intScheduleID.ToString() & " " +
                            "UNION " +
                            "SELECT 'Add' AS [AddEdit]," +
                            "[EventID]," +
                            "-1 AS [ScheduleID], -1 AS [SceneID], -1 AS [MacroInitiatorID], -1 AS [SDay], -1 AS [DOW], -1 AS [STime], -1 AS [ARise], -1 AS [ASet], -1 AS [TOD], -1 AS [Sec]," +
                            "'' AS [Schedule]," +
                            "'' AS [Scene]," +
                            "'' AS [Macro]," +
                            "'' AS [SecurityYN]," +
                            "'' AS [EnabledYN]," +
                            "'' AS [StartDate]," +
                            "'' AS [StopDate] " +
                            "FROM Events " +
                            "WHERE [EventID] = -1 " +
                            "ORDER BY [AddEdit], [Scene], [Macro];"

                strTryStep = "CreateConnection"
                Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                    strTryStep = "ConnectionString"
                    objDbConnection.ConnectionString = strConnectionString

                    strTryStep = "Connection.Open"
                    objDbConnection.Open()

                    strTryStep = "CreateCommand"
                    Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                        strTryStep = "CommandText"
                        objDbCommand.CommandText = sqlString

                        strTryStep = "CommandTimeout"
                        objDbCommand.CommandTimeout = 30 ' Seconds

                        strTryStep = "CommandType"
                        ' Text              - An SQL text command (default).
                        ' StoredProcedure   - To call a stored procedure.
                        ' TableDirect       - All rows and columns of the named table or tables will be returned.
                        objDbCommand.CommandType() = CommandType.Text

                        strTryStep = "ExecuteReader"
                        ' ExecuteReader     - Executes commands that return rows.
                        '   System.Data.CommandBehavior.Default          - The query may return multiple result sets. ExecuteReader(CommandBehavior.Default) is functionally equivalent to calling ExecuteReader().
                        '   System.Data.CommandBehavior.SingleResult     - The query returns a single result set.
                        '   System.Data.CommandBehavior.SchemaOnly       - The query returns column information only.
                        '   System.Data.CommandBehavior.KeyInfo          - The query returns column and primary key information.
                        '   System.Data.CommandBehavior.SingleRow        - The query is expected to return a single row of the first result set.
                        '   System.Data.CommandBehavior.SequentialAccess - Provides a way for the DataReader to handle rows that contain columns with large binary values. You can then use the GetBytes or GetChars method to specify a byte location to start the read operation.
                        '   System.Data.CommandBehavior.CloseConnection  - When the command is executed, the associated Connection object is closed when the associated DataReader object is closed.
                        ' ExecuteNonQuery   - Executes commands such as Transact-SQL INSERT, DELETE, UPDATE, and SET statements.
                        ' ExecuteScalar     - Retrieves a single value (for example, an aggregate value) from a database.
                        ' ExecuteXmlReader  - Sends the CommandText to the Connection and builds an XmlReader object.
                        Using objDbDataReader As System.Data.Common.DbDataReader = objDbCommand.ExecuteReader(System.Data.CommandBehavior.Default)

                            strTryStep = "HasRows"
                            If objDbDataReader.HasRows() Then

                                strTryStep = "Read"
                                While objDbDataReader.Read()
                                    intRowIndex = intRowIndex + 1

                                    strTryStep = ""
                                    strAddEdit = objDbDataReader("AddEdit").ToString()

                                    strTryStep = "EventID"
                                    intEventID = CType(objDbDataReader("EventID"), Integer)

                                    strTryStep = "SceneID"
                                    intSceneID = CType(objDbDataReader("SceneID"), Integer)

                                    strTryStep = "MacroInitiatorID"
                                    intMacroInitiatorID = CType(objDbDataReader("MacroInitiatorID"), Integer)

                                    strTryStep = "SDay"
                                    intSDay = CType(objDbDataReader("SDay"), Integer)

                                    strTryStep = "DOW"
                                    intDOW = CType(objDbDataReader("DOW"), Integer)

                                    strTryStep = "STime"
                                    intSTime = CType(objDbDataReader("STime"), Integer)

                                    strTryStep = "ARise"
                                    intARise = CType(objDbDataReader("ARise"), Integer)

                                    strTryStep = "ASet"
                                    intASet = CType(objDbDataReader("ASet"), Integer)

                                    strTryStep = "TOD"
                                    intTOD = CType(objDbDataReader("TOD"), Integer)

                                    strTryStep = "Sec"
                                    intSec = CType(objDbDataReader("Sec"), Integer)

                                    strTryStep = "Days"
                                    Select Case intDOW
                                        Case 0
                                            ' Today
                                            strDays = "Today"
                                        Case 1
                                            ' Tomorrow
                                            strDays = "Tomorrow"
                                        Case 2
                                            ' All Days
                                            ' Su Mo Tu We Th Fr Sa
                                            strDays = "Every Day"
                                        Case 3
                                            ' Specific Day(s) as A mask of days
                                            strDays = nsX10DbMethods.DayCodeToStringOfDays(intSDay)
                                        Case 4
                                            ' Weekends
                                            strDays = "Weekends"
                                        Case 5
                                            ' Weekdays
                                            strDays = "Weekdays"
                                        Case -1
                                            ' No Days - Probably an Add
                                            strDays = ""
                                    End Select

                                    strTryStep = "Time"
                                    Select Case intTOD
                                        Case 0
                                            ' Specific Time

                                            If (intSTime > -1) Then

                                                intHour = intSTime \ 60

                                                If (intHour = 12) Then
                                                    ' PM
                                                    strAMPM = "PM"
                                                    intHourAMPM = intHour
                                                ElseIf (intHour > 12) Then
                                                    ' PM
                                                    strAMPM = "PM"
                                                    intHourAMPM = intHour - 12
                                                ElseIf (intHour = 0) Then
                                                    ' AM
                                                    strAMPM = "AM"
                                                    intHourAMPM = 12
                                                Else
                                                    ' AM
                                                    strAMPM = "AM"
                                                    intHourAMPM = intHour
                                                End If

                                                intMinute = intSTime Mod 60

                                                strTime = nsStringMethods.addLeadingZeros(intHourAMPM.ToString(), 2) & ":" & nsStringMethods.addLeadingZeros(intMinute.ToString(), 2) & " " & strAMPM

                                            Else
                                                intHour = -1
                                                intHourAMPM = -1
                                                strAMPM = ""
                                                intMinute = -1
                                                strTime = ""
                                            End If

                                        Case 1
                                            ' Sunrise Minutes

                                            If (intARise = 0) Then
                                                strTime = "Sunrise"
                                            ElseIf (intARise < 0) Then
                                                strTime = "Sunrise - " & System.Math.Abs(intARise).ToString() & " minutes"
                                            Else
                                                strTime = "Sunrise + " & intARise.ToString() & " minutes"
                                            End If

                                        Case 2
                                            ' Sunset Minutes

                                            If (intASet = 0) Then
                                                strTime = "Sunset"
                                            ElseIf (intASet < 0) Then
                                                strTime = "Sunset - " & System.Math.Abs(intASet).ToString() & " minutes"
                                            Else
                                                strTime = "Sunset + " & intASet.ToString() & " minutes"
                                            End If

                                        Case Else
                                            ' No Time - Probably an Add
                                            strTime = ""
                                    End Select ' END - Time

                                    strTryStep = "Scene/Macro"
                                    If (intEventID > -1) Then
                                        If (intMacroInitiatorID > -1) Then
                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("Macro"))) Then
                                                strSceneMacro = ""
                                            Else
                                                strSceneMacro = "[m] " & objDbDataReader("Macro").ToString()
                                            End If
                                        Else
                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("Scene"))) Then
                                                strSceneMacro = ""
                                            Else
                                                strSceneMacro = "[s] " & objDbDataReader("Scene").ToString()
                                            End If
                                        End If
                                    Else
                                        strSceneMacro = ""
                                    End If

                                    strTryStep = "SecurityYN"
                                    strSecurityYN = objDbDataReader("SecurityYN").ToString()

                                    strTryStep = "EnabledYN"
                                    strEnabledYN = objDbDataReader("EnabledYN").ToString()

                                    strTryStep = "StartDate"
                                    strStartDate = objDbDataReader("StartDate").ToString()

                                    strTryStep = "StopDate"
                                    strStopDate = objDbDataReader("StopDate").ToString()

                                    strTryStep = "NewObjectDataGridViewRow"
                                    objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                                    strTryStep = "Add_AddEdit"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strAddEdit
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_EventID"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intEventID.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_SceneMacro"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strSceneMacro
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_Days"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strDays
                                    If (intDOW = 3) Then
                                        ' Specific Day(s) as A mask of days
                                        objDataGridViewTextBoxCell.Style = New System.Windows.Forms.DataGridViewCellStyle
                                        objDataGridViewTextBoxCell.Style.BackColor = System.Drawing.Color.White
                                        objDataGridViewTextBoxCell.Style.Font = New System.Drawing.Font(System.Drawing.FontFamily.GenericMonospace, 8, System.Drawing.FontStyle.Regular)
                                    End If
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_Time"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strTime
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_SecurityYN"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strSecurityYN
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_EnabledYN"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strEnabledYN
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_StartDate"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strStartDate
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_StopDate"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strStopDate
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_SceneID"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intSceneID.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroInitiatorID"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intMacroInitiatorID.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_SDay"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intSDay.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_DOW"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intDOW.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_STime"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intSTime.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_ARise"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intARise.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_ASet"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intASet.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_TOD"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intTOD.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_Sec"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intSec.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Rows.Add"
                                    formScheduleAddUpdateEventsDataGridView.Rows.Add(objDataGridViewRow)

                                    objDataGridViewRow = Nothing
                                End While

                                strTryStep = "DataGridViewCurrentCellRowIndexFormScheduleAddUpdateEvents"
                                intCurrentCellRowIndex = X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormScheduleAddUpdateEvents

                                strTryStep = "DataGridViewFirstDisplayedCellRowIndexFormScheduleAddUpdateEvents"
                                intFirstDisplayedCellRowIndex = X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormScheduleAddUpdateEvents

                                strTryStep = "CheckForRestoreCursorPostion"
                                If (intCurrentCellRowIndex > -1 And intCurrentCellRowIndex < formScheduleAddUpdateEventsDataGridView.Rows.Count And intFirstDisplayedCellRowIndex > -1) Then
                                    formScheduleAddUpdateEventsDataGridView.FirstDisplayedScrollingRowIndex = intFirstDisplayedCellRowIndex
                                    formScheduleAddUpdateEventsDataGridView.CurrentCell = formScheduleAddUpdateEventsDataGridView.Rows(intCurrentCellRowIndex).Cells(0) ' Always restore to the first column.
                                End If

                            End If ' END - HasRows

                        End Using ' END - ExecuteReader

                    End Using ' END - CreateCommand

                    strTryStep = "Connection.Close"
                    objDbConnection.Close()

                End Using ' END - CreateConnection

            Else
                strTryStep = "NewScheduleID"
                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormScheduleAddUpdateEvents = -1
                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormScheduleAddUpdateEvents = -1
            End If ' END - ExistingOrNewScheduleID

        Catch ex As Exception
            strStatus = "formScheduleAddUpdate_GetEventsDataSet(" & strTryStep & "): Exception: " & ex.Message & vbCrLf & sqlString
        Finally
            objDataGridViewTextBoxCell = Nothing
            objDataGridViewComboBoxCell = Nothing
            objDataGridViewRow = Nothing
            objDataGridViewColumn = Nothing
            objFactory = Nothing
        End Try

        Return strStatus

    End Function ' END - formScheduleAddUpdate_GetEventsDataSet()

    Private Function getSunriseSunsetTimes(ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
        Dim nsSunTimeMethods As New TrekkerPhotoArt.X10Include.SunTimeMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objTimeZone As TrekkerPhotoArt.X10Include.TimeZone = Nothing

        strSunriseTime = ""
        strSunsetTime = ""

        Try

            ' nsSunTimeMethods.getTimeZone(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone) As String
            strError = nsSunTimeMethods.getTimeZone(objTimeZone)
            If (strError = "") Then

                ' nsSunTimeMethods.SunTimes(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
                strError = nsSunTimeMethods.SunTimes(objTimeZone, CType(X10ManagerDesktop.latitude, Double), CType(X10ManagerDesktop.longitude, Double), strSunriseTime, strSunsetTime)
                If (strError <> "") Then
                    strStatus = "getSunriseSunsetTimes(): " & strError
                End If ' END - nsSunTimeMethods.SunTimes()

            Else
                strStatus = "getSunriseSunsetTimes(): " & strError
            End If ' END - nsSunTimeMethods.getTimeZone()

        Catch ex As Exception
            strSunriseTime = ""
            strSunsetTime = ""
            strStatus = "getSunriseSunsetTimes(): Exception: " & ex.Message
        Finally
            objTimeZone = Nothing
        End Try

        Return strStatus

    End Function ' END - getSunriseSunsetTimes()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formScheduleAddUpdateEventsDataGridView_CellClick(ByVal objSender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles formScheduleAddUpdateEventsDataGridView.CellClick
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim strIDText As String = ""
        Dim bActiveFormFound = False
        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormEventAddUpdate As formEventAddUpdate = Nothing

        Dim objLocation As System.Drawing.Point = Nothing

        Dim intCurrentRow As Integer = -1

        Dim intColumnEventID As Integer = 1         ' Column that contains EventID.

        Try

            ' Save current Cursor Position.
            strTryStep = "CurrentCell"
            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormScheduleAddUpdateEvents = formScheduleAddUpdateEventsDataGridView.CurrentCell.RowIndex
            strTryStep = "FirstDisplayedCell"
            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormScheduleAddUpdateEvents = formScheduleAddUpdateEventsDataGridView.FirstDisplayedCell.RowIndex

            formScheduleAddUpdate_BringToFrontLabel.Text() = "Y"

            strTryStep = "CurrentRow.Index"
            intCurrentRow = formScheduleAddUpdateEventsDataGridView.CurrentRow.Index

            strTryStep = "CurrentRow"
            ' Including e.RowIndex >= 0 stops this from responding when Header Row is clicked.
            If (intCurrentRow >= 0 And e.RowIndex >= 0) Then
                ' Item(column, row)

                ' Get X10 EventID
                strTryStep = "GetEventID"
                strIDText = formScheduleAddUpdateEventsDataGridView.Item(intColumnEventID, intCurrentRow).Value.ToString()

                strTryStep = "OfType"
                If objFormCollection.OfType(Of formEventAddUpdate).Any Then

                    If (strIDText = "-1") Then
                        ' Looking for already open Add form.

                        strTryStep = "ForEachAlreadyOpenAddForm"
                        For Each objFormEventAddUpdate In objFormCollection.OfType(Of formEventAddUpdate)
                            If (objFormEventAddUpdate.formEventAddUpdateIDLabelText.Text() = "") Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    Else

                        strTryStep = "ForEachAlreadyOpenUpdateForm"
                        For Each objFormEventAddUpdate In objFormCollection.OfType(Of formEventAddUpdate)
                            If (objFormEventAddUpdate.formEventAddUpdateIDLabelText.Text() = strIDText) Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    End If

                End If

                strTryStep = "bActiveFormFound"
                If bActiveFormFound Then
                    strTryStep = "Activate"
                    objFormEventAddUpdate.Activate()
                Else

                    strTryStep = "NewObjectFormEventAddUpdate"
                    objFormEventAddUpdate = Nothing
                    objFormEventAddUpdate = New formEventAddUpdate

                    ' Put X10 ScheduleID
                    strTryStep = "PutScheduleID"
                    objFormEventAddUpdate.formEventAddUpdateScheduleIDLabelText.Text() = formScheduleAddUpdateIDLabelText.Text()

                    ' Put X10 ScheduleName
                    strTryStep = "PutScheduleName"
                    objFormEventAddUpdate.formEventAddUpdateScheduleLabelText.Text() = formScheduleAddUpdateNameTextBox.Text()

                    ' Put X10 EventID
                    strTryStep = "PutEventID"
                    objFormEventAddUpdate.formEventAddUpdateIDLabelText.Text() = strIDText

                    ' Set Calling Form Name (Class Name)
                    strTryStep = "SetClassName"
                    objFormEventAddUpdate.formEventAddUpdateCallingFormLabelText.Text() = "formScheduleAddUpdate"

                    ' Opens as seperate form.
                    strTryStep = "TopLevel"
                    objFormEventAddUpdate.TopLevel = True

                    ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                    strTryStep = "Me.Location"
                    objLocation = New System.Drawing.Point
                    objLocation = Me.Location

                    ' Set additional offset for new form.
                    strTryStep = "Offset"
                    objLocation.Offset(100, 150)

                    ' Set default Location for new form to be Shown.
                    strTryStep = "formEventAddUpdate.Location"
                    objFormEventAddUpdate.Location = objLocation

                    strTryStep = "Show"
                    objFormEventAddUpdate.Show()

                End If

                objFormEventAddUpdate.BringToFront()

            End If

        Catch ex As Exception
            strStatus = "formScheduleAddUpdateEventsDataGridView_CellClick(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdateEventsDataGridView_CellClick()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormEventAddUpdate = Nothing
            objFormCollection = Nothing
        End Try

    End Sub ' END - formScheduleAddUpdateEventsDataGridView_CellClick()

    Private Sub formScheduleAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formScheduleAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objX10DbSchedule As TrekkerPhotoArt.X10Include.X10DbSchedule = Nothing
        Dim objX10DbScheduleTest As TrekkerPhotoArt.X10Include.X10DbSchedule = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormScheduleEdit As formScheduleEdit = Nothing

        Dim strSunriseTime As String = ""
        Dim strSunsetTime As String = ""

        Dim strMessage As String = ""

        Try

            objX10DbSchedule = New TrekkerPhotoArt.X10Include.X10DbSchedule

            If (formScheduleAddUpdateNameTextBox.Text.Trim() = "") Then
                strStatus = "Missing Schedule Name."
            Else
                objX10DbSchedule.ScheduleName = formScheduleAddUpdateNameTextBox.Text().Trim()
            End If

            objX10DbSchedule.Active = 0

            ' getSunriseSunsetTimes(ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
            strError = getSunriseSunsetTimes(strSunriseTime, strSunsetTime)
            If (strError = "") Then
                formScheduleAddUpdateSunriseTimeLabelText.Text() = strSunriseTime
                formScheduleAddUpdateSunsetTimeLabelText.Text() = strSunsetTime
                objX10DbSchedule.SunriseTime = strSunriseTime
                objX10DbSchedule.SunsetTime = strSunsetTime
            Else
                If (strStatus = "") Then
                    strStatus = "Problem getting Sunrise/Sunset times: " & strError
                Else
                    strStatus &= vbCrLf & "Problem getting Sunrise/Sunset times: " & strError
                End If
            End If

            ' Was Something Missing?
            If (strStatus = "") Then

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                ' Verify the Schedule Name has not already been used.

                ' nsX10DbMethods.getX10DbSchedule(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByRef objX10DbSchedule As TrekkerPhotoArt.X10Include.X10DbSchedule) As String
                strError = nsX10DbMethods.getX10DbSchedule(strConnectionString, strProvider, objX10DbSchedule.ScheduleName, objX10DbScheduleTest)
                If (strError = "") Then

                    ' Was a Schedule found?
                    If (objX10DbScheduleTest.ScheduleID >= 0) Then
                        ' A Schedule was found with the specified Schedule Name.

                        ' Add or Modify Schedule?
                        If (formScheduleAddUpdate_AddUpdateButton.Text() = "Add") Then
                            strStatus = "Unable to Add the Schedule. The Schedule Name has already been used by another Schedule."
                            Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formScheduleAddUpdate_StatusLabel.Text = "Fail"
                            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else
                            ' Modify Schedule

                            objX10DbSchedule.ScheduleID = CType(formScheduleAddUpdateIDLabelText.Text(), Integer)

                            If (objX10DbScheduleTest.ScheduleID <> objX10DbSchedule.ScheduleID) Then
                                strStatus = "Unable to Update Schedule information. The new Schedule Name has already been used by another Schedule."
                                Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formScheduleAddUpdate_StatusLabel.Text = "Fail"
                                formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            Else

                                If formScheduleAddUpdateActiveCheckBox.Checked Then

                                    ' nsX10DbMethods.checkX10DbOtherActiveSchedulesForSameModules(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intScheduleID As Integer) As String
                                    strStatus = nsX10DbMethods.checkX10DbOtherActiveSchedulesForSameModules(strConnectionString, strProvider, objX10DbSchedule.ScheduleID)
                                    If (strStatus = "") Then
                                        objX10DbSchedule.Active = 1
                                    Else
                                        objX10DbSchedule.Active = 0
                                        formScheduleAddUpdateActiveCheckBox.Checked = False
                                        Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formScheduleAddUpdate_StatusLabel.Text = "Fail"
                                        formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red

                                        strMessage = objX10DbSchedule.ScheduleName & " [" & objX10DbSchedule.ScheduleID & "]"
                                        strMessage &= vbCrLf & vbCrLf & strStatus
                                        strMessage &= vbCrLf & vbCrLf & "Fail!"
                                        ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                        Call formConsoleMessages.DisplayMessage(strMessage, "Update Schedule")

                                    End If

                                Else
                                    objX10DbSchedule.Active = 0
                                End If

                            End If

                        End If ' END - Add or Modify Schedule?

                    Else
                        ' Nothing found.
                        If (formScheduleAddUpdate_AddUpdateButton.Text() = "Add") Then
                            ' Add Schedule
                            objX10DbSchedule.ScheduleID = -1
                        Else
                            ' Modify Schedule
                            objX10DbSchedule.ScheduleID = CType(formScheduleAddUpdateIDLabelText.Text(), Integer)
                        End If ' END - Add or Modify Schedule
                    End If ' END - Was a Schedule found?

                Else
                    strStatus = "Problem determining if Schedule Name has already been used." & vbCrLf & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formScheduleAddUpdate_StatusLabel.Text = "Fail"
                    formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                End If ' END - nsX10DbMethods.getX10DbSchedule()
                If (strStatus = "") Then

                    objX10DbSchedule.ScheduleDescription = formScheduleAddUpdateDescriptionTextBox.Text().Trim()

                    ' nsX10DbMethods.addUpdateScheduleToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbSchedule As TrekkerPhotoArt.X10Include.X10DbSchedule, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.addUpdateScheduleToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbSchedule, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then
                            formScheduleAddUpdateIDLabelText.Text() = objX10DbSchedule.ScheduleID.ToString()

                            If (formScheduleAddUpdate_AddUpdateButton.Text() = "Add") Then
                                formScheduleAddUpdate_AddUpdateButton.Text() = "Update"
                                formScheduleAddUpdate_StatusLabel.Text = "Successfully Added"
                                formScheduleAddUpdate_DeleteButton.Visible = True

                                formScheduleAddUpdateActiveCheckBox.Visible = True
                                formScheduleAddUpdateActiveCheckBox.Checked = False

                                formScheduleAddUpdateEventsLabel.Visible = True
                                formScheduleAddUpdateEventsLabel.Text() = "Events"

                                ' formScheduleAddUpdate_GetEventsDataSet(ByVal intScheduleID As Integer) As String
                                strStatus = formScheduleAddUpdate_GetEventsDataSet(objX10DbSchedule.ScheduleID)
                                If (strStatus = "") Then
                                    formScheduleAddUpdateEventsDataGridView.Visible = True
                                    formScheduleAddUpdateEventsDataGridView.Enabled = True
                                Else
                                    Windows.Forms.MessageBox.Show("formScheduleAddUpdate_AddUpdateButton_Click(): " & strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formScheduleAddUpdate_StatusLabel.Text = "Fail"
                                    formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                                End If

                            Else
                                formScheduleAddUpdate_StatusLabel.Text = "Successfully Updated"
                            End If

                            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formScheduleAddUpdate_CancelButton.Text() = "Done"

                            objFormScheduleEdit = New formScheduleEdit
                            objFormScheduleEdit.formScheduleEdit_BringToFrontLabel.Text() = "N"

                            ' Refresh DataSet on Form formScheduleEdit if it's active.
                            If objFormCollection.OfType(Of formScheduleEdit).Any Then

                                objFormScheduleEdit = objFormCollection.Item("formScheduleEdit")

                                ' formScheduleEdit_GetSchedulesDataSet() As String
                                strStatus = objFormScheduleEdit.formScheduleEdit_GetSchedulesDataSet()
                                If (strStatus = "") Then
                                    objFormScheduleEdit.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formScheduleAddUpdate_AddUpdateButton_Click(): " & strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formScheduleEdit_GetSchedulesDataSet()

                            End If

                        Else
                            formScheduleAddUpdate_StatusLabel.Text = "Fail"
                            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                            If (formScheduleAddUpdate_AddUpdateButton.Text() = "Add") Then
                                Windows.Forms.MessageBox.Show("Problem adding Schedule to X10 Db.", "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Else
                                Windows.Forms.MessageBox.Show("Problem modifying Schedule to X10 Db.", "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If
                        End If

                    Else
                        formScheduleAddUpdate_StatusLabel.Text = "Fail"
                        formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                        If (formScheduleAddUpdate_AddUpdateButton.Text() = "Add") Then
                            Windows.Forms.MessageBox.Show("Problem adding Schedule to X10 Db." & vbCrLf & strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Else
                            Windows.Forms.MessageBox.Show("Problem modifying Schedule to X10 Db." & vbCrLf & strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If
                    End If ' END - nsX10DbMethods.addUpdateScheduleToX10db()

                End If ' END - nsX10DbMethods.getX10DbSchedule()

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formScheduleAddUpdate_StatusLabel.Text = "Fail"
                formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            End If ' END - Was Something Missing?

        Catch ex As Exception
            strStatus = "formScheduleAddUpdate_AddUpdateButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formScheduleAddUpdate_StatusLabel.Text = "Fail"
            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formScheduleAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormScheduleEdit = Nothing
            objX10DbScheduleTest = Nothing
            objX10DbSchedule = Nothing
        End Try

    End Sub ' END - formScheduleAddUpdate_AddUpdateButton_Click()

    Private Sub formScheduleAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formScheduleAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formScheduleAddUpdate_CancelButton_Click()

    Private Sub formScheduleAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formScheduleAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objX10DbSchedule As TrekkerPhotoArt.X10Include.X10DbSchedule = Nothing
        Dim intScheduleID As Integer = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormScheduleEdit As formScheduleEdit = Nothing

        Try

            If (formScheduleAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing ScheduleID", "formScheduleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                If Windows.Forms.MessageBox.Show("Confirm removal of Schedule" & vbCrLf & """" & formScheduleAddUpdateNameTextBox.Text() & """ [" & formScheduleAddUpdateIDLabelText.Text() & "]" & vbCrLf & "and it's Events?", "Confirm", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Stop) = Windows.Forms.DialogResult.Yes Then

                    intScheduleID = CType(formScheduleAddUpdateIDLabelText.Text(), Integer)

                    objX10DbSchedule = New TrekkerPhotoArt.X10Include.X10DbSchedule
                    objX10DbSchedule.ScheduleID = intScheduleID
                    objX10DbSchedule.ScheduleName = formScheduleAddUpdateNameTextBox.Text()
                    objX10DbSchedule.ScheduleDescription = ""


                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    ' nsX10DbMethods.removeX10ScheduleFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSchedule As TrekkerPhotoArt.X10Include.X10DbSchedule, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.removeX10ScheduleFromX10Db(strConnectionString, strProvider, objX10DbSchedule, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then

                            formScheduleAddUpdateIDLabelText.Text() = ""
                            formScheduleAddUpdate_AddUpdateButton.Text() = "Add"
                            formScheduleAddUpdate_StatusLabel.Text = "Successfully Deleted"
                            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formScheduleAddUpdate_CancelButton.Text() = "Done"
                            formScheduleAddUpdate_DeleteButton.Visible = False

                            formScheduleAddUpdateActiveCheckBox.Visible = False
                            formScheduleAddUpdateActiveCheckBox.Checked = False

                            formScheduleAddUpdateEventsLabel.Visible = True
                            formScheduleAddUpdateEventsLabel.Text() = "Events - New Schedule must first be added."
                            formScheduleAddUpdateEventsDataGridView.Rows.Clear()
                            formScheduleAddUpdateEventsDataGridView.Visible = True
                            formScheduleAddUpdateEventsDataGridView.Enabled = False

                            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormScheduleAddUpdateEvents = -1
                            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormScheduleAddUpdateEvents = -1


                            objFormScheduleEdit = New formScheduleEdit
                            objFormScheduleEdit.formScheduleEdit_BringToFrontLabel.Text() = "N"

                            ' Refresh DataSet on Form formScheduleEdit if it's active.
                            If objFormCollection.OfType(Of formScheduleEdit).Any Then

                                objFormScheduleEdit = objFormCollection.Item("formScheduleEdit")

                                ' The row has been deleted.
                                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormScheduleEdit = -1
                                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormScheduleEdit = -1

                                ' formScheduleEdit_GetSchedulesDataSet() As String
                                strStatus = objFormScheduleEdit.formScheduleEdit_GetSchedulesDataSet()
                                If (strStatus = "") Then
                                    objFormScheduleEdit.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formScheduleAddUpdate_DeleteButton_Click(): " & strStatus, "formScheduleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formScheduleEdit_GetSchedulesDataSet()

                            End If

                        Else
                            formScheduleAddUpdate_StatusLabel.Text = "Fail"
                            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                            Windows.Forms.MessageBox.Show("Problem removing Schedule from X10 Db.", "formScheduleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If ' END - RowsAffected

                    Else
                        formScheduleAddUpdate_StatusLabel.Text = "Fail"
                        formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formScheduleAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Schedule from X10 Db." & vbCrLf & strStatus, "formScheduleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - nsX10DbMethods.addUpdateScheduleToX10db()

                End If ' END - Confirm removal of Schedule?

            End If ' END - Is there a ScheduleID?

        Catch ex As Exception
            strStatus = "formScheduleAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formScheduleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formScheduleAddUpdate_StatusLabel.Text = "Fail"
            formScheduleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formScheduleAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormScheduleEdit = Nothing
            objX10DbSchedule = Nothing
        End Try

    End Sub ' END - formScheduleAddUpdate_DeleteButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formScheduleAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationScheduleAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formScheduleAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(675, 555)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationScheduleAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationScheduleAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationScheduleAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formScheduleAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formScheduleAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formScheduleAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formScheduleAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationScheduleAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formScheduleAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationScheduleAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationScheduleAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formScheduleAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formScheduleAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formScheduleAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class