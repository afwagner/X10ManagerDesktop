﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formEventAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formEventAddUpdate))
        Me.formEventAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formEventAddUpdateEventIDLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formEventAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formEventAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formEventAddUpdateScheduleLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateScenesMacrosComboBox = New System.Windows.Forms.ComboBox()
        Me.formEventAddUpdateScenesMacrosLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateDayLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateTodayRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateEveryDayRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateSelectedDayRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateMonCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateTueCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateWedCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateThuCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateFriCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateSatCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateSunCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateCallingFormLabelText = New System.Windows.Forms.Label()
        Me.formEventAddUpdateScheduleLabelText = New System.Windows.Forms.Label()
        Me.formEventAddUpdateScheduleIDLabelText = New System.Windows.Forms.Label()
        Me.formEventAddUpdateTomorrowRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateTimePanel = New System.Windows.Forms.Panel()
        Me.formEventAddUpdateSpecificTimeDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.formEventAddUpdateSpecificTimeLabelFormat = New System.Windows.Forms.Label()
        Me.formEventAddUpdateSunsetMinutesLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateSunriseMinutesLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateSunsetMinutesTextBox = New System.Windows.Forms.TextBox()
        Me.formEventAddUpdateSunriseMinutesTextBox = New System.Windows.Forms.TextBox()
        Me.formEventAddUpdateSecurityVarationsCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateAfterSunsetByRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateAfterSunriseByRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateSpecificTimeRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateTimeLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateDayPanel = New System.Windows.Forms.Panel()
        Me.formEventAddUpdateWeekdaysRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateWeekendsRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateDayDeterminedMessageLine2LabelText = New System.Windows.Forms.Label()
        Me.formEventAddUpdateDayDeterminedMessageLine1LabelText = New System.Windows.Forms.Label()
        Me.formEventAddUpdateEventEnabledCheckBox = New System.Windows.Forms.CheckBox()
        Me.formEventAddUpdateStartDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.formEventAddUpdateStartDateLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateStopDateLabel = New System.Windows.Forms.Label()
        Me.formEventAddUpdateStopDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.formEventAddUpdateSceneMacroPanel = New System.Windows.Forms.Panel()
        Me.formEventAddUpdateMacroRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateSceneRadioButton = New System.Windows.Forms.RadioButton()
        Me.formEventAddUpdateTimePanel.SuspendLayout()
        Me.formEventAddUpdateDayPanel.SuspendLayout()
        Me.formEventAddUpdateSceneMacroPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'formEventAddUpdate_StatusLabel
        '
        Me.formEventAddUpdate_StatusLabel.AutoSize = True
        Me.formEventAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formEventAddUpdate_StatusLabel.Location = New System.Drawing.Point(143, 489)
        Me.formEventAddUpdate_StatusLabel.Name = "formEventAddUpdate_StatusLabel"
        Me.formEventAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formEventAddUpdate_StatusLabel.TabIndex = 13
        Me.formEventAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formEventAddUpdateIDLabelText
        '
        Me.formEventAddUpdateIDLabelText.AutoSize = True
        Me.formEventAddUpdateIDLabelText.Location = New System.Drawing.Point(75, 20)
        Me.formEventAddUpdateIDLabelText.Name = "formEventAddUpdateIDLabelText"
        Me.formEventAddUpdateIDLabelText.Size = New System.Drawing.Size(167, 13)
        Me.formEventAddUpdateIDLabelText.TabIndex = 12
        Me.formEventAddUpdateIDLabelText.Text = "formEventAddUpdateIDLabelText"
        '
        'formEventAddUpdateEventIDLabel
        '
        Me.formEventAddUpdateEventIDLabel.AutoSize = True
        Me.formEventAddUpdateEventIDLabel.Location = New System.Drawing.Point(21, 20)
        Me.formEventAddUpdateEventIDLabel.Name = "formEventAddUpdateEventIDLabel"
        Me.formEventAddUpdateEventIDLabel.Size = New System.Drawing.Size(49, 13)
        Me.formEventAddUpdateEventIDLabel.TabIndex = 11
        Me.formEventAddUpdateEventIDLabel.Text = "EventID:"
        '
        'formEventAddUpdate_DeleteButton
        '
        Me.formEventAddUpdate_DeleteButton.Location = New System.Drawing.Point(319, 15)
        Me.formEventAddUpdate_DeleteButton.Name = "formEventAddUpdate_DeleteButton"
        Me.formEventAddUpdate_DeleteButton.Size = New System.Drawing.Size(79, 23)
        Me.formEventAddUpdate_DeleteButton.TabIndex = 10
        Me.formEventAddUpdate_DeleteButton.Text = "Delete"
        Me.formEventAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdate_AddUpdateButton
        '
        Me.formEventAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(51, 486)
        Me.formEventAddUpdate_AddUpdateButton.Name = "formEventAddUpdate_AddUpdateButton"
        Me.formEventAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(86, 23)
        Me.formEventAddUpdate_AddUpdateButton.TabIndex = 9
        Me.formEventAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formEventAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdate_CancelButton
        '
        Me.formEventAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formEventAddUpdate_CancelButton.Location = New System.Drawing.Point(320, 486)
        Me.formEventAddUpdate_CancelButton.Name = "formEventAddUpdate_CancelButton"
        Me.formEventAddUpdate_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formEventAddUpdate_CancelButton.TabIndex = 8
        Me.formEventAddUpdate_CancelButton.Text = "Cancel"
        Me.formEventAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateScheduleLabel
        '
        Me.formEventAddUpdateScheduleLabel.AutoSize = True
        Me.formEventAddUpdateScheduleLabel.Location = New System.Drawing.Point(15, 47)
        Me.formEventAddUpdateScheduleLabel.Name = "formEventAddUpdateScheduleLabel"
        Me.formEventAddUpdateScheduleLabel.Size = New System.Drawing.Size(55, 13)
        Me.formEventAddUpdateScheduleLabel.TabIndex = 30
        Me.formEventAddUpdateScheduleLabel.Text = "Schedule:"
        '
        'formEventAddUpdateScenesMacrosComboBox
        '
        Me.formEventAddUpdateScenesMacrosComboBox.FormattingEnabled = True
        Me.formEventAddUpdateScenesMacrosComboBox.Location = New System.Drawing.Point(79, 96)
        Me.formEventAddUpdateScenesMacrosComboBox.Name = "formEventAddUpdateScenesMacrosComboBox"
        Me.formEventAddUpdateScenesMacrosComboBox.Size = New System.Drawing.Size(320, 21)
        Me.formEventAddUpdateScenesMacrosComboBox.TabIndex = 33
        '
        'formEventAddUpdateScenesMacrosLabel
        '
        Me.formEventAddUpdateScenesMacrosLabel.AutoSize = True
        Me.formEventAddUpdateScenesMacrosLabel.Location = New System.Drawing.Point(29, 99)
        Me.formEventAddUpdateScenesMacrosLabel.Name = "formEventAddUpdateScenesMacrosLabel"
        Me.formEventAddUpdateScenesMacrosLabel.Size = New System.Drawing.Size(41, 13)
        Me.formEventAddUpdateScenesMacrosLabel.TabIndex = 32
        Me.formEventAddUpdateScenesMacrosLabel.Text = "Scene:"
        '
        'formEventAddUpdateDayLabel
        '
        Me.formEventAddUpdateDayLabel.AutoSize = True
        Me.formEventAddUpdateDayLabel.Location = New System.Drawing.Point(9, 12)
        Me.formEventAddUpdateDayLabel.Name = "formEventAddUpdateDayLabel"
        Me.formEventAddUpdateDayLabel.Size = New System.Drawing.Size(40, 13)
        Me.formEventAddUpdateDayLabel.TabIndex = 35
        Me.formEventAddUpdateDayLabel.Text = "Day(s):"
        '
        'formEventAddUpdateTodayRadioButton
        '
        Me.formEventAddUpdateTodayRadioButton.AutoSize = True
        Me.formEventAddUpdateTodayRadioButton.Location = New System.Drawing.Point(58, 10)
        Me.formEventAddUpdateTodayRadioButton.Name = "formEventAddUpdateTodayRadioButton"
        Me.formEventAddUpdateTodayRadioButton.Size = New System.Drawing.Size(55, 17)
        Me.formEventAddUpdateTodayRadioButton.TabIndex = 39
        Me.formEventAddUpdateTodayRadioButton.TabStop = True
        Me.formEventAddUpdateTodayRadioButton.Text = "Today"
        Me.formEventAddUpdateTodayRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateEveryDayRadioButton
        '
        Me.formEventAddUpdateEveryDayRadioButton.AutoSize = True
        Me.formEventAddUpdateEveryDayRadioButton.Location = New System.Drawing.Point(58, 102)
        Me.formEventAddUpdateEveryDayRadioButton.Name = "formEventAddUpdateEveryDayRadioButton"
        Me.formEventAddUpdateEveryDayRadioButton.Size = New System.Drawing.Size(74, 17)
        Me.formEventAddUpdateEveryDayRadioButton.TabIndex = 41
        Me.formEventAddUpdateEveryDayRadioButton.TabStop = True
        Me.formEventAddUpdateEveryDayRadioButton.Text = "Every Day"
        Me.formEventAddUpdateEveryDayRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateSelectedDayRadioButton
        '
        Me.formEventAddUpdateSelectedDayRadioButton.AutoSize = True
        Me.formEventAddUpdateSelectedDayRadioButton.Location = New System.Drawing.Point(58, 126)
        Me.formEventAddUpdateSelectedDayRadioButton.Name = "formEventAddUpdateSelectedDayRadioButton"
        Me.formEventAddUpdateSelectedDayRadioButton.Size = New System.Drawing.Size(100, 17)
        Me.formEventAddUpdateSelectedDayRadioButton.TabIndex = 42
        Me.formEventAddUpdateSelectedDayRadioButton.TabStop = True
        Me.formEventAddUpdateSelectedDayRadioButton.Text = "Selected Day(s)"
        Me.formEventAddUpdateSelectedDayRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateMonCheckBox
        '
        Me.formEventAddUpdateMonCheckBox.AutoSize = True
        Me.formEventAddUpdateMonCheckBox.Location = New System.Drawing.Point(65, 154)
        Me.formEventAddUpdateMonCheckBox.Name = "formEventAddUpdateMonCheckBox"
        Me.formEventAddUpdateMonCheckBox.Size = New System.Drawing.Size(47, 17)
        Me.formEventAddUpdateMonCheckBox.TabIndex = 44
        Me.formEventAddUpdateMonCheckBox.Text = "Mon"
        Me.formEventAddUpdateMonCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateTueCheckBox
        '
        Me.formEventAddUpdateTueCheckBox.AutoSize = True
        Me.formEventAddUpdateTueCheckBox.Location = New System.Drawing.Point(114, 154)
        Me.formEventAddUpdateTueCheckBox.Name = "formEventAddUpdateTueCheckBox"
        Me.formEventAddUpdateTueCheckBox.Size = New System.Drawing.Size(45, 17)
        Me.formEventAddUpdateTueCheckBox.TabIndex = 45
        Me.formEventAddUpdateTueCheckBox.Text = "Tue"
        Me.formEventAddUpdateTueCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateWedCheckBox
        '
        Me.formEventAddUpdateWedCheckBox.AutoSize = True
        Me.formEventAddUpdateWedCheckBox.Location = New System.Drawing.Point(167, 154)
        Me.formEventAddUpdateWedCheckBox.Name = "formEventAddUpdateWedCheckBox"
        Me.formEventAddUpdateWedCheckBox.Size = New System.Drawing.Size(49, 17)
        Me.formEventAddUpdateWedCheckBox.TabIndex = 46
        Me.formEventAddUpdateWedCheckBox.Text = "Wed"
        Me.formEventAddUpdateWedCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateThuCheckBox
        '
        Me.formEventAddUpdateThuCheckBox.AutoSize = True
        Me.formEventAddUpdateThuCheckBox.Location = New System.Drawing.Point(220, 154)
        Me.formEventAddUpdateThuCheckBox.Name = "formEventAddUpdateThuCheckBox"
        Me.formEventAddUpdateThuCheckBox.Size = New System.Drawing.Size(45, 17)
        Me.formEventAddUpdateThuCheckBox.TabIndex = 47
        Me.formEventAddUpdateThuCheckBox.Text = "Thu"
        Me.formEventAddUpdateThuCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateFriCheckBox
        '
        Me.formEventAddUpdateFriCheckBox.AutoSize = True
        Me.formEventAddUpdateFriCheckBox.Location = New System.Drawing.Point(271, 154)
        Me.formEventAddUpdateFriCheckBox.Name = "formEventAddUpdateFriCheckBox"
        Me.formEventAddUpdateFriCheckBox.Size = New System.Drawing.Size(37, 17)
        Me.formEventAddUpdateFriCheckBox.TabIndex = 48
        Me.formEventAddUpdateFriCheckBox.Text = "Fri"
        Me.formEventAddUpdateFriCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateSatCheckBox
        '
        Me.formEventAddUpdateSatCheckBox.AutoSize = True
        Me.formEventAddUpdateSatCheckBox.Location = New System.Drawing.Point(314, 154)
        Me.formEventAddUpdateSatCheckBox.Name = "formEventAddUpdateSatCheckBox"
        Me.formEventAddUpdateSatCheckBox.Size = New System.Drawing.Size(42, 17)
        Me.formEventAddUpdateSatCheckBox.TabIndex = 49
        Me.formEventAddUpdateSatCheckBox.Text = "Sat"
        Me.formEventAddUpdateSatCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateSunCheckBox
        '
        Me.formEventAddUpdateSunCheckBox.AutoSize = True
        Me.formEventAddUpdateSunCheckBox.Location = New System.Drawing.Point(14, 154)
        Me.formEventAddUpdateSunCheckBox.Name = "formEventAddUpdateSunCheckBox"
        Me.formEventAddUpdateSunCheckBox.Size = New System.Drawing.Size(45, 17)
        Me.formEventAddUpdateSunCheckBox.TabIndex = 50
        Me.formEventAddUpdateSunCheckBox.Text = "Sun"
        Me.formEventAddUpdateSunCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateCallingFormLabelText
        '
        Me.formEventAddUpdateCallingFormLabelText.AutoSize = True
        Me.formEventAddUpdateCallingFormLabelText.Location = New System.Drawing.Point(56, 467)
        Me.formEventAddUpdateCallingFormLabelText.Name = "formEventAddUpdateCallingFormLabelText"
        Me.formEventAddUpdateCallingFormLabelText.Size = New System.Drawing.Size(64, 13)
        Me.formEventAddUpdateCallingFormLabelText.TabIndex = 57
        Me.formEventAddUpdateCallingFormLabelText.Text = "Calling Form"
        Me.formEventAddUpdateCallingFormLabelText.Visible = False
        '
        'formEventAddUpdateScheduleLabelText
        '
        Me.formEventAddUpdateScheduleLabelText.AutoSize = True
        Me.formEventAddUpdateScheduleLabelText.Location = New System.Drawing.Point(75, 47)
        Me.formEventAddUpdateScheduleLabelText.Name = "formEventAddUpdateScheduleLabelText"
        Me.formEventAddUpdateScheduleLabelText.Size = New System.Drawing.Size(78, 13)
        Me.formEventAddUpdateScheduleLabelText.TabIndex = 59
        Me.formEventAddUpdateScheduleLabelText.Text = "scheduleName"
        '
        'formEventAddUpdateScheduleIDLabelText
        '
        Me.formEventAddUpdateScheduleIDLabelText.AutoSize = True
        Me.formEventAddUpdateScheduleIDLabelText.Location = New System.Drawing.Point(152, 467)
        Me.formEventAddUpdateScheduleIDLabelText.Name = "formEventAddUpdateScheduleIDLabelText"
        Me.formEventAddUpdateScheduleIDLabelText.Size = New System.Drawing.Size(63, 13)
        Me.formEventAddUpdateScheduleIDLabelText.TabIndex = 60
        Me.formEventAddUpdateScheduleIDLabelText.Text = "ScheduleID"
        Me.formEventAddUpdateScheduleIDLabelText.Visible = False
        '
        'formEventAddUpdateTomorrowRadioButton
        '
        Me.formEventAddUpdateTomorrowRadioButton.AutoSize = True
        Me.formEventAddUpdateTomorrowRadioButton.Location = New System.Drawing.Point(58, 33)
        Me.formEventAddUpdateTomorrowRadioButton.Name = "formEventAddUpdateTomorrowRadioButton"
        Me.formEventAddUpdateTomorrowRadioButton.Size = New System.Drawing.Size(72, 17)
        Me.formEventAddUpdateTomorrowRadioButton.TabIndex = 63
        Me.formEventAddUpdateTomorrowRadioButton.TabStop = True
        Me.formEventAddUpdateTomorrowRadioButton.Text = "Tomorrow"
        Me.formEventAddUpdateTomorrowRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateTimePanel
        '
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSpecificTimeDateTimePicker)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSpecificTimeLabelFormat)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSunsetMinutesLabel)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSunriseMinutesLabel)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSunsetMinutesTextBox)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSunriseMinutesTextBox)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSecurityVarationsCheckBox)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateAfterSunsetByRadioButton)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateAfterSunriseByRadioButton)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateSpecificTimeRadioButton)
        Me.formEventAddUpdateTimePanel.Controls.Add(Me.formEventAddUpdateTimeLabel)
        Me.formEventAddUpdateTimePanel.Location = New System.Drawing.Point(28, 181)
        Me.formEventAddUpdateTimePanel.Name = "formEventAddUpdateTimePanel"
        Me.formEventAddUpdateTimePanel.Size = New System.Drawing.Size(370, 118)
        Me.formEventAddUpdateTimePanel.TabIndex = 64
        '
        'formEventAddUpdateSpecificTimeDateTimePicker
        '
        Me.formEventAddUpdateSpecificTimeDateTimePicker.CustomFormat = "hh:mm tt"
        Me.formEventAddUpdateSpecificTimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.formEventAddUpdateSpecificTimeDateTimePicker.Location = New System.Drawing.Point(164, 9)
        Me.formEventAddUpdateSpecificTimeDateTimePicker.Name = "formEventAddUpdateSpecificTimeDateTimePicker"
        Me.formEventAddUpdateSpecificTimeDateTimePicker.Size = New System.Drawing.Size(70, 20)
        Me.formEventAddUpdateSpecificTimeDateTimePicker.TabIndex = 73
        Me.formEventAddUpdateSpecificTimeDateTimePicker.Value = New Date(2020, 12, 12, 15, 34, 18, 0)
        '
        'formEventAddUpdateSpecificTimeLabelFormat
        '
        Me.formEventAddUpdateSpecificTimeLabelFormat.AutoSize = True
        Me.formEventAddUpdateSpecificTimeLabelFormat.Location = New System.Drawing.Point(240, 11)
        Me.formEventAddUpdateSpecificTimeLabelFormat.Name = "formEventAddUpdateSpecificTimeLabelFormat"
        Me.formEventAddUpdateSpecificTimeLabelFormat.Size = New System.Drawing.Size(78, 13)
        Me.formEventAddUpdateSpecificTimeLabelFormat.TabIndex = 72
        Me.formEventAddUpdateSpecificTimeLabelFormat.Text = "hh:mm AM/PM"
        '
        'formEventAddUpdateSunsetMinutesLabel
        '
        Me.formEventAddUpdateSunsetMinutesLabel.AutoSize = True
        Me.formEventAddUpdateSunsetMinutesLabel.Location = New System.Drawing.Point(222, 64)
        Me.formEventAddUpdateSunsetMinutesLabel.Name = "formEventAddUpdateSunsetMinutesLabel"
        Me.formEventAddUpdateSunsetMinutesLabel.Size = New System.Drawing.Size(43, 13)
        Me.formEventAddUpdateSunsetMinutesLabel.TabIndex = 71
        Me.formEventAddUpdateSunsetMinutesLabel.Text = "minutes"
        '
        'formEventAddUpdateSunriseMinutesLabel
        '
        Me.formEventAddUpdateSunriseMinutesLabel.AutoSize = True
        Me.formEventAddUpdateSunriseMinutesLabel.Location = New System.Drawing.Point(222, 38)
        Me.formEventAddUpdateSunriseMinutesLabel.Name = "formEventAddUpdateSunriseMinutesLabel"
        Me.formEventAddUpdateSunriseMinutesLabel.Size = New System.Drawing.Size(43, 13)
        Me.formEventAddUpdateSunriseMinutesLabel.TabIndex = 70
        Me.formEventAddUpdateSunriseMinutesLabel.Text = "minutes"
        '
        'formEventAddUpdateSunsetMinutesTextBox
        '
        Me.formEventAddUpdateSunsetMinutesTextBox.Location = New System.Drawing.Point(164, 61)
        Me.formEventAddUpdateSunsetMinutesTextBox.Name = "formEventAddUpdateSunsetMinutesTextBox"
        Me.formEventAddUpdateSunsetMinutesTextBox.Size = New System.Drawing.Size(52, 20)
        Me.formEventAddUpdateSunsetMinutesTextBox.TabIndex = 69
        '
        'formEventAddUpdateSunriseMinutesTextBox
        '
        Me.formEventAddUpdateSunriseMinutesTextBox.Location = New System.Drawing.Point(164, 35)
        Me.formEventAddUpdateSunriseMinutesTextBox.Name = "formEventAddUpdateSunriseMinutesTextBox"
        Me.formEventAddUpdateSunriseMinutesTextBox.Size = New System.Drawing.Size(52, 20)
        Me.formEventAddUpdateSunriseMinutesTextBox.TabIndex = 68
        '
        'formEventAddUpdateSecurityVarationsCheckBox
        '
        Me.formEventAddUpdateSecurityVarationsCheckBox.AutoSize = True
        Me.formEventAddUpdateSecurityVarationsCheckBox.Location = New System.Drawing.Point(111, 87)
        Me.formEventAddUpdateSecurityVarationsCheckBox.Name = "formEventAddUpdateSecurityVarationsCheckBox"
        Me.formEventAddUpdateSecurityVarationsCheckBox.Size = New System.Drawing.Size(111, 17)
        Me.formEventAddUpdateSecurityVarationsCheckBox.TabIndex = 67
        Me.formEventAddUpdateSecurityVarationsCheckBox.Text = "Security Varations"
        Me.formEventAddUpdateSecurityVarationsCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateAfterSunsetByRadioButton
        '
        Me.formEventAddUpdateAfterSunsetByRadioButton.AutoSize = True
        Me.formEventAddUpdateAfterSunsetByRadioButton.Location = New System.Drawing.Point(58, 62)
        Me.formEventAddUpdateAfterSunsetByRadioButton.Name = "formEventAddUpdateAfterSunsetByRadioButton"
        Me.formEventAddUpdateAfterSunsetByRadioButton.Size = New System.Drawing.Size(101, 17)
        Me.formEventAddUpdateAfterSunsetByRadioButton.TabIndex = 66
        Me.formEventAddUpdateAfterSunsetByRadioButton.TabStop = True
        Me.formEventAddUpdateAfterSunsetByRadioButton.Text = "After Sunset By:"
        Me.formEventAddUpdateAfterSunsetByRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateAfterSunriseByRadioButton
        '
        Me.formEventAddUpdateAfterSunriseByRadioButton.AutoSize = True
        Me.formEventAddUpdateAfterSunriseByRadioButton.Location = New System.Drawing.Point(58, 36)
        Me.formEventAddUpdateAfterSunriseByRadioButton.Name = "formEventAddUpdateAfterSunriseByRadioButton"
        Me.formEventAddUpdateAfterSunriseByRadioButton.Size = New System.Drawing.Size(103, 17)
        Me.formEventAddUpdateAfterSunriseByRadioButton.TabIndex = 65
        Me.formEventAddUpdateAfterSunriseByRadioButton.TabStop = True
        Me.formEventAddUpdateAfterSunriseByRadioButton.Text = "After Sunrise By:"
        Me.formEventAddUpdateAfterSunriseByRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateSpecificTimeRadioButton
        '
        Me.formEventAddUpdateSpecificTimeRadioButton.AutoSize = True
        Me.formEventAddUpdateSpecificTimeRadioButton.Location = New System.Drawing.Point(58, 9)
        Me.formEventAddUpdateSpecificTimeRadioButton.Name = "formEventAddUpdateSpecificTimeRadioButton"
        Me.formEventAddUpdateSpecificTimeRadioButton.Size = New System.Drawing.Size(92, 17)
        Me.formEventAddUpdateSpecificTimeRadioButton.TabIndex = 64
        Me.formEventAddUpdateSpecificTimeRadioButton.TabStop = True
        Me.formEventAddUpdateSpecificTimeRadioButton.Text = "Specific Time:"
        Me.formEventAddUpdateSpecificTimeRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateTimeLabel
        '
        Me.formEventAddUpdateTimeLabel.AutoSize = True
        Me.formEventAddUpdateTimeLabel.Location = New System.Drawing.Point(16, 11)
        Me.formEventAddUpdateTimeLabel.Name = "formEventAddUpdateTimeLabel"
        Me.formEventAddUpdateTimeLabel.Size = New System.Drawing.Size(33, 13)
        Me.formEventAddUpdateTimeLabel.TabIndex = 63
        Me.formEventAddUpdateTimeLabel.Text = "Time:"
        '
        'formEventAddUpdateDayPanel
        '
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateWeekdaysRadioButton)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateWeekendsRadioButton)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateDayDeterminedMessageLine2LabelText)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateDayDeterminedMessageLine1LabelText)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateEveryDayRadioButton)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateDayLabel)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateTomorrowRadioButton)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateTodayRadioButton)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateSelectedDayRadioButton)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateMonCheckBox)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateTueCheckBox)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateSunCheckBox)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateWedCheckBox)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateSatCheckBox)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateThuCheckBox)
        Me.formEventAddUpdateDayPanel.Controls.Add(Me.formEventAddUpdateFriCheckBox)
        Me.formEventAddUpdateDayPanel.Location = New System.Drawing.Point(28, 291)
        Me.formEventAddUpdateDayPanel.Name = "formEventAddUpdateDayPanel"
        Me.formEventAddUpdateDayPanel.Size = New System.Drawing.Size(370, 174)
        Me.formEventAddUpdateDayPanel.TabIndex = 65
        '
        'formEventAddUpdateWeekdaysRadioButton
        '
        Me.formEventAddUpdateWeekdaysRadioButton.AutoSize = True
        Me.formEventAddUpdateWeekdaysRadioButton.Location = New System.Drawing.Point(58, 79)
        Me.formEventAddUpdateWeekdaysRadioButton.Name = "formEventAddUpdateWeekdaysRadioButton"
        Me.formEventAddUpdateWeekdaysRadioButton.Size = New System.Drawing.Size(76, 17)
        Me.formEventAddUpdateWeekdaysRadioButton.TabIndex = 67
        Me.formEventAddUpdateWeekdaysRadioButton.TabStop = True
        Me.formEventAddUpdateWeekdaysRadioButton.Text = "Weekdays"
        Me.formEventAddUpdateWeekdaysRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateWeekendsRadioButton
        '
        Me.formEventAddUpdateWeekendsRadioButton.AutoSize = True
        Me.formEventAddUpdateWeekendsRadioButton.Location = New System.Drawing.Point(58, 56)
        Me.formEventAddUpdateWeekendsRadioButton.Name = "formEventAddUpdateWeekendsRadioButton"
        Me.formEventAddUpdateWeekendsRadioButton.Size = New System.Drawing.Size(77, 17)
        Me.formEventAddUpdateWeekendsRadioButton.TabIndex = 66
        Me.formEventAddUpdateWeekendsRadioButton.TabStop = True
        Me.formEventAddUpdateWeekendsRadioButton.Text = "Weekends"
        Me.formEventAddUpdateWeekendsRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateDayDeterminedMessageLine2LabelText
        '
        Me.formEventAddUpdateDayDeterminedMessageLine2LabelText.AutoSize = True
        Me.formEventAddUpdateDayDeterminedMessageLine2LabelText.Location = New System.Drawing.Point(161, 35)
        Me.formEventAddUpdateDayDeterminedMessageLine2LabelText.Name = "formEventAddUpdateDayDeterminedMessageLine2LabelText"
        Me.formEventAddUpdateDayDeterminedMessageLine2LabelText.Size = New System.Drawing.Size(206, 13)
        Me.formEventAddUpdateDayDeterminedMessageLine2LabelText.TabIndex = 65
        Me.formEventAddUpdateDayDeterminedMessageLine2LabelText.Text = "when Event is downloaded to a Controller."
        '
        'formEventAddUpdateDayDeterminedMessageLine1LabelText
        '
        Me.formEventAddUpdateDayDeterminedMessageLine1LabelText.AutoSize = True
        Me.formEventAddUpdateDayDeterminedMessageLine1LabelText.Location = New System.Drawing.Point(161, 12)
        Me.formEventAddUpdateDayDeterminedMessageLine1LabelText.Name = "formEventAddUpdateDayDeterminedMessageLine1LabelText"
        Me.formEventAddUpdateDayDeterminedMessageLine1LabelText.Size = New System.Drawing.Size(207, 13)
        Me.formEventAddUpdateDayDeterminedMessageLine1LabelText.TabIndex = 64
        Me.formEventAddUpdateDayDeterminedMessageLine1LabelText.Text = "For Today and Tomorrow, day determined "
        '
        'formEventAddUpdateEventEnabledCheckBox
        '
        Me.formEventAddUpdateEventEnabledCheckBox.AutoSize = True
        Me.formEventAddUpdateEventEnabledCheckBox.Location = New System.Drawing.Point(19, 144)
        Me.formEventAddUpdateEventEnabledCheckBox.Name = "formEventAddUpdateEventEnabledCheckBox"
        Me.formEventAddUpdateEventEnabledCheckBox.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.formEventAddUpdateEventEnabledCheckBox.Size = New System.Drawing.Size(96, 17)
        Me.formEventAddUpdateEventEnabledCheckBox.TabIndex = 66
        Me.formEventAddUpdateEventEnabledCheckBox.Text = "Event Enabled"
        Me.formEventAddUpdateEventEnabledCheckBox.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateStartDateDateTimePicker
        '
        Me.formEventAddUpdateStartDateDateTimePicker.Location = New System.Drawing.Point(192, 130)
        Me.formEventAddUpdateStartDateDateTimePicker.Name = "formEventAddUpdateStartDateDateTimePicker"
        Me.formEventAddUpdateStartDateDateTimePicker.Size = New System.Drawing.Size(207, 20)
        Me.formEventAddUpdateStartDateDateTimePicker.TabIndex = 67
        Me.formEventAddUpdateStartDateDateTimePicker.Value = New Date(2020, 12, 12, 15, 34, 49, 0)
        '
        'formEventAddUpdateStartDateLabel
        '
        Me.formEventAddUpdateStartDateLabel.AutoSize = True
        Me.formEventAddUpdateStartDateLabel.Location = New System.Drawing.Point(131, 133)
        Me.formEventAddUpdateStartDateLabel.Name = "formEventAddUpdateStartDateLabel"
        Me.formEventAddUpdateStartDateLabel.Size = New System.Drawing.Size(58, 13)
        Me.formEventAddUpdateStartDateLabel.TabIndex = 68
        Me.formEventAddUpdateStartDateLabel.Text = "Start Date:"
        '
        'formEventAddUpdateStopDateLabel
        '
        Me.formEventAddUpdateStopDateLabel.AutoSize = True
        Me.formEventAddUpdateStopDateLabel.Location = New System.Drawing.Point(131, 159)
        Me.formEventAddUpdateStopDateLabel.Name = "formEventAddUpdateStopDateLabel"
        Me.formEventAddUpdateStopDateLabel.Size = New System.Drawing.Size(58, 13)
        Me.formEventAddUpdateStopDateLabel.TabIndex = 70
        Me.formEventAddUpdateStopDateLabel.Text = "Stop Date:"
        '
        'formEventAddUpdateStopDateDateTimePicker
        '
        Me.formEventAddUpdateStopDateDateTimePicker.Location = New System.Drawing.Point(192, 156)
        Me.formEventAddUpdateStopDateDateTimePicker.Name = "formEventAddUpdateStopDateDateTimePicker"
        Me.formEventAddUpdateStopDateDateTimePicker.Size = New System.Drawing.Size(207, 20)
        Me.formEventAddUpdateStopDateDateTimePicker.TabIndex = 69
        Me.formEventAddUpdateStopDateDateTimePicker.Value = New Date(2020, 12, 12, 15, 34, 57, 0)
        '
        'formEventAddUpdateSceneMacroPanel
        '
        Me.formEventAddUpdateSceneMacroPanel.Controls.Add(Me.formEventAddUpdateMacroRadioButton)
        Me.formEventAddUpdateSceneMacroPanel.Controls.Add(Me.formEventAddUpdateSceneRadioButton)
        Me.formEventAddUpdateSceneMacroPanel.Location = New System.Drawing.Point(79, 63)
        Me.formEventAddUpdateSceneMacroPanel.Name = "formEventAddUpdateSceneMacroPanel"
        Me.formEventAddUpdateSceneMacroPanel.Size = New System.Drawing.Size(187, 29)
        Me.formEventAddUpdateSceneMacroPanel.TabIndex = 86
        '
        'formEventAddUpdateMacroRadioButton
        '
        Me.formEventAddUpdateMacroRadioButton.AutoSize = True
        Me.formEventAddUpdateMacroRadioButton.Location = New System.Drawing.Point(129, 9)
        Me.formEventAddUpdateMacroRadioButton.Name = "formEventAddUpdateMacroRadioButton"
        Me.formEventAddUpdateMacroRadioButton.Size = New System.Drawing.Size(55, 17)
        Me.formEventAddUpdateMacroRadioButton.TabIndex = 63
        Me.formEventAddUpdateMacroRadioButton.TabStop = True
        Me.formEventAddUpdateMacroRadioButton.Text = "Macro"
        Me.formEventAddUpdateMacroRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdateSceneRadioButton
        '
        Me.formEventAddUpdateSceneRadioButton.AutoSize = True
        Me.formEventAddUpdateSceneRadioButton.Location = New System.Drawing.Point(7, 9)
        Me.formEventAddUpdateSceneRadioButton.Name = "formEventAddUpdateSceneRadioButton"
        Me.formEventAddUpdateSceneRadioButton.Size = New System.Drawing.Size(56, 17)
        Me.formEventAddUpdateSceneRadioButton.TabIndex = 39
        Me.formEventAddUpdateSceneRadioButton.TabStop = True
        Me.formEventAddUpdateSceneRadioButton.Text = "Scene"
        Me.formEventAddUpdateSceneRadioButton.UseVisualStyleBackColor = True
        '
        'formEventAddUpdate
        '
        Me.AcceptButton = Me.formEventAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formEventAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(425, 522)
        Me.Controls.Add(Me.formEventAddUpdateSceneMacroPanel)
        Me.Controls.Add(Me.formEventAddUpdateStopDateLabel)
        Me.Controls.Add(Me.formEventAddUpdateStopDateDateTimePicker)
        Me.Controls.Add(Me.formEventAddUpdateStartDateLabel)
        Me.Controls.Add(Me.formEventAddUpdateStartDateDateTimePicker)
        Me.Controls.Add(Me.formEventAddUpdateEventEnabledCheckBox)
        Me.Controls.Add(Me.formEventAddUpdateDayPanel)
        Me.Controls.Add(Me.formEventAddUpdateTimePanel)
        Me.Controls.Add(Me.formEventAddUpdateScheduleIDLabelText)
        Me.Controls.Add(Me.formEventAddUpdateScheduleLabelText)
        Me.Controls.Add(Me.formEventAddUpdateCallingFormLabelText)
        Me.Controls.Add(Me.formEventAddUpdateScenesMacrosComboBox)
        Me.Controls.Add(Me.formEventAddUpdateScenesMacrosLabel)
        Me.Controls.Add(Me.formEventAddUpdateScheduleLabel)
        Me.Controls.Add(Me.formEventAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formEventAddUpdateIDLabelText)
        Me.Controls.Add(Me.formEventAddUpdateEventIDLabel)
        Me.Controls.Add(Me.formEventAddUpdate_DeleteButton)
        Me.Controls.Add(Me.formEventAddUpdate_AddUpdateButton)
        Me.Controls.Add(Me.formEventAddUpdate_CancelButton)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formEventAddUpdate"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Event Add / Update"
        Me.formEventAddUpdateTimePanel.ResumeLayout(False)
        Me.formEventAddUpdateTimePanel.PerformLayout()
        Me.formEventAddUpdateDayPanel.ResumeLayout(False)
        Me.formEventAddUpdateDayPanel.PerformLayout()
        Me.formEventAddUpdateSceneMacroPanel.ResumeLayout(False)
        Me.formEventAddUpdateSceneMacroPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formEventAddUpdate_StatusLabel As Label
    Friend WithEvents formEventAddUpdateIDLabelText As Label
    Friend WithEvents formEventAddUpdateEventIDLabel As Label
    Friend WithEvents formEventAddUpdate_DeleteButton As Button
    Friend WithEvents formEventAddUpdate_AddUpdateButton As Button
    Friend WithEvents formEventAddUpdate_CancelButton As Button
    Friend WithEvents formEventAddUpdateScheduleLabel As Label
    Friend WithEvents formEventAddUpdateScenesMacrosComboBox As ComboBox
    Friend WithEvents formEventAddUpdateScenesMacrosLabel As Label
    Friend WithEvents formEventAddUpdateDayLabel As Label
    Friend WithEvents formEventAddUpdateTodayRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateEveryDayRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateSelectedDayRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateMonCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateTueCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateWedCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateThuCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateFriCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateSatCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateSunCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateCallingFormLabelText As Label
    Friend WithEvents formEventAddUpdateScheduleLabelText As Label
    Friend WithEvents formEventAddUpdateScheduleIDLabelText As Label
    Friend WithEvents formEventAddUpdateTomorrowRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateTimePanel As Panel
    Friend WithEvents formEventAddUpdateSpecificTimeLabelFormat As Label
    Friend WithEvents formEventAddUpdateSunsetMinutesLabel As Label
    Friend WithEvents formEventAddUpdateSunriseMinutesLabel As Label
    Friend WithEvents formEventAddUpdateSunsetMinutesTextBox As TextBox
    Friend WithEvents formEventAddUpdateSunriseMinutesTextBox As TextBox
    Friend WithEvents formEventAddUpdateSecurityVarationsCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateAfterSunsetByRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateAfterSunriseByRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateSpecificTimeRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateTimeLabel As Label
    Friend WithEvents formEventAddUpdateDayPanel As Panel
    Friend WithEvents formEventAddUpdateDayDeterminedMessageLine2LabelText As Label
    Friend WithEvents formEventAddUpdateDayDeterminedMessageLine1LabelText As Label
    Friend WithEvents formEventAddUpdateWeekdaysRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateWeekendsRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateEventEnabledCheckBox As CheckBox
    Friend WithEvents formEventAddUpdateStartDateDateTimePicker As DateTimePicker
    Friend WithEvents formEventAddUpdateStartDateLabel As Label
    Friend WithEvents formEventAddUpdateStopDateLabel As Label
    Friend WithEvents formEventAddUpdateStopDateDateTimePicker As DateTimePicker
    Friend WithEvents formEventAddUpdateSpecificTimeDateTimePicker As DateTimePicker
    Friend WithEvents formEventAddUpdateSceneMacroPanel As Panel
    Friend WithEvents formEventAddUpdateMacroRadioButton As RadioButton
    Friend WithEvents formEventAddUpdateSceneRadioButton As RadioButton
End Class
