﻿Imports System.Configuration

' Name: formMacroCommandAddUpdate.vb
' By: Alan Wagner
' Date: February 2021

Public Class formMacroCommandAddUpdate

#Region "X10ManagerDesktopMacroCommandAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim intMacroCommandID As Integer = -1
        Dim objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim strMessage As String = ""

        Try

            Me.BringToFront()

            strTryStep = "formMacroCommandAddUpdate_FormRestore"
            ' formMacroCommandAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formMacroCommandAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formMacroCommandAddUpdateIDLabelText"
                If (formMacroCommandAddUpdateIDLabelText.Text() = "" Or formMacroCommandAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddMacroCommand"

                    formMacroCommandAddUpdateIDLabelText.Text() = ""

                    ' Set the caption bar text of the form.
                    Me.Text = "Add Macro Command"

                    formMacroCommandAddUpdate_AddUpdateButton.Text() = "Add"
                    formMacroCommandAddUpdate_AddUpdateButton.Select()
                    formMacroCommandAddUpdate_StatusLabel.Visible = True
                    formMacroCommandAddUpdate_StatusLabel.Text = ""

                    formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"

                    formMacroCommandAddUpdate_DeleteButton.Visible = False
                    formMacroCommandAddUpdate_DeleteButton.Text() = "Delete"


                    formMacroCommandAddUpdateMacroCommandSortOrderLabel.Visible = True

                    strTryStep = "Add_generateSortOrderComboBox"
                    ' generateSortOrderComboBox(ByVal intSort As Integer) As String
                    strStatus = generateSortOrderComboBox(-1)
                    If (strStatus = "") Then

                        formMacroCommandAddUpdateMacroCommandSortOrderComboBox.Visible = True
                    Else
                        formMacroCommandAddUpdateMacroCommandSortOrderComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroCommandAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroCommandAddUpdate_CancelButton.Select()
                        formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                        formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formMacroCommandAddUpdateCommandLabel.Visible = True

                    strTryStep = "Add_generateCommandComboBox"
                    ' objX10DbMacroCommand.command byte
                    ' generateCommandComboBox(ByVal intCommand As Integer) As String
                    strStatus = generateCommandComboBox(-1)
                    If (strStatus = "") Then
                        formMacroCommandAddUpdateCommandComboBox.Visible = True
                    Else
                        formMacroCommandAddUpdateCommandComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroCommandAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroCommandAddUpdate_CancelButton.Select()
                        formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                        formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formMacroCommandAddUpdateHouseCodeLabel.Visible = True

                    strTryStep = "Add_generateHouseCodesComboBox"
                    ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                    strStatus = generateHouseCodesComboBox("")
                    If (strStatus = "") Then
                        formMacroCommandAddUpdateHouseCodeComboBox.Visible = True
                    Else
                        formMacroCommandAddUpdateHouseCodeComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroCommandAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroCommandAddUpdate_CancelButton.Select()
                        formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                        formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    strTryStep = "Add_setDefaults"
                    Call setDefaults()


                Else
                    strTryStep = "UpdateMacroCommand"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Macro Command"

                    formMacroCommandAddUpdate_AddUpdateButton.Text() = "Update"
                    formMacroCommandAddUpdate_AddUpdateButton.Select()
                    formMacroCommandAddUpdate_StatusLabel.Visible = True
                    formMacroCommandAddUpdate_StatusLabel.Text = ""

                    formMacroCommandAddUpdate_CancelButton.Text() = "Done"

                    formMacroCommandAddUpdate_DeleteButton.Visible = True
                    formMacroCommandAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "MacroCommandID"
                    intMacroCommandID = CType(formMacroCommandAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbMacroCommand"
                    ' nsX10DbMethods.getX10DbMacroCommand(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intMacroCommandID As Integer, ByRef objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand) As String
                    strStatus = nsX10DbMethods.getX10DbMacroCommand(strConnectionString, strProvider, intMacroCommandID, objX10DbMacroCommand)
                    If (strStatus = "") Then

                        formMacroCommandAddUpdateIDLabelText.Visible = True
                        formMacroCommandAddUpdateIDLabelText.Visible = True
                        formMacroCommandAddUpdateIDLabelText.Text() = objX10DbMacroCommand.MacroCommandID.ToString()


                        formMacroCommandAddUpdateMacroCommandSortOrderLabel.Visible = True

                        strTryStep = "Update_generateSortOrderComboBox"
                        ' generateSortOrderComboBox(ByVal intSort As Integer) As String
                        strStatus = generateSortOrderComboBox(objX10DbMacroCommand.MacroCommandSort)
                        If (strStatus = "") Then

                            formMacroCommandAddUpdateMacroCommandSortOrderComboBox.Visible = True
                        Else
                            formMacroCommandAddUpdateMacroCommandSortOrderComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroCommandAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_CancelButton.Select()
                            formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                            formMacroCommandAddUpdate_DeleteButton.Visible = False
                        End If


                        formMacroCommandAddUpdateCommandLabel.Visible = True

                        strTryStep = "Update_generateCommandComboBox"
                        ' generateCommandComboBox(ByVal intCommand As Integer) As String
                        strStatus = generateCommandComboBox(CType(objX10DbMacroCommand.command, Integer))
                        If (strStatus = "") Then
                            formMacroCommandAddUpdateCommandComboBox.Visible = True
                        Else
                            formMacroCommandAddUpdateCommandComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroCommandAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_CancelButton.Select()
                            formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                            formMacroCommandAddUpdate_DeleteButton.Visible = False
                        End If


                        formMacroCommandAddUpdateHouseCodeLabel.Visible = True

                        strTryStep = "Update_generateHouseCodesComboBox"
                        ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                        strStatus = generateHouseCodesComboBox(nsX10CM15AMethods.x10BinaryValueToHouseCode(objX10DbMacroCommand.house))
                        If (strStatus = "") Then
                            formMacroCommandAddUpdateHouseCodeComboBox.Visible = True
                        Else
                            formMacroCommandAddUpdateHouseCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroCommandAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_CancelButton.Select()
                            formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                            formMacroCommandAddUpdate_DeleteButton.Visible = False
                        End If


                        strTryStep = "Update_setDefaults"
                        Call setDefaults()


                        strTryStep = "Update_processCommandCode()"
                        ' processCommandCode(ByVal bytCommandCode As Byte, ByRef objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand) As String
                        strStatus = processCommandCode(objX10DbMacroCommand.command, objX10DbMacroCommand)
                        If (strStatus <> "") Then
                            Windows.Forms.MessageBox.Show("Main(formMacroCommandAddUpdate-Update): " & strStatus, "Main(formMacroCommandAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                            formMacroCommandAddUpdate_DeleteButton.Visible = False
                        End If ' END - Update_processCommandCode()


                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Macro Command from X10 db." & vbCrLf & strStatus, "Main(formMacroCommandAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroCommandAddUpdate_CancelButton.Select()
                        formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                        formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                        formMacroCommandAddUpdate_DeleteButton.Visible = False
                    End If ' END - nsX10DbMethods.getX10DbMacroCommand()

                End If ' END - formMacroCommandAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formMacroCommandAddUpdate): " & strStatus, "Main(formMacroCommandAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                formMacroCommandAddUpdate_DeleteButton.Visible = False
            End If ' END - formMacroCommandAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formMacroCommandAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroCommandAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
            formMacroCommandAddUpdate_DeleteButton.Visible = False
        Finally
            objX10DbMacroCommand = Nothing
        End Try

    End Sub ' END Sub - Main(formMacroCommandAddUpdate)

    Private Sub formMacroCommandAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formMacroCommandAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formMacroCommandAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formMacroCommandAddUpdate_FormClosingHandler(): " & strStatus, "formMacroCommandAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formMacroCommandAddUpdate_FormSave()

    End Sub ' END Sub - formMacroCommandAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopMacroCommandAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function generateSortOrderComboBox()
    ' Alan Wagner
    '
    Private Function generateSortOrderComboBox(ByVal intSort As Integer) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataTableComboBoxs As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            sqlString = "SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='SortOrder' " &
                        "ORDER BY ComboBoxs.ValueMember ASC;"

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableComboBoxs)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroCommandAddUpdateMacroCommandSortOrderComboBox
                .DisplayMember = "DisplayMember"
                .ValueMember = "ValueMember"
                .DataSource = objDataTableComboBoxs
            End With

            If (intSort = -1) Then
                formMacroCommandAddUpdateMacroCommandSortOrderComboBox.SelectedIndex = 0
            Else
                formMacroCommandAddUpdateMacroCommandSortOrderComboBox.SelectedIndex = formMacroCommandAddUpdateMacroCommandSortOrderComboBox.FindString(intSort.ToString())
            End If

        Catch ex As Exception
            strStatus = "generateSortOrderComboBox(): Exception: " & ex.Message
        Finally
            objDataTableComboBoxs = Nothing
        End Try

        Return strStatus

    End Function ' END - generateSortOrderComboBox()

    '=====================================================================================
    ' Function generateHouseCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateHouseCodesComboBox(ByVal strHouseCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableHouseCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT HouseCodeID, HouseCode FROM HouseCodes UNION SELECT 0 AS HouseCodeID, 'Select HouseCode...' AS HouseCode FROM HouseCodes ORDER BY HouseCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableHouseCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroCommandAddUpdateHouseCodeComboBox
                .DisplayMember = "HouseCode"
                .ValueMember = "HouseCodeID"
                .DataSource = objDataTableHouseCodes
            End With

            If (strHouseCode = "") Then
                formMacroCommandAddUpdateHouseCodeComboBox.SelectedIndex = 0
            Else
                formMacroCommandAddUpdateHouseCodeComboBox.SelectedIndex = formMacroCommandAddUpdateHouseCodeComboBox.FindString(strHouseCode)
            End If

        Catch ex As Exception
            strStatus = "generateHouseCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableHouseCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateHouseCodesComboBox()

    '=====================================================================================
    ' Function putCheckBoxUnits()
    '
    ' Bit Mapped unit codes.
    ' "1" -  bytUnitcodeMaskOdd =  01000000 = 0x40
    ' "2" -  bytUnitcodeMaskEven = 01000000 = 0x40
    ' "3" -  bytUnitcodeMaskOdd =  00000100 = 0x4
    ' "4" -  bytUnitcodeMaskEven = 00000100 = 0x4
    ' "5" -  bytUnitcodeMaskOdd =  00000010 = 0x2
    ' "6" -  bytUnitcodeMaskEven = 00000010 = 0x2
    ' "7" -  bytUnitcodeMaskOdd =  00100000 = 0x20
    ' "8" -  bytUnitcodeMaskEven = 00100000 = 0x20
    ' "9" -  bytUnitcodeMaskOdd =  10000000 = 0x80
    ' "10" - bytUnitcodeMaskEven = 10000000 = 0x80
    ' "11" - bytUnitcodeMaskOdd =  00001000 = 0x8
    ' "12" - bytUnitcodeMaskEven = 00001000 = 0x8
    ' "13" - bytUnitcodeMaskOdd =  00000001 = 0x1
    ' "14" - bytUnitcodeMaskEven = 00000001 = 0x1
    ' "15" - bytUnitcodeMaskOdd =  00010000 = 0x10
    ' "16" - bytUnitcodeMaskEven = 00010000 = 0x10
    '
    Private Sub putCheckBoxUnits(ByVal bytUnitcodeMaskOdd As Byte, ByVal bytUnitcodeMaskEven As Byte)

        ' Unit Code 1
        ' &H40 = &B01000000
        If ((bytUnitcodeMaskOdd And &H40) = &H40) Then
            formMacroCommandAddUpdateUnit01CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit01CheckBox.Checked = False
        End If

        ' Unit Code 3
        ' &H4 = &B00000100
        If ((bytUnitcodeMaskOdd And &H4) = &H4) Then
            formMacroCommandAddUpdateUnit03CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit03CheckBox.Checked = False
        End If

        ' Unit Code 5
        ' &H2 = &B00000010
        If ((bytUnitcodeMaskOdd And &H2) = &H2) Then
            formMacroCommandAddUpdateUnit05CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit05CheckBox.Checked = False
        End If

        ' Unit Code 7
        ' &H20 = &B00100000
        If ((bytUnitcodeMaskOdd And &H20) = &H20) Then
            formMacroCommandAddUpdateUnit07CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit07CheckBox.Checked = False
        End If

        ' Unit Code 9
        ' &H80 = &B10000000
        If ((bytUnitcodeMaskOdd And &H80) = &H80) Then
            formMacroCommandAddUpdateUnit09CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit09CheckBox.Checked = False
        End If

        ' Unit Code 11
        ' &H8 = &B00001000
        If ((bytUnitcodeMaskOdd And &H8) = &H8) Then
            formMacroCommandAddUpdateUnit11CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit11CheckBox.Checked = False
        End If

        ' Unit Code 13
        ' &H1 = &B00000001
        If ((bytUnitcodeMaskOdd And &H1) = &H1) Then
            formMacroCommandAddUpdateUnit13CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit13CheckBox.Checked = False
        End If

        ' Unit Code 15
        ' &H10 = &B00010000
        If ((bytUnitcodeMaskOdd And &H10) = &H10) Then
            formMacroCommandAddUpdateUnit15CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit15CheckBox.Checked = False
        End If


        ' Unit Code 2
        ' &H40 = &B01000000
        If ((bytUnitcodeMaskEven And &H40) = &H40) Then
            formMacroCommandAddUpdateUnit02CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit02CheckBox.Checked = False
        End If

        ' Unit Code 4
        ' &H4 = &B00000100
        If ((bytUnitcodeMaskEven And &H4) = &H4) Then
            formMacroCommandAddUpdateUnit04CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit04CheckBox.Checked = False
        End If

        ' Unit Code 6
        ' &H2 = &B00000010
        If ((bytUnitcodeMaskEven And &H2) = &H2) Then
            formMacroCommandAddUpdateUnit06CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit06CheckBox.Checked = False
        End If

        ' Unit Code 8
        ' &H20 = &B00100000
        If ((bytUnitcodeMaskEven And &H20) = &H20) Then
            formMacroCommandAddUpdateUnit08CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit08CheckBox.Checked = False
        End If

        ' Unit Code 10
        ' &H80 = &B10000000
        If ((bytUnitcodeMaskEven And &H80) = &H80) Then
            formMacroCommandAddUpdateUnit10CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit10CheckBox.Checked = False
        End If

        ' Unit Code 12
        ' &H8 = &B00001000
        If ((bytUnitcodeMaskEven And &H8) = &H8) Then
            formMacroCommandAddUpdateUnit12CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit12CheckBox.Checked = False
        End If

        ' Unit Code 14
        ' &H1 = &B00000001
        If ((bytUnitcodeMaskEven And &H1) = &H1) Then
            formMacroCommandAddUpdateUnit14CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit14CheckBox.Checked = False
        End If

        ' Unit Code 16
        ' &H10 = &B00010000
        If ((bytUnitcodeMaskEven And &H10) = &H10) Then
            formMacroCommandAddUpdateUnit16CheckBox.Checked = True
        Else
            formMacroCommandAddUpdateUnit16CheckBox.Checked = False
        End If

    End Sub ' END - putCheckBoxUnits()

    '=====================================================================================
    ' Function getCheckBoxUnits()
    '
    ' Bit Mapped unit codes.
    ' "1" -  bytUnitcodeMaskOdd =  01000000 = 0x40
    ' "2" -  bytUnitcodeMaskEven = 01000000 = 0x40
    ' "3" -  bytUnitcodeMaskOdd =  00000100 = 0x4
    ' "4" -  bytUnitcodeMaskEven = 00000100 = 0x4
    ' "5" -  bytUnitcodeMaskOdd =  00000010 = 0x2
    ' "6" -  bytUnitcodeMaskEven = 00000010 = 0x2
    ' "7" -  bytUnitcodeMaskOdd =  00100000 = 0x20
    ' "8" -  bytUnitcodeMaskEven = 00100000 = 0x20
    ' "9" -  bytUnitcodeMaskOdd =  10000000 = 0x80
    ' "10" - bytUnitcodeMaskEven = 10000000 = 0x80
    ' "11" - bytUnitcodeMaskOdd =  00001000 = 0x8
    ' "12" - bytUnitcodeMaskEven = 00001000 = 0x8
    ' "13" - bytUnitcodeMaskOdd =  00000001 = 0x1
    ' "14" - bytUnitcodeMaskEven = 00000001 = 0x1
    ' "15" - bytUnitcodeMaskOdd =  00010000 = 0x10
    ' "16" - bytUnitcodeMaskEven = 00010000 = 0x10
    '
    Private Sub getCheckBoxUnits(ByRef bytUnitcodeMaskOdd As Byte, ByRef bytUnitcodeMaskEven As Byte)

        bytUnitcodeMaskOdd = 0
        bytUnitcodeMaskEven = 0

        ' Unit Code 1
        ' &H40 = &B01000000
        If formMacroCommandAddUpdateUnit01CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H40
        End If

        ' Unit Code 3
        ' &H4 = &B00000100
        If formMacroCommandAddUpdateUnit03CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H4
        End If

        ' Unit Code 5
        ' &H2 = &B00000010
        If formMacroCommandAddUpdateUnit05CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H2
        End If

        ' Unit Code 7
        ' &H20 = &B00100000
        If formMacroCommandAddUpdateUnit07CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H20
        End If

        ' Unit Code 9
        ' &H80 = &B10000000
        If formMacroCommandAddUpdateUnit09CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H80
        End If

        ' Unit Code 11
        ' &H8 = &B00001000
        If formMacroCommandAddUpdateUnit11CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H8
        End If

        ' Unit Code 13
        ' &H1 = &B00000001
        If formMacroCommandAddUpdateUnit13CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H1
        End If

        ' Unit Code 15
        ' &H10 = &B00010000
        If formMacroCommandAddUpdateUnit15CheckBox.Checked Then
            bytUnitcodeMaskOdd = bytUnitcodeMaskOdd Or &H10
        End If


        ' Unit Code 2
        ' &H40 = &B01000000
        If formMacroCommandAddUpdateUnit02CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H40
        End If

        ' Unit Code 4
        ' &H4 = &B00000100
        If formMacroCommandAddUpdateUnit04CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H4
        End If

        ' Unit Code 6
        ' &H2 = &B00000010
        If formMacroCommandAddUpdateUnit06CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H2
        End If

        ' Unit Code 8
        ' &H20 = &B00100000
        If formMacroCommandAddUpdateUnit08CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H20
        End If

        ' Unit Code 10
        ' &H80 = &B10000000
        If formMacroCommandAddUpdateUnit10CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H80
        End If

        ' Unit Code 12
        ' &H8 = &B00001000
        If formMacroCommandAddUpdateUnit12CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H8
        End If

        ' Unit Code 14
        ' &H1 = &B00000001
        If formMacroCommandAddUpdateUnit14CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H1
        End If

        ' Unit Code 16
        ' &H10 = &B00010000
        If formMacroCommandAddUpdateUnit16CheckBox.Checked Then
            bytUnitcodeMaskEven = bytUnitcodeMaskEven Or &H10
        End If

    End Sub ' END - getCheckBoxUnits()

    '=====================================================================================
    ' Function generateModuleCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateModuleCodesComboBox(ByVal strModuleCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableModuleCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT ModuleCodeID, ModuleCode FROM ModuleCodes UNION SELECT 0 AS ModuleCodeID, 'Select UnitCode...' AS ModuleCode FROM ModuleCodes ORDER BY ModuleCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableModuleCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroCommandAddUpdateUnitCodeComboBox
                .DisplayMember = "ModuleCode"
                .ValueMember = "ModuleCodeID"
                .DataSource = objDataTableModuleCodes
            End With

            If (strModuleCode = "") Then
                formMacroCommandAddUpdateUnitCodeComboBox.SelectedIndex = 0
            Else
                formMacroCommandAddUpdateUnitCodeComboBox.SelectedIndex = formMacroCommandAddUpdateUnitCodeComboBox.FindString(strModuleCode)
            End If

        Catch ex As Exception
            strStatus = "generateModuleCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableModuleCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateModuleCodesComboBox()

    '=====================================================================================
    ' Function generateCommandComboBox()
    ' Alan Wagner
    '
    Private Function generateCommandComboBox(ByVal intCommand As Integer) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataTableComboBoxs As New System.Data.DataTable
        Dim objDataRowView As System.Data.DataRowView = Nothing
        Dim intIndex As Integer = 0

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            sqlString = "SELECT DISTINCT '['+TRIM(STR(ComboBoxs.ValueMember))+'] '+ComboBoxs.DisplayMember AS [DisplayMember], ComboBoxs.ValueMember AS [ValueMember], 'zzz' AS [ValueMemberSort] " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='Command' " &
                        "AND ComboBoxs.ValueMember<>99 " &
                        "UNION " &
                        "SELECT DISTINCT ComboBoxs.DisplayMember AS [DisplayMember], ComboBoxs.ValueMember AS [ValueMember], 'aaa' AS [ValueMemberSort] " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='Command' " &
                        "AND ComboBoxs.ValueMember=99 " &
                        "ORDER BY [ValueMemberSort],[ValueMember] ASC;"

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableComboBoxs)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroCommandAddUpdateCommandComboBox
                .DisplayMember = "DisplayMember"
                .ValueMember = "ValueMember"
                .DataSource = objDataTableComboBoxs
            End With

            If (intCommand = -1) Then
                formMacroCommandAddUpdateCommandComboBox.SelectedIndex = 0
            Else

                For Each objDataRowView In formMacroCommandAddUpdateCommandComboBox.Items

                    If (intCommand = objDataRowView.Row("ValueMember")) Then
                        formMacroCommandAddUpdateCommandComboBox.SelectedIndex = intIndex
                        Exit For
                    End If

                    intIndex = intIndex + 1
                Next

            End If

        Catch ex As Exception
            strStatus = "generateCommandComboBox(): Exception: " & ex.Message
        Finally
            objDataRowView = Nothing
            objDataTableComboBoxs = Nothing
        End Try

        Return strStatus

    End Function ' END - generateCommandComboBox()

    Private Sub formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles formMacroCommandAddUpdateCommandComboBox.SelectionChangeCommitted
        'formMacroCommandAddUpdateCommandComboBox.SelectedIndexChanged

        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim strStatus As String = ""
        Dim strTryStep As String = ""
        Dim bAllOK As Boolean = True

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim intMacroCommandID As Integer = -1
        Dim objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand = Nothing

        Dim objDataRowView As System.Data.DataRowView = Nothing
        Dim strCommandDescription As String = ""
        Dim bytCommandCode As Byte = 99

        Try

            strTryStep = "SelectedItem"
            objDataRowView = formMacroCommandAddUpdateCommandComboBox.SelectedItem
            strCommandDescription = objDataRowView(0).ToString ' ex: "All Units Off"
            bytCommandCode = CType(objDataRowView(1).ToString, Byte)

            strTryStep = "AddOrUpdate_getX10DbMacroCommand"
            If (Not formMacroCommandAddUpdateIDLabelText.Text() = "" And Not formMacroCommandAddUpdateIDLabelText.Text() = "-1") Then

                strTryStep = "ConnectionStrings"
                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                strTryStep = "MacroCommandID"
                intMacroCommandID = CType(formMacroCommandAddUpdateIDLabelText.Text(), Integer)

                strTryStep = "nsX10DbMethods.getX10DbMacroCommand"
                ' nsX10DbMethods.getX10DbMacroCommand(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intMacroCommandID As Integer, ByRef objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand) As String
                strStatus = nsX10DbMethods.getX10DbMacroCommand(strConnectionString, strProvider, intMacroCommandID, objX10DbMacroCommand)
                If (strStatus <> "") Then
                    bAllOK = False
                    Windows.Forms.MessageBox.Show("formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged(): " & strStatus, "formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                    formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                    formMacroCommandAddUpdate_DeleteButton.Visible = False
                End If ' END - nsX10DbMethods.getX10DbMacroCommand()

            End If

            strTryStep = "bAllOK"
            If bAllOK Then

                strTryStep = "processCommandCode()"
                ' processCommandCode(ByVal bytCommandCode As Byte, ByRef objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand) As String
                strStatus = processCommandCode(bytCommandCode, objX10DbMacroCommand)
                If (strStatus <> "") Then
                    Windows.Forms.MessageBox.Show("formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged(): " & strStatus, "formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                    formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                    formMacroCommandAddUpdate_DeleteButton.Visible = False
                End If ' END - processCommandCode()

            End If ' END - bAllOK

        Catch ex As Exception
            strStatus = "formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
            formMacroCommandAddUpdate_DeleteButton.Visible = False
        Finally
            objX10DbMacroCommand = Nothing
            objDataRowView = Nothing
        End Try

    End Sub ' END - formMacroCommandAddUpdateCommandComboBox_SelectedIndexChanged()

    '=====================================================================================
    ' Function processCommandCode()
    ' Alan Wagner
    '
    ' Constants defined in X10IncludeCM.cs
    ' CM15A_ALLUNITSOFF = 0x0;
    ' CM15A_ALLLIGHTSON = 0x1;
    ' CM15A_ON = 0x2;
    ' CM15A_OFF = 0x3;
    ' CM15A_DIM = 0x4;
    ' CM15A_BRIGHT = 0x5;
    ' CM15A_ALLLIGHTSOFF = 0x6;
    ' CM15A_EXTENDEDCODE = 0x7;
    ' CM15A_HAILREQUEST = 0x8;
    ' CM15A_HAILACKNOWLEDGE = 0x9;
    ' CM15A_PRESETDIM1 = 0xa;
    ' CM15A_PRESETDIM2 = 0xb;
    ' CM15A_EXTENDEDDATATRANSFER = 0xc;
    ' CM15A_STATUSON = 0xd;
    ' CM15A_STATUSOFF = 0xe;
    ' CM15A_STATUSREQUEST = 0xf;
    ' CM15A_NOOP = 0xff;
    '
    Private Function processCommandCode(ByVal bytCommandCode As Byte, ByRef objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand) As String
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Try

            strTryStep = "SelectCommandCode"
            Select Case bytCommandCode
                Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ALLUNITSOFF,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ALLLIGHTSON,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ON,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_OFF,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ALLLIGHTSOFF
                    ' X10 Standard Command

                    strTryStep = "AddOrUpdate"
                    If (formMacroCommandAddUpdateIDLabelText.Text() = "" Or formMacroCommandAddUpdateIDLabelText.Text() = "-1") Then
                        strTryStep = "AddMacroCommand"

                        strTryStep = "Add_SelectCommandCode_OnOffDimBright"
                        formMacroCommandAddUpdateUnit01CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit02CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit03CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit04CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit05CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit06CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit07CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit08CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit09CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit10CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit11CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit12CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit13CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit14CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit15CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit16CheckBox.Checked = False
                        Select Case bytCommandCode
                            Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ON,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_OFF,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT

                                formMacroCommandAddUpdateUnitsPanel.Visible = True
                                formMacroCommandAddUpdateUnitsLabel.Visible = True
                                formMacroCommandAddUpdateUnit01CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit02CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit03CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit04CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit05CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit06CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit07CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit08CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit09CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit10CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit11CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit12CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit13CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit14CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit15CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit16CheckBox.Visible = True

                            Case Else

                                formMacroCommandAddUpdateUnitsPanel.Visible = False
                                formMacroCommandAddUpdateUnitsLabel.Visible = False
                                formMacroCommandAddUpdateUnit01CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit02CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit03CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit04CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit05CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit06CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit07CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit08CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit09CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit10CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit11CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit12CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit13CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit14CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit15CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit16CheckBox.Visible = False

                        End Select ' END - Add_SelectCommandCode_OnOffDimBright


                        strTryStep = "Add_SelectCommandCode_DimBright"
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                        Select Case bytCommandCode
                            Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT

                                strTryStep = "Add_PreDimBright"
                                Select Case bytCommandCode
                                    Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM
                                        formMacroCommandAddUpdatePreDimBrightLabel.Text() = "   pre-Dim:"
                                        formMacroCommandAddUpdateDimBrightLabel.Text() = "   Dims:"
                                    Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT
                                        formMacroCommandAddUpdatePreDimBrightLabel.Text() = "pre-Bright:"
                                        formMacroCommandAddUpdateDimBrightLabel.Text() = "Brights:"
                                End Select

                                formMacroCommandAddUpdatePreDimBrightLabel.Visible = True
                                formMacroCommandAddUpdatePreDimBrightPanel.Visible = True

                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Visible = True
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = False
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Visible = True
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = True

                                strTryStep = "Add_DimsBrights"
                                formMacroCommandAddUpdateDimBrightLabel.Visible = True
                                formMacroCommandAddUpdateDimsBrightsTextBox.Visible = True
                                formMacroCommandAddUpdateDimsBrightsTextBox.Text() = ""
                                formMacroCommandAddUpdateDimsBrightsFormatLabel.Visible = True

                            Case Else
                                strTryStep = "Add_SelectCommandCode_DimBright_Else"

                                formMacroCommandAddUpdatePreDimBrightLabel.Visible = False
                                formMacroCommandAddUpdatePreDimBrightPanel.Visible = False
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Visible = False
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = False
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Visible = False
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = False

                                formMacroCommandAddUpdateDimBrightLabel.Visible = False
                                formMacroCommandAddUpdateDimsBrightsTextBox.Visible = False
                                formMacroCommandAddUpdateDimsBrightsTextBox.Text() = ""
                                formMacroCommandAddUpdateDimsBrightsFormatLabel.Visible = False

                        End Select ' END - Add_SelectCommandCode_DimBright


                        formMacroCommandAddUpdateUnitCodeLabel.Visible = False
                        formMacroCommandAddUpdateUnitCodeComboBox.Visible = False

                        formMacroCommandAddUpdateExtendedCommandLabel.Visible = False
                        formMacroCommandAddUpdateExtendedCommandComboBox.Visible = False

                        formMacroCommandAddUpdateExtendedDataByteLabel.Visible = False
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Text() = ""
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Visible = False
                        formMacroCommandAddUpdateExtendedDataByteFormatLabel.Visible = False

                    Else
                        strTryStep = "UpdateMacroCommand"

                        strTryStep = "Update_SelectCommandCode_OnOffDimBright"
                        Select Case bytCommandCode
                            Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ON,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_OFF,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT

                                formMacroCommandAddUpdateUnitsPanel.Visible = True
                                formMacroCommandAddUpdateUnitsLabel.Visible = True
                                formMacroCommandAddUpdateUnit01CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit02CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit03CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit04CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit05CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit06CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit07CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit08CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit09CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit10CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit11CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit12CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit13CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit14CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit15CheckBox.Visible = True
                                formMacroCommandAddUpdateUnit16CheckBox.Visible = True

                                strTryStep = "Update_putCheckBoxUnits"
                                ' putCheckBoxUnits(ByVal bytUnitcodeMaskOdd As Byte, ByVal bytUnitcodeMaskEven As Byte)
                                Call putCheckBoxUnits(objX10DbMacroCommand.unitcodeMaskOdd, objX10DbMacroCommand.unitcodeMaskEven)

                            Case Else

                                formMacroCommandAddUpdateUnitsPanel.Visible = False
                                formMacroCommandAddUpdateUnitsLabel.Visible = False
                                formMacroCommandAddUpdateUnit01CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit02CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit03CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit04CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit05CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit06CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit07CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit08CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit09CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit10CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit11CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit12CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit13CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit14CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit15CheckBox.Visible = False
                                formMacroCommandAddUpdateUnit16CheckBox.Visible = False

                                formMacroCommandAddUpdateUnit01CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit02CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit03CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit04CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit05CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit06CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit07CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit08CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit09CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit10CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit11CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit12CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit13CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit14CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit15CheckBox.Checked = False
                                formMacroCommandAddUpdateUnit16CheckBox.Checked = False

                        End Select ' END - Update_SelectCommandCode_OnOffDimBright


                        strTryStep = "Update_SelectCommandCode_DimBright"
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                        Select Case bytCommandCode
                            Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM,
                                    TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT

                                strTryStep = "Update_PreDimBright"
                                Select Case bytCommandCode
                                    Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM
                                        formMacroCommandAddUpdatePreDimBrightLabel.Text() = "   pre-Dim:"
                                        formMacroCommandAddUpdateDimBrightLabel.Text() = "   Dims:"
                                    Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT
                                        formMacroCommandAddUpdatePreDimBrightLabel.Text() = "pre-Bright:"
                                        formMacroCommandAddUpdateDimBrightLabel.Text() = "Brights:"
                                End Select

                                formMacroCommandAddUpdatePreDimBrightLabel.Visible = True
                                formMacroCommandAddUpdatePreDimBrightPanel.Visible = True

                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Visible = True
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Visible = True
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                                Select Case objX10DbMacroCommand.prebrighten
                                    Case 0
                                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = True
                                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = False
                                    Case 1
                                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = False
                                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = True
                                End Select

                                strTryStep = "Update_DimsBrights"
                                formMacroCommandAddUpdateDimBrightLabel.Visible = True
                                formMacroCommandAddUpdateDimsBrightsTextBox.Visible = True
                                formMacroCommandAddUpdateDimsBrightsTextBox.Text() = objX10DbMacroCommand.dimValue.ToString()
                                formMacroCommandAddUpdateDimsBrightsFormatLabel.Visible = True

                            Case Else
                                strTryStep = "Update_SelectCommandCode_DimBright_Else"

                                formMacroCommandAddUpdatePreDimBrightLabel.Visible = False
                                formMacroCommandAddUpdatePreDimBrightPanel.Visible = False
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Visible = False
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                                formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = False
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Visible = False
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                                formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = False

                                formMacroCommandAddUpdateDimBrightLabel.Visible = False
                                formMacroCommandAddUpdateDimsBrightsTextBox.Visible = False
                                formMacroCommandAddUpdateDimsBrightsTextBox.Text() = ""
                                formMacroCommandAddUpdateDimsBrightsFormatLabel.Visible = False

                        End Select ' END - Add_SelectCommandCode_DimBright


                        formMacroCommandAddUpdateUnitCodeLabel.Visible = False
                        formMacroCommandAddUpdateUnitCodeComboBox.Visible = False

                        formMacroCommandAddUpdateExtendedCommandLabel.Visible = False
                        formMacroCommandAddUpdateExtendedCommandComboBox.Visible = False

                        formMacroCommandAddUpdateExtendedDataByteLabel.Visible = False
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Text() = ""
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Visible = False
                        formMacroCommandAddUpdateExtendedDataByteFormatLabel.Visible = False

                    End If ' END - AddOrUpdate

                Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_EXTENDEDCODE,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_HAILREQUEST,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_HAILACKNOWLEDGE,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_PRESETDIM1,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_PRESETDIM2,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_EXTENDEDDATATRANSFER,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_STATUSON,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_STATUSOFF,
                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_STATUSREQUEST
                    ' X10 Extended Command

                    strTryStep = "AddOrUpdate_Extended"
                    If (formMacroCommandAddUpdateIDLabelText.Text() = "" Or formMacroCommandAddUpdateIDLabelText.Text() = "-1") Then
                        strTryStep = "AddMacroCommand_Extended"

                        formMacroCommandAddUpdateUnitsPanel.Visible = False
                        formMacroCommandAddUpdateUnitsLabel.Visible = False
                        formMacroCommandAddUpdateUnit01CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit02CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit03CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit04CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit05CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit06CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit07CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit08CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit09CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit10CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit11CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit12CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit13CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit14CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit15CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit16CheckBox.Visible = False

                        formMacroCommandAddUpdateUnit01CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit02CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit03CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit04CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit05CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit06CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit07CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit08CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit09CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit10CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit11CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit12CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit13CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit14CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit15CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit16CheckBox.Checked = False


                        strTryStep = "Add_PreDimBright_Extended"
                        formMacroCommandAddUpdatePreDimBrightLabel.Visible = False
                        formMacroCommandAddUpdatePreDimBrightPanel.Visible = False
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Visible = False
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = False
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Visible = False
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = False

                        formMacroCommandAddUpdateDimBrightLabel.Visible = False
                        formMacroCommandAddUpdateDimsBrightsTextBox.Visible = False
                        formMacroCommandAddUpdateDimsBrightsTextBox.Text() = ""
                        formMacroCommandAddUpdateDimsBrightsFormatLabel.Visible = False


                        formMacroCommandAddUpdateUnitCodeLabel.Visible = True

                        strTryStep = "Add_generateModuleCodesComboBox_Extended"
                        ' generateModuleCodesComboBox(ByVal strModuleCode As String) As String
                        strStatus = generateModuleCodesComboBox("")
                        If (strStatus = "") Then
                            formMacroCommandAddUpdateUnitCodeComboBox.Visible = True
                        Else
                            formMacroCommandAddUpdateUnitCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "processCommandCode(Add_Extended)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_CancelButton.Select()
                            formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        formMacroCommandAddUpdateExtendedCommandLabel.Visible = True

                        strTryStep = "Add_generateExtendedCommandComboBox_Extended"
                        ' generateExtendedCommandComboBox(ByVal intExtendedCommand As Integer) As String
                        strStatus = generateExtendedCommandComboBox(-1)
                        If (strStatus = "") Then
                            formMacroCommandAddUpdateExtendedCommandComboBox.Visible = True
                        Else
                            formMacroCommandAddUpdateExtendedCommandComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "processCommandCode(Add_Extended)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_CancelButton.Select()
                            formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        strTryStep = "Add_ExtendedDataByte_Extended"
                        ' Decimal number ranged from 0 to 255
                        formMacroCommandAddUpdateExtendedDataByteLabel.Visible = True
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Text() = "0"
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Visible = True
                        formMacroCommandAddUpdateExtendedDataByteFormatLabel.Visible = True


                    Else
                        strTryStep = "UpdateMacroCommand_Extended"

                        formMacroCommandAddUpdateUnitsPanel.Visible = False
                        formMacroCommandAddUpdateUnitsLabel.Visible = False
                        formMacroCommandAddUpdateUnit01CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit02CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit03CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit04CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit05CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit06CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit07CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit08CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit09CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit10CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit11CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit12CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit13CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit14CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit15CheckBox.Visible = False
                        formMacroCommandAddUpdateUnit16CheckBox.Visible = False

                        formMacroCommandAddUpdateUnit01CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit02CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit03CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit04CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit05CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit06CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit07CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit08CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit09CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit10CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit11CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit12CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit13CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit14CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit15CheckBox.Checked = False
                        formMacroCommandAddUpdateUnit16CheckBox.Checked = False


                        strTryStep = "Update_PreDimBright_Extended"
                        formMacroCommandAddUpdatePreDimBrightLabel.Visible = False
                        formMacroCommandAddUpdatePreDimBrightPanel.Visible = False
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Visible = False
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
                        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = False
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Visible = False
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
                        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = False

                        formMacroCommandAddUpdateDimBrightLabel.Visible = False
                        formMacroCommandAddUpdateDimsBrightsTextBox.Visible = False
                        formMacroCommandAddUpdateDimsBrightsTextBox.Text() = ""
                        formMacroCommandAddUpdateDimsBrightsFormatLabel.Visible = False


                        formMacroCommandAddUpdateUnitCodeLabel.Visible = True

                        strTryStep = "Update_generateModuleCodesComboBox_Extended"
                        ' generateModuleCodesComboBox(ByVal strModuleCode As String) As String
                        strStatus = generateModuleCodesComboBox(nsX10CM15AMethods.x10BinaryValueToDeviceCode(objX10DbMacroCommand.unitcode))
                        If (strStatus = "") Then
                            formMacroCommandAddUpdateUnitCodeComboBox.Visible = True
                        Else
                            formMacroCommandAddUpdateUnitCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "processCommandCode(Update_Extended)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_CancelButton.Select()
                            formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                            formMacroCommandAddUpdate_DeleteButton.Visible = False
                        End If


                        formMacroCommandAddUpdateExtendedCommandLabel.Visible = True

                        strTryStep = "Update_generateExtendedCommandComboBox_Extended"
                        ' generateExtendedCommandComboBox(ByVal intExtendedCommand As Integer) As String
                        strStatus = generateExtendedCommandComboBox(CType(objX10DbMacroCommand.extendedCommand, Integer))
                        If (strStatus = "") Then
                            formMacroCommandAddUpdateExtendedCommandComboBox.Visible = True
                        Else
                            formMacroCommandAddUpdateExtendedCommandComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "processCommandCode(Update_Extended)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroCommandAddUpdate_CancelButton.Select()
                            formMacroCommandAddUpdate_AddUpdateButton.Visible = False
                            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                            formMacroCommandAddUpdate_DeleteButton.Visible = False
                        End If


                        strTryStep = "Update_ExtendedDataByte_Extended"
                        ' Decimal number ranged from 0 to 255
                        formMacroCommandAddUpdateExtendedDataByteLabel.Visible = True
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Text() = objX10DbMacroCommand.extendedData.ToString()
                        formMacroCommandAddUpdateExtendedDataByteTextBox.Visible = True
                        formMacroCommandAddUpdateExtendedDataByteFormatLabel.Visible = True


                    End If ' END - AddOrUpdate_Extended

                Case Else

                    strTryStep = "setDefaults"
                    Call setDefaults()

            End Select ' END - SelectCommandCode

        Catch ex As Exception
            strStatus = "processCommandCode(" & strTryStep & "): Exception: " & ex.Message
        Finally
            objX10DbMacroCommand = Nothing
        End Try

        Return strStatus

    End Function ' END - processCommandCode()

    '=====================================================================================
    ' Function setDefaults()
    '
    Private Sub setDefaults()

        formMacroCommandAddUpdateUnitsPanel.Visible = False
        formMacroCommandAddUpdateUnitsLabel.Visible = False
        formMacroCommandAddUpdateUnit01CheckBox.Visible = False
        formMacroCommandAddUpdateUnit01CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit02CheckBox.Visible = False
        formMacroCommandAddUpdateUnit02CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit03CheckBox.Visible = False
        formMacroCommandAddUpdateUnit03CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit04CheckBox.Visible = False
        formMacroCommandAddUpdateUnit04CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit05CheckBox.Visible = False
        formMacroCommandAddUpdateUnit05CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit06CheckBox.Visible = False
        formMacroCommandAddUpdateUnit06CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit07CheckBox.Visible = False
        formMacroCommandAddUpdateUnit07CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit08CheckBox.Visible = False
        formMacroCommandAddUpdateUnit08CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit09CheckBox.Visible = False
        formMacroCommandAddUpdateUnit09CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit10CheckBox.Visible = False
        formMacroCommandAddUpdateUnit10CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit11CheckBox.Visible = False
        formMacroCommandAddUpdateUnit11CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit12CheckBox.Visible = False
        formMacroCommandAddUpdateUnit12CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit13CheckBox.Visible = False
        formMacroCommandAddUpdateUnit13CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit14CheckBox.Visible = False
        formMacroCommandAddUpdateUnit14CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit15CheckBox.Visible = False
        formMacroCommandAddUpdateUnit15CheckBox.Enabled = True
        formMacroCommandAddUpdateUnit16CheckBox.Visible = False
        formMacroCommandAddUpdateUnit16CheckBox.Enabled = True

        formMacroCommandAddUpdateUnit01CheckBox.Checked = False
        formMacroCommandAddUpdateUnit02CheckBox.Checked = False
        formMacroCommandAddUpdateUnit03CheckBox.Checked = False
        formMacroCommandAddUpdateUnit04CheckBox.Checked = False
        formMacroCommandAddUpdateUnit05CheckBox.Checked = False
        formMacroCommandAddUpdateUnit06CheckBox.Checked = False
        formMacroCommandAddUpdateUnit07CheckBox.Checked = False
        formMacroCommandAddUpdateUnit08CheckBox.Checked = False
        formMacroCommandAddUpdateUnit09CheckBox.Checked = False
        formMacroCommandAddUpdateUnit10CheckBox.Checked = False
        formMacroCommandAddUpdateUnit11CheckBox.Checked = False
        formMacroCommandAddUpdateUnit12CheckBox.Checked = False
        formMacroCommandAddUpdateUnit13CheckBox.Checked = False
        formMacroCommandAddUpdateUnit14CheckBox.Checked = False
        formMacroCommandAddUpdateUnit15CheckBox.Checked = False
        formMacroCommandAddUpdateUnit16CheckBox.Checked = False

        formMacroCommandAddUpdatePreDimBrightLabel.Visible = False
        formMacroCommandAddUpdatePreDimBrightPanel.Visible = False
        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Visible = False
        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Enabled = True
        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Visible = False
        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Enabled = True
        formMacroCommandAddUpdatePreDimBrightNoRadioButton.Checked = False
        formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked = False

        formMacroCommandAddUpdateDimBrightLabel.Visible = False
        formMacroCommandAddUpdateDimsBrightsTextBox.Visible = False
        formMacroCommandAddUpdateDimsBrightsTextBox.Text() = ""
        formMacroCommandAddUpdateDimsBrightsFormatLabel.Visible = False

        formMacroCommandAddUpdateUnitCodeLabel.Visible = False
        formMacroCommandAddUpdateUnitCodeComboBox.Visible = False

        formMacroCommandAddUpdateExtendedCommandLabel.Visible = False
        formMacroCommandAddUpdateExtendedCommandComboBox.Visible = False

        formMacroCommandAddUpdateExtendedDataByteLabel.Visible = False
        formMacroCommandAddUpdateExtendedDataByteTextBox.Text() = ""
        formMacroCommandAddUpdateExtendedDataByteTextBox.Visible = False
        formMacroCommandAddUpdateExtendedDataByteFormatLabel.Visible = False

    End Sub ' END - setDefaults()

    '=====================================================================================
    ' Function generateExtendedCommandComboBox()
    ' Alan Wagner
    '
    Private Function generateExtendedCommandComboBox(ByVal intExtendedCommand As Integer) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataTableComboBoxs As New System.Data.DataTable
        Dim objDataRowView As System.Data.DataRowView = Nothing
        Dim intIndex As Integer = 0

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            sqlString = "SELECT DISTINCT '['+TRIM(STR(ComboBoxs.ValueMember))+'] '+ComboBoxs.DisplayMember AS [DisplayMember], ComboBoxs.ValueMember AS [ValueMember] " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='ExtendedCommand' " &
                        "AND ComboBoxs.ValueMember<>0 " &
                        "UNION " &
                        "SELECT DISTINCT ComboBoxs.DisplayMember AS [DisplayMember], ComboBoxs.ValueMember AS [ValueMember] " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='ExtendedCommand' " &
                        "AND ComboBoxs.ValueMember=0 " &
                        "ORDER BY [ValueMember] ASC;"

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableComboBoxs)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroCommandAddUpdateExtendedCommandComboBox
                .DisplayMember = "DisplayMember"
                .ValueMember = "ValueMember"
                .DataSource = objDataTableComboBoxs
            End With

            If (intExtendedCommand = -1) Then
                formMacroCommandAddUpdateExtendedCommandComboBox.SelectedIndex = 0
            Else

                For Each objDataRowView In formMacroCommandAddUpdateExtendedCommandComboBox.Items

                    If (intExtendedCommand = objDataRowView.Row("ValueMember")) Then
                        formMacroCommandAddUpdateExtendedCommandComboBox.SelectedIndex = intIndex
                        Exit For
                    End If

                    intIndex = intIndex + 1
                Next

            End If

        Catch ex As Exception
            strStatus = "generateExtendedCommandComboBox(): Exception: " & ex.Message
        Finally
            objDataRowView = Nothing
            objDataTableComboBoxs = Nothing
        End Try

        Return strStatus

    End Function ' END - generateExtendedCommandComboBox()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    '=====================================================================================
    ' Function formMacroCommandAddUpdate_AddUpdateButton_Click()
    ' Alan Wagner
    '
    ' Constants defined in X10IncludeCM.cs
    ' CM15A_ALLUNITSOFF = 0x0;
    ' CM15A_ALLLIGHTSON = 0x1;
    ' CM15A_ON = 0x2;
    ' CM15A_OFF = 0x3;
    ' CM15A_DIM = 0x4;
    ' CM15A_BRIGHT = 0x5;
    ' CM15A_ALLLIGHTSOFF = 0x6;
    ' CM15A_EXTENDEDCODE = 0x7;
    ' CM15A_HAILREQUEST = 0x8;
    ' CM15A_HAILACKNOWLEDGE = 0x9;
    ' CM15A_PRESETDIM1 = 0xa;
    ' CM15A_PRESETDIM2 = 0xb;
    ' CM15A_EXTENDEDDATATRANSFER = 0xc;
    ' CM15A_STATUSON = 0xd;
    ' CM15A_STATUSOFF = 0xe;
    ' CM15A_STATUSREQUEST = 0xf;
    ' CM15A_NOOP = 0xff;
    '
    Private Sub formMacroCommandAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroCommandAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objDataRowViewSort As System.Data.DataRowView = Nothing
        Dim objDataRowViewCommand As System.Data.DataRowView = Nothing
        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing
        Dim objDataRowViewUnitCode As System.Data.DataRowView = Nothing
        Dim objDataRowViewExtendedCommand As System.Data.DataRowView = Nothing

        Dim strDimsBrightsText As String = ""

        Dim objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand = Nothing

        Dim intMacroInitiatorID As Integer = -1
        Dim strMacroInitiatorName As String = ""
        Dim strDeviceCodeStringOdd As String = ""
        Dim arrDeviceCodeStringOdd() As String = Nothing
        Dim strDeviceCodeStringEven As String = ""
        Dim arrDeviceCodeStringEven() As String = Nothing
        Dim intPointer As Integer = 0
        Dim strTriggerHouseCode As String = ""
        Dim strTriggerModuleCode As String = ""
        Dim objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormMacroAddUpdate As formMacroAddUpdate = Nothing
        Dim objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate = Nothing

        Try

            formMacroCommandAddUpdate_StatusLabel.Text = ""
            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString

            strTryStep = "ProviderName"
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "MacroInitatorID"
            intMacroInitiatorID = CType(formMacroCommandAddUpdateMacroInitatorIDLabelText.Text(), Integer)

            strTryStep = "MacroInitiatorName"
            strMacroInitiatorName = formMacroCommandAddUpdateMacroInInitatorNameLabelText.Text()

            strTryStep = "NewObjectX10DbMacroCommand"
            objX10DbMacroCommand = New TrekkerPhotoArt.X10Include.X10DbMacroCommand

            strTryStep = "command"
            objDataRowViewCommand = formMacroCommandAddUpdateCommandComboBox.SelectedItem
            objX10DbMacroCommand.command = CType(objDataRowViewCommand(1), Byte)

            strTryStep = "IsHouseCodeSelected?"
            objDataRowViewHouseCode = formMacroCommandAddUpdateHouseCodeComboBox.SelectedItem
            If (objDataRowViewHouseCode.Row("HouseCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing House Code selection."
                Else
                    strStatus &= vbCrLf & "Missing House Code selection."
                End If
            Else
                strTryStep = "house"
                objX10DbMacroCommand.house = nsX10CM15AMethods.x10HouseCodeToBinaryValue(objDataRowViewHouseCode(1).ToString()) ' DisplayMember ex: "A"
                strTriggerHouseCode = objDataRowViewHouseCode(1).ToString()
            End If ' END -IsHouseCodeSelected?

            strTryStep = "SelectCommandCode"
            Select Case objX10DbMacroCommand.command
                Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ALLUNITSOFF,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ALLLIGHTSON,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ON,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_OFF,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_ALLLIGHTSOFF
                    ' X10 Standard Command

                    strTryStep = "getCheckBoxUnits_StandardCommand"
                    ' getCheckBoxUnits(ByRef bytUnitcodeMaskOdd As Byte, ByRef bytUnitcodeMaskEven As Byte)
                    Call getCheckBoxUnits(objX10DbMacroCommand.unitcodeMaskOdd, objX10DbMacroCommand.unitcodeMaskEven)
                    If (objX10DbMacroCommand.unitcodeMaskOdd = 0 And objX10DbMacroCommand.unitcodeMaskEven = 0) Then
                        If (strStatus = "") Then
                            strStatus = "One or more Units must be selected."
                        Else
                            strStatus &= vbCrLf & "One or more Units must be selected."
                        End If
                    Else

                        If (objX10DbMacroCommand.unitcodeMaskOdd > 0) Then

                            strTryStep = "nsX10CM15AMethods.x10DeviceCodeMapToStringOdd"
                            strDeviceCodeStringOdd = nsX10CM15AMethods.x10DeviceCodeMapToStringOdd(objX10DbMacroCommand.unitcodeMaskOdd)
                            arrDeviceCodeStringOdd = strDeviceCodeStringOdd.Split(" ")
                            If (arrDeviceCodeStringOdd.Count > 0) Then
                                For intPointer = 0 To arrDeviceCodeStringOdd.Count - 1 Step 1

                                    strTryStep = "nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand_odd"
                                    ' verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(string strX10DbConnectionString, string strX10DbProvider, int intMacroInitiatorID, string strMacroInitiatorName, bool bVerifyMacroInitiatorTriggerOnly, string strTriggerHouseCode, string strTriggerModuleCode)
                                    objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(strConnectionString, strProvider, intMacroInitiatorID, strMacroInitiatorName, True, strTriggerHouseCode, arrDeviceCodeStringOdd(intPointer))
                                    If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status.Length = 0) Then

                                        If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.triggerUsed) Then

                                            If (strStatus = "") Then
                                                strStatus = "Macro Command Module """ & strTriggerHouseCode & arrDeviceCodeStringOdd(intPointer) & """ is also the" & vbCrLf & "Macro Initiator Trigger."
                                            Else
                                                strStatus &= vbCrLf & "Macro Command Module """ & strTriggerHouseCode & arrDeviceCodeStringOdd(intPointer) & """ is also the" & vbCrLf & "Macro Initiator Trigger."
                                            End If
                                            strStatus &= vbCrLf & vbCrLf & "This Macro Command Module cannot also be used within this Macro Initiator" & vbCrLf & """" & strMacroInitiatorName & """ [" & intMacroInitiatorID.ToString() & "]"

                                            Exit For
                                        End If

                                    Else
                                        If (strStatus = "") Then
                                            strStatus = "Problem verifying Macro Initiator Trigger (odd): " & objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status
                                        Else
                                            strStatus &= vbCrLf & "Problem verifying Macro Initiator Trigger (odd): " & objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status
                                        End If
                                        Exit For
                                    End If ' END - nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(odd)

                                Next
                            End If

                        End If

                        If (objX10DbMacroCommand.unitcodeMaskEven > 0) Then

                            strTryStep = "nsX10CM15AMethods.x10DeviceCodeMapToStringEven"
                            strDeviceCodeStringEven = nsX10CM15AMethods.x10DeviceCodeMapToStringEven(objX10DbMacroCommand.unitcodeMaskEven)
                            arrDeviceCodeStringEven = strDeviceCodeStringEven.Split(" ")
                            If (arrDeviceCodeStringEven.Count > 0) Then
                                For intPointer = 0 To arrDeviceCodeStringEven.Count - 1 Step 1

                                    strTryStep = "nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand_even"
                                    ' verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(string strX10DbConnectionString, string strX10DbProvider, int intMacroInitiatorID, string strMacroInitiatorName, bool bVerifyMacroInitiatorTriggerOnly, string strTriggerHouseCode, string strTriggerModuleCode)
                                    objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(strConnectionString, strProvider, intMacroInitiatorID, strMacroInitiatorName, True, strTriggerHouseCode, arrDeviceCodeStringEven(intPointer))
                                    If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status.Length = 0) Then

                                        If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.triggerUsed) Then

                                            If (strStatus = "") Then
                                                strStatus = "Macro Command Module """ & strTriggerHouseCode & arrDeviceCodeStringEven(intPointer) & """ is also the" & vbCrLf & "Macro Initiator Trigger."
                                            Else
                                                strStatus &= vbCrLf & "Macro Command Module """ & strTriggerHouseCode & arrDeviceCodeStringEven(intPointer) & """ is also the" & vbCrLf & "Macro Initiator Trigger."
                                            End If
                                            strStatus &= vbCrLf & vbCrLf & "This Macro Command Module cannot also be used within this Macro Initiator" & vbCrLf & """" & strMacroInitiatorName & """ [" & intMacroInitiatorID.ToString() & "]"

                                            Exit For
                                        End If

                                    Else
                                        If (strStatus = "") Then
                                            strStatus = "Problem verifying Macro Initiator Trigger (even): " & objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status
                                        Else
                                            strStatus &= vbCrLf & "Problem verifying Macro Initiator Trigger (even): " & objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status
                                        End If
                                        Exit For
                                    End If ' END - nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(even)

                                Next
                            End If

                        End If

                    End If ' END - getCheckBoxUnits(StandardCommand)

                    strTryStep = "SelectDimBright_StandardCommand"
                    Select Case objX10DbMacroCommand.command
                        Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM,
                                        TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT

                            strTryStep = "prebrighten_StandardCommand"
                            If (formMacroCommandAddUpdatePreDimBrightYesRadioButton.Checked) Then
                                objX10DbMacroCommand.prebrighten = 1
                            Else
                                objX10DbMacroCommand.prebrighten = 0
                            End If


                            strTryStep = "dimValue_StandardCommand"
                            Select Case objX10DbMacroCommand.command
                                Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_DIM
                                    strDimsBrightsText = "Dims"
                                Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_BRIGHT
                                    strDimsBrightsText = "Brights"
                            End Select
                            Try

                                objX10DbMacroCommand.dimValue = CType(formMacroCommandAddUpdateDimsBrightsTextBox.Text(), Byte)

                                If (objX10DbMacroCommand.dimValue > 210) Then
                                    If (strStatus = "") Then
                                        strStatus = "RANGE: " & strDimsBrightsText & " must be a Decimal number ranged from 0 to 210."
                                    Else
                                        strStatus &= vbCrLf & "RANGE: " & strDimsBrightsText & " must be a Decimal number ranged from 0 to 210."
                                    End If
                                End If

                            Catch ex As Exception
                                If (strStatus = "") Then
                                    strStatus = "INVALID: " & strDimsBrightsText & " must be a Decimal number ranged from 0 to 210."
                                Else
                                    strStatus &= vbCrLf & "INVALID: " & strDimsBrightsText & " must be a Decimal number ranged from 0 to 210."
                                End If
                            End Try ' END - extendedData_ExtendedCommand


                        Case Else
                            objX10DbMacroCommand.prebrighten = 0
                            objX10DbMacroCommand.dimValue = 0
                    End Select ' END - SelectDimBright_StandardCommand

                    strTryStep = "unitcode_StandardCommand"
                    objX10DbMacroCommand.unitcode = 0

                    strTryStep = "extendedCommand_StandardCommand"
                    objX10DbMacroCommand.extendedCommand = 0

                    strTryStep = "extendedData_StandardCommand"
                    objX10DbMacroCommand.extendedData = 0

                Case TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_EXTENDEDCODE,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_HAILREQUEST,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_HAILACKNOWLEDGE,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_PRESETDIM1,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_PRESETDIM2,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_EXTENDEDDATATRANSFER,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_STATUSON,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_STATUSOFF,
                            TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_STATUSREQUEST
                    ' X10 Extended Command

                    strTryStep = "unitcodeMask_ExtendedCommand"
                    objX10DbMacroCommand.unitcodeMaskEven = 0
                    objX10DbMacroCommand.unitcodeMaskOdd = 0

                    strTryStep = "prebrighten_ExtendedCommand"
                    objX10DbMacroCommand.prebrighten = 0

                    strTryStep = "dimValue_ExtendedCommand"
                    objX10DbMacroCommand.dimValue = 0

                    strTryStep = "IsUnitCodeSelected?"
                    objDataRowViewUnitCode = formMacroCommandAddUpdateUnitCodeComboBox.SelectedItem
                    If (objDataRowViewUnitCode.Row("ModuleCodeID").ToString() = "0") Then
                        If (strStatus = "") Then
                            strStatus = "Missing Unit Code selection."
                        Else
                            strStatus &= vbCrLf & "Missing Unit Code selection."
                        End If
                    Else
                        strTryStep = "unitcode_ExtendedCommand"
                        objX10DbMacroCommand.unitcode = nsX10CM15AMethods.x10DeviceCodeToBinaryValue(objDataRowViewUnitCode(1).ToString()) ' DisplayMember ex: "1"
                        strTriggerModuleCode = objDataRowViewUnitCode(1).ToString

                        strTryStep = "nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand_unitcode"
                        ' verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(string strX10DbConnectionString, string strX10DbProvider, int intMacroInitiatorID, string strMacroInitiatorName, bool bVerifyMacroInitiatorTriggerOnly, string strTriggerHouseCode, string strTriggerModuleCode)
                        objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(strConnectionString, strProvider, intMacroInitiatorID, strMacroInitiatorName, True, strTriggerHouseCode, strTriggerModuleCode)
                        If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status.Length = 0) Then

                            If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.triggerUsed) Then

                                If (strStatus = "") Then
                                    strStatus = "Macro Command Module """ & strTriggerHouseCode & strTriggerModuleCode & """ is also the" & vbCrLf & "Macro Initiator Trigger."
                                Else
                                    strStatus &= vbCrLf & "Macro Command Module """ & strTriggerHouseCode & strTriggerModuleCode & """ is also the" & vbCrLf & "Macro Initiator Trigger."
                                End If
                                strStatus &= vbCrLf & vbCrLf & "This Macro Command Module cannot also be used within this Macro Initiator" & vbCrLf & """" & strMacroInitiatorName & """ [" & intMacroInitiatorID.ToString() & "]"

                            End If

                        Else
                            If (strStatus = "") Then
                                strStatus = "Problem verifying Macro Initiator Trigger (unitcode): " & objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status
                            Else
                                strStatus &= vbCrLf & "Problem verifying Macro Initiator Trigger (unitcode): " & objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status
                            End If
                        End If ' END - nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(unitcode)

                    End If ' END -IsUnitCodeSelected?

                    strTryStep = "extendedCommand_ExtendedCommand"
                    objDataRowViewExtendedCommand = formMacroCommandAddUpdateExtendedCommandComboBox.SelectedItem
                    objX10DbMacroCommand.extendedCommand = CType(objDataRowViewExtendedCommand(1), Byte)
                    If (objX10DbMacroCommand.extendedCommand = 0) Then
                        If (strStatus = "") Then
                            strStatus = "Missing Extended Command selection."
                        Else
                            strStatus &= vbCrLf & "Missing Extended Command selection."
                        End If
                    End If ' END - extendedCommand_ExtendedCommand

                    strTryStep = "extendedData_ExtendedCommand"
                    Try

                        objX10DbMacroCommand.extendedData = CType(formMacroCommandAddUpdateExtendedDataByteTextBox.Text(), Byte)

                        If (objX10DbMacroCommand.extendedData > 255) Then
                            If (strStatus = "") Then
                                strStatus = "RANGE: Extended Data must be a Decimal number ranged from 0 to 255."
                            Else
                                strStatus &= vbCrLf & "RANGE: Extended Data must be a Decimal number ranged from 0 to 255."
                            End If
                        End If

                    Catch ex As Exception
                        If (strStatus = "") Then
                            strStatus = "INVALID: Extended Data must be a Decimal number ranged from 0 to 255."
                        Else
                            strStatus &= vbCrLf & "INVALID: Extended Data must be a Decimal number ranged from 0 to 255."
                        End If
                    End Try ' END - extendedData_ExtendedCommand

                Case Else
                    If (strStatus = "") Then
                        strStatus = "Missing Command selection."
                    Else
                        strStatus &= vbCrLf & "Missing Command selection."
                    End If
            End Select ' END - SelectCommandCode

            strTryStep = "WasSomethingMissing"
            If (strStatus = "") Then

                strTryStep = "MacroCommandID"
                If (formMacroCommandAddUpdateIDLabelText.Text() = "") Then
                    objX10DbMacroCommand.MacroCommandID = -1
                Else
                    objX10DbMacroCommand.MacroCommandID = CType(formMacroCommandAddUpdateIDLabelText.Text(), Integer)
                End If

                strTryStep = "MacroID"
                objX10DbMacroCommand.MacroID = CType(formMacroCommandAddUpdateMacroIDLabelText.Text(), Integer)


                strTryStep = "DataRowViewSort"
                objDataRowViewSort = formMacroCommandAddUpdateMacroCommandSortOrderComboBox.SelectedItem

                strTryStep = "MacroCommandSort"
                objX10DbMacroCommand.MacroCommandSort = CType(objDataRowViewSort.Row("ValueMember").ToString(), Integer)

                strTryStep = "nsX10DbMethods.addUpdateMacroCommandToX10db"
                ' nsX10DbMethods.addUpdateMacroCommandToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbMacroCommand As TrekkerPhotoArt.X10Include.X10DbMacroCommand, ByRef intRowsAffected As Integer) As String
                strStatus = nsX10DbMethods.addUpdateMacroCommandToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbMacroCommand, intRowsAffected)
                If (strStatus = "") Then

                    If (intRowsAffected > 0) Then
                        formMacroCommandAddUpdateIDLabelText.Text() = objX10DbMacroCommand.MacroCommandID.ToString()

                        If (formMacroCommandAddUpdate_AddUpdateButton.Text() = "Add") Then
                            formMacroCommandAddUpdate_AddUpdateButton.Text() = "Update"
                            formMacroCommandAddUpdate_StatusLabel.Text = "Successfully Added"
                            formMacroCommandAddUpdate_DeleteButton.Visible = True

                        Else
                            formMacroCommandAddUpdate_StatusLabel.Text = "Successfully Updated"
                        End If

                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                        formMacroCommandAddUpdate_CancelButton.Text() = "Done"


                        ' Refresh "MacroCommands" DataSet on Calling Form formMacroAddUpdate.
                        strTryStep = "RefreshMacroCommandsDataSetOnCallingFormFormMacroAddUpdate"
                        For Each objFormMacroAddUpdate In objFormCollection.OfType(Of formMacroAddUpdate)

                            If (objFormMacroAddUpdate.formMacroAddUpdateIDLabelText.Text() = objX10DbMacroCommand.MacroID.ToString()) Then

                                objFormMacroAddUpdate.formMacroAddUpdate_BringToFrontLabel.Text() = "N"

                                ' formMacroAddUpdate_GetMacroCommandsDataSet(ByVal intMacroID As Integer) As String
                                strStatus = objFormMacroAddUpdate.formMacroAddUpdate_GetMacroCommandsDataSet(objX10DbMacroCommand.MacroID)
                                If (strStatus = "") Then
                                    objFormMacroAddUpdate.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formMacroCommandAddUpdate_AddUpdateButton_Click(): " & strStatus, "formMacroCommandAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formMacroAddUpdate_GetMacroCommandsDataSet()

                                Exit For
                            End If

                        Next ' END - RefreshMacroCommandsDataSetOnCallingFormFormMacroAddUpdate


                        Me.BringToFront()

                    Else
                        formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                        If (formMacroCommandAddUpdate_AddUpdateButton.Text() = "Add") Then
                            Windows.Forms.MessageBox.Show("Problem adding Macro Command to X10 Db.", "formMacroCommandAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Else
                            Windows.Forms.MessageBox.Show("Problem modifying Macro Command to X10 Db.", "formMacroCommandAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If
                    End If ' END - RowsAffected

                Else
                    formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                    formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                    If (formMacroCommandAddUpdate_AddUpdateButton.Text() = "Add") Then
                        Windows.Forms.MessageBox.Show("Problem adding Macro Command to X10 Db." & vbCrLf & strStatus, "formMacroCommandAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    Else
                        Windows.Forms.MessageBox.Show("Problem modifying Macro Command to X10 Db." & vbCrLf & strStatus, "formMacroCommandAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If
                End If ' END - nsX10DbMethods.addUpdateMacroCommandToX10db()

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formMacroCommandAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            End If ' END - WasSomethingMissing

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "formMacroCommandAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroCommandAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            End If

            Windows.Forms.MessageBox.Show(strStatus, "formMacroCommandAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormMacroInitiatorAddUpdate = Nothing
            objFormMacroAddUpdate = Nothing
            objX10DbMacroCommand = Nothing
            objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = Nothing
            objDataRowViewSort = Nothing
            objDataRowViewCommand = Nothing
            objDataRowViewHouseCode = Nothing
            objDataRowViewUnitCode = Nothing
            objDataRowViewExtendedCommand = Nothing
        End Try

    End Sub ' END - formMacroCommandAddUpdate_AddUpdateButton_Click()

    Private Sub formMacroCommandAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroCommandAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formMacroCommandAddUpdate_CancelButton_Click()

    Private Sub formMacroCommandAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroCommandAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim intMacroCommandID As Integer = Nothing
        Dim intMacroID As Integer = -1
        Dim intMacroInitiatorID As Integer = -1

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormMacroAddUpdate As formMacroAddUpdate = Nothing
        Dim objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate = Nothing

        Try

            formMacroCommandAddUpdate_StatusLabel.Text = ""
            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            If (formMacroCommandAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing MacroCommandID", "formMacroCommandAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                intMacroCommandID = CType(formMacroCommandAddUpdateIDLabelText.Text(), Integer)

                ' nsX10DbMethods.removeMacroCommandFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef intMacroCommandID As Integer, ByRef intRowsAffected As Integer) As String
                strStatus = nsX10DbMethods.removeMacroCommandFromX10Db(strConnectionString, strProvider, intMacroCommandID, intRowsAffected)
                If (strStatus = "") Then

                    If (intRowsAffected > 0) Then

                        formMacroCommandAddUpdateIDLabelText.Text() = ""
                        formMacroCommandAddUpdate_AddUpdateButton.Text() = "Add"
                        formMacroCommandAddUpdate_StatusLabel.Text = "Successfully Deleted"
                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                        formMacroCommandAddUpdate_CancelButton.Text() = "Done"
                        formMacroCommandAddUpdate_DeleteButton.Visible = False


                        ' Refresh "MacroCommands" DataSet on Calling Form formMacroAddUpdate.
                        intMacroID = CType(formMacroCommandAddUpdateMacroIDLabelText.Text(), Integer)
                        For Each objFormMacroAddUpdate In objFormCollection.OfType(Of formMacroAddUpdate)

                            If (objFormMacroAddUpdate.formMacroAddUpdateIDLabelText.Text() = intMacroID.ToString()) Then

                                objFormMacroAddUpdate.formMacroAddUpdate_BringToFrontLabel.Text() = "N"

                                ' The row has been deleted.
                                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroAddUpdateMacroCommands = -1
                                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroAddUpdateMacroCommands = -1

                                ' formMacroAddUpdate_GetMacroCommandsDataSet(ByVal intMacroInitiatorID As Integer) As String
                                strStatus = objFormMacroAddUpdate.formMacroAddUpdate_GetMacroCommandsDataSet(intMacroID)
                                If (strStatus = "") Then
                                    objFormMacroAddUpdate.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formMacroCommandAddUpdate_DeleteButton_Click(): " & strStatus, "formMacroCommandAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formMacroAddUpdate_GetMacroCommandsDataSet()

                                Exit For
                            End If

                        Next


                        Me.BringToFront()

                    Else
                        formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                        formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Macro Command from X10 Db.", "formMacroCommandAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - RowsAffected

                Else
                    formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
                    formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
                    Windows.Forms.MessageBox.Show("Problem removing Macro Command from X10 Db." & vbCrLf & strStatus, "formMacroCommandAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - nsX10DbMethods.removeMacroFromX10Db

            End If ' END - Is there a MacroID?

        Catch ex As Exception
            strStatus = "formMacroCommandAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroCommandAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroCommandAddUpdate_StatusLabel.Text = "Fail"
            formMacroCommandAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroCommandAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormMacroAddUpdate = Nothing
            objFormMacroInitiatorAddUpdate = Nothing
        End Try

    End Sub ' END - formMacroCommandAddUpdate_DeleteButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formMacroCommandAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMacroCommandAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formMacroCommandAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(585, 485)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationMacroCommandAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationMacroCommandAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationMacroCommandAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formMacroCommandAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroCommandAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formMacroCommandAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formMacroCommandAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMacroCommandAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formMacroCommandAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationMacroCommandAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationMacroCommandAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formMacroCommandAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroCommandAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formMacroCommandAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formMacroCommandAddUpdate