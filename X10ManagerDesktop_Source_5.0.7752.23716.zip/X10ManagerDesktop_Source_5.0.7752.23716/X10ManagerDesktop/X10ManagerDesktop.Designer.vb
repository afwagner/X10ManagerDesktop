﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class X10ManagerDesktop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(X10ManagerDesktop))
        Me.MenuStripTop = New System.Windows.Forms.MenuStrip()
        Me.menuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuFile_Settings = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuFile_Backup = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuFile_Restore = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuFile_Seperator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.menuFile_Exit = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuController = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuController_Add = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuController_Edit = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuController_Download = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuModule = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuModule_Add = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuModule_Edit = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuModule_Import = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuModule_Export = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuScene = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuScene_Add = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuScene_Edit = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuSchedule = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuSchedule_Add = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuSchedule_Edit = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuMacro = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuMacro_Add = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuMacro_Edit = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuHelp_ViewHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuHelp_AboutX10ManagerDesktop = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuPlaceHolder = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuDownload = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuAllLightsOff = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuAllLightsOn = New System.Windows.Forms.ToolStripMenuItem()
        Me.menuController_Seperator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.menuModule_Seperator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.MenuStripTop.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStripTop
        '
        Me.MenuStripTop.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuFile, Me.menuController, Me.menuModule, Me.menuScene, Me.menuSchedule, Me.menuMacro, Me.menuHelp, Me.menuPlaceHolder, Me.menuDownload, Me.menuAllLightsOff, Me.menuAllLightsOn})
        Me.MenuStripTop.Location = New System.Drawing.Point(0, 0)
        Me.MenuStripTop.Name = "MenuStripTop"
        Me.MenuStripTop.Size = New System.Drawing.Size(744, 24)
        Me.MenuStripTop.TabIndex = 0
        Me.MenuStripTop.Text = "MenuStripTop"
        '
        'menuFile
        '
        Me.menuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuFile_Settings, Me.menuFile_Backup, Me.menuFile_Restore, Me.menuFile_Seperator10, Me.menuFile_Exit})
        Me.menuFile.Name = "menuFile"
        Me.menuFile.Size = New System.Drawing.Size(37, 20)
        Me.menuFile.Text = "File"
        '
        'menuFile_Settings
        '
        Me.menuFile_Settings.Name = "menuFile_Settings"
        Me.menuFile_Settings.Size = New System.Drawing.Size(152, 22)
        Me.menuFile_Settings.Text = "Settings"
        '
        'menuFile_Backup
        '
        Me.menuFile_Backup.Name = "menuFile_Backup"
        Me.menuFile_Backup.Size = New System.Drawing.Size(152, 22)
        Me.menuFile_Backup.Text = "Backup"
        '
        'menuFile_Restore
        '
        Me.menuFile_Restore.Name = "menuFile_Restore"
        Me.menuFile_Restore.Size = New System.Drawing.Size(152, 22)
        Me.menuFile_Restore.Text = "Restore"
        '
        'menuFile_Seperator10
        '
        Me.menuFile_Seperator10.Name = "menuFile_Seperator10"
        Me.menuFile_Seperator10.Size = New System.Drawing.Size(149, 6)
        '
        'menuFile_Exit
        '
        Me.menuFile_Exit.Name = "menuFile_Exit"
        Me.menuFile_Exit.Size = New System.Drawing.Size(152, 22)
        Me.menuFile_Exit.Text = "Exit"
        '
        'menuController
        '
        Me.menuController.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuController_Add, Me.menuController_Edit, Me.menuController_Seperator10, Me.menuController_Download})
        Me.menuController.Name = "menuController"
        Me.menuController.Size = New System.Drawing.Size(72, 20)
        Me.menuController.Text = "Controller"
        '
        'menuController_Add
        '
        Me.menuController_Add.Name = "menuController_Add"
        Me.menuController_Add.Size = New System.Drawing.Size(152, 22)
        Me.menuController_Add.Text = "Add"
        '
        'menuController_Edit
        '
        Me.menuController_Edit.Name = "menuController_Edit"
        Me.menuController_Edit.Size = New System.Drawing.Size(152, 22)
        Me.menuController_Edit.Text = "Edit"
        '
        'menuController_Download
        '
        Me.menuController_Download.Name = "menuController_Download"
        Me.menuController_Download.Size = New System.Drawing.Size(152, 22)
        Me.menuController_Download.Text = "Download"
        '
        'menuModule
        '
        Me.menuModule.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuModule_Add, Me.menuModule_Edit, Me.menuModule_Seperator10, Me.menuModule_Import, Me.menuModule_Export})
        Me.menuModule.Name = "menuModule"
        Me.menuModule.Size = New System.Drawing.Size(60, 20)
        Me.menuModule.Text = "Module"
        '
        'menuModule_Add
        '
        Me.menuModule_Add.Name = "menuModule_Add"
        Me.menuModule_Add.Size = New System.Drawing.Size(152, 22)
        Me.menuModule_Add.Text = "Add"
        '
        'menuModule_Edit
        '
        Me.menuModule_Edit.Name = "menuModule_Edit"
        Me.menuModule_Edit.Size = New System.Drawing.Size(152, 22)
        Me.menuModule_Edit.Text = "Edit"
        '
        'menuModule_Import
        '
        Me.menuModule_Import.Name = "menuModule_Import"
        Me.menuModule_Import.Size = New System.Drawing.Size(152, 22)
        Me.menuModule_Import.Text = "Import"
        '
        'menuModule_Export
        '
        Me.menuModule_Export.Name = "menuModule_Export"
        Me.menuModule_Export.Size = New System.Drawing.Size(152, 22)
        Me.menuModule_Export.Text = "Export"
        '
        'menuScene
        '
        Me.menuScene.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuScene_Add, Me.menuScene_Edit})
        Me.menuScene.Name = "menuScene"
        Me.menuScene.Size = New System.Drawing.Size(50, 20)
        Me.menuScene.Text = "Scene"
        '
        'menuScene_Add
        '
        Me.menuScene_Add.Name = "menuScene_Add"
        Me.menuScene_Add.Size = New System.Drawing.Size(152, 22)
        Me.menuScene_Add.Text = "Add"
        '
        'menuScene_Edit
        '
        Me.menuScene_Edit.Name = "menuScene_Edit"
        Me.menuScene_Edit.Size = New System.Drawing.Size(152, 22)
        Me.menuScene_Edit.Text = "Edit"
        '
        'menuSchedule
        '
        Me.menuSchedule.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuSchedule_Add, Me.menuSchedule_Edit})
        Me.menuSchedule.Name = "menuSchedule"
        Me.menuSchedule.Size = New System.Drawing.Size(67, 20)
        Me.menuSchedule.Text = "Schedule"
        '
        'menuSchedule_Add
        '
        Me.menuSchedule_Add.Name = "menuSchedule_Add"
        Me.menuSchedule_Add.Size = New System.Drawing.Size(152, 22)
        Me.menuSchedule_Add.Text = "Add"
        '
        'menuSchedule_Edit
        '
        Me.menuSchedule_Edit.Name = "menuSchedule_Edit"
        Me.menuSchedule_Edit.Size = New System.Drawing.Size(152, 22)
        Me.menuSchedule_Edit.Text = "Edit"
        '
        'menuMacro
        '
        Me.menuMacro.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuMacro_Add, Me.menuMacro_Edit})
        Me.menuMacro.Name = "menuMacro"
        Me.menuMacro.Size = New System.Drawing.Size(53, 20)
        Me.menuMacro.Text = "Macro"
        '
        'menuMacro_Add
        '
        Me.menuMacro_Add.Name = "menuMacro_Add"
        Me.menuMacro_Add.Size = New System.Drawing.Size(152, 22)
        Me.menuMacro_Add.Text = "Add"
        '
        'menuMacro_Edit
        '
        Me.menuMacro_Edit.Name = "menuMacro_Edit"
        Me.menuMacro_Edit.Size = New System.Drawing.Size(152, 22)
        Me.menuMacro_Edit.Text = "Edit"
        '
        'menuHelp
        '
        Me.menuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.menuHelp_ViewHelp, Me.menuHelp_AboutX10ManagerDesktop})
        Me.menuHelp.Name = "menuHelp"
        Me.menuHelp.Size = New System.Drawing.Size(44, 20)
        Me.menuHelp.Text = "Help"
        '
        'menuHelp_ViewHelp
        '
        Me.menuHelp_ViewHelp.Name = "menuHelp_ViewHelp"
        Me.menuHelp_ViewHelp.Size = New System.Drawing.Size(219, 22)
        Me.menuHelp_ViewHelp.Text = "View Help"
        '
        'menuHelp_AboutX10ManagerDesktop
        '
        Me.menuHelp_AboutX10ManagerDesktop.Name = "menuHelp_AboutX10ManagerDesktop"
        Me.menuHelp_AboutX10ManagerDesktop.Size = New System.Drawing.Size(219, 22)
        Me.menuHelp_AboutX10ManagerDesktop.Text = "About X10ManagerDesktop"
        '
        'menuPlaceHolder
        '
        Me.menuPlaceHolder.AutoSize = False
        Me.menuPlaceHolder.Enabled = False
        Me.menuPlaceHolder.Name = "menuPlaceHolder"
        Me.menuPlaceHolder.Size = New System.Drawing.Size(70, 20)
        Me.menuPlaceHolder.Text = " "
        '
        'menuDownload
        '
        Me.menuDownload.Name = "menuDownload"
        Me.menuDownload.Size = New System.Drawing.Size(73, 20)
        Me.menuDownload.Text = "Download"
        '
        'menuAllLightsOff
        '
        Me.menuAllLightsOff.Name = "menuAllLightsOff"
        Me.menuAllLightsOff.Size = New System.Drawing.Size(88, 20)
        Me.menuAllLightsOff.Text = "All Lights Off"
        '
        'menuAllLightsOn
        '
        Me.menuAllLightsOn.Name = "menuAllLightsOn"
        Me.menuAllLightsOn.Size = New System.Drawing.Size(87, 20)
        Me.menuAllLightsOn.Text = "All Lights On"
        '
        'menuController_Seperator10
        '
        Me.menuController_Seperator10.Name = "menuController_Seperator10"
        Me.menuController_Seperator10.Size = New System.Drawing.Size(149, 6)
        '
        'menuModule_Seperator10
        '
        Me.menuModule_Seperator10.Name = "menuModule_Seperator10"
        Me.menuModule_Seperator10.Size = New System.Drawing.Size(149, 6)
        '
        'X10ManagerDesktop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(744, 491)
        Me.Controls.Add(Me.MenuStripTop)
        Me.HelpButton = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStripTop
        Me.Name = "X10ManagerDesktop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "X10ManagerDesktop"
        Me.MenuStripTop.ResumeLayout(False)
        Me.MenuStripTop.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStripTop As MenuStrip
    Friend WithEvents menuFile As ToolStripMenuItem
    Friend WithEvents menuFile_Backup As ToolStripMenuItem
    Friend WithEvents menuFile_Seperator10 As ToolStripSeparator
    Friend WithEvents menuFile_Exit As ToolStripMenuItem
    Friend WithEvents menuHelp As ToolStripMenuItem
    Friend WithEvents menuHelp_ViewHelp As ToolStripMenuItem
    Friend WithEvents menuHelp_AboutX10ManagerDesktop As ToolStripMenuItem
    Friend WithEvents menuController As ToolStripMenuItem
    Friend WithEvents menuController_Add As ToolStripMenuItem
    Friend WithEvents menuController_Edit As ToolStripMenuItem
    Friend WithEvents menuModule As ToolStripMenuItem
    Friend WithEvents menuModule_Add As ToolStripMenuItem
    Friend WithEvents menuModule_Edit As ToolStripMenuItem
    Friend WithEvents menuScene As ToolStripMenuItem
    Friend WithEvents menuScene_Add As ToolStripMenuItem
    Friend WithEvents menuScene_Edit As ToolStripMenuItem
    Friend WithEvents menuSchedule As ToolStripMenuItem
    Friend WithEvents menuSchedule_Add As ToolStripMenuItem
    Friend WithEvents menuSchedule_Edit As ToolStripMenuItem
    Friend WithEvents menuFile_Settings As ToolStripMenuItem
    Friend WithEvents menuFile_Restore As ToolStripMenuItem
    Friend WithEvents menuController_Download As ToolStripMenuItem
    Friend WithEvents menuMacro As ToolStripMenuItem
    Friend WithEvents menuMacro_Add As ToolStripMenuItem
    Friend WithEvents menuMacro_Edit As ToolStripMenuItem
    Friend WithEvents menuPlaceHolder As ToolStripMenuItem
    Friend WithEvents menuDownload As ToolStripMenuItem
    Friend WithEvents menuAllLightsOff As ToolStripMenuItem
    Friend WithEvents menuAllLightsOn As ToolStripMenuItem
    Friend WithEvents menuModule_Import As ToolStripMenuItem
    Friend WithEvents menuModule_Export As ToolStripMenuItem
    Friend WithEvents menuController_Seperator10 As ToolStripSeparator
    Friend WithEvents menuModule_Seperator10 As ToolStripSeparator
End Class
