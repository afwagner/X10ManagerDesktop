﻿Imports System.Configuration

' Name: formMacroAddUpdate.vb
' By: Alan Wagner
' Date: February 2021

Public Class formMacroAddUpdate

#Region "X10ManagerDesktopMacroAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim intMacroID As Integer = -1
        Dim objX10DbMacro As TrekkerPhotoArt.X10Include.X10DbMacro = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim strMessage As String = ""

        Dim intHours As Integer = -1
        Dim intTotalMinutes As Integer = -1
        Dim intMinutes As Integer = -1
        Dim intSeconds As Integer = -1
        Dim strDateTime As String = ""

        Try

            If (formMacroAddUpdate_BringToFrontLabel.Text() = "Y") Then
                Me.BringToFront()
            Else
                formMacroAddUpdate_BringToFrontLabel.Text() = "Y"
            End If

            strTryStep = "formMacroAddUpdateCallingFormLabelText.Visible"
            formMacroAddUpdateCallingFormLabelText.Visible = False
            formMacroAddUpdateMacroInitatorIDLabelText.Visible = False
            formMacroAddUpdateMacroInitatorNameLabel.Visible = True
            formMacroAddUpdateMacroInInitatorNameLabelText.Visible = True

            strTryStep = "formMacroAddUpdate_FormRestore"
            ' formMacroAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formMacroAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formMacroAddUpdateIDLabelText"
                If (formMacroAddUpdateIDLabelText.Text() = "" Or formMacroAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddMacro"

                    strTryStep = "formMacroAddUpdateMacroInitatorIDLabelText.Text()"
                    If (formMacroAddUpdateMacroInitatorIDLabelText.Text() = "") Then
                        Windows.Forms.MessageBox.Show("Missing MacroInitatorID from calling Form """ & formMacroAddUpdateCallingFormLabelText.Text() & """.", "Main(formMacroAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Me.Close()
                    Else

                        formMacroAddUpdateMacroIDLabel.Visible = True
                        formMacroAddUpdateIDLabelText.Visible = True
                        formMacroAddUpdateIDLabelText.Text() = ""

                        ' Set the caption bar text of the form.
                        Me.Text = "Add Macro"

                        strTryStep = "AddMacro"
                        formMacroAddUpdate_AddUpdateButton.Text() = "Add"
                        formMacroAddUpdate_AddUpdateButton.Select()
                        formMacroAddUpdate_StatusLabel.Visible = True
                        formMacroAddUpdate_StatusLabel.Text = ""

                        formMacroAddUpdate_CancelButton.Text() = "Cancel"

                        formMacroAddUpdate_DeleteButton.Visible = False
                        formMacroAddUpdate_DeleteButton.Text() = "Delete"

                        formMacroAddUpdateMacroNameLabel.Visible = True
                        formMacroAddUpdateMacroNameTextBox.Visible = True
                        formMacroAddUpdateMacroNameTextBox.Text() = ""

                        formMacroAddUpdateDescriptionLabel.Visible = True
                        formMacroAddUpdateDescriptionTextBox.Visible = True
                        formMacroAddUpdateDescriptionTextBox.Text() = ""


                        formMacroAddUpdateMacroSortOrderLabel.Visible = True

                        strTryStep = "Add_generateSortOrderComboBox"
                        ' generateSortOrderComboBox(ByVal intSort As Integer) As String
                        strStatus = generateSortOrderComboBox(-1)
                        If (strStatus = "") Then

                            formMacroAddUpdateMacroSortOrderComboBox.Visible = True
                        Else
                            formMacroAddUpdateMacroSortOrderComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroAddUpdate_CancelButton.Select()
                            formMacroAddUpdate_AddUpdateButton.Visible = False
                            formMacroAddUpdate_StatusLabel.Text = "Fail"
                            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        strTryStep = "RF_Add"
                        formMacroAddUpdateRfLabel.Visible = True
                        formMacroAddUpdateRfFunctionPanel.Visible = True
                        formMacroAddUpdateRfOnRadioButton.Visible = True
                        formMacroAddUpdateRfOnRadioButton.Enabled = True
                        formMacroAddUpdateRfOnRadioButton.Checked = False
                        formMacroAddUpdateRfOffRadioButton.Visible = True
                        formMacroAddUpdateRfOffRadioButton.Enabled = True
                        formMacroAddUpdateRfOffRadioButton.Checked = True

                        strTryStep = "Delay_Add"
                        ' Max Value: 0x3FFF = 11 1111 1111 1111 = 16,383 seconds; 16,383/60 = 273 minutes, 3 seconds; 273/60 = 4 hours, 33 minutes, 3 seconds
                        ' 16,200 seconds = 270 minutes; 270/60 = 4 hours, 30 minutes
                        formMacroAddUpdateDelayLabel.Visible = True
                        formMacroAddUpdateDelayLabelFormat.Visible = True
                        strDateTime = System.DateTime.Today.ToShortDateString() & " " & "00:00:00.00"
                        formMacroAddUpdateDelayDateTimePicker.Value = System.Convert.ToDateTime(strDateTime)
                        formMacroAddUpdateDelayDateTimePicker.Enabled = True
                        formMacroAddUpdateDelayDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
                        formMacroAddUpdateDelayDateTimePicker.CustomFormat = "HH:mm:ss" ' "HH:mm:ss" starts at "00:00:00", "hh:mm:ss" starts at "12:00:00"
                        formMacroAddUpdateDelayDateTimePicker.ShowUpDown = True
                        formMacroAddUpdateDelayDateTimePicker.Visible = True

                        strTryStep = "InhibitRetrigger_Add"
                        formMacroAddUpdateInhibitRetriggerLabel.Visible = True
                        formMacroAddUpdateInhibitRetriggerPanel.Visible = True
                        formMacroAddUpdateInhibitRetriggerOnRadioButton.Visible = True
                        formMacroAddUpdateInhibitRetriggerOnRadioButton.Enabled = True
                        formMacroAddUpdateInhibitRetriggerOnRadioButton.Checked = False
                        formMacroAddUpdateInhibitRetriggerOffRadioButton.Visible = True
                        formMacroAddUpdateInhibitRetriggerOffRadioButton.Enabled = True
                        formMacroAddUpdateInhibitRetriggerOffRadioButton.Checked = True

                        formMacroAddUpdateMacroCommandsLabel.Visible = True
                        formMacroAddUpdateMacroCommandsLabel.Text() = "Macro Commands - New Macro must first be added."

                        strTryStep = "formMacroAddUpdate_GetMacroCommandsDataSet_Add"
                        ' formMacroAddUpdate_GetMacroCommandsDataSet(ByVal intMacroID As Integer) As String
                        strStatus = formMacroAddUpdate_GetMacroCommandsDataSet(-1)
                        If (strStatus = "") Then
                            formMacroAddUpdateMacroCommandsDataGridView.Rows.Clear()
                            formMacroAddUpdateMacroCommandsDataGridView.Visible = True
                            formMacroAddUpdateMacroCommandsDataGridView.Enabled = False
                        Else
                            Windows.Forms.MessageBox.Show("Main(formMacroAddUpdate-Add): TryStep=" & strTryStep & ": " & strStatus, "Main(formMacroAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroAddUpdate_StatusLabel.Text = "Fail"
                            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                    End If ' END - formMacroAddUpdateMacroInitatorIDLabelText.Text()

                Else
                    strTryStep = "UpdateMacro"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Macro"

                    strTryStep = "UpdateMacro"
                    formMacroAddUpdate_AddUpdateButton.Text() = "Update"
                    formMacroAddUpdate_AddUpdateButton.Select()
                    formMacroAddUpdate_StatusLabel.Visible = True
                    formMacroAddUpdate_StatusLabel.Text = ""

                    formMacroAddUpdate_CancelButton.Text() = "Done"

                    formMacroAddUpdate_DeleteButton.Visible = True
                    formMacroAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "MacroID"
                    intMacroID = CType(formMacroAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbMacro"
                    ' nsX10DbMethods.getX10DbMacro(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intMacroID As Integer, ByRef objX10DbMacro As TrekkerPhotoArt.X10Include.X10DbMacro) As String
                    strStatus = nsX10DbMethods.getX10DbMacro(strConnectionString, strProvider, intMacroID, objX10DbMacro)
                    If (strStatus = "") Then

                        formMacroAddUpdateMacroNameLabel.Visible = True
                        formMacroAddUpdateMacroNameTextBox.Visible = True
                        formMacroAddUpdateMacroNameTextBox.Text() = objX10DbMacro.name

                        formMacroAddUpdateMacroIDLabel.Visible = True
                        formMacroAddUpdateIDLabelText.Visible = True
                        formMacroAddUpdateIDLabelText.Text() = objX10DbMacro.MacroID.ToString()

                        formMacroAddUpdateDescriptionLabel.Visible = True
                        formMacroAddUpdateDescriptionTextBox.Visible = True
                        formMacroAddUpdateDescriptionTextBox.Text() = objX10DbMacro.description


                        formMacroAddUpdateMacroSortOrderLabel.Visible = True

                        strTryStep = "Add_generateSortOrderComboBox"
                        ' generateSortOrderComboBox(ByVal intSort As Integer) As String
                        strStatus = generateSortOrderComboBox(objX10DbMacro.MacroSort)
                        If (strStatus = "") Then

                            formMacroAddUpdateMacroSortOrderComboBox.Visible = True
                        Else
                            formMacroAddUpdateMacroSortOrderComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroAddUpdate_CancelButton.Select()
                            formMacroAddUpdate_AddUpdateButton.Visible = False
                            formMacroAddUpdate_StatusLabel.Text = "Fail"
                            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        strTryStep = "RF_Update"
                        formMacroAddUpdateRfLabel.Visible = True
                        formMacroAddUpdateRfFunctionPanel.Visible = True
                        formMacroAddUpdateRfOnRadioButton.Visible = True
                        formMacroAddUpdateRfOnRadioButton.Enabled = True
                        formMacroAddUpdateRfOffRadioButton.Visible = True
                        formMacroAddUpdateRfOffRadioButton.Enabled = True
                        Select Case objX10DbMacro.RF
                            Case 0
                                formMacroAddUpdateRfOnRadioButton.Checked = False
                                formMacroAddUpdateRfOffRadioButton.Checked = True
                            Case 1
                                formMacroAddUpdateRfOnRadioButton.Checked = True
                                formMacroAddUpdateRfOffRadioButton.Checked = False
                        End Select

                        strTryStep = "Delay_Update"
                        ' Max Value: 0x3FFF = 11 1111 1111 1111 = 16,383 seconds; 16,383/60 = 273 minutes, 3 seconds; 273/60 = 4 hours, 33 minutes, 3 seconds
                        ' 16,200 seconds = 270 minutes; 270/60 = 4 hours, 30 minutes
                        formMacroAddUpdateDelayLabel.Visible = True
                        formMacroAddUpdateDelayLabelFormat.Visible = True

                        ' \ - Integer Division, / - Real Number Division
                        ' objX10DbMacro.delay = total seconds
                        intTotalMinutes = objX10DbMacro.delay \ 60
                        intHours = intTotalMinutes \ 60
                        intMinutes = intTotalMinutes Mod 60
                        intSeconds = (objX10DbMacro.delay Mod 60)
                        strDateTime = System.DateTime.Today.ToShortDateString() & " " & intHours.ToString().PadLeft(2, "0") & ":" & intMinutes.ToString().PadLeft(2, "0") & ":" & intSeconds.ToString().PadLeft(2, "0") & ".00"

                        formMacroAddUpdateDelayDateTimePicker.Value = System.Convert.ToDateTime(strDateTime)
                        formMacroAddUpdateDelayDateTimePicker.Enabled = True
                        formMacroAddUpdateDelayDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
                        formMacroAddUpdateDelayDateTimePicker.CustomFormat = "HH:mm:ss" ' "HH:mm:ss" starts at "00:00:00", "hh:mm:ss" starts at "12:00:00"
                        formMacroAddUpdateDelayDateTimePicker.ShowUpDown = True
                        formMacroAddUpdateDelayDateTimePicker.Visible = True

                        strTryStep = "InhibitRetrigger_Update"
                        formMacroAddUpdateInhibitRetriggerLabel.Visible = True
                        formMacroAddUpdateInhibitRetriggerPanel.Visible = True
                        formMacroAddUpdateInhibitRetriggerOnRadioButton.Visible = True
                        formMacroAddUpdateInhibitRetriggerOnRadioButton.Enabled = True
                        formMacroAddUpdateInhibitRetriggerOffRadioButton.Visible = True
                        formMacroAddUpdateInhibitRetriggerOffRadioButton.Enabled = True
                        Select Case objX10DbMacro.inhibitRetrigger
                            Case 0
                                formMacroAddUpdateInhibitRetriggerOnRadioButton.Checked = False
                                formMacroAddUpdateInhibitRetriggerOffRadioButton.Checked = True
                            Case 1
                                formMacroAddUpdateInhibitRetriggerOnRadioButton.Checked = True
                                formMacroAddUpdateInhibitRetriggerOffRadioButton.Checked = False
                        End Select

                        formMacroAddUpdateMacroCommandsLabel.Visible = True
                        formMacroAddUpdateMacroCommandsLabel.Text() = "Macro Commands"

                        strTryStep = "formMacroAddUpdate_GetMacroCommandsDataSet_Update"
                        ' formMacroAddUpdate_GetMacroCommandsDataSet(ByVal intMacroID As Integer) As String
                        strStatus = formMacroAddUpdate_GetMacroCommandsDataSet(objX10DbMacro.MacroID)
                        If (strStatus = "") Then
                            formMacroAddUpdateMacroCommandsDataGridView.Visible = True
                            formMacroAddUpdateMacroCommandsDataGridView.Enabled = True
                        Else
                            Windows.Forms.MessageBox.Show("Main(formMacroAddUpdate-Update): TryStep=" & strTryStep & ": " & strStatus, "Main(formMacroAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroAddUpdate_StatusLabel.Text = "Fail"
                            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Macro from X10 db." & vbCrLf & strStatus, "Main(formMacroAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroAddUpdate_CancelButton.Select()
                        formMacroAddUpdate_AddUpdateButton.Visible = False
                        formMacroAddUpdate_StatusLabel.Text = "Fail"
                        formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getX10DbMacro()

                End If ' END - formMacroAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formMacroAddUpdate): " & strStatus, "Main(formMacroAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formMacroAddUpdate_StatusLabel.Text = "Fail"
                formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formMacroAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formMacroAddUpdate_FormRestore()

        Catch ex As Exception

            Select Case strTryStep
                Case "Delay_Add", "Delay_Update"
                    strStatus = "Main(formMacroAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message & ": DateTime=""" & strDateTime & """"
                Case Else
                    strStatus = "Main(formMacroAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            End Select

            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroAddUpdate_StatusLabel.Text = "Fail"
            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbMacro = Nothing
        End Try

    End Sub ' END Sub - Main(formMacroAddUpdate)

    Private Sub formMacroAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formMacroAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formMacroAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formMacroAddUpdate_FormClosingHandler(): " & strStatus, "formMacroAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formMacroAddUpdate_FormSave()

    End Sub ' END Sub - formMacroAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopMacroAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function generateSortOrderComboBox()
    ' Alan Wagner
    '
    Private Function generateSortOrderComboBox(ByVal intSort As Integer) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataTableComboBoxs As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            sqlString = "SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='SortOrder' " &
                        "ORDER BY ComboBoxs.ValueMember ASC;"

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableComboBoxs)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroAddUpdateMacroSortOrderComboBox
                .DisplayMember = "DisplayMember"
                .ValueMember = "ValueMember"
                .DataSource = objDataTableComboBoxs
            End With

            If (intSort = -1) Then
                formMacroAddUpdateMacroSortOrderComboBox.SelectedIndex = 0
            Else
                formMacroAddUpdateMacroSortOrderComboBox.SelectedIndex = formMacroAddUpdateMacroSortOrderComboBox.FindString(intSort.ToString())
            End If

        Catch ex As Exception
            strStatus = "generateSortOrderComboBox(): Exception: " & ex.Message
        Finally
            objDataTableComboBoxs = Nothing
        End Try

        Return strStatus

    End Function ' END - generateSortOrderComboBox()

    '=====================================================================================
    ' formMacroAddUpdate_GetMacroCommandsDataSet()
    ' Alan Wagner
    '
    Public Function formMacroAddUpdate_GetMacroCommandsDataSet(ByVal intMacroID As Integer) As String
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objFactory As System.Data.Common.DbProviderFactory = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataGridViewColumn As System.Windows.Forms.DataGridViewColumn = Nothing
        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim objDataGridViewTextBoxCell As System.Windows.Forms.DataGridViewTextBoxCell = Nothing
        Dim objDataGridViewComboBoxCell As System.Windows.Forms.DataGridViewComboBoxCell = Nothing

        Dim intRowIndex As Integer = -1

        Dim strAddEdit As String = ""

        ' MacroCommands table
        Dim strMacroCommandID As String = ""
        Dim strMacroCommandSort As String = ""
        Dim bytCommandCode As Byte = 0
        Dim strCommandName As String = ""
        Dim strPrebrightenYN As String = ""
        Dim strHouse As String = ""
        Dim strUnitcode As String = ""
        Dim strUnitcodeMaskOdd As String = ""
        Dim strUnitcodeMaskEven As String = ""
        Dim bytExtendedCommand As Byte = 0
        Dim objX10ExtendedCommand As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.x10ExtendedCommand = Nothing
        Dim strExtendedCommand As String = ""
        Dim strExtendedData As String = ""
        Dim strDimValue As String = ""

        Dim intCurrentCellRowIndex As Integer = -1
        Dim intFirstDisplayedCellRowIndex As Integer = -1

        Dim intColumnMacroID As Integer = 1             ' Column that contains MacroID.

        Dim bShowAdvancedInformation As Boolean = False

        Try

            strTryStep = "bShowAdvancedInformation"
            Select Case X10ManagerDesktop.showAdvancedInformation
                Case 0
                    bShowAdvancedInformation = False
                Case 1
                    bShowAdvancedInformation = True
            End Select

            strTryStep = "Columns.Count"
            If (formMacroAddUpdateMacroCommandsDataGridView.Columns.Count < 1) Then

                strTryStep = "WithFormMacroAddUpdateMacroCommandsDataGridView"
                With formMacroAddUpdateMacroCommandsDataGridView
                    .AllowDrop = True
                    .AutoGenerateColumns = False
                    .AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
                    .AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
                    .AllowUserToAddRows = False
                    .AllowUserToDeleteRows = False
                    .AllowUserToOrderColumns = False
                    .AllowUserToResizeColumns = False
                    .AllowUserToResizeRows = False
                    .ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
                    .EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
                    .ReadOnly = True
                    .RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
                    .ShowCellToolTips = False
                    .ShowEditingIcon = False

                    strTryStep = "DataGridViewColumn_AddEdit"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "AddEdit"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "AddEdit"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "MacroID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    ' MacroCommands table
                    strTryStep = "DataGridViewColumn_MacroCommandID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "MacroCommandID"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroCommandID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroCommandSort"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Macro Command Sort Order"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroCommandSort"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_command" ' SceneUnits.SceneUnitID
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Command"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "command"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_house"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "House Code"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "house"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_unitcodeMaskOdd"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Unit Code Mask Odd"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "unitcodeMaskOdd"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_unitcodeMaskEven"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Unit Code Mask Even"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "unitcodeMaskEven"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_prebrighten"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "pre Dim/Bright"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "prebrighten"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_dimValue"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Dims/Brights"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "dimValue"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_unitcode"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Unit Code"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "unitcode"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_extendedCommand"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Extended Command"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "extendedCommand"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_extendedData"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Extended Data"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "extendedData"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                End With ' END - WithFormMacroAddUpdateMacroCommandsDataGridView

            Else

                strTryStep = "SelectCaseShowAdvancedInformation"
                Select Case bShowAdvancedInformation
                    Case True
                        formMacroAddUpdateMacroCommandsDataGridView.Columns(intColumnMacroID).Visible = True
                    Case False
                        formMacroAddUpdateMacroCommandsDataGridView.Columns(intColumnMacroID).Visible = False
                End Select

            End If ' END - Columns.Count

            strTryStep = "Rows.Count"
            If (formMacroAddUpdateMacroCommandsDataGridView.Rows.Count > 0) Then
                strTryStep = "Rows.Clear"
                formMacroAddUpdateMacroCommandsDataGridView.Rows.Clear()
            End If ' END - Rows.Count

            strTryStep = "ExistingOrNewMacroID"
            If (intMacroID > -1) Then
                strTryStep = "ExistingMacroID"

                strTryStep = "ConnectionStrings"
                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                strTryStep = "GetFactory"
                objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

                strTryStep = "sqlString"
                sqlString = "Select 'Edit' AS [AddEdit]," &
                            "mcs.MacroID AS [MacroID]," &
                            "mcs.MacroCommandID AS [MacroCommandID]," &
                            "mcs.MacroCommandSort AS [MacroCommandSort]," &
                            "mcs.command AS [command]," &
                            "cbc.DisplayMember AS commandName," &
                            "mcs.prebrighten AS [prebrighten]," &
                            "mcs.house AS [house]," &
                            "mcs.unitcode AS [unitcode]," &
                            "mcs.unitcodeMaskOdd AS [unitcodeMaskOdd]," &
                            "mcs.unitcodeMaskEven AS [unitcodeMaskEven]," &
                            "mcs.extendedCommand AS [extendedCommand]," &
                            "mcs.extendedData AS [extendedData]," &
                            "mcs.dimValue AS [dimValue] " &
                            "FROM ((Macros AS ms LEFT JOIN MacroCommands AS mcs ON mcs.MacroID=ms.MacroID) LEFT JOIN ComboBoxs AS cbc ON cbc.ValueMember=mcs.command) " &
                            "WHERE mcs.MacroCommandID>-1 " &
                            "AND mcs.MacroID=" & intMacroID.ToString() & " " &
                            "AND cbc.Name='Command' " &
                            "UNION " &
                            "SELECT 'Add' AS [AddEdit]," &
                            "mcs.MacroID AS [MacroID]," &
                            "-1 AS [MacroCommandID]," &
                            "-1 AS [MacroCommandSort]," &
                            "-1 AS [command]," &
                            "'' AS commandName," &
                            "-1 AS [prebrighten]," &
                            "-1 AS [house]," &
                            "-1 AS [unitcode]," &
                            "0 AS [unitcodeMaskOdd]," &
                            "0 AS [unitcodeMaskEven]," &
                            "-1 AS [extendedCommand]," &
                            "-1 AS [extendedData]," &
                            "-1 AS [dimValue] " &
                            "FROM MacroCommands AS mcs " &
                            "WHERE mcs.MacroCommandID=-1 " &
                            "ORDER BY [AddEdit],[MacroCommandSort] ASC;"

                strTryStep = "CreateConnection"
                Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                    strTryStep = "ConnectionString"
                    objDbConnection.ConnectionString = strConnectionString

                    strTryStep = "Connection.Open"
                    objDbConnection.Open()

                    strTryStep = "CreateCommand"
                    Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                        strTryStep = "CommandText"
                        objDbCommand.CommandText = sqlString

                        strTryStep = "CommandTimeout"
                        objDbCommand.CommandTimeout = 30 ' Seconds

                        strTryStep = "CommandType"
                        ' Text              - An SQL text command (default).
                        ' StoredProcedure   - To call a stored procedure.
                        ' TableDirect       - All rows and columns of the named table or tables will be returned.
                        objDbCommand.CommandType() = CommandType.Text

                        strTryStep = "ExecuteReader"
                        ' ExecuteReader     - Executes commands that return rows.
                        '   System.Data.CommandBehavior.Default          - The query may return multiple result sets. ExecuteReader(CommandBehavior.Default) is functionally equivalent to calling ExecuteReader().
                        '   System.Data.CommandBehavior.SingleResult     - The query returns a single result set.
                        '   System.Data.CommandBehavior.SchemaOnly       - The query returns column information only.
                        '   System.Data.CommandBehavior.KeyInfo          - The query returns column and primary key information.
                        '   System.Data.CommandBehavior.SingleRow        - The query is expected to return a single row of the first result set.
                        '   System.Data.CommandBehavior.SequentialAccess - Provides a way for the DataReader to handle rows that contain columns with large binary values. You can then use the GetBytes or GetChars method to specify a byte location to start the read operation.
                        '   System.Data.CommandBehavior.CloseConnection  - When the command is executed, the associated Connection object is closed when the associated DataReader object is closed.
                        ' ExecuteNonQuery   - Executes commands such as Transact-SQL INSERT, DELETE, UPDATE, and SET statements.
                        ' ExecuteScalar     - Retrieves a single value (for example, an aggregate value) from a database.
                        ' ExecuteXmlReader  - Sends the CommandText to the Connection and builds an XmlReader object.
                        Using objDbDataReader As System.Data.Common.DbDataReader = objDbCommand.ExecuteReader(System.Data.CommandBehavior.Default)

                            strTryStep = "HasRows"
                            If objDbDataReader.HasRows() Then

                                strTryStep = "Read"
                                While objDbDataReader.Read()
                                    intRowIndex = intRowIndex + 1

                                    strTryStep = ""
                                    strAddEdit = objDbDataReader("AddEdit").ToString()

                                    ' MacroCommands table
                                    strTryStep = "MacroCommandID"
                                    If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("MacroCommandID"))) Then
                                        strMacroCommandID = ""
                                    Else
                                        strMacroCommandID = CType(objDbDataReader("MacroCommandID"), Integer).ToString()
                                    End If

                                    strTryStep = "MacroCommandSort"
                                    If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("MacroCommandSort"))) Then
                                        strMacroCommandSort = ""
                                    Else
                                        If (CType(objDbDataReader("MacroCommandSort"), Integer) = -1) Then
                                            strMacroCommandSort = ""
                                        Else
                                            strMacroCommandSort = CType(objDbDataReader("MacroCommandSort"), Integer)
                                        End If
                                    End If

                                    strTryStep = "house"
                                    If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("house"))) Then
                                        strHouse = ""
                                    Else
                                        If (CType(objDbDataReader("house"), Integer) = -1) Then
                                            strHouse = ""
                                        Else
                                            strHouse = nsX10CM15AMethods.x10BinaryValueToHouseCode(CType(objDbDataReader("house"), Byte))
                                        End If
                                    End If

                                    strTryStep = "setDefaults"
                                    strUnitcodeMaskOdd = ""
                                    strUnitcodeMaskEven = ""
                                    strPrebrightenYN = ""
                                    strDimValue = ""
                                    strUnitcode = ""
                                    strExtendedCommand = ""
                                    strExtendedData = ""

                                    strTryStep = "command"
                                    strCommandName = ""
                                    If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("command"))) Then
                                        bytCommandCode = 0
                                    Else
                                        If (CType(objDbDataReader("command"), Integer) = -1) Then
                                            bytCommandCode = 0
                                        Else
                                            bytCommandCode = CType(objDbDataReader("command"), Byte)

                                            If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("commandName"))) Then
                                                strCommandName = "[" & bytCommandCode.ToString() & "]"
                                            Else
                                                strCommandName = "[" & bytCommandCode.ToString() & "] " & objDbDataReader("commandName")
                                            End If

                                            strTryStep = "commandSelectCase"
                                            Select Case bytCommandCode
                                                Case 0, 1, 2, 3, 4, 5, 6
                                                    ' X10 Standard Command
                                                    ' 0 - All Units Off
                                                    ' 1 - All Lights On
                                                    ' 2 - On
                                                    ' 3 - Off
                                                    ' 4 - Dim
                                                    ' 5 - Bright
                                                    ' 6 - All Lights Off

                                                    strTryStep = "unitcodeMaskOdd"
                                                    If (Not Microsoft.VisualBasic.IsDBNull(objDbDataReader("unitcodeMaskOdd"))) Then
                                                        strUnitcodeMaskOdd = nsX10CM15AMethods.x10DeviceCodeMapToStringOdd(CType(objDbDataReader("unitcodeMaskOdd"), Byte))
                                                    End If

                                                    strTryStep = "unitcodeMaskEven"
                                                    If (Not Microsoft.VisualBasic.IsDBNull(objDbDataReader("unitcodeMaskEven"))) Then
                                                        strUnitcodeMaskEven = nsX10CM15AMethods.x10DeviceCodeMapToStringEven(CType(objDbDataReader("unitcodeMaskEven"), Byte))
                                                    End If

                                                    strTryStep = "SelectCaseDimBright"
                                                    Select Case bytCommandCode
                                                        Case 4, 5
                                                            ' 4 - Dim
                                                            ' 5 - Bright

                                                            strTryStep = "prebrighten"
                                                            If (Not Microsoft.VisualBasic.IsDBNull(objDbDataReader("prebrighten"))) Then
                                                                If (CType(objDbDataReader("prebrighten"), Integer) > -1) Then
                                                                    ' Pre Dim/Bright Yes|No
                                                                    Select Case CType(objDbDataReader("prebrighten"), Byte)
                                                                        Case 0
                                                                            strPrebrightenYN = "No"
                                                                        Case 1
                                                                            strPrebrightenYN = "Yes"
                                                                    End Select
                                                                End If
                                                            End If

                                                            strTryStep = "dimValue"
                                                            If (Not Microsoft.VisualBasic.IsDBNull(objDbDataReader("dimValue"))) Then
                                                                If (CType(objDbDataReader("dimValue"), Integer) > -1) Then
                                                                    strDimValue = objDbDataReader("dimValue").ToString()
                                                                End If
                                                            End If

                                                    End Select ' END - SelectCaseDimBright

                                                Case 7, 8, 9, 10, 11, 12, 13, 14, 15
                                                    ' X10 Extended Command
                                                    ' 7  - Extended Command
                                                    ' 8  - Hail Request
                                                    ' 9  - Hail Acknowledge
                                                    ' 10 - Pre-set Dim (1)
                                                    ' 11 - Pre-set Dim (2)
                                                    ' 12 - Extended Data Transfer
                                                    ' 13 - Status On
                                                    ' 14 - Status Off
                                                    ' 15 - Status Request

                                                    strTryStep = "unitcode_ExtendedCommand"
                                                    If (Not Microsoft.VisualBasic.IsDBNull(objDbDataReader("unitcode"))) Then
                                                        If (CType(objDbDataReader("unitcode"), Integer) > -1) Then
                                                            strUnitcode = nsX10CM15AMethods.x10BinaryValueToDeviceCode(CType(objDbDataReader("unitcode"), Byte))
                                                        End If
                                                    End If

                                                    strTryStep = "extendedCommand"
                                                    If (Not Microsoft.VisualBasic.IsDBNull(objDbDataReader("extendedCommand"))) Then
                                                        If (CType(objDbDataReader("extendedCommand"), Integer) > -1) Then
                                                            bytExtendedCommand = CType(objDbDataReader("extendedCommand"), Byte)
                                                            objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(bytExtendedCommand)
                                                            strExtendedCommand = "[" & bytExtendedCommand.ToString() & "] " & objX10ExtendedCommand.commandDescription
                                                        End If
                                                    End If

                                                    strTryStep = "extendedData"
                                                    If (Not Microsoft.VisualBasic.IsDBNull(objDbDataReader("extendedData"))) Then
                                                        If (CType(objDbDataReader("extendedData"), Integer) > -1) Then
                                                            strExtendedData = CType(objDbDataReader("extendedData"), Byte).ToString()
                                                        End If
                                                    End If

                                            End Select ' END - commandSelectCase
                                        End If ' END - command = -1
                                    End If ' END - command

                                    strTryStep = "NewObjectDataGridViewRow"
                                    objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                                    strTryStep = "Add_AddEdit"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strAddEdit
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroID"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intMacroID.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    ' MacroCommands table
                                    strTryStep = "Add_MacroCommandID"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strMacroCommandID
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroCommandSort"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strMacroCommandSort
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_commandName"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strCommandName
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_house"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strHouse
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_unitcodeMaskOdd"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strUnitcodeMaskOdd
                                    ' Specific Day(s) as A mask of days
                                    objDataGridViewTextBoxCell.Style = New System.Windows.Forms.DataGridViewCellStyle
                                    objDataGridViewTextBoxCell.Style.BackColor = System.Drawing.Color.White
                                    objDataGridViewTextBoxCell.Style.Font = New System.Drawing.Font(System.Drawing.FontFamily.GenericMonospace, 8, System.Drawing.FontStyle.Regular)
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_unitcodeMaskEven"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strUnitcodeMaskEven
                                    ' Specific Day(s) as A mask of days
                                    objDataGridViewTextBoxCell.Style = New System.Windows.Forms.DataGridViewCellStyle
                                    objDataGridViewTextBoxCell.Style.BackColor = System.Drawing.Color.White
                                    objDataGridViewTextBoxCell.Style.Font = New System.Drawing.Font(System.Drawing.FontFamily.GenericMonospace, 8, System.Drawing.FontStyle.Regular)
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_prebrighten"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strPrebrightenYN
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_dimValue"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strDimValue
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_unitcode"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strUnitcode
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_extendedCommand"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strExtendedCommand
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_extendedData"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strExtendedData
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Rows.Add"
                                    formMacroAddUpdateMacroCommandsDataGridView.Rows.Add(objDataGridViewRow)

                                    objDataGridViewRow = Nothing
                                End While

                                strTryStep = "DataGridViewCurrentCellRowIndexFormMacroAddUpdateMacros"
                                intCurrentCellRowIndex = X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroAddUpdateMacroCommands

                                strTryStep = "DataGridViewFirstDisplayedCellRowIndexFormMacroAddUpdateMacros"
                                intFirstDisplayedCellRowIndex = X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroAddUpdateMacroCommands

                                strTryStep = "CheckForRestoreCursorPostion"
                                If (intCurrentCellRowIndex > -1 And intCurrentCellRowIndex < formMacroAddUpdateMacroCommandsDataGridView.Rows.Count And intFirstDisplayedCellRowIndex > -1) Then
                                    formMacroAddUpdateMacroCommandsDataGridView.FirstDisplayedScrollingRowIndex = intFirstDisplayedCellRowIndex
                                    formMacroAddUpdateMacroCommandsDataGridView.CurrentCell = formMacroAddUpdateMacroCommandsDataGridView.Rows(intCurrentCellRowIndex).Cells(0) ' Always restore to the first column.
                                End If

                            End If ' END - HasRows

                        End Using ' END - ExecuteReader

                    End Using ' END - CreateCommand

                    strTryStep = "Connection.Close"
                    objDbConnection.Close()

                End Using ' END - CreateConnection

            Else
                strTryStep = "NewMacroID"
                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroAddUpdateMacroCommands = -1
                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroAddUpdateMacroCommands = -1
            End If ' END - ExistingOrNewMacroID

        Catch ex As Exception
            strStatus = "formMacroAddUpdate_GetMacroCommandsDataSet(" & strTryStep & "): Exception: " & ex.Message & vbCrLf & sqlString
        Finally
            objX10ExtendedCommand = Nothing
            objDataGridViewTextBoxCell = Nothing
            objDataGridViewComboBoxCell = Nothing
            objDataGridViewRow = Nothing
            objDataGridViewColumn = Nothing
            objFactory = Nothing
        End Try

        Return strStatus

    End Function ' END - formMacroAddUpdate_GetMacroCommandsDataSet()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formMacroAddUpdateMacroCommandsDataGridView_CellClick(ByVal objSender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles formMacroAddUpdateMacroCommandsDataGridView.CellClick
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim strIDText As String = ""
        Dim bActiveFormFound = False
        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormMacroCommandAddUpdate As formMacroCommandAddUpdate = Nothing

        Dim objLocation As System.Drawing.Point = Nothing

        Dim intCurrentRow As Integer = -1

        Dim intColumnMacroCommandID As Integer = 2             ' Column that contains MacroCommandID.

        Try

            ' Save current Cursor Position.
            strTryStep = "CurrentCell"
            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros = formMacroAddUpdateMacroCommandsDataGridView.CurrentCell.RowIndex
            strTryStep = "FirstDisplayedCell"
            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros = formMacroAddUpdateMacroCommandsDataGridView.FirstDisplayedCell.RowIndex

            formMacroAddUpdate_BringToFrontLabel.Text() = "Y"

            strTryStep = "CurrentRow.Index"
            intCurrentRow = formMacroAddUpdateMacroCommandsDataGridView.CurrentRow.Index

            strTryStep = "CurrentRow"
            ' Including e.RowIndex >= 0 stops this from responding when Header Row is clicked.
            If (intCurrentRow >= 0 And e.RowIndex >= 0) Then
                ' Item(column, row)

                ' Get X10 MacroCommandID
                strTryStep = "GetMacroCommandID"
                strIDText = formMacroAddUpdateMacroCommandsDataGridView.Item(intColumnMacroCommandID, intCurrentRow).Value.ToString()

                strTryStep = "OfType"
                If objFormCollection.OfType(Of formMacroCommandAddUpdate).Any Then

                    If (strIDText = "-1") Then
                        ' Looking for already open Add form.

                        strTryStep = "ForEachAlreadyOpenAddForm"
                        For Each objFormMacroCommandAddUpdate In objFormCollection.OfType(Of formMacroCommandAddUpdate)
                            If (objFormMacroCommandAddUpdate.formMacroCommandAddUpdateIDLabelText.Text() = "") Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    Else

                        strTryStep = "ForEachAlreadyOpenUpdateForm"
                        For Each objFormMacroCommandAddUpdate In objFormCollection.OfType(Of formMacroCommandAddUpdate)
                            If (objFormMacroCommandAddUpdate.formMacroCommandAddUpdateIDLabelText.Text() = strIDText) Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    End If

                End If

                strTryStep = "bActiveFormFound"
                If bActiveFormFound Then
                    strTryStep = "Activate"
                    objFormMacroCommandAddUpdate.Activate()
                Else

                    strTryStep = "NewObjectFormMacroCommandAddUpdate"
                    objFormMacroCommandAddUpdate = Nothing
                    objFormMacroCommandAddUpdate = New formMacroCommandAddUpdate

                    ' Put X10 MacroInitiatorID
                    strTryStep = "PutMacroInitiatorID"
                    objFormMacroCommandAddUpdate.formMacroCommandAddUpdateMacroInitatorIDLabelText.Text() = formMacroAddUpdateMacroInitatorIDLabelText.Text()

                    ' Put X10 MacroInitiatorName
                    strTryStep = "PutMacroInitiatorName"
                    objFormMacroCommandAddUpdate.formMacroCommandAddUpdateMacroInInitatorNameLabelText.Text() = formMacroAddUpdateMacroInInitatorNameLabelText.Text()

                    ' Put X10 MacroID
                    strTryStep = "PutMacroID"
                    objFormMacroCommandAddUpdate.formMacroCommandAddUpdateMacroIDLabelText.Text() = formMacroAddUpdateIDLabelText.Text()

                    ' Put X10 MacroName
                    strTryStep = "PutMacroName"
                    objFormMacroCommandAddUpdate.formMacroCommandAddUpdateMacroNameLabelText.Text() = formMacroAddUpdateMacroNameTextBox.Text()

                    ' Put X10 MacroCommandID
                    strTryStep = "PutMacroCommandID"
                    objFormMacroCommandAddUpdate.formMacroCommandAddUpdateIDLabelText.Text() = strIDText

                    ' Set Calling Form Name (Class Name)
                    strTryStep = "SetClassName"
                    objFormMacroCommandAddUpdate.formMacroCommandAddUpdateCallingFormLabelText.Text() = "formMacroAddUpdate"

                    ' Opens as seperate form.
                    strTryStep = "TopLevel"
                    objFormMacroCommandAddUpdate.TopLevel = True

                    ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                    strTryStep = "Me.Location"
                    objLocation = New System.Drawing.Point
                    objLocation = Me.Location

                    ' Set additional offset for new form.
                    strTryStep = "Offset"
                    objLocation.Offset(100, 150)

                    ' Set default Location for new form to be Shown.
                    strTryStep = "formMacroCommandAddUpdate.Location"
                    objFormMacroCommandAddUpdate.Location = objLocation

                    strTryStep = "Show"
                    objFormMacroCommandAddUpdate.Show()

                End If

                objFormMacroCommandAddUpdate.BringToFront()

            End If

        Catch ex As Exception
            strStatus = "formMacroAddUpdateMacroCommandsDataGridView_CellClick(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroAddUpdateMacroCommandsDataGridView_CellClick()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormMacroCommandAddUpdate = Nothing
            objFormCollection = Nothing
        End Try

    End Sub ' END - formMacroAddUpdateMacroCommandsDataGridView_CellClick()

    Private Sub formMacroAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objDataRowViewSort As System.Data.DataRowView = Nothing

        Dim objX10DbMacro As TrekkerPhotoArt.X10Include.X10DbMacro = Nothing
        Dim objX10DbMacroTest As TrekkerPhotoArt.X10Include.X10DbMacro = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate = Nothing
        Dim objFormMacroAddUpdate As formMacroAddUpdate = Nothing

        Try

            formMacroAddUpdate_StatusLabel.Text = ""
            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString

            strTryStep = "ProviderName"
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "NewObjectX10DbMacro"
            objX10DbMacro = New TrekkerPhotoArt.X10Include.X10DbMacro


            strTryStep = "MissingMacroName"
            If (formMacroAddUpdateMacroNameTextBox.Text.Trim() = "") Then
                strStatus = "Missing Macro Name."
            Else
                strTryStep = "name"
                objX10DbMacro.name = formMacroAddUpdateMacroNameTextBox.Text().Trim()
            End If


            strTryStep = "delay"
            ' Max Value: 0x3FFF = 11 1111 1111 1111 = 16,383 seconds; 16,383/60 = 273 minutes, 3 seconds; 273/60 = 4 hours, 33 minutes, 3 seconds
            ' 16,200 seconds = 270 minutes; 270/60 = 4 hours, 30 minutes
            objX10DbMacro.delay = (formMacroAddUpdateDelayDateTimePicker.Value.TimeOfDay.Hours * 60 * 60) + (formMacroAddUpdateDelayDateTimePicker.Value.TimeOfDay.Minutes * 60) + formMacroAddUpdateDelayDateTimePicker.Value.TimeOfDay.Seconds
            If (objX10DbMacro.delay > 16200) Then
                strStatus = "Delay can not be greater than 4 hours, 30 minutes."
                formMacroAddUpdate_StatusLabel.Text = "Fail"
                formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formMacroAddUpdate_CancelButton.Text() = "Cancel"
                If (formMacroAddUpdate_AddUpdateButton.Text() = "Add") Then
                    Windows.Forms.MessageBox.Show("Problem adding Macro to X10 Db." & vbCrLf & strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                Else
                    Windows.Forms.MessageBox.Show("Problem modifying Macro to X10 Db." & vbCrLf & strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If
            End If


            ' Was Something Missing?
            If (strStatus = "") Then

                strTryStep = "nsX10DbMethods.getX10DbMacro"
                ' nsX10DbMethods.getX10DbMacro(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strMacroName As String, ByRef objX10DbMacro As TrekkerPhotoArt.X10Include.X10DbMacro) As String
                strError = nsX10DbMethods.getX10DbMacro(strConnectionString, strProvider, objX10DbMacro.name, objX10DbMacroTest)
                If (strError = "") Then

                    ' Was a Macro found?
                    strTryStep = "WasMacroFound"
                    If (Not objX10DbMacroTest Is Nothing AndAlso objX10DbMacroTest.MacroID >= 0) Then
                        ' A Macro was found with the specified Macro Name.

                        ' Add or Modify Macro?
                        strTryStep = "MacroFound_AddModifyMacro"
                        If (formMacroAddUpdate_AddUpdateButton.Text() = "Add") Then
                            strTryStep = "MacroFound_AddMacro"
                            strStatus = "Unable to Add the Macro. The Macro Name has already been used by another Macro."
                            Windows.Forms.MessageBox.Show(strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroAddUpdate_StatusLabel.Text = "Fail"
                            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else
                            ' Modify Macro

                            strTryStep = "MacroFound_ModifyMacro_MacroID"
                            objX10DbMacro.MacroID = CType(formMacroAddUpdateIDLabelText.Text(), Integer)

                            If (objX10DbMacroTest.MacroID <> objX10DbMacro.MacroID) Then
                                strStatus = "Unable to Update Macro information. The new Macro Name has already been used by another Macro."
                                Windows.Forms.MessageBox.Show(strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formMacroAddUpdate_StatusLabel.Text = "Fail"
                                formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        End If ' END - Add or Modify Macro?

                    Else
                        ' Nothing found.
                        strTryStep = "NothingFound_AddModifyMacro"

                        If (formMacroAddUpdate_AddUpdateButton.Text() = "Add") Then
                            ' Add Macro
                            objX10DbMacro.MacroID = -1
                        Else
                            ' Modify Macro
                            objX10DbMacro.MacroID = CType(formMacroAddUpdateIDLabelText.Text(), Integer)
                        End If ' END - Add or Modify Macro

                    End If ' END - Was a Macro found?

                Else
                    strStatus = "Problem determining if Macro Name has already been used." & vbCrLf & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formMacroAddUpdate_StatusLabel.Text = "Fail"
                    formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                End If ' END - nsX10DbMethods.getX10DbMacro()
                If (strStatus = "") Then

                    strTryStep = "description"
                    objX10DbMacro.description = formMacroAddUpdateDescriptionTextBox.Text().Trim()

                    strTryStep = "MacroInitiatorID"
                    objX10DbMacro.MacroInitiatorID = CType(formMacroAddUpdateMacroInitatorIDLabelText.Text(), Integer)


                    strTryStep = "DataRowViewSort"
                    objDataRowViewSort = formMacroAddUpdateMacroSortOrderComboBox.SelectedItem

                    strTryStep = "MacroSort"
                    objX10DbMacro.MacroSort = CType(objDataRowViewSort.Row("ValueMember").ToString(), Integer)


                    strTryStep = "flag"
                    objX10DbMacro.flag = 0

                    strTryStep = "RF"
                    If (formMacroAddUpdateRfOnRadioButton.Checked) Then
                        objX10DbMacro.RF = 1
                    Else
                        objX10DbMacro.RF = 0
                    End If

                    strTryStep = "inhibitRetrigger"
                    If (formMacroAddUpdateInhibitRetriggerOnRadioButton.Checked) Then
                        objX10DbMacro.inhibitRetrigger = 1
                    Else
                        objX10DbMacro.inhibitRetrigger = 0
                    End If

                    strTryStep = "nsX10DbMethods.addUpdateMacroToX10db"
                    ' nsX10DbMethods.addUpdateMacroToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbMacro As TrekkerPhotoArt.X10Include.X10DbMacro, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.addUpdateMacroToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbMacro, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then
                            formMacroAddUpdateIDLabelText.Text() = objX10DbMacro.MacroID.ToString()

                            If (formMacroAddUpdate_AddUpdateButton.Text() = "Add") Then
                                formMacroAddUpdate_AddUpdateButton.Text() = "Update"
                                formMacroAddUpdate_StatusLabel.Text = "Successfully Added"
                                formMacroAddUpdate_DeleteButton.Visible = True

                                formMacroAddUpdateMacroCommandsLabel.Visible = True
                                formMacroAddUpdateMacroCommandsLabel.Text() = "Macro Commands"

                                strTryStep = "formMacroAddUpdate_GetMacroCommandsDataSet"
                                ' formMacroAddUpdate_GetMacroCommandsDataSet(ByVal intMacroID As Integer) As String
                                strStatus = formMacroAddUpdate_GetMacroCommandsDataSet(objX10DbMacro.MacroID)
                                If (strStatus = "") Then
                                    formMacroAddUpdateMacroCommandsDataGridView.Visible = True
                                    formMacroAddUpdateMacroCommandsDataGridView.Enabled = True
                                Else
                                    Windows.Forms.MessageBox.Show("formMacroAddUpdate_AddUpdateButton_Click(): " & strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formMacroAddUpdate_StatusLabel.Text = "Fail"
                                    formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formMacroAddUpdate_CancelButton.Text() = "Cancel"
                                End If

                            Else
                                formMacroAddUpdate_StatusLabel.Text = "Successfully Updated"
                            End If

                            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formMacroAddUpdate_CancelButton.Text() = "Done"


                            ' Refresh "Macros" DataSet on Calling Form formMacroInitiatorAddUpdate.
                            strTryStep = "RefreshMacrosDataSetOnCallingFormFormMacroInitiatorAddUpdate"
                            For Each objFormMacroInitiatorAddUpdate In objFormCollection.OfType(Of formMacroInitiatorAddUpdate)

                                If (objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdateIDLabelText.Text() = objX10DbMacro.MacroInitiatorID.ToString()) Then

                                    objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdate_BringToFrontLabel.Text() = "N"

                                    ' formMacroInitiatorAddUpdate_GetMacrosDataSet(ByVal intMacroInitiatorID As Integer) As String
                                    strStatus = objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdate_GetMacrosDataSet(objX10DbMacro.MacroInitiatorID)
                                    If (strStatus = "") Then
                                        objFormMacroInitiatorAddUpdate.Activate()
                                    Else
                                        Windows.Forms.MessageBox.Show("formMacroAddUpdate_AddUpdateButton_Click(): " & strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    End If ' END - formMacroInitiatorAddUpdate_GetMacrosDataSet()

                                    Exit For
                                End If

                            Next ' END - RefreshMacrosDataSetOnCallingFormFormMacroInitiatorAddUpdate


                            Me.BringToFront()

                        Else
                            formMacroAddUpdate_StatusLabel.Text = "Fail"
                            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroAddUpdate_CancelButton.Text() = "Cancel"
                            If (formMacroAddUpdate_AddUpdateButton.Text() = "Add") Then
                                Windows.Forms.MessageBox.Show("Problem adding Macro to X10 Db.", "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Else
                                Windows.Forms.MessageBox.Show("Problem modifying Macro to X10 Db.", "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If
                        End If ' END - RowsAffected

                    Else
                        formMacroAddUpdate_StatusLabel.Text = "Fail"
                        formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroAddUpdate_CancelButton.Text() = "Cancel"
                        If (formMacroAddUpdate_AddUpdateButton.Text() = "Add") Then
                            Windows.Forms.MessageBox.Show("Problem adding Macro to X10 Db." & vbCrLf & strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Else
                            Windows.Forms.MessageBox.Show("Problem modifying Macro to X10 Db." & vbCrLf & strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If
                    End If ' END - nsX10DbMethods.addUpdateMacroToX10db()

                End If ' END - nsX10DbMethods.getX10DbMacro(Status)

            End If ' END - Was Something Missing?

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "formMacroAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            End If

            Windows.Forms.MessageBox.Show(strStatus, "formMacroAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroAddUpdate_StatusLabel.Text = "Fail"
            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormMacroInitiatorAddUpdate = Nothing
            objFormMacroAddUpdate = Nothing
            objX10DbMacro = Nothing
            objX10DbMacroTest = Nothing
            objDataRowViewSort = Nothing
        End Try

    End Sub ' END - formMacroAddUpdate_AddUpdateButton_Click()

    Private Sub formMacroAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formMacroAddUpdate_CancelButton_Click()

    Private Sub formMacroAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim intMacroID As Integer = Nothing
        Dim intMacroInitiatorID As Integer = -1

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate = Nothing

        Try

            formMacroAddUpdate_StatusLabel.Text = ""
            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            If (formMacroAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing MacroID", "formMacroAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                intMacroID = CType(formMacroAddUpdateIDLabelText.Text(), Integer)

                ' nsX10DbMethods.removeMacroFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef intMacroID As Integer, ByRef intRowsAffected As Integer) As String
                strStatus = nsX10DbMethods.removeMacroFromX10Db(strConnectionString, strProvider, intMacroID, intRowsAffected)
                If (strStatus = "") Then

                    If (intRowsAffected > 0) Then

                        formMacroAddUpdateIDLabelText.Text() = ""
                        formMacroAddUpdate_AddUpdateButton.Text() = "Add"
                        formMacroAddUpdate_StatusLabel.Text = "Successfully Deleted"
                        formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                        formMacroAddUpdate_CancelButton.Text() = "Done"
                        formMacroAddUpdate_DeleteButton.Visible = False

                        formMacroAddUpdateMacroCommandsLabel.Visible = True
                        formMacroAddUpdateMacroCommandsLabel.Text() = "Macro Commands - New Macro must first be added."
                        formMacroAddUpdateMacroCommandsDataGridView.Rows.Clear()
                        formMacroAddUpdateMacroCommandsDataGridView.Visible = True
                        formMacroAddUpdateMacroCommandsDataGridView.Enabled = False

                        X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroAddUpdateMacroCommands = -1
                        X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroAddUpdateMacroCommands = -1


                        ' Refresh "Macros" DataSet on Calling Form formMacroInitiatorAddUpdate if it's active.
                        intMacroInitiatorID = CType(formMacroAddUpdateMacroInitatorIDLabelText.Text(), Integer)
                        For Each objFormMacroInitiatorAddUpdate In objFormCollection.OfType(Of formMacroInitiatorAddUpdate)

                            If (objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdateIDLabelText.Text() = intMacroInitiatorID.ToString()) Then

                                objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdate_BringToFrontLabel.Text() = "N"

                                ' The row has been deleted.
                                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros = -1
                                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros = -1

                                ' formMacroInitiatorAddUpdate_GetMacrosDataSet(ByVal intMacroInitiatorID As Integer) As String
                                strStatus = objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdate_GetMacrosDataSet(intMacroInitiatorID)
                                If (strStatus = "") Then
                                    objFormMacroInitiatorAddUpdate.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formMacroAddUpdate_DeleteButton_Click(): " & strStatus, "formMacroAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formMacroInitiatorAddUpdate_GetMacrosDataSet()

                                Exit For
                            End If

                        Next


                        Me.BringToFront()

                    Else
                        formMacroAddUpdate_StatusLabel.Text = "Fail"
                        formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Macro from X10 Db.", "formMacroAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - RowsAffected

                Else
                    formMacroAddUpdate_StatusLabel.Text = "Fail"
                    formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formMacroAddUpdate_CancelButton.Text() = "Cancel"
                    Windows.Forms.MessageBox.Show("Problem removing Macro from X10 Db." & vbCrLf & strStatus, "formMacroAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - nsX10DbMethods.removeMacroFromX10Db

            End If ' END - Is there a MacroID?

        Catch ex As Exception
            strStatus = "formMacroAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroAddUpdate_StatusLabel.Text = "Fail"
            formMacroAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormMacroInitiatorAddUpdate = Nothing
        End Try

    End Sub ' END - formMacroAddUpdate_DeleteButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formMacroAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMacroAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formMacroAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(800, 670)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationMacroAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationMacroAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationMacroAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formMacroAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formMacroAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formMacroAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMacroAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formMacroAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationMacroAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationMacroAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formMacroAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formMacroAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formMacroAddUpdate