﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formControllerAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formControllerAddUpdate))
        Me.formControllerAddUpdateModelComboBox = New System.Windows.Forms.ComboBox()
        Me.formControllerAddUpdateNameLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateModelLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateNameTextBox = New System.Windows.Forms.TextBox()
        Me.formControllerAddUpdatePortLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateIDLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formControllerAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdateAppKeyLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateUIDLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateAppKeyTextBox = New System.Windows.Forms.TextBox()
        Me.formControllerAddUpdateUIDTextBox = New System.Windows.Forms.TextBox()
        Me.formControllerAddUpdatePortInfoLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateDescriptionLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.formControllerAddUpdatePortValueLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdatePortComboBox = New System.Windows.Forms.ComboBox()
        Me.formControllerAddUpdateHouseCodeLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateHouseCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formControllerAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdate_GetStatusButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdate_SetBaseHouseCodeButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdate_SetClockButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdate_DownloadButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdateOperationsGroupBox = New System.Windows.Forms.GroupBox()
        Me.formControllerAddUpdate_ClearButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdate_ExportButton = New System.Windows.Forms.Button()
        Me.formControllerAddUpdateSetClockText2Label = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateSetClockText1Label = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateHouseCodeInfoLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateDuskDawnResolutionLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateDuskDawnResolutionComboBox = New System.Windows.Forms.ComboBox()
        Me.formControllerAddUpdateTransceiverHouseCodesPanel = New System.Windows.Forms.Panel()
        Me.formControllerAddUpdateHouseCodePCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeNCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeLCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeJCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeHCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeFCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeDCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeBCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeOCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeMCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeKCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeICheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeGCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeECheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeCCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateHouseCodeACheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateTransceiverHouseCodesLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdate_SaveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.formControllerAddUpdateActiveCheckBox = New System.Windows.Forms.CheckBox()
        Me.formControllerAddUpdateMacroSupportLabelText = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateMacroSupportLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateExtendedCommandsLabelText = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateExtendedCommandsLabel = New System.Windows.Forms.Label()
        Me.formControllerAddUpdateOperationsGroupBox.SuspendLayout()
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'formControllerAddUpdateModelComboBox
        '
        Me.formControllerAddUpdateModelComboBox.FormattingEnabled = True
        Me.formControllerAddUpdateModelComboBox.Location = New System.Drawing.Point(128, 77)
        Me.formControllerAddUpdateModelComboBox.Name = "formControllerAddUpdateModelComboBox"
        Me.formControllerAddUpdateModelComboBox.Size = New System.Drawing.Size(127, 21)
        Me.formControllerAddUpdateModelComboBox.TabIndex = 0
        '
        'formControllerAddUpdateNameLabel
        '
        Me.formControllerAddUpdateNameLabel.AutoSize = True
        Me.formControllerAddUpdateNameLabel.Location = New System.Drawing.Point(84, 21)
        Me.formControllerAddUpdateNameLabel.Name = "formControllerAddUpdateNameLabel"
        Me.formControllerAddUpdateNameLabel.Size = New System.Drawing.Size(38, 13)
        Me.formControllerAddUpdateNameLabel.TabIndex = 1
        Me.formControllerAddUpdateNameLabel.Text = "Name:"
        '
        'formControllerAddUpdateModelLabel
        '
        Me.formControllerAddUpdateModelLabel.AutoSize = True
        Me.formControllerAddUpdateModelLabel.Location = New System.Drawing.Point(83, 80)
        Me.formControllerAddUpdateModelLabel.Name = "formControllerAddUpdateModelLabel"
        Me.formControllerAddUpdateModelLabel.Size = New System.Drawing.Size(39, 13)
        Me.formControllerAddUpdateModelLabel.TabIndex = 2
        Me.formControllerAddUpdateModelLabel.Text = "Model:"
        '
        'formControllerAddUpdateNameTextBox
        '
        Me.formControllerAddUpdateNameTextBox.Location = New System.Drawing.Point(128, 18)
        Me.formControllerAddUpdateNameTextBox.MaxLength = 32
        Me.formControllerAddUpdateNameTextBox.Name = "formControllerAddUpdateNameTextBox"
        Me.formControllerAddUpdateNameTextBox.Size = New System.Drawing.Size(299, 20)
        Me.formControllerAddUpdateNameTextBox.TabIndex = 3
        Me.formControllerAddUpdateNameTextBox.Text = "formControllerAddUpdateNameTextBox"
        Me.formControllerAddUpdateNameTextBox.WordWrap = False
        '
        'formControllerAddUpdatePortLabel
        '
        Me.formControllerAddUpdatePortLabel.AutoSize = True
        Me.formControllerAddUpdatePortLabel.Location = New System.Drawing.Point(93, 211)
        Me.formControllerAddUpdatePortLabel.Name = "formControllerAddUpdatePortLabel"
        Me.formControllerAddUpdatePortLabel.Size = New System.Drawing.Size(29, 13)
        Me.formControllerAddUpdatePortLabel.TabIndex = 5
        Me.formControllerAddUpdatePortLabel.Text = "Port:"
        '
        'formControllerAddUpdateIDLabel
        '
        Me.formControllerAddUpdateIDLabel.AutoSize = True
        Me.formControllerAddUpdateIDLabel.Location = New System.Drawing.Point(103, 50)
        Me.formControllerAddUpdateIDLabel.Name = "formControllerAddUpdateIDLabel"
        Me.formControllerAddUpdateIDLabel.Size = New System.Drawing.Size(24, 13)
        Me.formControllerAddUpdateIDLabel.TabIndex = 6
        Me.formControllerAddUpdateIDLabel.Text = "ID: "
        '
        'formControllerAddUpdateIDLabelText
        '
        Me.formControllerAddUpdateIDLabelText.AutoSize = True
        Me.formControllerAddUpdateIDLabelText.Location = New System.Drawing.Point(128, 50)
        Me.formControllerAddUpdateIDLabelText.Name = "formControllerAddUpdateIDLabelText"
        Me.formControllerAddUpdateIDLabelText.Size = New System.Drawing.Size(183, 13)
        Me.formControllerAddUpdateIDLabelText.TabIndex = 7
        Me.formControllerAddUpdateIDLabelText.Text = "formControllerAddUpdateIDLabelText"
        '
        'formControllerAddUpdate_AddUpdateButton
        '
        Me.formControllerAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(68, 393)
        Me.formControllerAddUpdate_AddUpdateButton.Name = "formControllerAddUpdate_AddUpdateButton"
        Me.formControllerAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(88, 23)
        Me.formControllerAddUpdate_AddUpdateButton.TabIndex = 8
        Me.formControllerAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formControllerAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdate_CancelButton
        '
        Me.formControllerAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formControllerAddUpdate_CancelButton.Location = New System.Drawing.Point(352, 393)
        Me.formControllerAddUpdate_CancelButton.Name = "formControllerAddUpdate_CancelButton"
        Me.formControllerAddUpdate_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formControllerAddUpdate_CancelButton.TabIndex = 9
        Me.formControllerAddUpdate_CancelButton.Text = "Cancel"
        Me.formControllerAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateAppKeyLabel
        '
        Me.formControllerAddUpdateAppKeyLabel.AutoSize = True
        Me.formControllerAddUpdateAppKeyLabel.Location = New System.Drawing.Point(77, 238)
        Me.formControllerAddUpdateAppKeyLabel.Name = "formControllerAddUpdateAppKeyLabel"
        Me.formControllerAddUpdateAppKeyLabel.Size = New System.Drawing.Size(47, 13)
        Me.formControllerAddUpdateAppKeyLabel.TabIndex = 10
        Me.formControllerAddUpdateAppKeyLabel.Text = "AppKey:"
        '
        'formControllerAddUpdateUIDLabel
        '
        Me.formControllerAddUpdateUIDLabel.AutoSize = True
        Me.formControllerAddUpdateUIDLabel.Location = New System.Drawing.Point(93, 264)
        Me.formControllerAddUpdateUIDLabel.Name = "formControllerAddUpdateUIDLabel"
        Me.formControllerAddUpdateUIDLabel.Size = New System.Drawing.Size(29, 13)
        Me.formControllerAddUpdateUIDLabel.TabIndex = 11
        Me.formControllerAddUpdateUIDLabel.Text = "UID:"
        '
        'formControllerAddUpdateAppKeyTextBox
        '
        Me.formControllerAddUpdateAppKeyTextBox.Location = New System.Drawing.Point(128, 235)
        Me.formControllerAddUpdateAppKeyTextBox.MaxLength = 20
        Me.formControllerAddUpdateAppKeyTextBox.Name = "formControllerAddUpdateAppKeyTextBox"
        Me.formControllerAddUpdateAppKeyTextBox.Size = New System.Drawing.Size(127, 20)
        Me.formControllerAddUpdateAppKeyTextBox.TabIndex = 13
        Me.formControllerAddUpdateAppKeyTextBox.Text = "26d884ce-9f25-948537"
        '
        'formControllerAddUpdateUIDTextBox
        '
        Me.formControllerAddUpdateUIDTextBox.Location = New System.Drawing.Point(128, 261)
        Me.formControllerAddUpdateUIDTextBox.MaxLength = 34
        Me.formControllerAddUpdateUIDTextBox.Name = "formControllerAddUpdateUIDTextBox"
        Me.formControllerAddUpdateUIDTextBox.Size = New System.Drawing.Size(219, 20)
        Me.formControllerAddUpdateUIDTextBox.TabIndex = 14
        Me.formControllerAddUpdateUIDTextBox.Text = "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"
        '
        'formControllerAddUpdatePortInfoLabel
        '
        Me.formControllerAddUpdatePortInfoLabel.AutoSize = True
        Me.formControllerAddUpdatePortInfoLabel.Location = New System.Drawing.Point(261, 211)
        Me.formControllerAddUpdatePortInfoLabel.Name = "formControllerAddUpdatePortInfoLabel"
        Me.formControllerAddUpdatePortInfoLabel.Size = New System.Drawing.Size(116, 13)
        Me.formControllerAddUpdatePortInfoLabel.TabIndex = 15
        Me.formControllerAddUpdatePortInfoLabel.Text = "RS232 / USB Port Info"
        '
        'formControllerAddUpdateDescriptionLabel
        '
        Me.formControllerAddUpdateDescriptionLabel.AutoSize = True
        Me.formControllerAddUpdateDescriptionLabel.Location = New System.Drawing.Point(59, 107)
        Me.formControllerAddUpdateDescriptionLabel.Name = "formControllerAddUpdateDescriptionLabel"
        Me.formControllerAddUpdateDescriptionLabel.Size = New System.Drawing.Size(63, 13)
        Me.formControllerAddUpdateDescriptionLabel.TabIndex = 16
        Me.formControllerAddUpdateDescriptionLabel.Text = "Description:"
        '
        'formControllerAddUpdateDescriptionTextBox
        '
        Me.formControllerAddUpdateDescriptionTextBox.Location = New System.Drawing.Point(128, 104)
        Me.formControllerAddUpdateDescriptionTextBox.MaxLength = 128
        Me.formControllerAddUpdateDescriptionTextBox.Name = "formControllerAddUpdateDescriptionTextBox"
        Me.formControllerAddUpdateDescriptionTextBox.Size = New System.Drawing.Size(310, 20)
        Me.formControllerAddUpdateDescriptionTextBox.TabIndex = 17
        '
        'formControllerAddUpdatePortValueLabel
        '
        Me.formControllerAddUpdatePortValueLabel.AutoSize = True
        Me.formControllerAddUpdatePortValueLabel.Location = New System.Drawing.Point(430, 211)
        Me.formControllerAddUpdatePortValueLabel.Name = "formControllerAddUpdatePortValueLabel"
        Me.formControllerAddUpdatePortValueLabel.Size = New System.Drawing.Size(37, 13)
        Me.formControllerAddUpdatePortValueLabel.TabIndex = 18
        Me.formControllerAddUpdatePortValueLabel.Text = "COMn"
        Me.formControllerAddUpdatePortValueLabel.Visible = False
        '
        'formControllerAddUpdatePortComboBox
        '
        Me.formControllerAddUpdatePortComboBox.FormattingEnabled = True
        Me.formControllerAddUpdatePortComboBox.Location = New System.Drawing.Point(128, 208)
        Me.formControllerAddUpdatePortComboBox.Name = "formControllerAddUpdatePortComboBox"
        Me.formControllerAddUpdatePortComboBox.Size = New System.Drawing.Size(127, 21)
        Me.formControllerAddUpdatePortComboBox.TabIndex = 19
        '
        'formControllerAddUpdateHouseCodeLabel
        '
        Me.formControllerAddUpdateHouseCodeLabel.AutoSize = True
        Me.formControllerAddUpdateHouseCodeLabel.Location = New System.Drawing.Point(53, 184)
        Me.formControllerAddUpdateHouseCodeLabel.Name = "formControllerAddUpdateHouseCodeLabel"
        Me.formControllerAddUpdateHouseCodeLabel.Size = New System.Drawing.Size(69, 13)
        Me.formControllerAddUpdateHouseCodeLabel.TabIndex = 20
        Me.formControllerAddUpdateHouseCodeLabel.Text = "House Code:"
        '
        'formControllerAddUpdateHouseCodeComboBox
        '
        Me.formControllerAddUpdateHouseCodeComboBox.FormattingEnabled = True
        Me.formControllerAddUpdateHouseCodeComboBox.Location = New System.Drawing.Point(128, 181)
        Me.formControllerAddUpdateHouseCodeComboBox.Name = "formControllerAddUpdateHouseCodeComboBox"
        Me.formControllerAddUpdateHouseCodeComboBox.Size = New System.Drawing.Size(127, 21)
        Me.formControllerAddUpdateHouseCodeComboBox.TabIndex = 21
        '
        'formControllerAddUpdate_StatusLabel
        '
        Me.formControllerAddUpdate_StatusLabel.AutoSize = True
        Me.formControllerAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formControllerAddUpdate_StatusLabel.Location = New System.Drawing.Point(162, 396)
        Me.formControllerAddUpdate_StatusLabel.Name = "formControllerAddUpdate_StatusLabel"
        Me.formControllerAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formControllerAddUpdate_StatusLabel.TabIndex = 22
        Me.formControllerAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formControllerAddUpdate_DeleteButton
        '
        Me.formControllerAddUpdate_DeleteButton.Location = New System.Drawing.Point(352, 45)
        Me.formControllerAddUpdate_DeleteButton.Name = "formControllerAddUpdate_DeleteButton"
        Me.formControllerAddUpdate_DeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.formControllerAddUpdate_DeleteButton.TabIndex = 23
        Me.formControllerAddUpdate_DeleteButton.Text = "Delete"
        Me.formControllerAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdate_GetStatusButton
        '
        Me.formControllerAddUpdate_GetStatusButton.Location = New System.Drawing.Point(12, 19)
        Me.formControllerAddUpdate_GetStatusButton.Name = "formControllerAddUpdate_GetStatusButton"
        Me.formControllerAddUpdate_GetStatusButton.Size = New System.Drawing.Size(75, 23)
        Me.formControllerAddUpdate_GetStatusButton.TabIndex = 24
        Me.formControllerAddUpdate_GetStatusButton.Text = "Get Status"
        Me.formControllerAddUpdate_GetStatusButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdate_SetBaseHouseCodeButton
        '
        Me.formControllerAddUpdate_SetBaseHouseCodeButton.Location = New System.Drawing.Point(240, 19)
        Me.formControllerAddUpdate_SetBaseHouseCodeButton.Name = "formControllerAddUpdate_SetBaseHouseCodeButton"
        Me.formControllerAddUpdate_SetBaseHouseCodeButton.Size = New System.Drawing.Size(131, 23)
        Me.formControllerAddUpdate_SetBaseHouseCodeButton.TabIndex = 30
        Me.formControllerAddUpdate_SetBaseHouseCodeButton.Text = "Set Base House Code"
        Me.formControllerAddUpdate_SetBaseHouseCodeButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdate_SetClockButton
        '
        Me.formControllerAddUpdate_SetClockButton.Location = New System.Drawing.Point(106, 19)
        Me.formControllerAddUpdate_SetClockButton.Name = "formControllerAddUpdate_SetClockButton"
        Me.formControllerAddUpdate_SetClockButton.Size = New System.Drawing.Size(75, 23)
        Me.formControllerAddUpdate_SetClockButton.TabIndex = 26
        Me.formControllerAddUpdate_SetClockButton.Text = "Set Clock"
        Me.formControllerAddUpdate_SetClockButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdate_DownloadButton
        '
        Me.formControllerAddUpdate_DownloadButton.Location = New System.Drawing.Point(12, 57)
        Me.formControllerAddUpdate_DownloadButton.Name = "formControllerAddUpdate_DownloadButton"
        Me.formControllerAddUpdate_DownloadButton.Size = New System.Drawing.Size(359, 23)
        Me.formControllerAddUpdate_DownloadButton.TabIndex = 27
        Me.formControllerAddUpdate_DownloadButton.Text = "Download Events to Controller"
        Me.formControllerAddUpdate_DownloadButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateOperationsGroupBox
        '
        Me.formControllerAddUpdateOperationsGroupBox.BackColor = System.Drawing.SystemColors.Control
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdate_ClearButton)
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdate_ExportButton)
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdateSetClockText2Label)
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdate_SetBaseHouseCodeButton)
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdateSetClockText1Label)
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdate_DownloadButton)
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdate_GetStatusButton)
        Me.formControllerAddUpdateOperationsGroupBox.Controls.Add(Me.formControllerAddUpdate_SetClockButton)
        Me.formControllerAddUpdateOperationsGroupBox.Location = New System.Drawing.Point(56, 422)
        Me.formControllerAddUpdateOperationsGroupBox.Name = "formControllerAddUpdateOperationsGroupBox"
        Me.formControllerAddUpdateOperationsGroupBox.Size = New System.Drawing.Size(382, 118)
        Me.formControllerAddUpdateOperationsGroupBox.TabIndex = 28
        Me.formControllerAddUpdateOperationsGroupBox.TabStop = False
        '
        'formControllerAddUpdate_ClearButton
        '
        Me.formControllerAddUpdate_ClearButton.Location = New System.Drawing.Point(12, 86)
        Me.formControllerAddUpdate_ClearButton.Name = "formControllerAddUpdate_ClearButton"
        Me.formControllerAddUpdate_ClearButton.Size = New System.Drawing.Size(163, 23)
        Me.formControllerAddUpdate_ClearButton.TabIndex = 62
        Me.formControllerAddUpdate_ClearButton.Text = "Clear Controller Memory"
        Me.formControllerAddUpdate_ClearButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdate_ExportButton
        '
        Me.formControllerAddUpdate_ExportButton.Location = New System.Drawing.Point(208, 86)
        Me.formControllerAddUpdate_ExportButton.Name = "formControllerAddUpdate_ExportButton"
        Me.formControllerAddUpdate_ExportButton.Size = New System.Drawing.Size(163, 23)
        Me.formControllerAddUpdate_ExportButton.TabIndex = 32
        Me.formControllerAddUpdate_ExportButton.Text = "Export Controller Memory to File"
        Me.formControllerAddUpdate_ExportButton.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateSetClockText2Label
        '
        Me.formControllerAddUpdateSetClockText2Label.AutoSize = True
        Me.formControllerAddUpdateSetClockText2Label.Location = New System.Drawing.Point(180, 32)
        Me.formControllerAddUpdateSetClockText2Label.Name = "formControllerAddUpdateSetClockText2Label"
        Me.formControllerAddUpdateSetClockText2Label.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.formControllerAddUpdateSetClockText2Label.Size = New System.Drawing.Size(201, 13)
        Me.formControllerAddUpdateSetClockText2Label.TabIndex = 31
        Me.formControllerAddUpdateSetClockText2Label.Text = "Monitored and Transceiver House Codes"
        Me.formControllerAddUpdateSetClockText2Label.Visible = False
        '
        'formControllerAddUpdateSetClockText1Label
        '
        Me.formControllerAddUpdateSetClockText1Label.AutoSize = True
        Me.formControllerAddUpdateSetClockText1Label.Location = New System.Drawing.Point(180, 19)
        Me.formControllerAddUpdateSetClockText1Label.Name = "formControllerAddUpdateSetClockText1Label"
        Me.formControllerAddUpdateSetClockText1Label.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.formControllerAddUpdateSetClockText1Label.Size = New System.Drawing.Size(159, 13)
        Me.formControllerAddUpdateSetClockText1Label.TabIndex = 28
        Me.formControllerAddUpdateSetClockText1Label.Text = """Set Clock"" also sets Controllers"
        Me.formControllerAddUpdateSetClockText1Label.Visible = False
        '
        'formControllerAddUpdateHouseCodeInfoLabel
        '
        Me.formControllerAddUpdateHouseCodeInfoLabel.AutoSize = True
        Me.formControllerAddUpdateHouseCodeInfoLabel.Location = New System.Drawing.Point(261, 184)
        Me.formControllerAddUpdateHouseCodeInfoLabel.Name = "formControllerAddUpdateHouseCodeInfoLabel"
        Me.formControllerAddUpdateHouseCodeInfoLabel.Size = New System.Drawing.Size(136, 13)
        Me.formControllerAddUpdateHouseCodeInfoLabel.TabIndex = 29
        Me.formControllerAddUpdateHouseCodeInfoLabel.Text = "Controller Base / Monitored"
        '
        'formControllerAddUpdateDuskDawnResolutionLabel
        '
        Me.formControllerAddUpdateDuskDawnResolutionLabel.AutoSize = True
        Me.formControllerAddUpdateDuskDawnResolutionLabel.Location = New System.Drawing.Point(103, 360)
        Me.formControllerAddUpdateDuskDawnResolutionLabel.Name = "formControllerAddUpdateDuskDawnResolutionLabel"
        Me.formControllerAddUpdateDuskDawnResolutionLabel.Size = New System.Drawing.Size(121, 13)
        Me.formControllerAddUpdateDuskDawnResolutionLabel.TabIndex = 31
        Me.formControllerAddUpdateDuskDawnResolutionLabel.Text = "Dusk/Dawn Resolution:"
        '
        'formControllerAddUpdateDuskDawnResolutionComboBox
        '
        Me.formControllerAddUpdateDuskDawnResolutionComboBox.FormattingEnabled = True
        Me.formControllerAddUpdateDuskDawnResolutionComboBox.Location = New System.Drawing.Point(230, 357)
        Me.formControllerAddUpdateDuskDawnResolutionComboBox.Name = "formControllerAddUpdateDuskDawnResolutionComboBox"
        Me.formControllerAddUpdateDuskDawnResolutionComboBox.Size = New System.Drawing.Size(117, 21)
        Me.formControllerAddUpdateDuskDawnResolutionComboBox.TabIndex = 32
        '
        'formControllerAddUpdateTransceiverHouseCodesPanel
        '
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodePCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeNCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeLCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeJCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeHCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeFCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeDCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeBCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeOCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeMCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeKCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeICheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeGCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeECheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeCCheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Controls.Add(Me.formControllerAddUpdateHouseCodeACheckBox)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Location = New System.Drawing.Point(56, 308)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Name = "formControllerAddUpdateTransceiverHouseCodesPanel"
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.Size = New System.Drawing.Size(382, 43)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.TabIndex = 33
        '
        'formControllerAddUpdateHouseCodePCheckBox
        '
        Me.formControllerAddUpdateHouseCodePCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodePCheckBox.Location = New System.Drawing.Point(304, 25)
        Me.formControllerAddUpdateHouseCodePCheckBox.Name = "formControllerAddUpdateHouseCodePCheckBox"
        Me.formControllerAddUpdateHouseCodePCheckBox.Size = New System.Drawing.Size(33, 17)
        Me.formControllerAddUpdateHouseCodePCheckBox.TabIndex = 60
        Me.formControllerAddUpdateHouseCodePCheckBox.Text = "P"
        Me.formControllerAddUpdateHouseCodePCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeNCheckBox
        '
        Me.formControllerAddUpdateHouseCodeNCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeNCheckBox.Location = New System.Drawing.Point(265, 25)
        Me.formControllerAddUpdateHouseCodeNCheckBox.Name = "formControllerAddUpdateHouseCodeNCheckBox"
        Me.formControllerAddUpdateHouseCodeNCheckBox.Size = New System.Drawing.Size(34, 17)
        Me.formControllerAddUpdateHouseCodeNCheckBox.TabIndex = 59
        Me.formControllerAddUpdateHouseCodeNCheckBox.Text = "N"
        Me.formControllerAddUpdateHouseCodeNCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeLCheckBox
        '
        Me.formControllerAddUpdateHouseCodeLCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeLCheckBox.Location = New System.Drawing.Point(226, 25)
        Me.formControllerAddUpdateHouseCodeLCheckBox.Name = "formControllerAddUpdateHouseCodeLCheckBox"
        Me.formControllerAddUpdateHouseCodeLCheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formControllerAddUpdateHouseCodeLCheckBox.TabIndex = 58
        Me.formControllerAddUpdateHouseCodeLCheckBox.Text = "L"
        Me.formControllerAddUpdateHouseCodeLCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeJCheckBox
        '
        Me.formControllerAddUpdateHouseCodeJCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeJCheckBox.Location = New System.Drawing.Point(187, 25)
        Me.formControllerAddUpdateHouseCodeJCheckBox.Name = "formControllerAddUpdateHouseCodeJCheckBox"
        Me.formControllerAddUpdateHouseCodeJCheckBox.Size = New System.Drawing.Size(31, 17)
        Me.formControllerAddUpdateHouseCodeJCheckBox.TabIndex = 57
        Me.formControllerAddUpdateHouseCodeJCheckBox.Text = "J"
        Me.formControllerAddUpdateHouseCodeJCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeHCheckBox
        '
        Me.formControllerAddUpdateHouseCodeHCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeHCheckBox.Location = New System.Drawing.Point(148, 25)
        Me.formControllerAddUpdateHouseCodeHCheckBox.Name = "formControllerAddUpdateHouseCodeHCheckBox"
        Me.formControllerAddUpdateHouseCodeHCheckBox.Size = New System.Drawing.Size(34, 17)
        Me.formControllerAddUpdateHouseCodeHCheckBox.TabIndex = 56
        Me.formControllerAddUpdateHouseCodeHCheckBox.Text = "H"
        Me.formControllerAddUpdateHouseCodeHCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeFCheckBox
        '
        Me.formControllerAddUpdateHouseCodeFCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeFCheckBox.Location = New System.Drawing.Point(109, 25)
        Me.formControllerAddUpdateHouseCodeFCheckBox.Name = "formControllerAddUpdateHouseCodeFCheckBox"
        Me.formControllerAddUpdateHouseCodeFCheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formControllerAddUpdateHouseCodeFCheckBox.TabIndex = 55
        Me.formControllerAddUpdateHouseCodeFCheckBox.Text = "F"
        Me.formControllerAddUpdateHouseCodeFCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeDCheckBox
        '
        Me.formControllerAddUpdateHouseCodeDCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeDCheckBox.Location = New System.Drawing.Point(70, 25)
        Me.formControllerAddUpdateHouseCodeDCheckBox.Name = "formControllerAddUpdateHouseCodeDCheckBox"
        Me.formControllerAddUpdateHouseCodeDCheckBox.Size = New System.Drawing.Size(34, 17)
        Me.formControllerAddUpdateHouseCodeDCheckBox.TabIndex = 54
        Me.formControllerAddUpdateHouseCodeDCheckBox.Text = "D"
        Me.formControllerAddUpdateHouseCodeDCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeBCheckBox
        '
        Me.formControllerAddUpdateHouseCodeBCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeBCheckBox.Location = New System.Drawing.Point(30, 25)
        Me.formControllerAddUpdateHouseCodeBCheckBox.Name = "formControllerAddUpdateHouseCodeBCheckBox"
        Me.formControllerAddUpdateHouseCodeBCheckBox.Size = New System.Drawing.Size(33, 17)
        Me.formControllerAddUpdateHouseCodeBCheckBox.TabIndex = 53
        Me.formControllerAddUpdateHouseCodeBCheckBox.Text = "B"
        Me.formControllerAddUpdateHouseCodeBCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeOCheckBox
        '
        Me.formControllerAddUpdateHouseCodeOCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeOCheckBox.Location = New System.Drawing.Point(304, 3)
        Me.formControllerAddUpdateHouseCodeOCheckBox.Name = "formControllerAddUpdateHouseCodeOCheckBox"
        Me.formControllerAddUpdateHouseCodeOCheckBox.Size = New System.Drawing.Size(34, 17)
        Me.formControllerAddUpdateHouseCodeOCheckBox.TabIndex = 52
        Me.formControllerAddUpdateHouseCodeOCheckBox.Text = "O"
        Me.formControllerAddUpdateHouseCodeOCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeMCheckBox
        '
        Me.formControllerAddUpdateHouseCodeMCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeMCheckBox.Location = New System.Drawing.Point(265, 3)
        Me.formControllerAddUpdateHouseCodeMCheckBox.Name = "formControllerAddUpdateHouseCodeMCheckBox"
        Me.formControllerAddUpdateHouseCodeMCheckBox.Size = New System.Drawing.Size(35, 17)
        Me.formControllerAddUpdateHouseCodeMCheckBox.TabIndex = 51
        Me.formControllerAddUpdateHouseCodeMCheckBox.Text = "M"
        Me.formControllerAddUpdateHouseCodeMCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeKCheckBox
        '
        Me.formControllerAddUpdateHouseCodeKCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeKCheckBox.Location = New System.Drawing.Point(226, 3)
        Me.formControllerAddUpdateHouseCodeKCheckBox.Name = "formControllerAddUpdateHouseCodeKCheckBox"
        Me.formControllerAddUpdateHouseCodeKCheckBox.Size = New System.Drawing.Size(33, 17)
        Me.formControllerAddUpdateHouseCodeKCheckBox.TabIndex = 50
        Me.formControllerAddUpdateHouseCodeKCheckBox.Text = "K"
        Me.formControllerAddUpdateHouseCodeKCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeICheckBox
        '
        Me.formControllerAddUpdateHouseCodeICheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeICheckBox.Location = New System.Drawing.Point(187, 3)
        Me.formControllerAddUpdateHouseCodeICheckBox.Name = "formControllerAddUpdateHouseCodeICheckBox"
        Me.formControllerAddUpdateHouseCodeICheckBox.Size = New System.Drawing.Size(29, 17)
        Me.formControllerAddUpdateHouseCodeICheckBox.TabIndex = 49
        Me.formControllerAddUpdateHouseCodeICheckBox.Text = "I"
        Me.formControllerAddUpdateHouseCodeICheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeGCheckBox
        '
        Me.formControllerAddUpdateHouseCodeGCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeGCheckBox.Location = New System.Drawing.Point(148, 3)
        Me.formControllerAddUpdateHouseCodeGCheckBox.Name = "formControllerAddUpdateHouseCodeGCheckBox"
        Me.formControllerAddUpdateHouseCodeGCheckBox.Size = New System.Drawing.Size(34, 17)
        Me.formControllerAddUpdateHouseCodeGCheckBox.TabIndex = 48
        Me.formControllerAddUpdateHouseCodeGCheckBox.Text = "G"
        Me.formControllerAddUpdateHouseCodeGCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeECheckBox
        '
        Me.formControllerAddUpdateHouseCodeECheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeECheckBox.Location = New System.Drawing.Point(109, 3)
        Me.formControllerAddUpdateHouseCodeECheckBox.Name = "formControllerAddUpdateHouseCodeECheckBox"
        Me.formControllerAddUpdateHouseCodeECheckBox.Size = New System.Drawing.Size(33, 17)
        Me.formControllerAddUpdateHouseCodeECheckBox.TabIndex = 47
        Me.formControllerAddUpdateHouseCodeECheckBox.Text = "E"
        Me.formControllerAddUpdateHouseCodeECheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeCCheckBox
        '
        Me.formControllerAddUpdateHouseCodeCCheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeCCheckBox.Location = New System.Drawing.Point(70, 3)
        Me.formControllerAddUpdateHouseCodeCCheckBox.Name = "formControllerAddUpdateHouseCodeCCheckBox"
        Me.formControllerAddUpdateHouseCodeCCheckBox.Size = New System.Drawing.Size(33, 17)
        Me.formControllerAddUpdateHouseCodeCCheckBox.TabIndex = 46
        Me.formControllerAddUpdateHouseCodeCCheckBox.Text = "C"
        Me.formControllerAddUpdateHouseCodeCCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateHouseCodeACheckBox
        '
        Me.formControllerAddUpdateHouseCodeACheckBox.AutoSize = True
        Me.formControllerAddUpdateHouseCodeACheckBox.Location = New System.Drawing.Point(30, 3)
        Me.formControllerAddUpdateHouseCodeACheckBox.Name = "formControllerAddUpdateHouseCodeACheckBox"
        Me.formControllerAddUpdateHouseCodeACheckBox.Size = New System.Drawing.Size(33, 17)
        Me.formControllerAddUpdateHouseCodeACheckBox.TabIndex = 45
        Me.formControllerAddUpdateHouseCodeACheckBox.Text = "A"
        Me.formControllerAddUpdateHouseCodeACheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateTransceiverHouseCodesLabel
        '
        Me.formControllerAddUpdateTransceiverHouseCodesLabel.AutoSize = True
        Me.formControllerAddUpdateTransceiverHouseCodesLabel.Location = New System.Drawing.Point(175, 292)
        Me.formControllerAddUpdateTransceiverHouseCodesLabel.Name = "formControllerAddUpdateTransceiverHouseCodesLabel"
        Me.formControllerAddUpdateTransceiverHouseCodesLabel.Size = New System.Drawing.Size(130, 13)
        Me.formControllerAddUpdateTransceiverHouseCodesLabel.TabIndex = 61
        Me.formControllerAddUpdateTransceiverHouseCodesLabel.Text = "Transceiver House Codes"
        '
        'formControllerAddUpdateActiveCheckBox
        '
        Me.formControllerAddUpdateActiveCheckBox.AutoSize = True
        Me.formControllerAddUpdateActiveCheckBox.Location = New System.Drawing.Point(433, 20)
        Me.formControllerAddUpdateActiveCheckBox.Name = "formControllerAddUpdateActiveCheckBox"
        Me.formControllerAddUpdateActiveCheckBox.Size = New System.Drawing.Size(56, 17)
        Me.formControllerAddUpdateActiveCheckBox.TabIndex = 62
        Me.formControllerAddUpdateActiveCheckBox.Text = "Active"
        Me.formControllerAddUpdateActiveCheckBox.UseVisualStyleBackColor = True
        '
        'formControllerAddUpdateMacroSupportLabelText
        '
        Me.formControllerAddUpdateMacroSupportLabelText.AutoSize = True
        Me.formControllerAddUpdateMacroSupportLabelText.Location = New System.Drawing.Point(125, 158)
        Me.formControllerAddUpdateMacroSupportLabelText.Name = "formControllerAddUpdateMacroSupportLabelText"
        Me.formControllerAddUpdateMacroSupportLabelText.Size = New System.Drawing.Size(239, 13)
        Me.formControllerAddUpdateMacroSupportLabelText.TabIndex = 64
        Me.formControllerAddUpdateMacroSupportLabelText.Text = "formControllerAddUpdateMacroSupportLabelText"
        '
        'formControllerAddUpdateMacroSupportLabel
        '
        Me.formControllerAddUpdateMacroSupportLabel.AutoSize = True
        Me.formControllerAddUpdateMacroSupportLabel.Location = New System.Drawing.Point(42, 158)
        Me.formControllerAddUpdateMacroSupportLabel.Name = "formControllerAddUpdateMacroSupportLabel"
        Me.formControllerAddUpdateMacroSupportLabel.Size = New System.Drawing.Size(80, 13)
        Me.formControllerAddUpdateMacroSupportLabel.TabIndex = 63
        Me.formControllerAddUpdateMacroSupportLabel.Text = "Macro Support:"
        '
        'formControllerAddUpdateExtendedCommandsLabelText
        '
        Me.formControllerAddUpdateExtendedCommandsLabelText.AutoSize = True
        Me.formControllerAddUpdateExtendedCommandsLabelText.Location = New System.Drawing.Point(125, 133)
        Me.formControllerAddUpdateExtendedCommandsLabelText.Name = "formControllerAddUpdateExtendedCommandsLabelText"
        Me.formControllerAddUpdateExtendedCommandsLabelText.Size = New System.Drawing.Size(269, 13)
        Me.formControllerAddUpdateExtendedCommandsLabelText.TabIndex = 66
        Me.formControllerAddUpdateExtendedCommandsLabelText.Text = "formControllerAddUpdateExtendedCommandsLabelText"
        '
        'formControllerAddUpdateExtendedCommandsLabel
        '
        Me.formControllerAddUpdateExtendedCommandsLabel.AutoSize = True
        Me.formControllerAddUpdateExtendedCommandsLabel.Location = New System.Drawing.Point(12, 133)
        Me.formControllerAddUpdateExtendedCommandsLabel.Name = "formControllerAddUpdateExtendedCommandsLabel"
        Me.formControllerAddUpdateExtendedCommandsLabel.Size = New System.Drawing.Size(110, 13)
        Me.formControllerAddUpdateExtendedCommandsLabel.TabIndex = 65
        Me.formControllerAddUpdateExtendedCommandsLabel.Text = "Extended Commands:"
        '
        'formControllerAddUpdate
        '
        Me.AcceptButton = Me.formControllerAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formControllerAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(495, 552)
        Me.Controls.Add(Me.formControllerAddUpdateExtendedCommandsLabelText)
        Me.Controls.Add(Me.formControllerAddUpdateExtendedCommandsLabel)
        Me.Controls.Add(Me.formControllerAddUpdateMacroSupportLabelText)
        Me.Controls.Add(Me.formControllerAddUpdateMacroSupportLabel)
        Me.Controls.Add(Me.formControllerAddUpdateActiveCheckBox)
        Me.Controls.Add(Me.formControllerAddUpdateTransceiverHouseCodesLabel)
        Me.Controls.Add(Me.formControllerAddUpdateTransceiverHouseCodesPanel)
        Me.Controls.Add(Me.formControllerAddUpdateDuskDawnResolutionComboBox)
        Me.Controls.Add(Me.formControllerAddUpdateDuskDawnResolutionLabel)
        Me.Controls.Add(Me.formControllerAddUpdateHouseCodeInfoLabel)
        Me.Controls.Add(Me.formControllerAddUpdateOperationsGroupBox)
        Me.Controls.Add(Me.formControllerAddUpdate_DeleteButton)
        Me.Controls.Add(Me.formControllerAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formControllerAddUpdateHouseCodeComboBox)
        Me.Controls.Add(Me.formControllerAddUpdateHouseCodeLabel)
        Me.Controls.Add(Me.formControllerAddUpdatePortComboBox)
        Me.Controls.Add(Me.formControllerAddUpdatePortValueLabel)
        Me.Controls.Add(Me.formControllerAddUpdateDescriptionTextBox)
        Me.Controls.Add(Me.formControllerAddUpdateDescriptionLabel)
        Me.Controls.Add(Me.formControllerAddUpdatePortInfoLabel)
        Me.Controls.Add(Me.formControllerAddUpdateUIDTextBox)
        Me.Controls.Add(Me.formControllerAddUpdateAppKeyTextBox)
        Me.Controls.Add(Me.formControllerAddUpdateUIDLabel)
        Me.Controls.Add(Me.formControllerAddUpdateAppKeyLabel)
        Me.Controls.Add(Me.formControllerAddUpdate_CancelButton)
        Me.Controls.Add(Me.formControllerAddUpdate_AddUpdateButton)
        Me.Controls.Add(Me.formControllerAddUpdateIDLabelText)
        Me.Controls.Add(Me.formControllerAddUpdateIDLabel)
        Me.Controls.Add(Me.formControllerAddUpdatePortLabel)
        Me.Controls.Add(Me.formControllerAddUpdateNameTextBox)
        Me.Controls.Add(Me.formControllerAddUpdateModelLabel)
        Me.Controls.Add(Me.formControllerAddUpdateNameLabel)
        Me.Controls.Add(Me.formControllerAddUpdateModelComboBox)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formControllerAddUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Controller Add / Update"
        Me.formControllerAddUpdateOperationsGroupBox.ResumeLayout(False)
        Me.formControllerAddUpdateOperationsGroupBox.PerformLayout()
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.ResumeLayout(False)
        Me.formControllerAddUpdateTransceiverHouseCodesPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formControllerAddUpdateModelComboBox As ComboBox
    Friend WithEvents formControllerAddUpdateNameLabel As Label
    Friend WithEvents formControllerAddUpdateModelLabel As Label
    Friend WithEvents formControllerAddUpdateNameTextBox As TextBox
    Friend WithEvents formControllerAddUpdatePortLabel As Label
    Friend WithEvents formControllerAddUpdateIDLabel As Label
    Friend WithEvents formControllerAddUpdateIDLabelText As Label
    Friend WithEvents formControllerAddUpdate_AddUpdateButton As Button
    Friend WithEvents formControllerAddUpdate_CancelButton As Button
    Friend WithEvents formControllerAddUpdateAppKeyLabel As Label
    Friend WithEvents formControllerAddUpdateUIDLabel As Label
    Friend WithEvents formControllerAddUpdateAppKeyTextBox As TextBox
    Friend WithEvents formControllerAddUpdateUIDTextBox As TextBox
    Friend WithEvents formControllerAddUpdatePortInfoLabel As Label
    Friend WithEvents formControllerAddUpdateDescriptionLabel As Label
    Friend WithEvents formControllerAddUpdateDescriptionTextBox As TextBox
    Friend WithEvents formControllerAddUpdatePortValueLabel As Label
    Friend WithEvents formControllerAddUpdatePortComboBox As ComboBox
    Friend WithEvents formControllerAddUpdateHouseCodeLabel As Label
    Friend WithEvents formControllerAddUpdateHouseCodeComboBox As ComboBox
    Friend WithEvents formControllerAddUpdate_StatusLabel As Label
    Friend WithEvents formControllerAddUpdate_DeleteButton As Button
    Friend WithEvents formControllerAddUpdate_GetStatusButton As Button
    Friend WithEvents formControllerAddUpdate_SetBaseHouseCodeButton As Button
    Friend WithEvents formControllerAddUpdate_SetClockButton As Button
    Friend WithEvents formControllerAddUpdate_DownloadButton As Button
    Friend WithEvents formControllerAddUpdateOperationsGroupBox As GroupBox
    Friend WithEvents formControllerAddUpdateHouseCodeInfoLabel As Label
    Friend WithEvents formControllerAddUpdateSetClockText1Label As Label
    Friend WithEvents formControllerAddUpdateDuskDawnResolutionLabel As Label
    Friend WithEvents formControllerAddUpdateDuskDawnResolutionComboBox As ComboBox
    Friend WithEvents formControllerAddUpdateTransceiverHouseCodesPanel As Panel
    Friend WithEvents formControllerAddUpdateTransceiverHouseCodesLabel As Label
    Friend WithEvents formControllerAddUpdateHouseCodePCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeNCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeLCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeJCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeHCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeFCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeDCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeBCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeOCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeMCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeKCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeICheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeGCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeECheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeCCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateHouseCodeACheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateSetClockText2Label As Label
    Friend WithEvents formControllerAddUpdate_ExportButton As Button
    Friend WithEvents formControllerAddUpdate_SaveFileDialog As SaveFileDialog
    Friend WithEvents formControllerAddUpdate_ClearButton As Button
    Friend WithEvents formControllerAddUpdateActiveCheckBox As CheckBox
    Friend WithEvents formControllerAddUpdateMacroSupportLabelText As Label
    Friend WithEvents formControllerAddUpdateMacroSupportLabel As Label
    Friend WithEvents formControllerAddUpdateExtendedCommandsLabelText As Label
    Friend WithEvents formControllerAddUpdateExtendedCommandsLabel As Label
End Class
