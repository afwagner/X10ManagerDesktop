﻿Imports System.Configuration

' Name: formMacroInitiatorAddUpdate.vb
' By: Alan Wagner
' Date: November 2020

Public Class formMacroInitiatorAddUpdate

#Region "X10ManagerDesktopMacroInitiatorAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim intMacroInitiatorID As Integer = -1
        Dim objX10DbMacroInitiator As TrekkerPhotoArt.X10Include.X10DbMacroInitiator = Nothing

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim strMessage As String = ""

        Try

            If (formMacroInitiatorAddUpdate_BringToFrontLabel.Text() = "Y") Then
                Me.BringToFront()
            Else
                formMacroInitiatorAddUpdate_BringToFrontLabel.Text() = "Y"
            End If

            strTryStep = "formMacroInitiatorAddUpdate_FormRestore"
            ' formMacroInitiatorAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formMacroInitiatorAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formMacroInitiatorAddUpdateIDLabelText"
                If (formMacroInitiatorAddUpdateIDLabelText.Text() = "" Or formMacroInitiatorAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddMacroInitiator"

                    formMacroInitiatorAddUpdateIDLabelText.Text() = ""

                    ' Set the caption bar text of the form.
                    Me.Text = "Add Macro Initiator"

                    formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Add"
                    formMacroInitiatorAddUpdate_AddUpdateButton.Select()
                    formMacroInitiatorAddUpdate_StatusLabel.Visible = True
                    formMacroInitiatorAddUpdate_StatusLabel.Text = ""

                    formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"

                    formMacroInitiatorAddUpdate_DeleteButton.Visible = False
                    formMacroInitiatorAddUpdate_DeleteButton.Text() = "Delete"

                    formMacroInitiatorAddUpdateInitiatorNameLabel.Visible = True
                    formMacroInitiatorAddUpdateInitiatorNameTextBox.Visible = True
                    formMacroInitiatorAddUpdateInitiatorNameTextBox.Text() = ""

                    formMacroInitiatorAddUpdateIDLabel.Visible = True
                    formMacroInitiatorAddUpdateIDLabelText.Visible = True
                    formMacroInitiatorAddUpdateIDLabelText.Text() = ""

                    formMacroInitiatorAddUpdateDescriptionLabel.Visible = True
                    formMacroInitiatorAddUpdateDescriptionTextBox.Visible = True
                    formMacroInitiatorAddUpdateDescriptionTextBox.Text() = ""


                    formMacroInitiatorAddUpdateControllerLabel.Visible = True
                    formMacroInitiatorAddUpdateControllerActiveLabel.Visible = True

                    strTryStep = "Add_generateControllersComboBox"
                    ' generateControllersComboBox(ByVal intControllerID As Integer) As String
                    strStatus = generateControllersComboBox(-1)
                    If (strStatus = "") Then
                        formMacroInitiatorAddUpdateControllerComboBox.Visible = True
                        formMacroInitiatorAddUpdateControllerActiveLabelText.Visible = True
                        formMacroInitiatorAddUpdateControllerActiveLabelText.Text() = ""
                    Else
                        formMacroInitiatorAddUpdateControllerComboBox.Visible = False
                        formMacroInitiatorAddUpdateControllerActiveLabelText.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_CancelButton.Select()
                        formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Visible = True
                    formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Enabled = True
                    formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Checked = True

                    formMacroInitiatorAddUpdateStartDateLabel.Visible = True
                    formMacroInitiatorAddUpdateStopDateLabel.Visible = True
                    formMacroInitiatorAddUpdateStartDateDateTimePicker.Visible = True
                    formMacroInitiatorAddUpdateStartDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 1, 1)
                    formMacroInitiatorAddUpdateStopDateDateTimePicker.Visible = True
                    formMacroInitiatorAddUpdateStopDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 12, 31)


                    formMacroInitiatorAddUpdateTriggerLabel.Visible = True

                    strTryStep = "Add_generateHouseCodesComboBox"
                    ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                    strStatus = generateHouseCodesComboBox("")
                    If (strStatus = "") Then
                        formMacroInitiatorAddUpdateHouseCodeComboBox.Visible = True
                    Else
                        formMacroInitiatorAddUpdateHouseCodeComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_CancelButton.Select()
                        formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                    End If

                    strTryStep = "Add_generateModuleCodesComboBox"
                    ' generateModuleCodesComboBox(ByVal strModuleCode As String) As String
                    strStatus = generateModuleCodesComboBox("")
                    If (strStatus = "") Then
                        formMacroInitiatorAddUpdateModuleCodeComboBox.Visible = True
                    Else
                        formMacroInitiatorAddUpdateModuleCodeComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_CancelButton.Select()
                        formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formMacroInitiatorAddUpdateFunctionLabel.Visible = True
                    formMacroInitiatorAddUpdateFunctionPanel.Visible = True
                    formMacroInitiatorAddUpdateOnRadioButton.Visible = True
                    formMacroInitiatorAddUpdateOnRadioButton.Checked = False
                    formMacroInitiatorAddUpdateOnRadioButton.Enabled = True
                    formMacroInitiatorAddUpdateOffRadioButton.Visible = True
                    formMacroInitiatorAddUpdateOffRadioButton.Checked = False
                    formMacroInitiatorAddUpdateOffRadioButton.Enabled = True

                    formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Visible = False

                    formMacroInitiatorAddUpdateMacrosLabel.Visible = True
                    formMacroInitiatorAddUpdateMacrosLabel.Text() = "Macros - New Macro Initiator must first be added."

                    strTryStep = "formMacroInitiatorAddUpdate_GetMacrosDataSet_Add"
                    ' formMacroInitiatorAddUpdate_GetMacrosDataSet(ByVal intMacroInitiatorID As Integer) As String
                    strStatus = formMacroInitiatorAddUpdate_GetMacrosDataSet(-1)
                    If (strStatus = "") Then
                        formMacroInitiatorAddUpdateMacrosDataGridView.Rows.Clear()
                        formMacroInitiatorAddUpdateMacrosDataGridView.Visible = True
                        formMacroInitiatorAddUpdateMacrosDataGridView.Enabled = False
                    Else
                        Windows.Forms.MessageBox.Show("Main(formMacroInitiatorAddUpdate-Add): TryStep=" & strTryStep & ": " & strStatus, "Main(formMacroInitiatorAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                    End If

                Else
                    strTryStep = "UpdateMacroInitiator"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Macro Initiator"

                    formMacroInitiatorAddUpdateMacrosLabel.Visible = True
                    formMacroInitiatorAddUpdateMacrosDataGridView.Visible = True

                    formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Update"
                    formMacroInitiatorAddUpdate_AddUpdateButton.Select()
                    formMacroInitiatorAddUpdate_StatusLabel.Visible = True
                    formMacroInitiatorAddUpdate_StatusLabel.Text = ""

                    formMacroInitiatorAddUpdate_CancelButton.Text() = "Done"

                    formMacroInitiatorAddUpdate_DeleteButton.Visible = True
                    formMacroInitiatorAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "MacroInitiatorID"
                    intMacroInitiatorID = CType(formMacroInitiatorAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbMacroInitiator"
                    ' nsX10DbMethods.getX10DbMacroInitiator(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intMacroInitiatorID As Integer, ByRef objX10DbMacroInitiator As TrekkerPhotoArt.X10Include.X10DbMacroInitiator) As String
                    strStatus = nsX10DbMethods.getX10DbMacroInitiator(strConnectionString, strProvider, intMacroInitiatorID, objX10DbMacroInitiator)
                    If (strStatus = "") Then

                        formMacroInitiatorAddUpdateInitiatorNameLabel.Visible = True
                        formMacroInitiatorAddUpdateInitiatorNameTextBox.Visible = True
                        formMacroInitiatorAddUpdateInitiatorNameTextBox.Text() = objX10DbMacroInitiator.name

                        formMacroInitiatorAddUpdateIDLabel.Visible = True
                        formMacroInitiatorAddUpdateIDLabelText.Visible = True
                        formMacroInitiatorAddUpdateIDLabelText.Text() = objX10DbMacroInitiator.MacroInitiatorID.ToString()

                        formMacroInitiatorAddUpdateDescriptionLabel.Visible = True
                        formMacroInitiatorAddUpdateDescriptionTextBox.Visible = True
                        formMacroInitiatorAddUpdateDescriptionTextBox.Text() = objX10DbMacroInitiator.description


                        formMacroInitiatorAddUpdateControllerLabel.Visible = True

                        strTryStep = "Update_generateControllersComboBox"
                        ' generateControllersComboBox(ByVal intControllerID As Integer) As String
                        strStatus = generateControllersComboBox(objX10DbMacroInitiator.ControllerID)
                        If (strStatus = "") Then

                            If (objX10DbMacroInitiator.ControllerID > -1) Then
                                ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                                strStatus = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, objX10DbMacroInitiator.ControllerID, objX10DbController)
                                If (strStatus = "") Then

                                    formMacroInitiatorAddUpdateControllerActiveLabelText.Visible = True
                                    Select Case objX10DbController.ControllerActive
                                        Case 0
                                            formMacroInitiatorAddUpdateControllerActiveLabelText.Text() = "No"
                                        Case 1
                                            formMacroInitiatorAddUpdateControllerActiveLabelText.Text() = "Yes"
                                    End Select

                                Else
                                    formMacroInitiatorAddUpdateControllerActiveLabelText.Visible = False
                                    Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formMacroInitiatorAddUpdate_CancelButton.Select()
                                    formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                                End If
                            End If

                        Else
                            formMacroInitiatorAddUpdateControllerComboBox.Visible = False
                            formMacroInitiatorAddUpdateControllerActiveLabelText.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroInitiatorAddUpdate_CancelButton.Select()
                            formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Visible = True
                        formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Enabled = True
                        Select Case objX10DbMacroInitiator.Enabled
                            Case 0
                                formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Checked = False
                                formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Visible = False
                            Case 1
                                formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Checked = True
                                formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Visible = True
                        End Select

                        formMacroInitiatorAddUpdateStartDateLabel.Visible = True
                        formMacroInitiatorAddUpdateStartDateDateTimePicker.Visible = True
                        If (objX10DbMacroInitiator.StartDate = Nothing) Then
                            formMacroInitiatorAddUpdateStartDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 1, 1)
                        Else
                            formMacroInitiatorAddUpdateStartDateDateTimePicker.Value = objX10DbMacroInitiator.StartDate
                        End If

                        formMacroInitiatorAddUpdateStopDateLabel.Visible = True
                        formMacroInitiatorAddUpdateStopDateDateTimePicker.Visible = True
                        If (objX10DbMacroInitiator.StopDate = Nothing) Then
                            formMacroInitiatorAddUpdateStopDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 12, 31)
                        Else
                            formMacroInitiatorAddUpdateStopDateDateTimePicker.Value = objX10DbMacroInitiator.StopDate
                        End If


                        formMacroInitiatorAddUpdateTriggerLabel.Visible = True

                        strTryStep = "Add_generateHouseCodesComboBox"
                        ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                        strStatus = generateHouseCodesComboBox(objX10DbMacroInitiator.triggerHouseCode)
                        If (strStatus = "") Then
                            formMacroInitiatorAddUpdateHouseCodeComboBox.Visible = True
                        Else
                            formMacroInitiatorAddUpdateHouseCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroInitiatorAddUpdate_CancelButton.Select()
                            formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                        strTryStep = "Add_generateModuleCodesComboBox"
                        ' generateModuleCodesComboBox(ByVal strModuleCode As String) As String
                        strStatus = generateModuleCodesComboBox(objX10DbMacroInitiator.triggerModuleCode)
                        If (strStatus = "") Then
                            formMacroInitiatorAddUpdateModuleCodeComboBox.Visible = True
                        Else
                            formMacroInitiatorAddUpdateModuleCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroInitiatorAddUpdate_CancelButton.Select()
                            formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        formMacroInitiatorAddUpdateFunctionLabel.Visible = True
                        formMacroInitiatorAddUpdateFunctionPanel.Visible = True
                        formMacroInitiatorAddUpdateOnRadioButton.Visible = True
                        formMacroInitiatorAddUpdateOnRadioButton.Enabled = True
                        formMacroInitiatorAddUpdateOffRadioButton.Visible = True
                        formMacroInitiatorAddUpdateOffRadioButton.Enabled = True
                        Select Case objX10DbMacroInitiator.function
                            Case 0
                                formMacroInitiatorAddUpdateOnRadioButton.Checked = False
                                formMacroInitiatorAddUpdateOffRadioButton.Checked = True
                            Case 1
                                formMacroInitiatorAddUpdateOnRadioButton.Checked = True
                                formMacroInitiatorAddUpdateOffRadioButton.Checked = False
                        End Select


                        formMacroInitiatorAddUpdateMacrosLabel.Visible = True
                        formMacroInitiatorAddUpdateMacrosDataGridView.Visible = True

                        ' Refresh Macro Initiator - Macros Data Grid View
                        formMacroInitiatorAddUpdateMacrosLabel.Visible = True
                        formMacroInitiatorAddUpdateMacrosLabel.Text() = "Macros"

                        strTryStep = "formMacroInitiatorAddUpdate_GetMacrosDataSet_Update"
                        ' formMacroInitiatorAddUpdate_GetMacrosDataSet(ByVal intMacroInitiatorID As Integer) As String
                        strStatus = formMacroInitiatorAddUpdate_GetMacrosDataSet(objX10DbMacroInitiator.MacroInitiatorID)
                        If (strStatus = "") Then
                            formMacroInitiatorAddUpdateMacrosDataGridView.Visible = True
                            formMacroInitiatorAddUpdateMacrosDataGridView.Enabled = True
                        Else
                            Windows.Forms.MessageBox.Show("Main(formMacroInitiatorAddUpdate-Update): TryStep=" & strTryStep & ": " & strStatus, "Main(formMacroInitiatorAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Macro Initiator from X10 db." & vbCrLf & strStatus, "Main(formMacroInitiatorAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_CancelButton.Select()
                        formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getX10DbMacroInitiator()

                End If ' END - formMacroInitiatorAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formMacroInitiatorAddUpdate): " & strStatus, "Main(formMacroInitiatorAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formMacroInitiatorAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formMacroInitiatorAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formMacroInitiatorAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbMacroInitiator = Nothing
            objX10DbController = Nothing
        End Try

    End Sub ' END Sub - Main(formMacroInitiatorAddUpdate)

    Private Sub formMacroInitiatorAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formMacroInitiatorAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formMacroInitiatorAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formMacroInitiatorAddUpdate_FormClosingHandler(): " & strStatus, "formMacroInitiatorAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formMacroInitiatorAddUpdate_FormSave()

    End Sub ' END Sub - formMacroInitiatorAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopMacroInitiatorAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function generateControllersComboBox()
    ' Alan Wagner
    '
    Private Function generateControllersComboBox(ByVal intControllerID As Integer) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""
        Dim objDataTableControllers As New System.Data.DataTable

        Dim objDataRowViewController As System.Data.DataRowView = Nothing
        Dim intSelectedIndex As Integer = 0

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()

                sqlString = "SELECT ControllerID, ControllerName+' ['+ControllerType+']' AS Controller " &
                        "FROM (Controllers INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID) " &
                        "WHERE ControllerTypes.ControllerExtendedCommands=1 " &
                        "AND ControllerTypes.ControllerMacros=1 " &
                        "UNION " &
                        "SELECT -1 AS ControllerID, 'Select Controller...' AS Controller FROM Controllers " &
                        "ORDER BY ControllerID ASC"

                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableControllers)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            If (objDataTableControllers.Rows.Count() > 0) Then

                With formMacroInitiatorAddUpdateControllerComboBox
                    .DisplayMember = "Controller"
                    .ValueMember = "ControllerID"
                    .DataSource = objDataTableControllers
                End With

                If (intControllerID = -1) Then
                    formMacroInitiatorAddUpdateControllerComboBox.SelectedIndex = 0
                Else
                    formMacroInitiatorAddUpdateControllerComboBox.SelectedIndex = formMacroInitiatorAddUpdateControllerComboBox.FindString(intControllerID.ToString)

                    For intSelectedIndex = 0 To formMacroInitiatorAddUpdateControllerComboBox.Items.Count - 1

                        objDataRowViewController = formMacroInitiatorAddUpdateControllerComboBox.Items(intSelectedIndex)

                        If (intControllerID = CType(objDataRowViewController.Row("ControllerID").ToString(), Integer)) Then
                            formMacroInitiatorAddUpdateControllerComboBox.SelectedIndex = intSelectedIndex
                            Exit For
                        End If

                    Next

                End If

            Else
                strStatus = "generateControllersComboBox(): No X10 Controllers found."
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "generateControllersComboBox(): Exception: " & ex.Message
            Else
                strStatus = "generateControllersComboBox(): Exception: " & ex.Message
            End If
        Finally
            objDataRowViewController = Nothing
            objDataTableControllers = Nothing
        End Try

        Return strStatus

    End Function ' END - generateControllersComboBox()

    '=====================================================================================
    ' Function generateHouseCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateHouseCodesComboBox(ByVal strHouseCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableHouseCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT HouseCodeID, HouseCode FROM HouseCodes UNION SELECT 0 AS HouseCodeID, 'Select HouseCode...' AS HouseCode FROM HouseCodes ORDER BY HouseCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableHouseCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroInitiatorAddUpdateHouseCodeComboBox
                .DisplayMember = "HouseCode"
                .ValueMember = "HouseCodeID"
                .DataSource = objDataTableHouseCodes
            End With

            If (strHouseCode = "") Then
                formMacroInitiatorAddUpdateHouseCodeComboBox.SelectedIndex = 0
            Else
                formMacroInitiatorAddUpdateHouseCodeComboBox.SelectedIndex = formMacroInitiatorAddUpdateHouseCodeComboBox.FindString(strHouseCode)
            End If

        Catch ex As Exception
            strStatus = "generateHouseCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableHouseCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateHouseCodesComboBox()

    '=====================================================================================
    ' Function generateModuleCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateModuleCodesComboBox(ByVal strModuleCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableModuleCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT ModuleCodeID, ModuleCode FROM ModuleCodes UNION SELECT 0 AS ModuleCodeID, 'Select UnitCode...' AS ModuleCode FROM ModuleCodes ORDER BY ModuleCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableModuleCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formMacroInitiatorAddUpdateModuleCodeComboBox
                .DisplayMember = "ModuleCode"
                .ValueMember = "ModuleCodeID"
                .DataSource = objDataTableModuleCodes
            End With

            If (strModuleCode = "") Then
                formMacroInitiatorAddUpdateModuleCodeComboBox.SelectedIndex = 0
            Else
                formMacroInitiatorAddUpdateModuleCodeComboBox.SelectedIndex = formMacroInitiatorAddUpdateModuleCodeComboBox.FindString(strModuleCode)
            End If

        Catch ex As Exception
            strStatus = "generateModuleCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableModuleCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateModuleCodesComboBox()

    '=====================================================================================
    ' formMacroInitiatorAddUpdate_GetMacrosDataSet()
    ' Alan Wagner
    '
    Public Function formMacroInitiatorAddUpdate_GetMacrosDataSet(ByVal intMacroInitiatorID As Integer) As String
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objFactory As System.Data.Common.DbProviderFactory = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataGridViewColumn As System.Windows.Forms.DataGridViewColumn = Nothing
        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim objDataGridViewTextBoxCell As System.Windows.Forms.DataGridViewTextBoxCell = Nothing
        Dim objDataGridViewComboBoxCell As System.Windows.Forms.DataGridViewComboBoxCell = Nothing

        Dim intRowIndex As Integer = -1

        Dim strAddEdit As String = ""

        ' Macros table
        Dim intMacroID As Integer = -1
        Dim strMacroSort As String = ""
        Dim strFlagOnOff As String = ""
        Dim strRFOnOff As String = ""
        Dim objTime As System.TimeSpan = System.TimeSpan.MinValue
        Dim strDelay As String = ""
        Dim strInhibitRetriggerYN As String = ""

        Dim intCurrentCellRowIndex As Integer = -1
        Dim intFirstDisplayedCellRowIndex As Integer = -1

        Dim intColumnMacroInitiatorID As Integer = 8    ' Column that contains MacroInitiatorID.
        Dim intColumnMacroID As Integer = 9    ' Column that contains MacroID.

        Dim bShowAdvancedInformation As Boolean = False

        Try

            strTryStep = "bShowAdvancedInformation"
            Select Case X10ManagerDesktop.showAdvancedInformation
                Case 0
                    bShowAdvancedInformation = False
                Case 1
                    bShowAdvancedInformation = True
            End Select

            strTryStep = "Columns.Count"
            If (formMacroInitiatorAddUpdateMacrosDataGridView.Columns.Count < 1) Then

                strTryStep = "WithFormMacroInitiatorAddUpdateMacrosDataGridView"
                With formMacroInitiatorAddUpdateMacrosDataGridView
                    .AllowDrop = True
                    .AutoGenerateColumns = False
                    .AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
                    .AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
                    .AllowUserToAddRows = False
                    .AllowUserToDeleteRows = False
                    .AllowUserToOrderColumns = False
                    .AllowUserToResizeColumns = False
                    .AllowUserToResizeRows = False
                    .ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
                    .EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
                    .ReadOnly = True
                    .RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
                    .ShowCellToolTips = False
                    .ShowEditingIcon = False

                    strTryStep = "DataGridViewColumn_AddEdit"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "AddEdit"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "AddEdit"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroName"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Macro Name"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroName"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroSort"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Macro Sort Order"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroSort"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroDescription"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Macro Description"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroDescription"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_flag"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Flag"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "flag"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_RF"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "RF"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "RF"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_delay"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Delay (hh:mm:ss)"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "delay"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_inhibitRetrigger"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Inhibit Retrigger"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "inhibitRetrigger"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroInitiatorID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "MacroInitiatorID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroInitiatorID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_MacroID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "MacroID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "MacroID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                End With ' END - WithFormMacroInitiatorAddUpdateMacrosDataGridView

            Else

                strTryStep = "SelectCaseShowAdvancedInformation"
                Select Case bShowAdvancedInformation
                    Case True
                        formMacroInitiatorAddUpdateMacrosDataGridView.Columns(intColumnMacroInitiatorID).Visible = True
                        formMacroInitiatorAddUpdateMacrosDataGridView.Columns(intColumnMacroID).Visible = True
                    Case False
                        formMacroInitiatorAddUpdateMacrosDataGridView.Columns(intColumnMacroInitiatorID).Visible = False
                        formMacroInitiatorAddUpdateMacrosDataGridView.Columns(intColumnMacroID).Visible = False
                End Select

            End If ' END - Columns.Count

            strTryStep = "Rows.Count"
            If (formMacroInitiatorAddUpdateMacrosDataGridView.Rows.Count > 0) Then
                strTryStep = "Rows.Clear"
                formMacroInitiatorAddUpdateMacrosDataGridView.Rows.Clear()
            End If ' END - Rows.Count

            strTryStep = "ExistingOrNewMacroInitiatorID"
            If (intMacroInitiatorID > -1) Then
                strTryStep = "ExistingMacroInitiatorID"

                strTryStep = "ConnectionStrings"
                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                strTryStep = "GetFactory"
                objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

                strTryStep = "sqlString"
                sqlString = "Select 'Edit' AS [AddEdit]," &
                            "ms.MacroID AS [MacroID]," &
                            "ms.[name] AS [name]," &
                            "ms.[description] AS [description]," &
                            "ms.MacroInitiatorID AS [MacroInitiatorID]," &
                            "ms.MacroSort AS [MacroSort]," &
                            "ms.flag AS [flag]," &
                            "ms.RF AS [RF]," &
                            "ms.delay AS [delay]," &
                            "ms.inhibitRetrigger AS [inhibitRetrigger] " &
                            "FROM Macros AS ms " &
                            "WHERE ms.MacroID>-1 " &
                            "AND ms.MacroInitiatorID=" & intMacroInitiatorID.ToString() & " " &
                            "UNION " &
                            "SELECT 'Add' AS [AddEdit]," &
                            "ms.MacroID AS [MacroID]," &
                            "'' AS [name]," &
                            "'' AS [description]," &
                            "-1 AS [MacroInitiatorID]," &
                            "-1 AS [MacroSort]," &
                            "-1 AS [flag]," &
                            "-1 AS [RF]," &
                            "-1 AS [delay]," &
                            "-1 AS [inhibitRetrigger] " &
                            "FROM Macros AS ms " &
                            "WHERE ms.MacroID=-1 " &
                            "ORDER BY [AddEdit],[MacroSort] ASC;"

                strTryStep = "CreateConnection"
                Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                    strTryStep = "ConnectionString"
                    objDbConnection.ConnectionString = strConnectionString

                    strTryStep = "Connection.Open"
                    objDbConnection.Open()

                    strTryStep = "CreateCommand"
                    Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                        strTryStep = "CommandText"
                        objDbCommand.CommandText = sqlString

                        strTryStep = "CommandTimeout"
                        objDbCommand.CommandTimeout = 30 ' Seconds

                        strTryStep = "CommandType"
                        ' Text              - An SQL text command (default).
                        ' StoredProcedure   - To call a stored procedure.
                        ' TableDirect       - All rows and columns of the named table or tables will be returned.
                        objDbCommand.CommandType() = CommandType.Text

                        strTryStep = "ExecuteReader"
                        ' ExecuteReader     - Executes commands that return rows.
                        '   System.Data.CommandBehavior.Default          - The query may return multiple result sets. ExecuteReader(CommandBehavior.Default) is functionally equivalent to calling ExecuteReader().
                        '   System.Data.CommandBehavior.SingleResult     - The query returns a single result set.
                        '   System.Data.CommandBehavior.SchemaOnly       - The query returns column information only.
                        '   System.Data.CommandBehavior.KeyInfo          - The query returns column and primary key information.
                        '   System.Data.CommandBehavior.SingleRow        - The query is expected to return a single row of the first result set.
                        '   System.Data.CommandBehavior.SequentialAccess - Provides a way for the DataReader to handle rows that contain columns with large binary values. You can then use the GetBytes or GetChars method to specify a byte location to start the read operation.
                        '   System.Data.CommandBehavior.CloseConnection  - When the command is executed, the associated Connection object is closed when the associated DataReader object is closed.
                        ' ExecuteNonQuery   - Executes commands such as Transact-SQL INSERT, DELETE, UPDATE, and SET statements.
                        ' ExecuteScalar     - Retrieves a single value (for example, an aggregate value) from a database.
                        ' ExecuteXmlReader  - Sends the CommandText to the Connection and builds an XmlReader object.
                        Using objDbDataReader As System.Data.Common.DbDataReader = objDbCommand.ExecuteReader(System.Data.CommandBehavior.Default)

                            strTryStep = "HasRows"
                            If objDbDataReader.HasRows() Then

                                strTryStep = "Read"
                                While objDbDataReader.Read()
                                    intRowIndex = intRowIndex + 1

                                    strTryStep = ""
                                    strAddEdit = objDbDataReader("AddEdit").ToString()

                                    ' Macros table
                                    strTryStep = "MacroID"
                                    intMacroID = CType(objDbDataReader("MacroID"), Integer)

                                    strTryStep = "MacroSort"
                                    If (CType(objDbDataReader("MacroSort"), Integer) = -1) Then
                                        strMacroSort = ""
                                    Else
                                        strMacroSort = CType(objDbDataReader("MacroSort"), Integer)
                                    End If

                                    strTryStep = "flag"
                                    Select Case CType(objDbDataReader("flag"), Integer)
                                        Case 0
                                            strFlagOnOff = "off"
                                        Case 1
                                            strFlagOnOff = "on"
                                        Case Else
                                            strFlagOnOff = ""
                                    End Select

                                    strTryStep = "RF"
                                    Select Case CType(objDbDataReader("RF"), Integer)
                                        Case 0
                                            strRFOnOff = "off"
                                        Case 1
                                            strRFOnOff = "on"
                                        Case Else
                                            strRFOnOff = ""
                                    End Select

                                    strTryStep = "delay"
                                    If (CType(objDbDataReader("delay"), Integer) = -1) Then
                                        strDelay = ""
                                    Else
                                        objTime = System.TimeSpan.FromSeconds(CType(objDbDataReader("delay"), Integer))
                                        strDelay = objTime.ToString("hh\:mm\:ss")
                                    End If

                                    strTryStep = "inhibitRetrigger"
                                    Select Case CType(objDbDataReader("inhibitRetrigger"), Integer)
                                        Case 0
                                            strInhibitRetriggerYN = "No"
                                        Case 1
                                            strInhibitRetriggerYN = "Yes"
                                        Case Else
                                            strInhibitRetriggerYN = ""
                                    End Select

                                    strTryStep = "NewObjectDataGridViewRow"
                                    objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                                    strTryStep = "Add_AddEdit"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strAddEdit
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroName"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = objDbDataReader("name")
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroSort"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strMacroSort
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroDescription"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = objDbDataReader("description")
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_flag"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strFlagOnOff
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_RF"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strRFOnOff
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_delay"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strDelay
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_inhibitRetrigger"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = strInhibitRetriggerYN
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroInitiatorID"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intMacroInitiatorID.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Add_MacroID"
                                    objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                    objDataGridViewTextBoxCell.Value = intMacroID.ToString()
                                    objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                    objDataGridViewTextBoxCell = Nothing

                                    strTryStep = "Rows.Add"
                                    formMacroInitiatorAddUpdateMacrosDataGridView.Rows.Add(objDataGridViewRow)

                                    objDataGridViewRow = Nothing
                                End While

                                strTryStep = "DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros"
                                intCurrentCellRowIndex = X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros

                                strTryStep = "DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros"
                                intFirstDisplayedCellRowIndex = X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros

                                strTryStep = "CheckForRestoreCursorPostion"
                                If (intCurrentCellRowIndex > -1 And intCurrentCellRowIndex < formMacroInitiatorAddUpdateMacrosDataGridView.Rows.Count And intFirstDisplayedCellRowIndex > -1) Then
                                    formMacroInitiatorAddUpdateMacrosDataGridView.FirstDisplayedScrollingRowIndex = intFirstDisplayedCellRowIndex
                                    formMacroInitiatorAddUpdateMacrosDataGridView.CurrentCell = formMacroInitiatorAddUpdateMacrosDataGridView.Rows(intCurrentCellRowIndex).Cells(0) ' Always restore to the first column.
                                End If

                            End If ' END - HasRows

                        End Using ' END - ExecuteReader

                    End Using ' END - CreateCommand

                    strTryStep = "Connection.Close"
                    objDbConnection.Close()

                End Using ' END - CreateConnection

            Else
                strTryStep = "NewMacroInitiatorID"
                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros = -1
                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros = -1
            End If ' END - ExistingOrNewMacroInitiatorID

        Catch ex As Exception
            strStatus = "formMacroInitiatorAddUpdate_GetMacrosDataSet(" & strTryStep & "): Exception: " & ex.Message & vbCrLf & sqlString
        Finally
            objDataGridViewTextBoxCell = Nothing
            objDataGridViewComboBoxCell = Nothing
            objDataGridViewRow = Nothing
            objDataGridViewColumn = Nothing
            objFactory = Nothing
        End Try

        Return strStatus

    End Function ' END - formMacroInitiatorAddUpdate_GetMacrosDataSet()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formMacroInitiatorAddUpdateMacrosDataGridView_CellClick(ByVal objSender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles formMacroInitiatorAddUpdateMacrosDataGridView.CellClick
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim strIDText As String = ""
        Dim bActiveFormFound = False
        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormMacroAddUpdate As formMacroAddUpdate = Nothing

        Dim objLocation As System.Drawing.Point = Nothing

        Dim intCurrentRow As Integer = -1

        Dim intColumnMacroID As Integer = 9             ' Column that contains MacroID.

        Try

            ' Save current Cursor Position.
            strTryStep = "CurrentCell"
            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros = formMacroInitiatorAddUpdateMacrosDataGridView.CurrentCell.RowIndex
            strTryStep = "FirstDisplayedCell"
            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros = formMacroInitiatorAddUpdateMacrosDataGridView.FirstDisplayedCell.RowIndex

            formMacroInitiatorAddUpdate_BringToFrontLabel.Text() = "Y"

            strTryStep = "CurrentRow.Index"
            intCurrentRow = formMacroInitiatorAddUpdateMacrosDataGridView.CurrentRow.Index

            strTryStep = "CurrentRow"
            ' Including e.RowIndex >= 0 stops this from responding when Header Row is clicked.
            If (intCurrentRow >= 0 And e.RowIndex >= 0) Then
                ' Item(column, row)

                ' Get X10 MacroID
                strTryStep = "GetMacroID"
                strIDText = formMacroInitiatorAddUpdateMacrosDataGridView.Item(intColumnMacroID, intCurrentRow).Value.ToString()

                strTryStep = "OfType"
                If objFormCollection.OfType(Of formMacroAddUpdate).Any Then

                    If (strIDText = "-1") Then
                        ' Looking for already open Add form.

                        strTryStep = "ForEachAlreadyOpenAddForm"
                        For Each objFormMacroAddUpdate In objFormCollection.OfType(Of formMacroAddUpdate)
                            If (objFormMacroAddUpdate.formMacroAddUpdateIDLabelText.Text() = "") Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    Else

                        strTryStep = "ForEachAlreadyOpenUpdateForm"
                        For Each objFormMacroAddUpdate In objFormCollection.OfType(Of formMacroAddUpdate)
                            If (objFormMacroAddUpdate.formMacroAddUpdateIDLabelText.Text() = strIDText) Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    End If

                End If

                strTryStep = "bActiveFormFound"
                If bActiveFormFound Then
                    strTryStep = "Activate"
                    objFormMacroAddUpdate.Activate()
                Else

                    strTryStep = "NewObjectFormMacroAddUpdate"
                    objFormMacroAddUpdate = Nothing
                    objFormMacroAddUpdate = New formMacroAddUpdate

                    ' Put X10 MacroInitiatorID
                    strTryStep = "PutMacroInitiatorID"
                    objFormMacroAddUpdate.formMacroAddUpdateMacroInitatorIDLabelText.Text() = formMacroInitiatorAddUpdateIDLabelText.Text()

                    ' Put X10 MacroInitiatorName
                    strTryStep = "PutMacroInitiatorName"
                    objFormMacroAddUpdate.formMacroAddUpdateMacroInInitatorNameLabelText.Text() = formMacroInitiatorAddUpdateInitiatorNameTextBox.Text()

                    ' Put X10 MacroID
                    strTryStep = "PutMacroID"
                    objFormMacroAddUpdate.formMacroAddUpdateIDLabelText.Text() = strIDText

                    ' Set Calling Form Name (Class Name)
                    strTryStep = "SetClassName"
                    objFormMacroAddUpdate.formMacroAddUpdateCallingFormLabelText.Text() = "formMacroInitiatorAddUpdate"

                    ' Opens as seperate form.
                    strTryStep = "TopLevel"
                    objFormMacroAddUpdate.TopLevel = True

                    ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                    strTryStep = "Me.Location"
                    objLocation = New System.Drawing.Point
                    objLocation = Me.Location

                    ' Set additional offset for new form.
                    strTryStep = "Offset"
                    objLocation.Offset(100, 150)

                    ' Set default Location for new form to be Shown.
                    strTryStep = "formMacroAddUpdate.Location"
                    objFormMacroAddUpdate.Location = objLocation

                    strTryStep = "Show"
                    objFormMacroAddUpdate.Show()

                End If

                objFormMacroAddUpdate.BringToFront()

            End If

        Catch ex As Exception
            strStatus = "formMacroInitiatorAddUpdateMacrosDataGridView_CellClick(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdateMacrosDataGridView_CellClick()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormMacroAddUpdate = Nothing
            objFormCollection = Nothing
        End Try

    End Sub ' END - formMacroInitiatorAddUpdateMacrosDataGridView_CellClick()

    Private Sub formMacroInitiatorAddUpdateControllerComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles formMacroInitiatorAddUpdateControllerComboBox.SelectionChangeCommitted
        'formMacroInitiatorAddUpdateControllerComboBox.SelectedIndexChanged

        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataRowView As System.Data.DataRowView = Nothing
        Dim intControllerID As Integer = -1
        Dim strController As String = ""

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            objDataRowView = formMacroInitiatorAddUpdateControllerComboBox.SelectedItem
            intControllerID = CType(objDataRowView(0).ToString, Integer)
            strController = objDataRowView(1).ToString ' ex: "CM15A Controller for House Lighting"

            If (intControllerID > -1) Then

                ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                strError = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, intControllerID, objX10DbController)
                If (strError = "") Then

                    formMacroInitiatorAddUpdateControllerActiveLabelText.Visible = True
                    Select Case objX10DbController.ControllerActive
                        Case 0
                            formMacroInitiatorAddUpdateControllerActiveLabelText.Text() = "No"
                        Case 1
                            formMacroInitiatorAddUpdateControllerActiveLabelText.Text() = "Yes"
                    End Select

                Else
                    formMacroInitiatorAddUpdateControllerActiveLabelText.Visible = False
                    strStatus = "formMacroInitiatorAddUpdateControllerComboBox_SelectedIndexChanged(): " & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdateControllerComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formMacroInitiatorAddUpdate_CancelButton.Select()
                    formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
                    formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                    formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                End If ' END - nsX10DbMethods.getX10DbController()

            Else
                formMacroInitiatorAddUpdateControllerActiveLabelText.Text() = ""
            End If

        Catch ex As Exception
            strStatus = "formMacroInitiatorAddUpdateControllerComboBox_SelectedIndexChanged(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdateControllerComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroInitiatorAddUpdate_CancelButton.Select()
            formMacroInitiatorAddUpdate_AddUpdateButton.Visible = False
            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbController = Nothing
            objDataRowView = Nothing
        End Try

    End Sub ' END - formMacroInitiatorAddUpdateControllerComboBox_SelectedIndexChanged()

    Private Sub formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.CheckedChanged

        Select Case formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Checked
            Case True
                formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Visible = True
            Case False
                formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Visible = False
        End Select

    End Sub ' END - formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox_CheckedChanged()

    Private Sub formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroInitiatorAddUpdate_TestMacroInitiatorButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataRowViewController As System.Data.DataRowView = Nothing
        Dim intControllerID As Integer = -1
        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing

        Dim objDataRowViewModuleHouseCode As System.Data.DataRowView = Nothing
        Dim strUnitHouseCode As String = ""

        Dim objDataRowViewModuleUnitCode As System.Data.DataRowView = Nothing
        Dim strUnitModuleCode As String = ""

        Dim intUnitOnOff As Integer = -1
        Dim strUnitOnOff As String = ""

        Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
        Dim objSendMacroInitiatorTriggerClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendMacroInitiatorTriggerClass = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Dim strMessage As String = ""

        Try

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString

            strTryStep = "ProviderName"
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName


            strTryStep = "DataRowViewController"
            objDataRowViewController = formMacroInitiatorAddUpdateControllerComboBox.SelectedItem

            strTryStep = "IsControllerSelected"
            If (objDataRowViewController.Row("ControllerID").ToString() = "0") Then
                ' No
                strStatus = "Missing Controller."
            Else
                ' Yes

                strTryStep = "formConsoleMessages"
                If objFormCollection.OfType(Of formConsoleMessages).Any Then
                    objFormConsoleMessages = New formConsoleMessages
                    objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")
                    objFormConsoleMessages.Close()
                    objFormConsoleMessages = Nothing
                End If

                strTryStep = "ControllerID"
                intControllerID = CType(objDataRowViewController.Row("ControllerID").ToString(), Integer)

                strTryStep = "nsX10DbMethods.getX10DbController"
                ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                strError = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, intControllerID, objX10DbController)
                If (strError = "") Then

                    If (objX10DbController Is Nothing) Then
                        strStatus = "getX10DbController(): Controller ID""" & intControllerID.ToString() & """ not found in X10Db."
                        Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    Else

                        strTryStep = "SelectCaseControllerTypeGetPort"
                        Select Case objX10DbController.ControllerType.ToUpper()
                            Case "CM15A"

                                strTryStep = "nsX10DbMethods.getX10DbUSBPort"
                                ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                                strError = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                                If (strError = "") Then

                                    strTryStep = "nsX10CM15AMethods.getX10ControllerStatus"
                                    ' getX10ControllerStatusClass getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                    objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                    If (objGetX10ControllerStatusClass.status <> "") Then
                                        strStatus = "Problem sending MacroInitiator Trigger to Controller." & vbCrLf & objGetX10ControllerStatusClass.status
                                        Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                                Else
                                    strStatus = "Problem geting Controller's USB Port Information." & vbCrLf & strError
                                    Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                                    formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                End If ' END - nsX10DbMethods.getX10DbUSBPort()

                        End Select ' END - SelectCaseControllerTypeGetPort

                    End If

                Else
                    strStatus = "Problem geting Controller Information." & vbCrLf & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                    formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                End If ' END - nsX10DbMethods.getX10DbController()

            End If


            strTryStep = "DataRowViewModuleHouseCode"
            objDataRowViewModuleHouseCode = formMacroInitiatorAddUpdateHouseCodeComboBox.SelectedItem

            strTryStep = "IsModuleHouseCodeSelected?"
            If (objDataRowViewModuleHouseCode.Row("HouseCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing Module House Code."
                Else
                    strStatus &= vbCrLf & "Missing Module House Code."
                End If
            Else
                strTryStep = "UnitHouseCode"
                strUnitHouseCode = objDataRowViewModuleHouseCode(1).ToString ' DisplayMember ex: "A"
            End If


            strTryStep = "DataRowViewModuleUnitCode"
            objDataRowViewModuleUnitCode = formMacroInitiatorAddUpdateModuleCodeComboBox.SelectedItem

            strTryStep = "IsModuleUnitCodeSelected?"
            If (objDataRowViewModuleUnitCode.Row("ModuleCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing Module Unit Code."
                Else
                    strStatus &= vbCrLf & "Missing Module Unit Code."
                End If
            Else
                strTryStep = "UnitModuleCode"
                strUnitModuleCode = objDataRowViewModuleUnitCode(1).ToString ' DisplayMember ex: "1"
            End If


            strTryStep = "WasSomethingMissing"
            If (strStatus = "") Then

                strTryStep = "UnitOnOff"
                Select Case formMacroInitiatorAddUpdateOnRadioButton.Checked
                    Case True
                        intUnitOnOff = 1
                        strUnitOnOff = "On"
                    Case False
                        intUnitOnOff = 0
                        strUnitOnOff = "Off"
                End Select

                strTryStep = "SelectCaseControllerType"
                Select Case objX10DbController.ControllerType.ToUpper()
                    Case "CM15A"

                        strMessage = "  Trigger: " & strUnitHouseCode & strUnitModuleCode & " - " & strUnitOnOff
                        strMessage &= vbCrLf & "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"

                        strMessage &= vbCrLf & vbCrLf & "Sending Trigger to Controller...Please wait......."
                        ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                        Call formConsoleMessages.DisplayMessage(strMessage, "Test MacroInitiator on Controller " & objX10DbController.ControllerType.ToUpper())

                        strTryStep = "nsX10CM15AMethods.sendUnitCommand"
                        ' sendMacroInitiatorTriggerClass sendMacroInitiatorTrigger(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strX10DbConnectionString, string strX10DbProvider, string strUnitHouseCodeLetter, string strUnitModuleCode, int intUnitOnOff)
                        objSendMacroInitiatorTriggerClass = nsX10CM15AMethods.sendMacroInitiatorTrigger(objX10DbController, objX10DbUSBPort, strConnectionString, strProvider, strUnitHouseCode, strUnitModuleCode, intUnitOnOff)
                        If (objSendMacroInitiatorTriggerClass.status = "") Then

                            strMessage &= vbCrLf & "  Complete:"
                            strMessage &= vbCrLf & "    Send MacroInitiator Trigger " & objSendMacroInitiatorTriggerClass.unitHouseCodeLetter & objSendMacroInitiatorTriggerClass.unitModuleCode & " - " & strUnitOnOff & " to Controller."


                            If (objSendMacroInitiatorTriggerClass.objSendAddressCommandPowerLineClass.retryReason.Length > 0) Then
                                strMessage &= vbCrLf & "    SendAddressCommandPowerLine.retryReason=" & objSendMacroInitiatorTriggerClass.objSendAddressCommandPowerLineClass.retryReason
                            End If

                            If (objSendMacroInitiatorTriggerClass.objSendFunctionCommandPowerLineClass.retryReason.Length > 0) Then
                                strMessage &= vbCrLf & "    SendFunctionCommandPowerLine.retryReason=" & objSendMacroInitiatorTriggerClass.objSendFunctionCommandPowerLineClass.retryReason
                            End If

                            strMessage &= vbCrLf & vbCrLf & "Success!"

                            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                            Call formConsoleMessages.DisplayMessage(strMessage, "Test MacroInitiator on Controller " & objX10DbController.ControllerType.ToUpper())

                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Success"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formMacroInitiatorAddUpdate_CancelButton.Text() = "Done"

                        Else
                            strStatus = "Problem sending MacroInitiator Trigger to Controller." & vbCrLf & objSendMacroInitiatorTriggerClass.status
                            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"

                            strMessage &= vbCrLf & vbCrLf & strStatus
                            strMessage &= vbCrLf & vbCrLf & "Fail!"
                            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                            Call formConsoleMessages.DisplayMessage(strMessage, "Test MacroInitiator on Controller " & objX10DbController.ControllerType.ToUpper())

                        End If ' END - nsX10CM15AMethods.sendMacroInitiatorTrigger()

                    Case Else
                        Windows.Forms.MessageBox.Show("Missing or Unknown Controller Model """ & objX10DbController.ControllerType & """.", "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                End Select ' END - SelectCaseControllerType

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - WasSomethingMissing

        Catch ex As Exception
            strStatus = "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objGetX10ControllerStatusClass = Nothing
            objSendMacroInitiatorTriggerClass = Nothing
            objX10DbUSBPort = Nothing
            objDataRowViewController = Nothing
            objX10DbController = Nothing
            objDataRowViewModuleHouseCode = Nothing
            objDataRowViewModuleUnitCode = Nothing
            objFormCollection = Nothing
            objFormConsoleMessages = Nothing
        End Try

    End Sub ' END - formMacroInitiatorAddUpdate_TestMacroInitiatorButton_Click()

    Private Sub formMacroInitiatorAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroInitiatorAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objDataRowViewController As System.Data.DataRowView = Nothing
        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing
        Dim objDataRowViewModuleCode As System.Data.DataRowView = Nothing

        Dim objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = Nothing
        Dim objMacroCommandUsingTrigger As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.macroCommandUsingTrigger = Nothing

        Dim objX10DbMacroInitiator As TrekkerPhotoArt.X10Include.X10DbMacroInitiator = Nothing
        Dim objX10DbMacroInitiatorTest As TrekkerPhotoArt.X10Include.X10DbMacroInitiator = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormMacroInitiatorEdit As formMacroInitiatorEdit = Nothing

        Try

            formMacroInitiatorAddUpdate_StatusLabel.Text = ""
            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString

            strTryStep = "ProviderName"
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "NewObjectX10DbMacroInitiator"
            objX10DbMacroInitiator = New TrekkerPhotoArt.X10Include.X10DbMacroInitiator


            strTryStep = "MissingMacroInitiatorName"
            If (formMacroInitiatorAddUpdateInitiatorNameTextBox.Text.Trim() = "") Then
                strStatus = "Missing Macro Initiator Name."
            Else
                strTryStep = "name"
                objX10DbMacroInitiator.name = formMacroInitiatorAddUpdateInitiatorNameTextBox.Text().Trim()
            End If


            strTryStep = "DataRowViewTriggerHouseCode"
            objDataRowViewHouseCode = formMacroInitiatorAddUpdateHouseCodeComboBox.SelectedItem

            strTryStep = "IsTriggerHouseCodeSelected?"
            If (objDataRowViewHouseCode.Row("HouseCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing Trigger House Code."
                Else
                    strStatus &= vbCrLf & "Missing Trigger House Code."
                End If
                objX10DbMacroInitiator.triggerHouseCode = ""
            Else
                strTryStep = "triggerHouseCode"
                objX10DbMacroInitiator.triggerHouseCode = objDataRowViewHouseCode(1).ToString ' DisplayMember ex: "A"
            End If ' END -IsTriggerHouseCodeSelected?


            strTryStep = "DataRowViewTriggerModuleCode"
            objDataRowViewModuleCode = formMacroInitiatorAddUpdateModuleCodeComboBox.SelectedItem

            strTryStep = "IsTriggerModuleCodeSelected?"
            If (objDataRowViewModuleCode.Row("ModuleCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing Trigger Module Code."
                Else
                    strStatus &= vbCrLf & "Missing Trigger Module Code."
                End If
                objX10DbMacroInitiator.triggerModuleCode = ""
            Else
                strTryStep = "triggerModuleCode"
                objX10DbMacroInitiator.triggerModuleCode = objDataRowViewModuleCode(1).ToString ' DisplayMember ex: "1"
            End If ' END - IsTriggerModuleCodeSelected?


            strTryStep = "functionOnOffSelected?"
            If (Not formMacroInitiatorAddUpdateOnRadioButton.Checked And Not formMacroInitiatorAddUpdateOffRadioButton.Checked) Then
                If (strStatus = "") Then
                    strStatus = "Missing Function On/Off Selection."
                Else
                    strStatus &= vbCrLf & "Missing Function On/Off Selection."
                End If
            Else
                strTryStep = "function"
                If (formMacroInitiatorAddUpdateOnRadioButton.Checked) Then
                    objX10DbMacroInitiator.function = 1
                Else
                    objX10DbMacroInitiator.function = 0
                End If
            End If ' END - functionOnOffSelected?


            strTryStep = "DataRowViewController"
            objDataRowViewController = formMacroInitiatorAddUpdateControllerComboBox.SelectedItem

            strTryStep = "IsControllerSelected?"
            If (objDataRowViewController.Row("ControllerID").ToString() = "-1") Then
                ' No
                objX10DbMacroInitiator.ControllerID = -1
                If (strStatus = "") Then
                    strStatus = "Missing Controller Selection."
                Else
                    strStatus &= vbCrLf & "Missing Controller Selection."
                End If
            Else
                ' Yes
                strTryStep = "ControllerID"
                objX10DbMacroInitiator.ControllerID = CType(objDataRowViewController.Row("ControllerID").ToString(), Integer)
            End If ' END - IsControllerSelected?


            ' Was Something Missing?
            If (strStatus = "") Then

                ' Verify the Macro Initiator Name has not already been used.

                strTryStep = "nsX10DbMethods.getX10DbMacroInitiator"
                ' nsX10DbMethods.getX10DbMacroInitiator(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strMacroInitiatorName As String, ByRef objX10DbMacroInitiator As TrekkerPhotoArt.X10Include.X10DbMacroInitiator) As String
                strError = nsX10DbMethods.getX10DbMacroInitiator(strConnectionString, strProvider, objX10DbMacroInitiator.name, objX10DbMacroInitiatorTest)
                If (strError = "") Then

                    ' Was a Macro Initiator found?
                    strTryStep = "WasMacroInitiatorFound"
                    If (Not objX10DbMacroInitiatorTest Is Nothing AndAlso objX10DbMacroInitiatorTest.MacroInitiatorID >= 0) Then
                        ' A Macro Initiator was found with the specified Macro Initiator Name.

                        ' Add or Modify Macro Initiator?
                        strTryStep = "MacroInitiatorFound_AddModifyMacroInitiator"
                        If (formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Add") Then
                            strTryStep = "MacroInitiatorFound_AddMacroInitiator"
                            strStatus = "Unable to Add the Macro Initiator. The Macro Initiator Name has already been used by another Macro Initiator."
                            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else
                            ' Modify Macro Initiator

                            strTryStep = "MacroInitiatorFound_ModifyMacroInitiator_MacroInitiatorID"
                            objX10DbMacroInitiator.MacroInitiatorID = CType(formMacroInitiatorAddUpdateIDLabelText.Text(), Integer)

                            If (objX10DbMacroInitiatorTest.MacroInitiatorID <> objX10DbMacroInitiator.MacroInitiatorID) Then
                                strStatus = "Unable to Update Macro Initiator information. The new Macro Initiator Name has already been used by another Macro Initiator."
                                Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                                formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        End If ' END - Add or Modify Macro Initiator?

                    Else
                        ' Nothing found.
                        strTryStep = "NothingFound_AddModifyMacroInitiator"

                        If (formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Add") Then
                            ' Add Macro Initiator
                            objX10DbMacroInitiator.MacroInitiatorID = -1
                        Else
                            ' Modify Macro Initiator
                            objX10DbMacroInitiator.MacroInitiatorID = CType(formMacroInitiatorAddUpdateIDLabelText.Text(), Integer)
                        End If ' END - Add or Modify Macro Initiator

                    End If ' END - Was a Macro Initiator found?

                Else
                    strStatus = "Problem determining if Macro Initiator Name has already been used." & vbCrLf & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                    formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                End If ' END - nsX10DbMethods.getX10DbMacroInitiator()
                If (strStatus = "") Then

                    strTryStep = "nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand"
                    ' verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(string strX10DbConnectionString, string strX10DbProvider, int intMacroInitiatorID, string strMacroInitiatorName, bool bVerifyMacroInitiatorTriggerOnly, string strTriggerHouseCode, string strTriggerModuleCode)
                    objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand(strConnectionString, strProvider, objX10DbMacroInitiator.MacroInitiatorID, objX10DbMacroInitiator.name, False, objX10DbMacroInitiator.triggerHouseCode, objX10DbMacroInitiator.triggerModuleCode)
                    If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status.Length = 0) Then

                        strTryStep = "triggerUsed"
                        If (objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.triggerUsed) Then
                            strStatus = "Macro Initiator Trigger """ & objX10DbMacroInitiator.triggerHouseCode & objX10DbMacroInitiator.triggerModuleCode & """ is used by the following" & vbCrLf & "Macro Commands:"
                            For Each objMacroCommandUsingTrigger In objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.objMacroCommandsUsingTrigger
                                strStatus &= vbCrLf & "  """ & objMacroCommandUsingTrigger.macroName & """ [" & objMacroCommandUsingTrigger.MacroID.ToString() & "] MacroCommandID=" & objMacroCommandUsingTrigger.MacroCommandID.ToString()
                            Next
                            strStatus &= vbCrLf & vbCrLf & "The Trigger for this Macro Initiator cannot also be used as a Macro Command Module within this Macro Initiator."

                            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else

                            strTryStep = "description"
                            objX10DbMacroInitiator.description = formMacroInitiatorAddUpdateDescriptionTextBox.Text().Trim()

                            strTryStep = "conditions"
                            objX10DbMacroInitiator.conditions = 0

                            strTryStep = "Enabled"
                            Select Case formMacroInitiatorAddUpdateMacroInitiatorEnabledCheckBox.Checked
                                Case True
                                    objX10DbMacroInitiator.Enabled = 1
                                Case False
                                    objX10DbMacroInitiator.Enabled = 0
                            End Select

                            strTryStep = "StartDate"
                            objX10DbMacroInitiator.StartDate = formMacroInitiatorAddUpdateStartDateDateTimePicker.Value
                            objX10DbMacroInitiator.StopDate = formMacroInitiatorAddUpdateStopDateDateTimePicker.Value

                            strTryStep = "nsX10DbMethods.addUpdateMacroInitiatorToX10db"
                            ' nsX10DbMethods.addUpdateMacroInitiatorToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbMacroInitiator As TrekkerPhotoArt.X10Include.X10DbMacroInitiator, ByRef intRowsAffected As Integer) As String
                            strStatus = nsX10DbMethods.addUpdateMacroInitiatorToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbMacroInitiator, intRowsAffected)
                            If (strStatus = "") Then

                                If (intRowsAffected > 0) Then
                                    formMacroInitiatorAddUpdateIDLabelText.Text() = objX10DbMacroInitiator.MacroInitiatorID.ToString()

                                    If (formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Add") Then
                                        formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Update"
                                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Successfully Added"
                                        formMacroInitiatorAddUpdate_DeleteButton.Visible = True

                                        formMacroInitiatorAddUpdateMacrosLabel.Visible = True
                                        formMacroInitiatorAddUpdateMacrosLabel.Text() = "Macros"

                                        strTryStep = "formMacroInitiatorAddUpdate_GetMacrosDataSet"
                                        ' formMacroInitiatorAddUpdate_GetMacrosDataSet(ByVal intMacroInitiatorID As Integer) As String
                                        strStatus = formMacroInitiatorAddUpdate_GetMacrosDataSet(objX10DbMacroInitiator.MacroInitiatorID)
                                        If (strStatus = "") Then
                                            formMacroInitiatorAddUpdateMacrosDataGridView.Visible = True
                                            formMacroInitiatorAddUpdateMacrosDataGridView.Enabled = True
                                        Else
                                            Windows.Forms.MessageBox.Show("formMacroInitiatorAddUpdate_AddUpdateButton_Click(): " & strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                                            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                                        End If

                                    Else
                                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Successfully Updated"
                                    End If

                                    formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                    formMacroInitiatorAddUpdate_CancelButton.Text() = "Done"

                                    objFormMacroInitiatorEdit = New formMacroInitiatorEdit
                                    objFormMacroInitiatorEdit.formMacroInitiatorEdit_BringToFrontLabel.Text() = "N"

                                    ' Refresh DataSet on Form formMacroInitiatorEdit if it's active.
                                    strTryStep = "RefreshDataSetOnFormMacroInitiatorEdit"
                                    If objFormCollection.OfType(Of formMacroInitiatorEdit).Any Then

                                        objFormMacroInitiatorEdit = objFormCollection.Item("formMacroInitiatorEdit")

                                        ' formMacroInitiatorEdit_GetMacroInitiatorsDataSet() As String
                                        strStatus = objFormMacroInitiatorEdit.formMacroInitiatorEdit_GetMacroInitiatorsDataSet()
                                        If (strStatus = "") Then
                                            objFormMacroInitiatorEdit.Activate()
                                        Else
                                            Windows.Forms.MessageBox.Show("formMacroInitiatorAddUpdate_AddUpdateButton_Click(): " & strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        End If ' END - formMacroInitiatorEdit_GetMacroInitiatorsDataSet()

                                    End If

                                Else
                                    formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                                    formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                                    If (formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Add") Then
                                        Windows.Forms.MessageBox.Show("Problem adding Macro Initiator to X10 Db.", "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    Else
                                        Windows.Forms.MessageBox.Show("Problem modifying Macro Initiator to X10 Db.", "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    End If
                                End If ' END - RowsAffected

                            Else
                                formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                                formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                                If (formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Add") Then
                                    Windows.Forms.MessageBox.Show("Problem adding Macro Initiator to X10 Db." & vbCrLf & strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                Else
                                    Windows.Forms.MessageBox.Show("Problem modifying Macro Initiator to X10 Db." & vbCrLf & strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If
                            End If ' END - nsX10DbMethods.addUpdateMacroInitiatorToX10db()

                        End If ' END - triggerUsed

                    Else
                        strStatus = "Problem verifying Macro Initiator Trigger: " & objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass.status
                        Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    End If ' END - nsX10CM15AMethods.verifyX10DbMacroInitiatorTriggerNotUsedByMacroCommand()

                End If ' END - nsX10DbMethods.getX10DbMacroInitiator(Status)

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            End If ' END - Was Something Missing?

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "formMacroInitiatorAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroInitiatorAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            End If

            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormMacroInitiatorEdit = Nothing
            objDataRowViewController = Nothing
            objDataRowViewHouseCode = Nothing
            objDataRowViewModuleCode = Nothing
            objMacroCommandUsingTrigger = Nothing
            objVerifyX10DbMacroInitiatorTriggerNotUsedByMacroCommandClass = Nothing
            objX10DbMacroInitiator = Nothing
            objX10DbMacroInitiatorTest = Nothing
        End Try

    End Sub ' END - formMacroInitiatorAddUpdate_AddUpdateButton_Click()

    Private Sub formMacroInitiatorAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroInitiatorAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formMacroInitiatorAddUpdate_CancelButton_Click()

    Private Sub formMacroInitiatorAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formMacroInitiatorAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim intMacroInitiatorID As Integer = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objMacroInitiatorEdit As formMacroInitiatorEdit = Nothing

        Try

            formMacroInitiatorAddUpdate_StatusLabel.Text = ""
            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            If (formMacroInitiatorAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing MacroInitiatorID", "formMacroInitiatorAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                intMacroInitiatorID = CType(formMacroInitiatorAddUpdateIDLabelText.Text(), Integer)

                ' nsX10DbMethods.removeMacroInitiatorFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef intMacroInitiatorID As Integer, ByRef intRowsAffected As Integer) As String
                strStatus = nsX10DbMethods.removeMacroInitiatorFromX10Db(strConnectionString, strProvider, intMacroInitiatorID, intRowsAffected)
                If (strStatus = "") Then

                    If (intRowsAffected > 0) Then

                        formMacroInitiatorAddUpdateIDLabelText.Text() = ""
                        formMacroInitiatorAddUpdate_AddUpdateButton.Text() = "Add"
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Successfully Deleted"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Done"
                        formMacroInitiatorAddUpdate_DeleteButton.Visible = False

                        formMacroInitiatorAddUpdateMacrosLabel.Visible = True
                        formMacroInitiatorAddUpdateMacrosLabel.Text() = "Macros - New Macro Initiator must first be added."
                        formMacroInitiatorAddUpdateMacrosDataGridView.Rows.Clear()
                        formMacroInitiatorAddUpdateMacrosDataGridView.Visible = True
                        formMacroInitiatorAddUpdateMacrosDataGridView.Enabled = False

                        X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros = -1
                        X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros = -1


                        objMacroInitiatorEdit = New formMacroInitiatorEdit
                        objMacroInitiatorEdit.formMacroInitiatorEdit_BringToFrontLabel.Text() = "N"

                        ' Refresh DataSet on Form formMacroInitiatorEdit if it's active.
                        If objFormCollection.OfType(Of formMacroInitiatorEdit).Any Then

                            objMacroInitiatorEdit = objFormCollection.Item("formMacroInitiatorEdit")

                            ' The row has been deleted.
                            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormMacroInitiatorEdit = -1
                            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorEdit = -1

                            ' formMacroInitiatorEdit_GetMacroInitiatorsDataSet() As String
                            strStatus = objMacroInitiatorEdit.formMacroInitiatorEdit_GetMacroInitiatorsDataSet()
                            If (strStatus = "") Then
                                objMacroInitiatorEdit.Activate()
                            Else
                                Windows.Forms.MessageBox.Show("formMacroInitiatorAddUpdate_DeleteButton_Click(): " & strStatus, "formMacroInitiatorAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If ' END - formMacroInitiatorEdit_GetMacroInitiatorsDataSet()

                        End If

                    Else
                        formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                        formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Macro Initiator from X10 Db.", "formMacroInitiatorAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - RowsAffected

                Else
                    formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
                    formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
                    Windows.Forms.MessageBox.Show("Problem removing Macro Initiator from X10 Db." & vbCrLf & strStatus, "formMacroInitiatorAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - nsX10DbMethods.removeMacroInitiatorFromX10Db

            End If ' END - Is there a MacroInitiatorID?

        Catch ex As Exception
            strStatus = "formMacroInitiatorAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMacroInitiatorAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formMacroInitiatorAddUpdate_StatusLabel.Text = "Fail"
            formMacroInitiatorAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formMacroInitiatorAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objMacroInitiatorEdit = Nothing
        End Try

    End Sub ' END - formMacroInitiatorAddUpdate_DeleteButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formMacroInitiatorAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMacroInitiatorAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formMacroInitiatorAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(725, 690)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationMacroInitiatorAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationMacroInitiatorAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationMacroInitiatorAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formMacroInitiatorAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroInitiatorAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formMacroInitiatorAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formMacroInitiatorAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMacroInitiatorAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formMacroInitiatorAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationMacroInitiatorAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationMacroInitiatorAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formMacroInitiatorAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMacroInitiatorAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formMacroInitiatorAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formMacroInitiatorAddUpdate