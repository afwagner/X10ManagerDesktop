﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formModuleEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.formModuleEditDataGridView = New System.Windows.Forms.DataGridView()
        Me.formModuleEdit_BringToFrontLabel = New System.Windows.Forms.Label()
        CType(Me.formModuleEditDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'formModuleEditDataGridView
        '
        Me.formModuleEditDataGridView.AllowUserToAddRows = False
        Me.formModuleEditDataGridView.AllowUserToDeleteRows = False
        Me.formModuleEditDataGridView.AllowUserToResizeRows = False
        Me.formModuleEditDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formModuleEditDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formModuleEditDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.formModuleEditDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.formModuleEditDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.formModuleEditDataGridView.Name = "formModuleEditDataGridView"
        Me.formModuleEditDataGridView.ReadOnly = True
        Me.formModuleEditDataGridView.ShowCellToolTips = False
        Me.formModuleEditDataGridView.ShowEditingIcon = False
        Me.formModuleEditDataGridView.Size = New System.Drawing.Size(675, 358)
        Me.formModuleEditDataGridView.TabIndex = 2
        '
        'formModuleEdit_BringToFrontLabel
        '
        Me.formModuleEdit_BringToFrontLabel.AutoSize = True
        Me.formModuleEdit_BringToFrontLabel.Location = New System.Drawing.Point(12, 9)
        Me.formModuleEdit_BringToFrontLabel.Name = "formModuleEdit_BringToFrontLabel"
        Me.formModuleEdit_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formModuleEdit_BringToFrontLabel.TabIndex = 3
        Me.formModuleEdit_BringToFrontLabel.Text = "Y | N"
        Me.formModuleEdit_BringToFrontLabel.Visible = False
        '
        'formModuleEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(675, 358)
        Me.Controls.Add(Me.formModuleEdit_BringToFrontLabel)
        Me.Controls.Add(Me.formModuleEditDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formModuleEdit"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Module Edit"
        CType(Me.formModuleEditDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formModuleEditDataGridView As DataGridView
    Friend WithEvents formModuleEdit_BringToFrontLabel As Label
End Class
