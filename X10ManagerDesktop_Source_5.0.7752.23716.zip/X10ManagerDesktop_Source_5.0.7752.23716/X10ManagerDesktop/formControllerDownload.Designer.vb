﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formControllerDownload
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formControllerDownload))
        Me.formControllerDownload_StatusLabel = New System.Windows.Forms.Label()
        Me.formControllerDownload_DownloadButton = New System.Windows.Forms.Button()
        Me.formControllerDownload_CancelButton = New System.Windows.Forms.Button()
        Me.formControllerDownloadControllersLabel = New System.Windows.Forms.Label()
        Me.formControllerDownloadControllersDataGridView = New System.Windows.Forms.DataGridView()
        CType(Me.formControllerDownloadControllersDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'formControllerDownload_StatusLabel
        '
        Me.formControllerDownload_StatusLabel.AutoSize = True
        Me.formControllerDownload_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formControllerDownload_StatusLabel.Location = New System.Drawing.Point(93, 256)
        Me.formControllerDownload_StatusLabel.Name = "formControllerDownload_StatusLabel"
        Me.formControllerDownload_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formControllerDownload_StatusLabel.TabIndex = 9
        Me.formControllerDownload_StatusLabel.Text = "Success | Fail"
        '
        'formControllerDownload_DownloadButton
        '
        Me.formControllerDownload_DownloadButton.Location = New System.Drawing.Point(12, 253)
        Me.formControllerDownload_DownloadButton.Name = "formControllerDownload_DownloadButton"
        Me.formControllerDownload_DownloadButton.Size = New System.Drawing.Size(75, 23)
        Me.formControllerDownload_DownloadButton.TabIndex = 8
        Me.formControllerDownload_DownloadButton.Text = "Download"
        Me.formControllerDownload_DownloadButton.UseVisualStyleBackColor = True
        '
        'formControllerDownload_CancelButton
        '
        Me.formControllerDownload_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formControllerDownload_CancelButton.Location = New System.Drawing.Point(523, 253)
        Me.formControllerDownload_CancelButton.Name = "formControllerDownload_CancelButton"
        Me.formControllerDownload_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formControllerDownload_CancelButton.TabIndex = 7
        Me.formControllerDownload_CancelButton.Text = "Cancel"
        Me.formControllerDownload_CancelButton.UseMnemonic = False
        Me.formControllerDownload_CancelButton.UseVisualStyleBackColor = True
        '
        'formControllerDownloadControllersLabel
        '
        Me.formControllerDownloadControllersLabel.AutoSize = True
        Me.formControllerDownloadControllersLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formControllerDownloadControllersLabel.Location = New System.Drawing.Point(156, 9)
        Me.formControllerDownloadControllersLabel.Name = "formControllerDownloadControllersLabel"
        Me.formControllerDownloadControllersLabel.Size = New System.Drawing.Size(247, 17)
        Me.formControllerDownloadControllersLabel.TabIndex = 44
        Me.formControllerDownloadControllersLabel.Text = "Download Events to Active Controllers"
        '
        'formControllerDownloadControllersDataGridView
        '
        Me.formControllerDownloadControllersDataGridView.AllowDrop = True
        Me.formControllerDownloadControllersDataGridView.AllowUserToAddRows = False
        Me.formControllerDownloadControllersDataGridView.AllowUserToDeleteRows = False
        Me.formControllerDownloadControllersDataGridView.AllowUserToResizeColumns = False
        Me.formControllerDownloadControllersDataGridView.AllowUserToResizeRows = False
        Me.formControllerDownloadControllersDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formControllerDownloadControllersDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formControllerDownloadControllersDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.formControllerDownloadControllersDataGridView.Location = New System.Drawing.Point(0, 39)
        Me.formControllerDownloadControllersDataGridView.Name = "formControllerDownloadControllersDataGridView"
        Me.formControllerDownloadControllersDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.formControllerDownloadControllersDataGridView.ShowCellToolTips = False
        Me.formControllerDownloadControllersDataGridView.ShowEditingIcon = False
        Me.formControllerDownloadControllersDataGridView.Size = New System.Drawing.Size(610, 199)
        Me.formControllerDownloadControllersDataGridView.TabIndex = 45
        '
        'formControllerDownload
        '
        Me.AcceptButton = Me.formControllerDownload_DownloadButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formControllerDownload_CancelButton
        Me.ClientSize = New System.Drawing.Size(610, 287)
        Me.Controls.Add(Me.formControllerDownloadControllersDataGridView)
        Me.Controls.Add(Me.formControllerDownloadControllersLabel)
        Me.Controls.Add(Me.formControllerDownload_StatusLabel)
        Me.Controls.Add(Me.formControllerDownload_DownloadButton)
        Me.Controls.Add(Me.formControllerDownload_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formControllerDownload"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Controllers Download"
        CType(Me.formControllerDownloadControllersDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formControllerDownload_StatusLabel As Label
    Friend WithEvents formControllerDownload_DownloadButton As Button
    Friend WithEvents formControllerDownload_CancelButton As Button
    Friend WithEvents formControllerDownloadControllersLabel As Label
    Friend WithEvents formControllerDownloadControllersDataGridView As DataGridView
End Class
