﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formMacroCommandAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formMacroCommandAddUpdate))
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateMacroIDLabelText = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateCallingFormLabelText = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateMacroCommandIDLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formMacroCommandAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formMacroCommandAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateMacroInitatorNameLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateHouseCodeLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateCommandLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateUnitCodeLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateExtendedCommandLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateExtendedDataByteLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateHouseCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroCommandAddUpdateCommandComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroCommandAddUpdateUnitCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroCommandAddUpdateExtendedCommandComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroCommandAddUpdateUnitsPanel = New System.Windows.Forms.Panel()
        Me.formMacroCommandAddUpdateUnit16CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit09CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit10CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit15CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit11CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit14CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit12CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit13CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit08CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnitsLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateUnit01CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit07CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit06CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit03CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit02CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit05CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateUnit04CheckBox = New System.Windows.Forms.CheckBox()
        Me.formMacroCommandAddUpdateExtendedDataByteTextBox = New System.Windows.Forms.TextBox()
        Me.formMacroCommandAddUpdatePreDimBrightLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdatePreDimBrightPanel = New System.Windows.Forms.Panel()
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton = New System.Windows.Forms.RadioButton()
        Me.formMacroCommandAddUpdateDimBrightLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateMacroCommandSortOrderComboBox = New System.Windows.Forms.ComboBox()
        Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateMacroNameLabelText = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateMacroNameLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateDimsBrightsFormatLabel = New System.Windows.Forms.Label()
        Me.formMacroCommandAddUpdateDimsBrightsTextBox = New System.Windows.Forms.TextBox()
        Me.formMacroCommandAddUpdateUnitsPanel.SuspendLayout()
        Me.formMacroCommandAddUpdatePreDimBrightPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'formMacroCommandAddUpdateMacroInitatorIDLabelText
        '
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText.AutoSize = True
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText.Location = New System.Drawing.Point(140, 375)
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText.Name = "formMacroCommandAddUpdateMacroInitatorIDLabelText"
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText.Size = New System.Drawing.Size(79, 13)
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText.TabIndex = 80
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText.Text = "macroInitatorID"
        Me.formMacroCommandAddUpdateMacroInitatorIDLabelText.Visible = False
        '
        'formMacroCommandAddUpdateMacroIDLabelText
        '
        Me.formMacroCommandAddUpdateMacroIDLabelText.AutoSize = True
        Me.formMacroCommandAddUpdateMacroIDLabelText.Location = New System.Drawing.Point(238, 375)
        Me.formMacroCommandAddUpdateMacroIDLabelText.Name = "formMacroCommandAddUpdateMacroIDLabelText"
        Me.formMacroCommandAddUpdateMacroIDLabelText.Size = New System.Drawing.Size(47, 13)
        Me.formMacroCommandAddUpdateMacroIDLabelText.TabIndex = 79
        Me.formMacroCommandAddUpdateMacroIDLabelText.Text = "macroID"
        Me.formMacroCommandAddUpdateMacroIDLabelText.Visible = False
        '
        'formMacroCommandAddUpdateCallingFormLabelText
        '
        Me.formMacroCommandAddUpdateCallingFormLabelText.AutoSize = True
        Me.formMacroCommandAddUpdateCallingFormLabelText.Location = New System.Drawing.Point(53, 375)
        Me.formMacroCommandAddUpdateCallingFormLabelText.Name = "formMacroCommandAddUpdateCallingFormLabelText"
        Me.formMacroCommandAddUpdateCallingFormLabelText.Size = New System.Drawing.Size(64, 13)
        Me.formMacroCommandAddUpdateCallingFormLabelText.TabIndex = 78
        Me.formMacroCommandAddUpdateCallingFormLabelText.Text = "Calling Form"
        Me.formMacroCommandAddUpdateCallingFormLabelText.Visible = False
        '
        'formMacroCommandAddUpdate_StatusLabel
        '
        Me.formMacroCommandAddUpdate_StatusLabel.AutoSize = True
        Me.formMacroCommandAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formMacroCommandAddUpdate_StatusLabel.Location = New System.Drawing.Point(140, 397)
        Me.formMacroCommandAddUpdate_StatusLabel.Name = "formMacroCommandAddUpdate_StatusLabel"
        Me.formMacroCommandAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formMacroCommandAddUpdate_StatusLabel.TabIndex = 76
        Me.formMacroCommandAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formMacroCommandAddUpdateIDLabelText
        '
        Me.formMacroCommandAddUpdateIDLabelText.AutoSize = True
        Me.formMacroCommandAddUpdateIDLabelText.Location = New System.Drawing.Point(149, 21)
        Me.formMacroCommandAddUpdateIDLabelText.Name = "formMacroCommandAddUpdateIDLabelText"
        Me.formMacroCommandAddUpdateIDLabelText.Size = New System.Drawing.Size(216, 13)
        Me.formMacroCommandAddUpdateIDLabelText.TabIndex = 75
        Me.formMacroCommandAddUpdateIDLabelText.Text = "formMacroCommandAddUpdateIDLabelText"
        '
        'formMacroCommandAddUpdateMacroCommandIDLabel
        '
        Me.formMacroCommandAddUpdateMacroCommandIDLabel.AutoSize = True
        Me.formMacroCommandAddUpdateMacroCommandIDLabel.Location = New System.Drawing.Point(45, 21)
        Me.formMacroCommandAddUpdateMacroCommandIDLabel.Name = "formMacroCommandAddUpdateMacroCommandIDLabel"
        Me.formMacroCommandAddUpdateMacroCommandIDLabel.Size = New System.Drawing.Size(98, 13)
        Me.formMacroCommandAddUpdateMacroCommandIDLabel.TabIndex = 74
        Me.formMacroCommandAddUpdateMacroCommandIDLabel.Text = "MacroCommandID:"
        '
        'formMacroCommandAddUpdate_DeleteButton
        '
        Me.formMacroCommandAddUpdate_DeleteButton.Location = New System.Drawing.Point(371, 16)
        Me.formMacroCommandAddUpdate_DeleteButton.Name = "formMacroCommandAddUpdate_DeleteButton"
        Me.formMacroCommandAddUpdate_DeleteButton.Size = New System.Drawing.Size(79, 23)
        Me.formMacroCommandAddUpdate_DeleteButton.TabIndex = 73
        Me.formMacroCommandAddUpdate_DeleteButton.Text = "Delete"
        Me.formMacroCommandAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdate_AddUpdateButton
        '
        Me.formMacroCommandAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(48, 394)
        Me.formMacroCommandAddUpdate_AddUpdateButton.Name = "formMacroCommandAddUpdate_AddUpdateButton"
        Me.formMacroCommandAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(86, 23)
        Me.formMacroCommandAddUpdate_AddUpdateButton.TabIndex = 72
        Me.formMacroCommandAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formMacroCommandAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdate_CancelButton
        '
        Me.formMacroCommandAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formMacroCommandAddUpdate_CancelButton.Location = New System.Drawing.Point(348, 394)
        Me.formMacroCommandAddUpdate_CancelButton.Name = "formMacroCommandAddUpdate_CancelButton"
        Me.formMacroCommandAddUpdate_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formMacroCommandAddUpdate_CancelButton.TabIndex = 71
        Me.formMacroCommandAddUpdate_CancelButton.Text = "Cancel"
        Me.formMacroCommandAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateMacroInInitatorNameLabelText
        '
        Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText.AutoSize = True
        Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText.Location = New System.Drawing.Point(149, 74)
        Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText.Name = "formMacroCommandAddUpdateMacroInInitatorNameLabelText"
        Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText.Size = New System.Drawing.Size(105, 13)
        Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText.TabIndex = 82
        Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText.Text = "macroInInitatorName"
        '
        'formMacroCommandAddUpdateMacroInitatorNameLabel
        '
        Me.formMacroCommandAddUpdateMacroInitatorNameLabel.AutoSize = True
        Me.formMacroCommandAddUpdateMacroInitatorNameLabel.Location = New System.Drawing.Point(35, 74)
        Me.formMacroCommandAddUpdateMacroInitatorNameLabel.Name = "formMacroCommandAddUpdateMacroInitatorNameLabel"
        Me.formMacroCommandAddUpdateMacroInitatorNameLabel.Size = New System.Drawing.Size(108, 13)
        Me.formMacroCommandAddUpdateMacroInitatorNameLabel.TabIndex = 81
        Me.formMacroCommandAddUpdateMacroInitatorNameLabel.Text = "Macro Initiator Name:"
        '
        'formMacroCommandAddUpdateHouseCodeLabel
        '
        Me.formMacroCommandAddUpdateHouseCodeLabel.AutoSize = True
        Me.formMacroCommandAddUpdateHouseCodeLabel.Location = New System.Drawing.Point(74, 154)
        Me.formMacroCommandAddUpdateHouseCodeLabel.Name = "formMacroCommandAddUpdateHouseCodeLabel"
        Me.formMacroCommandAddUpdateHouseCodeLabel.Size = New System.Drawing.Size(69, 13)
        Me.formMacroCommandAddUpdateHouseCodeLabel.TabIndex = 83
        Me.formMacroCommandAddUpdateHouseCodeLabel.Text = "House Code:"
        '
        'formMacroCommandAddUpdateCommandLabel
        '
        Me.formMacroCommandAddUpdateCommandLabel.AutoSize = True
        Me.formMacroCommandAddUpdateCommandLabel.Location = New System.Drawing.Point(86, 127)
        Me.formMacroCommandAddUpdateCommandLabel.Name = "formMacroCommandAddUpdateCommandLabel"
        Me.formMacroCommandAddUpdateCommandLabel.Size = New System.Drawing.Size(57, 13)
        Me.formMacroCommandAddUpdateCommandLabel.TabIndex = 84
        Me.formMacroCommandAddUpdateCommandLabel.Text = "Command:"
        '
        'formMacroCommandAddUpdateUnitCodeLabel
        '
        Me.formMacroCommandAddUpdateUnitCodeLabel.AutoSize = True
        Me.formMacroCommandAddUpdateUnitCodeLabel.Location = New System.Drawing.Point(86, 290)
        Me.formMacroCommandAddUpdateUnitCodeLabel.Name = "formMacroCommandAddUpdateUnitCodeLabel"
        Me.formMacroCommandAddUpdateUnitCodeLabel.Size = New System.Drawing.Size(57, 13)
        Me.formMacroCommandAddUpdateUnitCodeLabel.TabIndex = 85
        Me.formMacroCommandAddUpdateUnitCodeLabel.Text = "Unit Code:"
        '
        'formMacroCommandAddUpdateExtendedCommandLabel
        '
        Me.formMacroCommandAddUpdateExtendedCommandLabel.AutoSize = True
        Me.formMacroCommandAddUpdateExtendedCommandLabel.Location = New System.Drawing.Point(38, 318)
        Me.formMacroCommandAddUpdateExtendedCommandLabel.Name = "formMacroCommandAddUpdateExtendedCommandLabel"
        Me.formMacroCommandAddUpdateExtendedCommandLabel.Size = New System.Drawing.Size(105, 13)
        Me.formMacroCommandAddUpdateExtendedCommandLabel.TabIndex = 86
        Me.formMacroCommandAddUpdateExtendedCommandLabel.Text = "Extended Command:"
        '
        'formMacroCommandAddUpdateExtendedDataByteLabel
        '
        Me.formMacroCommandAddUpdateExtendedDataByteLabel.AutoSize = True
        Me.formMacroCommandAddUpdateExtendedDataByteLabel.Location = New System.Drawing.Point(38, 347)
        Me.formMacroCommandAddUpdateExtendedDataByteLabel.Name = "formMacroCommandAddUpdateExtendedDataByteLabel"
        Me.formMacroCommandAddUpdateExtendedDataByteLabel.Size = New System.Drawing.Size(105, 13)
        Me.formMacroCommandAddUpdateExtendedDataByteLabel.TabIndex = 87
        Me.formMacroCommandAddUpdateExtendedDataByteLabel.Text = "Extended Data Byte:"
        '
        'formMacroCommandAddUpdateHouseCodeComboBox
        '
        Me.formMacroCommandAddUpdateHouseCodeComboBox.FormattingEnabled = True
        Me.formMacroCommandAddUpdateHouseCodeComboBox.Location = New System.Drawing.Point(149, 151)
        Me.formMacroCommandAddUpdateHouseCodeComboBox.Name = "formMacroCommandAddUpdateHouseCodeComboBox"
        Me.formMacroCommandAddUpdateHouseCodeComboBox.Size = New System.Drawing.Size(136, 21)
        Me.formMacroCommandAddUpdateHouseCodeComboBox.TabIndex = 88
        '
        'formMacroCommandAddUpdateCommandComboBox
        '
        Me.formMacroCommandAddUpdateCommandComboBox.FormattingEnabled = True
        Me.formMacroCommandAddUpdateCommandComboBox.Location = New System.Drawing.Point(149, 124)
        Me.formMacroCommandAddUpdateCommandComboBox.Name = "formMacroCommandAddUpdateCommandComboBox"
        Me.formMacroCommandAddUpdateCommandComboBox.Size = New System.Drawing.Size(163, 21)
        Me.formMacroCommandAddUpdateCommandComboBox.TabIndex = 89
        '
        'formMacroCommandAddUpdateUnitCodeComboBox
        '
        Me.formMacroCommandAddUpdateUnitCodeComboBox.FormattingEnabled = True
        Me.formMacroCommandAddUpdateUnitCodeComboBox.Location = New System.Drawing.Point(149, 287)
        Me.formMacroCommandAddUpdateUnitCodeComboBox.Name = "formMacroCommandAddUpdateUnitCodeComboBox"
        Me.formMacroCommandAddUpdateUnitCodeComboBox.Size = New System.Drawing.Size(136, 21)
        Me.formMacroCommandAddUpdateUnitCodeComboBox.TabIndex = 90
        '
        'formMacroCommandAddUpdateExtendedCommandComboBox
        '
        Me.formMacroCommandAddUpdateExtendedCommandComboBox.FormattingEnabled = True
        Me.formMacroCommandAddUpdateExtendedCommandComboBox.Location = New System.Drawing.Point(149, 315)
        Me.formMacroCommandAddUpdateExtendedCommandComboBox.Name = "formMacroCommandAddUpdateExtendedCommandComboBox"
        Me.formMacroCommandAddUpdateExtendedCommandComboBox.Size = New System.Drawing.Size(404, 21)
        Me.formMacroCommandAddUpdateExtendedCommandComboBox.TabIndex = 91
        '
        'formMacroCommandAddUpdateUnitsPanel
        '
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit16CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit09CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit10CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit15CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit11CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit14CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit12CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit13CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit08CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnitsLabel)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit01CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit07CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit06CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit03CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit02CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit05CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Controls.Add(Me.formMacroCommandAddUpdateUnit04CheckBox)
        Me.formMacroCommandAddUpdateUnitsPanel.Location = New System.Drawing.Point(95, 178)
        Me.formMacroCommandAddUpdateUnitsPanel.Name = "formMacroCommandAddUpdateUnitsPanel"
        Me.formMacroCommandAddUpdateUnitsPanel.Size = New System.Drawing.Size(406, 44)
        Me.formMacroCommandAddUpdateUnitsPanel.TabIndex = 92
        '
        'formMacroCommandAddUpdateUnit16CheckBox
        '
        Me.formMacroCommandAddUpdateUnit16CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit16CheckBox.Location = New System.Drawing.Point(364, 26)
        Me.formMacroCommandAddUpdateUnit16CheckBox.Name = "formMacroCommandAddUpdateUnit16CheckBox"
        Me.formMacroCommandAddUpdateUnit16CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.formMacroCommandAddUpdateUnit16CheckBox.TabIndex = 59
        Me.formMacroCommandAddUpdateUnit16CheckBox.Text = "16"
        Me.formMacroCommandAddUpdateUnit16CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit09CheckBox
        '
        Me.formMacroCommandAddUpdateUnit09CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit09CheckBox.Location = New System.Drawing.Point(232, 3)
        Me.formMacroCommandAddUpdateUnit09CheckBox.Name = "formMacroCommandAddUpdateUnit09CheckBox"
        Me.formMacroCommandAddUpdateUnit09CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit09CheckBox.TabIndex = 52
        Me.formMacroCommandAddUpdateUnit09CheckBox.Text = "9"
        Me.formMacroCommandAddUpdateUnit09CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit10CheckBox
        '
        Me.formMacroCommandAddUpdateUnit10CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit10CheckBox.Location = New System.Drawing.Point(232, 26)
        Me.formMacroCommandAddUpdateUnit10CheckBox.Name = "formMacroCommandAddUpdateUnit10CheckBox"
        Me.formMacroCommandAddUpdateUnit10CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.formMacroCommandAddUpdateUnit10CheckBox.TabIndex = 53
        Me.formMacroCommandAddUpdateUnit10CheckBox.Text = "10"
        Me.formMacroCommandAddUpdateUnit10CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit15CheckBox
        '
        Me.formMacroCommandAddUpdateUnit15CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit15CheckBox.Location = New System.Drawing.Point(364, 3)
        Me.formMacroCommandAddUpdateUnit15CheckBox.Name = "formMacroCommandAddUpdateUnit15CheckBox"
        Me.formMacroCommandAddUpdateUnit15CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.formMacroCommandAddUpdateUnit15CheckBox.TabIndex = 58
        Me.formMacroCommandAddUpdateUnit15CheckBox.Text = "15"
        Me.formMacroCommandAddUpdateUnit15CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit11CheckBox
        '
        Me.formMacroCommandAddUpdateUnit11CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit11CheckBox.Location = New System.Drawing.Point(274, 3)
        Me.formMacroCommandAddUpdateUnit11CheckBox.Name = "formMacroCommandAddUpdateUnit11CheckBox"
        Me.formMacroCommandAddUpdateUnit11CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.formMacroCommandAddUpdateUnit11CheckBox.TabIndex = 54
        Me.formMacroCommandAddUpdateUnit11CheckBox.Text = "11"
        Me.formMacroCommandAddUpdateUnit11CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit14CheckBox
        '
        Me.formMacroCommandAddUpdateUnit14CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit14CheckBox.Location = New System.Drawing.Point(320, 26)
        Me.formMacroCommandAddUpdateUnit14CheckBox.Name = "formMacroCommandAddUpdateUnit14CheckBox"
        Me.formMacroCommandAddUpdateUnit14CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.formMacroCommandAddUpdateUnit14CheckBox.TabIndex = 57
        Me.formMacroCommandAddUpdateUnit14CheckBox.Text = "14"
        Me.formMacroCommandAddUpdateUnit14CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit12CheckBox
        '
        Me.formMacroCommandAddUpdateUnit12CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit12CheckBox.Location = New System.Drawing.Point(274, 26)
        Me.formMacroCommandAddUpdateUnit12CheckBox.Name = "formMacroCommandAddUpdateUnit12CheckBox"
        Me.formMacroCommandAddUpdateUnit12CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.formMacroCommandAddUpdateUnit12CheckBox.TabIndex = 55
        Me.formMacroCommandAddUpdateUnit12CheckBox.Text = "12"
        Me.formMacroCommandAddUpdateUnit12CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit13CheckBox
        '
        Me.formMacroCommandAddUpdateUnit13CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit13CheckBox.Location = New System.Drawing.Point(320, 3)
        Me.formMacroCommandAddUpdateUnit13CheckBox.Name = "formMacroCommandAddUpdateUnit13CheckBox"
        Me.formMacroCommandAddUpdateUnit13CheckBox.Size = New System.Drawing.Size(38, 17)
        Me.formMacroCommandAddUpdateUnit13CheckBox.TabIndex = 56
        Me.formMacroCommandAddUpdateUnit13CheckBox.Text = "13"
        Me.formMacroCommandAddUpdateUnit13CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit08CheckBox
        '
        Me.formMacroCommandAddUpdateUnit08CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit08CheckBox.Location = New System.Drawing.Point(185, 26)
        Me.formMacroCommandAddUpdateUnit08CheckBox.Name = "formMacroCommandAddUpdateUnit08CheckBox"
        Me.formMacroCommandAddUpdateUnit08CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit08CheckBox.TabIndex = 51
        Me.formMacroCommandAddUpdateUnit08CheckBox.Text = "8"
        Me.formMacroCommandAddUpdateUnit08CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnitsLabel
        '
        Me.formMacroCommandAddUpdateUnitsLabel.AutoSize = True
        Me.formMacroCommandAddUpdateUnitsLabel.Location = New System.Drawing.Point(8, 16)
        Me.formMacroCommandAddUpdateUnitsLabel.Name = "formMacroCommandAddUpdateUnitsLabel"
        Me.formMacroCommandAddUpdateUnitsLabel.Size = New System.Drawing.Size(40, 13)
        Me.formMacroCommandAddUpdateUnitsLabel.TabIndex = 35
        Me.formMacroCommandAddUpdateUnitsLabel.Text = "Unit(s):"
        '
        'formMacroCommandAddUpdateUnit01CheckBox
        '
        Me.formMacroCommandAddUpdateUnit01CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit01CheckBox.Location = New System.Drawing.Point(56, 3)
        Me.formMacroCommandAddUpdateUnit01CheckBox.Name = "formMacroCommandAddUpdateUnit01CheckBox"
        Me.formMacroCommandAddUpdateUnit01CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit01CheckBox.TabIndex = 44
        Me.formMacroCommandAddUpdateUnit01CheckBox.Text = "1"
        Me.formMacroCommandAddUpdateUnit01CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit07CheckBox
        '
        Me.formMacroCommandAddUpdateUnit07CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit07CheckBox.Location = New System.Drawing.Point(185, 3)
        Me.formMacroCommandAddUpdateUnit07CheckBox.Name = "formMacroCommandAddUpdateUnit07CheckBox"
        Me.formMacroCommandAddUpdateUnit07CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit07CheckBox.TabIndex = 50
        Me.formMacroCommandAddUpdateUnit07CheckBox.Text = "7"
        Me.formMacroCommandAddUpdateUnit07CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit06CheckBox
        '
        Me.formMacroCommandAddUpdateUnit06CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit06CheckBox.Location = New System.Drawing.Point(141, 26)
        Me.formMacroCommandAddUpdateUnit06CheckBox.Name = "formMacroCommandAddUpdateUnit06CheckBox"
        Me.formMacroCommandAddUpdateUnit06CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit06CheckBox.TabIndex = 49
        Me.formMacroCommandAddUpdateUnit06CheckBox.Text = "6"
        Me.formMacroCommandAddUpdateUnit06CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit03CheckBox
        '
        Me.formMacroCommandAddUpdateUnit03CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit03CheckBox.Location = New System.Drawing.Point(97, 3)
        Me.formMacroCommandAddUpdateUnit03CheckBox.Name = "formMacroCommandAddUpdateUnit03CheckBox"
        Me.formMacroCommandAddUpdateUnit03CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit03CheckBox.TabIndex = 46
        Me.formMacroCommandAddUpdateUnit03CheckBox.Text = "3"
        Me.formMacroCommandAddUpdateUnit03CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit02CheckBox
        '
        Me.formMacroCommandAddUpdateUnit02CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit02CheckBox.Location = New System.Drawing.Point(56, 26)
        Me.formMacroCommandAddUpdateUnit02CheckBox.Name = "formMacroCommandAddUpdateUnit02CheckBox"
        Me.formMacroCommandAddUpdateUnit02CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit02CheckBox.TabIndex = 45
        Me.formMacroCommandAddUpdateUnit02CheckBox.Text = "2"
        Me.formMacroCommandAddUpdateUnit02CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit05CheckBox
        '
        Me.formMacroCommandAddUpdateUnit05CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit05CheckBox.Location = New System.Drawing.Point(141, 3)
        Me.formMacroCommandAddUpdateUnit05CheckBox.Name = "formMacroCommandAddUpdateUnit05CheckBox"
        Me.formMacroCommandAddUpdateUnit05CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit05CheckBox.TabIndex = 48
        Me.formMacroCommandAddUpdateUnit05CheckBox.Text = "5"
        Me.formMacroCommandAddUpdateUnit05CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateUnit04CheckBox
        '
        Me.formMacroCommandAddUpdateUnit04CheckBox.AutoSize = True
        Me.formMacroCommandAddUpdateUnit04CheckBox.Location = New System.Drawing.Point(97, 26)
        Me.formMacroCommandAddUpdateUnit04CheckBox.Name = "formMacroCommandAddUpdateUnit04CheckBox"
        Me.formMacroCommandAddUpdateUnit04CheckBox.Size = New System.Drawing.Size(32, 17)
        Me.formMacroCommandAddUpdateUnit04CheckBox.TabIndex = 47
        Me.formMacroCommandAddUpdateUnit04CheckBox.Text = "4"
        Me.formMacroCommandAddUpdateUnit04CheckBox.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateExtendedDataByteTextBox
        '
        Me.formMacroCommandAddUpdateExtendedDataByteTextBox.Location = New System.Drawing.Point(149, 344)
        Me.formMacroCommandAddUpdateExtendedDataByteTextBox.Name = "formMacroCommandAddUpdateExtendedDataByteTextBox"
        Me.formMacroCommandAddUpdateExtendedDataByteTextBox.Size = New System.Drawing.Size(51, 20)
        Me.formMacroCommandAddUpdateExtendedDataByteTextBox.TabIndex = 93
        '
        'formMacroCommandAddUpdatePreDimBrightLabel
        '
        Me.formMacroCommandAddUpdatePreDimBrightLabel.AutoSize = True
        Me.formMacroCommandAddUpdatePreDimBrightLabel.Location = New System.Drawing.Point(88, 231)
        Me.formMacroCommandAddUpdatePreDimBrightLabel.Name = "formMacroCommandAddUpdatePreDimBrightLabel"
        Me.formMacroCommandAddUpdatePreDimBrightLabel.Size = New System.Drawing.Size(55, 13)
        Me.formMacroCommandAddUpdatePreDimBrightLabel.TabIndex = 94
        Me.formMacroCommandAddUpdatePreDimBrightLabel.Text = "pre-Bright:"
        '
        'formMacroCommandAddUpdatePreDimBrightPanel
        '
        Me.formMacroCommandAddUpdatePreDimBrightPanel.Controls.Add(Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton)
        Me.formMacroCommandAddUpdatePreDimBrightPanel.Controls.Add(Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton)
        Me.formMacroCommandAddUpdatePreDimBrightPanel.Location = New System.Drawing.Point(149, 223)
        Me.formMacroCommandAddUpdatePreDimBrightPanel.Name = "formMacroCommandAddUpdatePreDimBrightPanel"
        Me.formMacroCommandAddUpdatePreDimBrightPanel.Size = New System.Drawing.Size(100, 29)
        Me.formMacroCommandAddUpdatePreDimBrightPanel.TabIndex = 95
        '
        'formMacroCommandAddUpdatePreDimBrightNoRadioButton
        '
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.AutoSize = True
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.Location = New System.Drawing.Point(50, 6)
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.Name = "formMacroCommandAddUpdatePreDimBrightNoRadioButton"
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.Size = New System.Drawing.Size(39, 17)
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.TabIndex = 63
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.TabStop = True
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.Text = "No"
        Me.formMacroCommandAddUpdatePreDimBrightNoRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdatePreDimBrightYesRadioButton
        '
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.AutoSize = True
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.Location = New System.Drawing.Point(3, 6)
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.Name = "formMacroCommandAddUpdatePreDimBrightYesRadioButton"
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.Size = New System.Drawing.Size(43, 17)
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.TabIndex = 39
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.TabStop = True
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.Text = "Yes"
        Me.formMacroCommandAddUpdatePreDimBrightYesRadioButton.UseVisualStyleBackColor = True
        '
        'formMacroCommandAddUpdateDimBrightLabel
        '
        Me.formMacroCommandAddUpdateDimBrightLabel.AutoSize = True
        Me.formMacroCommandAddUpdateDimBrightLabel.Location = New System.Drawing.Point(101, 261)
        Me.formMacroCommandAddUpdateDimBrightLabel.Name = "formMacroCommandAddUpdateDimBrightLabel"
        Me.formMacroCommandAddUpdateDimBrightLabel.Size = New System.Drawing.Size(42, 13)
        Me.formMacroCommandAddUpdateDimBrightLabel.TabIndex = 96
        Me.formMacroCommandAddUpdateDimBrightLabel.Text = "Brights:"
        '
        'formMacroCommandAddUpdateExtendedDataByteFormatLabel
        '
        Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel.AutoSize = True
        Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel.Location = New System.Drawing.Point(206, 347)
        Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel.Name = "formMacroCommandAddUpdateExtendedDataByteFormatLabel"
        Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel.Size = New System.Drawing.Size(184, 13)
        Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel.TabIndex = 98
        Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel.Text = "Decimal number ranged from 0 to 255"
        '
        'formMacroCommandAddUpdateMacroCommandSortOrderComboBox
        '
        Me.formMacroCommandAddUpdateMacroCommandSortOrderComboBox.FormattingEnabled = True
        Me.formMacroCommandAddUpdateMacroCommandSortOrderComboBox.Location = New System.Drawing.Point(149, 97)
        Me.formMacroCommandAddUpdateMacroCommandSortOrderComboBox.Name = "formMacroCommandAddUpdateMacroCommandSortOrderComboBox"
        Me.formMacroCommandAddUpdateMacroCommandSortOrderComboBox.Size = New System.Drawing.Size(69, 21)
        Me.formMacroCommandAddUpdateMacroCommandSortOrderComboBox.TabIndex = 101
        '
        'formMacroCommandAddUpdateMacroCommandSortOrderLabel
        '
        Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel.AutoSize = True
        Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel.Location = New System.Drawing.Point(2, 99)
        Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel.Name = "formMacroCommandAddUpdateMacroCommandSortOrderLabel"
        Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel.Size = New System.Drawing.Size(141, 13)
        Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel.TabIndex = 100
        Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel.Text = "Macro Command Sort Order:"
        '
        'formMacroCommandAddUpdateMacroNameLabelText
        '
        Me.formMacroCommandAddUpdateMacroNameLabelText.AutoSize = True
        Me.formMacroCommandAddUpdateMacroNameLabelText.Location = New System.Drawing.Point(149, 49)
        Me.formMacroCommandAddUpdateMacroNameLabelText.Name = "formMacroCommandAddUpdateMacroNameLabelText"
        Me.formMacroCommandAddUpdateMacroNameLabelText.Size = New System.Drawing.Size(64, 13)
        Me.formMacroCommandAddUpdateMacroNameLabelText.TabIndex = 103
        Me.formMacroCommandAddUpdateMacroNameLabelText.Text = "macroName"
        '
        'formMacroCommandAddUpdateMacroNameLabel
        '
        Me.formMacroCommandAddUpdateMacroNameLabel.AutoSize = True
        Me.formMacroCommandAddUpdateMacroNameLabel.Location = New System.Drawing.Point(72, 49)
        Me.formMacroCommandAddUpdateMacroNameLabel.Name = "formMacroCommandAddUpdateMacroNameLabel"
        Me.formMacroCommandAddUpdateMacroNameLabel.Size = New System.Drawing.Size(71, 13)
        Me.formMacroCommandAddUpdateMacroNameLabel.TabIndex = 102
        Me.formMacroCommandAddUpdateMacroNameLabel.Text = "Macro Name:"
        '
        'formMacroCommandAddUpdateDimsBrightsFormatLabel
        '
        Me.formMacroCommandAddUpdateDimsBrightsFormatLabel.AutoSize = True
        Me.formMacroCommandAddUpdateDimsBrightsFormatLabel.Location = New System.Drawing.Point(206, 261)
        Me.formMacroCommandAddUpdateDimsBrightsFormatLabel.Name = "formMacroCommandAddUpdateDimsBrightsFormatLabel"
        Me.formMacroCommandAddUpdateDimsBrightsFormatLabel.Size = New System.Drawing.Size(184, 13)
        Me.formMacroCommandAddUpdateDimsBrightsFormatLabel.TabIndex = 105
        Me.formMacroCommandAddUpdateDimsBrightsFormatLabel.Text = "Decimal number ranged from 0 to 210"
        '
        'formMacroCommandAddUpdateDimsBrightsTextBox
        '
        Me.formMacroCommandAddUpdateDimsBrightsTextBox.Location = New System.Drawing.Point(149, 258)
        Me.formMacroCommandAddUpdateDimsBrightsTextBox.Name = "formMacroCommandAddUpdateDimsBrightsTextBox"
        Me.formMacroCommandAddUpdateDimsBrightsTextBox.Size = New System.Drawing.Size(51, 20)
        Me.formMacroCommandAddUpdateDimsBrightsTextBox.TabIndex = 104
        '
        'formMacroCommandAddUpdate
        '
        Me.AcceptButton = Me.formMacroCommandAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formMacroCommandAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(565, 442)
        Me.Controls.Add(Me.formMacroCommandAddUpdateDimsBrightsFormatLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateDimsBrightsTextBox)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroNameLabelText)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroNameLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroCommandSortOrderComboBox)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroCommandSortOrderLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateExtendedDataByteFormatLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateDimBrightLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdatePreDimBrightLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdatePreDimBrightPanel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateExtendedDataByteTextBox)
        Me.Controls.Add(Me.formMacroCommandAddUpdateUnitsPanel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateExtendedCommandComboBox)
        Me.Controls.Add(Me.formMacroCommandAddUpdateUnitCodeComboBox)
        Me.Controls.Add(Me.formMacroCommandAddUpdateCommandComboBox)
        Me.Controls.Add(Me.formMacroCommandAddUpdateHouseCodeComboBox)
        Me.Controls.Add(Me.formMacroCommandAddUpdateExtendedDataByteLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateExtendedCommandLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateUnitCodeLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateCommandLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateHouseCodeLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroInInitatorNameLabelText)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroInitatorNameLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroInitatorIDLabelText)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroIDLabelText)
        Me.Controls.Add(Me.formMacroCommandAddUpdateCallingFormLabelText)
        Me.Controls.Add(Me.formMacroCommandAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdateIDLabelText)
        Me.Controls.Add(Me.formMacroCommandAddUpdateMacroCommandIDLabel)
        Me.Controls.Add(Me.formMacroCommandAddUpdate_DeleteButton)
        Me.Controls.Add(Me.formMacroCommandAddUpdate_AddUpdateButton)
        Me.Controls.Add(Me.formMacroCommandAddUpdate_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formMacroCommandAddUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Macro Command Add / Update"
        Me.formMacroCommandAddUpdateUnitsPanel.ResumeLayout(False)
        Me.formMacroCommandAddUpdateUnitsPanel.PerformLayout()
        Me.formMacroCommandAddUpdatePreDimBrightPanel.ResumeLayout(False)
        Me.formMacroCommandAddUpdatePreDimBrightPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formMacroCommandAddUpdateMacroInitatorIDLabelText As Label
    Friend WithEvents formMacroCommandAddUpdateMacroIDLabelText As Label
    Friend WithEvents formMacroCommandAddUpdateCallingFormLabelText As Label
    Friend WithEvents formMacroCommandAddUpdate_StatusLabel As Label
    Friend WithEvents formMacroCommandAddUpdateIDLabelText As Label
    Friend WithEvents formMacroCommandAddUpdateMacroCommandIDLabel As Label
    Friend WithEvents formMacroCommandAddUpdate_DeleteButton As Button
    Friend WithEvents formMacroCommandAddUpdate_AddUpdateButton As Button
    Friend WithEvents formMacroCommandAddUpdate_CancelButton As Button
    Friend WithEvents formMacroCommandAddUpdateMacroInInitatorNameLabelText As Label
    Friend WithEvents formMacroCommandAddUpdateMacroInitatorNameLabel As Label
    Friend WithEvents formMacroCommandAddUpdateHouseCodeLabel As Label
    Friend WithEvents formMacroCommandAddUpdateCommandLabel As Label
    Friend WithEvents formMacroCommandAddUpdateUnitCodeLabel As Label
    Friend WithEvents formMacroCommandAddUpdateExtendedCommandLabel As Label
    Friend WithEvents formMacroCommandAddUpdateExtendedDataByteLabel As Label
    Friend WithEvents formMacroCommandAddUpdateHouseCodeComboBox As ComboBox
    Friend WithEvents formMacroCommandAddUpdateCommandComboBox As ComboBox
    Friend WithEvents formMacroCommandAddUpdateUnitCodeComboBox As ComboBox
    Friend WithEvents formMacroCommandAddUpdateExtendedCommandComboBox As ComboBox
    Friend WithEvents formMacroCommandAddUpdateUnitsPanel As Panel
    Friend WithEvents formMacroCommandAddUpdateUnitsLabel As Label
    Friend WithEvents formMacroCommandAddUpdateUnit01CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit02CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit07CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit03CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit06CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit04CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit05CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit16CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit09CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit10CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit15CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit11CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit14CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit12CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit13CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateUnit08CheckBox As CheckBox
    Friend WithEvents formMacroCommandAddUpdateExtendedDataByteTextBox As TextBox
    Friend WithEvents formMacroCommandAddUpdatePreDimBrightLabel As Label
    Friend WithEvents formMacroCommandAddUpdatePreDimBrightPanel As Panel
    Friend WithEvents formMacroCommandAddUpdatePreDimBrightNoRadioButton As RadioButton
    Friend WithEvents formMacroCommandAddUpdatePreDimBrightYesRadioButton As RadioButton
    Friend WithEvents formMacroCommandAddUpdateDimBrightLabel As Label
    Friend WithEvents formMacroCommandAddUpdateExtendedDataByteFormatLabel As Label
    Friend WithEvents formMacroCommandAddUpdateMacroCommandSortOrderComboBox As ComboBox
    Friend WithEvents formMacroCommandAddUpdateMacroCommandSortOrderLabel As Label
    Friend WithEvents formMacroCommandAddUpdateMacroNameLabelText As Label
    Friend WithEvents formMacroCommandAddUpdateMacroNameLabel As Label
    Friend WithEvents formMacroCommandAddUpdateDimsBrightsFormatLabel As Label
    Friend WithEvents formMacroCommandAddUpdateDimsBrightsTextBox As TextBox
End Class
