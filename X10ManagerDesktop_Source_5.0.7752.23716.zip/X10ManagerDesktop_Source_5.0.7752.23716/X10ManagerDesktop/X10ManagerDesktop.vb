﻿Imports System.Configuration

' Name: X10ManagerDesktop.vb
' By: Alan Wagner
' Date: March 14, 2020
' Purpose: Manage Schedules and Timers for X10 Controllers and Devices
'
Public Class X10ManagerDesktop

#Region "formFileSettings"

    Public formFileSettingsUpdatedFlag As Boolean = False

    ' These are populated at runtime by nsX10DbMethods.getX10DbSettings() initially executed by Main()
    Public verifyProgramExit As Integer = 0
    Public showAdvancedInformation As Integer = 0
    Public longitude As String = ""
    Public latitude As String = ""
    Public backupDirectoryPath As String = ""
    Public saveFormsOnExit As Boolean = True

#End Region ' END Region - formFileSettings

#Region "DataGridViewCurrentRows"

    Public DataGridViewCurrentCellRowIndexFormControllerEdit As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormControllerEdit As Integer = -1

    Public DataGridViewCurrentCellRowIndexFormModuleEdit As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormModuleEdit As Integer = -1

    Public DataGridViewCurrentCellRowIndexFormSceneEdit As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormSceneEdit As Integer = -1

    Public DataGridViewCurrentCellRowIndexFormScheduleEdit As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormScheduleEdit As Integer = -1

    Public DataGridViewCurrentCellRowIndexFormScheduleAddUpdateEvents As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormScheduleAddUpdateEvents As Integer = -1

    Public DataGridViewCurrentCellRowIndexFormMacroInitiatorEdit As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorEdit As Integer = -1

    Public DataGridViewCurrentCellRowIndexFormMacroInitiatorAddUpdateMacros As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormMacroInitiatorAddUpdateMacros As Integer = -1

    Public DataGridViewCurrentCellRowIndexFormMacroAddUpdateMacroCommands As Integer = -1
    Public DataGridViewFirstDisplayedCellRowIndexFormMacroAddUpdateMacroCommands As Integer = -1

#End Region ' END Region -  DataGridViewCurrentRows

    ' Used by nsX10DbMethods.getLockReleaseNextID()
    Public pubGuid As String = System.Guid.NewGuid().ToString()

#Region "X10ManagerDesktopMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting = Nothing
        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Try

            ' Set the caption bar text of the form.
            ' My.Application.Info.Title is in "X10ManagerDesktop\My Project\AssemblyInfo.vb"
            ' <Assembly: AssemblyTitle("X10ManagerDesktop")>
            Me.Text = My.Application.Info.Title

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
            strStatus = nsX10DbMethods.getX10DbSettings(strConnectionString, strProvider, objX10DbSetting)
            If (strStatus = "") Then

                verifyProgramExit = objX10DbSetting.verifyProgramExit
                showAdvancedInformation = objX10DbSetting.showAdvancedInformation
                longitude = objX10DbSetting.longitude
                latitude = objX10DbSetting.latitude
                backupDirectoryPath = objX10DbSetting.backupDirectoryPath

                strStatus = formMain_FormRestore()
                If (strStatus = "") Then

                    Call OpenForms()

                Else
                    Windows.Forms.MessageBox.Show("Main(): " & strStatus, "Main()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formMain_FormRestore()

            Else
                Windows.Forms.MessageBox.Show("Main(): " & strStatus, "Main()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - nsX10DbMethods.getX10DbSettings()

        Catch ex As Exception
            strStatus = "Main(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objX10DbSetting = Nothing
        End Try

    End Sub ' END Sub - Main()

    Private Sub formMain_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        Dim objOpenForms As System.Windows.Forms.FormCollection = System.Windows.Forms.Application.OpenForms
        Dim objForm As System.Windows.Forms.Form = Nothing
        Dim bUnSavedWork As Boolean = False

        Try

            ' formMain_FormSave() As String
            strStatus = formMain_FormSave()
            If (strStatus = "") Then

                If (saveFormsOnExit) Then
                    ' SaveForms()
                    Call SaveForms()
                End If

            Else
                    Windows.Forms.MessageBox.Show("formMain_FormClosingHandler(): " & strStatus, "formMain_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - formMain_FormSave()

            For Each objForm In objOpenForms

                If (Microsoft.VisualBasic.InStr(1, objForm.Name.ToString(), "AddUpdate", vbTextCompare) > 1) Then
                    bUnSavedWork = True
                    Exit For
                End If

            Next

            If bUnSavedWork Then

                If (Windows.Forms.MessageBox.Show("There is unsaved work." & vbCrLf & "Close X10ManagerDesktop anyway?", "Close", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Warning) = Windows.Forms.DialogResult.No) Then

                    ' Cancel the close
                    objFormClosingEventArgs.Cancel = True

                End If

            Else

                If (verifyProgramExit = 1) Then

                    If (Windows.Forms.MessageBox.Show("Close X10ManagerDesktop?", "Close", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Question) = Windows.Forms.DialogResult.No) Then

                        ' Cancel the close
                        objFormClosingEventArgs.Cancel = True

                    End If

                End If

            End If

        Catch ex As Exception
            strStatus = "formMain_FormClosingHandler(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formMain_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objForm = Nothing
            objOpenForms = Nothing
        End Try

    End Sub ' END Sub - formMain_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopMainMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formMain_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMain" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formMain_FormRestore() As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objLocation = New System.Drawing.Point
                objLocation = New System.Drawing.Point(10, 10)

                objSize = New System.Drawing.Size(760, 530)
                'objSize = Me.Size

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationMain Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationMain.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationMain.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 2) Then
                            objLocation = New System.Drawing.Point(Integer.Parse(arrInitialLocationSize(0)), Integer.Parse(arrInitialLocationSize(1)))
                        End If

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Location = objLocation
                Me.Size = objSize

            End If

        Catch ex As Exception
            strStatus = "formMain_FormRestore(): Exception: " & ex.Message
        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formMain_FormRestore()

    '=====================================================================================
    ' Function formMain_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationMain" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formMain_FormSave() As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationMain = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationMain = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formMain_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formMain_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formMain_FormSave()

#End Region ' END Region - formSaveRestoreMethods

#Region "MenuMethods"

    Private Sub menuFile_Settings_Click(objSender As Object, objEventArgs As EventArgs) Handles menuFile_Settings.Click
        Dim strStatus As String = ""

        Dim objFormFileSettings As formFileSettings = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            objFormFileSettings = New formFileSettings

            ' Opens as seperate form.
            objFormFileSettings.TopLevel = True

            ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
            ' This allows the new form to be located on top of form X10ManagerDesktop.
            objLocation = New System.Drawing.Point
            objLocation = Me.Location

            ' Set additional offset
            objLocation.Offset(50, 100)

            ' Set default Location for new form to be Shown.
            objFormFileSettings.Location = objLocation

            objFormFileSettings.ShowDialog()

        Catch ex As Exception
            strStatus = "menuFile_Settings_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuFile_Settings_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormFileSettings = Nothing
        End Try

    End Sub ' END - menuFile_Settings_Click()

    Private Sub menuFile_Backup_Click(objSender As Object, objEventArgs As EventArgs) Handles menuFile_Backup.Click
        Dim strStatus As String = ""

        Dim objFormFileBackup As formFileBackup = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            objFormFileBackup = New formFileBackup

            ' Opens as seperate form.
            objFormFileBackup.TopLevel = True

            ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
            ' This allows the new form to be located on top of form X10ManagerDesktop.
            objLocation = New System.Drawing.Point
            objLocation = Me.Location

            ' Set additional offset
            objLocation.Offset(50, 100)

            ' Set default Location for new form to be Shown.
            objFormFileBackup.Location = objLocation

            objFormFileBackup.ShowDialog()

        Catch ex As Exception
            strStatus = "menuFile_Backup_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuFile_Backup_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormFileBackup = Nothing
        End Try

    End Sub ' END - menuFile_Backup_Click()

    Private Sub menuFile_Restore_Click(objSender As Object, objEventArgs As EventArgs) Handles menuFile_Restore.Click
        Dim strStatus As String = ""

        Dim objFormFileRestore As formFileRestore = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            objFormFileRestore = New formFileRestore

            ' Opens as seperate form.
            objFormFileRestore.TopLevel = True

            ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
            ' This allows the new form to be located on top of form X10ManagerDesktop.
            objLocation = New System.Drawing.Point
            objLocation = Me.Location

            ' Set additional offset
            objLocation.Offset(50, 100)

            ' Set default Location for new form to be Shown.
            objFormFileRestore.Location = objLocation

            objFormFileRestore.ShowDialog()

        Catch ex As Exception
            strStatus = "menuFile_Restore_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuFile_Restore_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormFileRestore = Nothing
        End Try

    End Sub ' END - menuFile_Restore_Click()

    Private Sub menuFile_Exit_Click(objSender As Object, objEventArgs As EventArgs) Handles menuFile_Exit.Click

        Me.Close()

    End Sub ' END - menuFile_Exit_Click()

    Private Sub menuController_Add_Click(objSender As Object, objEventArgs As EventArgs) Handles menuController_Add.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormControllerAddUpdate As formControllerAddUpdate = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            If objFormCollection.OfType(Of formControllerAddUpdate).Any Then

                objFormControllerAddUpdate = objFormCollection.Item("formControllerAddUpdate")

                objFormControllerAddUpdate.Activate()

            Else

                objFormControllerAddUpdate = New formControllerAddUpdate

                ' Opens as seperate form.
                objFormControllerAddUpdate.TopLevel = True

                objFormControllerAddUpdate.formControllerAddUpdateNameTextBox.Text() = ""
                objFormControllerAddUpdate.formControllerAddUpdateIDLabelText.Text() = ""

                ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                ' This allows the new form to be located on top of form X10ManagerDesktop.
                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(50, 100)

                ' Set default Location for new form to be Shown.
                objFormControllerAddUpdate.Location = objLocation

                objFormControllerAddUpdate.Show()

            End If

            objFormControllerAddUpdate.BringToFront()

        Catch ex As Exception
            strStatus = "menuController_Add_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuController_Add_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objLocation = Nothing
            objFormControllerAddUpdate = Nothing
        End Try

    End Sub ' END - menuController_Add_Click()

    Private Sub menuController_Edit_Click(objSender As Object, objEventArgs As EventArgs) Handles menuController_Edit.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormControllerEdit As formControllerEdit = Nothing

        Try

            If objFormCollection.OfType(Of formControllerEdit).Any Then

                objFormControllerEdit = objFormCollection.Item("formControllerEdit")

                ' formControllerEdit_GetControllersDataSet() As String
                strStatus = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
                If (strStatus = "") Then
                    objFormControllerEdit.Activate()
                Else
                    Windows.Forms.MessageBox.Show("menuController_Edit_Click(): " & strStatus, "menuController_Edit_Click", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formControllerEdit_GetControllersDataSet()

            Else

                objFormControllerEdit = New formControllerEdit

                ' Open form in Parent form.
                objFormControllerEdit.TopLevel = False
                objFormControllerEdit.Parent = Me

                objFormControllerEdit.formControllerEdit_BringToFrontLabel.Text() = "Y"

                objFormControllerEdit.Show()

            End If

            objFormControllerEdit.BringToFront()

        Catch ex As Exception
            strStatus = "menuController_Edit_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuController_Edit_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
        End Try

    End Sub ' END - menuController_Edit_Click()

    Private Sub menuController_Download_Click(objSender As Object, objEventArgs As EventArgs) Handles menuController_Download.Click
        Dim strStatus As String = ""

        Dim objFormControllerDownload As formControllerDownload = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            objFormControllerDownload = New formControllerDownload

            ' Opens as seperate form.
            objFormControllerDownload.TopLevel = True

            ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
            ' This allows the new form to be located on top of form X10ManagerDesktop.
            objLocation = New System.Drawing.Point
            objLocation = Me.Location

            ' Set additional offset
            objLocation.Offset(50, 100)

            ' Set default Location for new form to be Shown.
            objFormControllerDownload.Location = objLocation

            objFormControllerDownload.ShowDialog()

        Catch ex As Exception
            strStatus = "menuController_Download_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuController_Download_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormControllerDownload = Nothing
        End Try

    End Sub ' END - menuController_Download_Click()

    Private Sub menuModule_Add_Click(objSender As Object, objEventArgs As EventArgs) Handles menuModule_Add.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormModuleAddUpdate As formModuleAddUpdate = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            If objFormCollection.OfType(Of formModuleAddUpdate).Any Then

                objFormModuleAddUpdate = objFormCollection.Item("formModuleAddUpdate")

                objFormModuleAddUpdate.Activate()

            Else

                objFormModuleAddUpdate = New formModuleAddUpdate

                ' Opens as seperate form.
                objFormModuleAddUpdate.TopLevel = True

                objFormModuleAddUpdate.formModuleAddUpdateNameTextBox.Text() = ""
                objFormModuleAddUpdate.formModuleAddUpdateIDLabelText.Text() = ""

                ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                ' This allows the new form to be located on top of form X10ManagerDesktop.
                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(50, 100)

                ' Set default Location for new form to be Shown.
                objFormModuleAddUpdate.Location = objLocation

                objFormModuleAddUpdate.Show()

            End If

            objFormModuleAddUpdate.BringToFront()

        Catch ex As Exception
            strStatus = "menuModule_Add_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuModule_Add_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objLocation = Nothing
            objFormModuleAddUpdate = Nothing
        End Try

    End Sub ' END - menuModule_Add_Click()

    Private Sub menuModule_Edit_Click(objSender As Object, objEventArgs As EventArgs) Handles menuModule_Edit.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormModuleEdit As formModuleEdit = Nothing

        Try

            If objFormCollection.OfType(Of formModuleEdit).Any Then

                objFormModuleEdit = objFormCollection.Item("formModuleEdit")

                ' formModuleEdit_GetModulesDataSet() As String
                strStatus = objFormModuleEdit.formModuleEdit_GetModulesDataSet()
                If (strStatus = "") Then
                    objFormModuleEdit.Activate()
                Else
                    Windows.Forms.MessageBox.Show("menuModule_Edit_Click(): " & strStatus, "menuModule_Edit_Click", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formModuleEdit_GetModulesDataSet()

            Else

                objFormModuleEdit = New formModuleEdit

                ' Open form in Parent form.
                objFormModuleEdit.TopLevel = False
                objFormModuleEdit.Parent = Me

                objFormModuleEdit.formModuleEdit_BringToFrontLabel.Text() = "Y"

                objFormModuleEdit.Show()

            End If

            objFormModuleEdit.BringToFront()

        Catch ex As Exception
            strStatus = "menuModule_Edit_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuModule_Edit_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objFormModuleEdit = Nothing
        End Try

    End Sub ' END - menuModule_Edit_Click()

    Private Sub menuModule_Import_Click(objSender As Object, objEventArgs As EventArgs) Handles menuModule_Import.Click
        Dim strStatus As String = ""

        Dim objFormModuleImport As formModuleImport = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            objFormModuleImport = New formModuleImport

            ' Opens as seperate form.
            objFormModuleImport.TopLevel = True

            ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
            ' This allows the new form to be located on top of form X10ManagerDesktop.
            objLocation = New System.Drawing.Point
            objLocation = Me.Location

            ' Set additional offset
            objLocation.Offset(50, 100)

            ' Set default Location for new form to be Shown.
            objFormModuleImport.Location = objLocation

            objFormModuleImport.ShowDialog()

        Catch ex As Exception
            strStatus = "menuModule_Import_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuModule_Import_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormModuleImport = Nothing
        End Try

    End Sub ' END - menuModule_Import_Click()

    Private Sub menuModule_Export_Click(objSender As Object, objEventArgs As EventArgs) Handles menuModule_Export.Click
        Dim strStatus As String = ""

        Dim objFormModuleExport As formModuleExport = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            objFormModuleExport = New formModuleExport

            ' Opens as seperate form.
            objFormModuleExport.TopLevel = True

            ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
            ' This allows the new form to be located on top of form X10ManagerDesktop.
            objLocation = New System.Drawing.Point
            objLocation = Me.Location

            ' Set additional offset
            objLocation.Offset(50, 100)

            ' Set default Location for new form to be Shown.
            objFormModuleExport.Location = objLocation

            objFormModuleExport.ShowDialog()

        Catch ex As Exception
            strStatus = "menuModule_Export_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuModule_Export_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormModuleExport = Nothing
        End Try

    End Sub ' END - menuModule_Export_Click()

    Private Sub menuScene_Add_Click(objSender As Object, objEventArgs As EventArgs) Handles menuScene_Add.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormSceneAddUpdate As formSceneAddUpdate = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            If objFormCollection.OfType(Of formSceneAddUpdate).Any Then

                objFormSceneAddUpdate = objFormCollection.Item("formSceneAddUpdate")

                objFormSceneAddUpdate.Activate()

            Else

                objFormSceneAddUpdate = New formSceneAddUpdate

                ' Opens as seperate form.
                objFormSceneAddUpdate.TopLevel = True

                objFormSceneAddUpdate.formSceneAddUpdateNameTextBox.Text() = ""
                objFormSceneAddUpdate.formSceneAddUpdateIDLabelText.Text() = ""

                ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                ' This allows the new form to be located on top of form X10ManagerDesktop.
                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(50, 100)

                ' Set default Location for new form to be Shown.
                objFormSceneAddUpdate.Location = objLocation

                objFormSceneAddUpdate.Show()

            End If

            objFormSceneAddUpdate.BringToFront()

        Catch ex As Exception
            strStatus = "menuScene_Add_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuScene_Add_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objLocation = Nothing
            objFormSceneAddUpdate = Nothing
        End Try

    End Sub ' END - menuScene_Add_Click()

    Private Sub menuScene_Edit_Click(objSender As Object, objEventArgs As EventArgs) Handles menuScene_Edit.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormSceneEdit As formSceneEdit = Nothing

        Try

            If objFormCollection.OfType(Of formSceneEdit).Any Then

                objFormSceneEdit = objFormCollection.Item("formSceneEdit")

                ' formSceneEdit_GetScenesDataSet() As String
                strStatus = objFormSceneEdit.formSceneEdit_GetScenesDataSet()
                If (strStatus = "") Then
                    objFormSceneEdit.Activate()
                Else
                    Windows.Forms.MessageBox.Show("menuScene_Edit_Click(): " & strStatus, "menuScene_Edit_Click", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formSceneEdit_GetScenesDataSet()

            Else

                objFormSceneEdit = New formSceneEdit

                ' Open form in Parent form.
                objFormSceneEdit.TopLevel = False
                objFormSceneEdit.Parent = Me

                objFormSceneEdit.formSceneEdit_BringToFrontLabel.Text() = "Y"

                objFormSceneEdit.Show()

            End If

            objFormSceneEdit.BringToFront()

        Catch ex As Exception
            strStatus = "menuScene_Edit_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuScene_Edit_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objFormSceneEdit = Nothing
        End Try

    End Sub ' END - menuScene_Edit_Click()

    Private Sub menuSchedule_Add_Click(objSender As Object, objEventArgs As EventArgs) Handles menuSchedule_Add.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormScheduleAddUpdate As formScheduleAddUpdate = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            If objFormCollection.OfType(Of formScheduleAddUpdate).Any Then

                objFormScheduleAddUpdate = objFormCollection.Item("formScheduleAddUpdate")

                objFormScheduleAddUpdate.Activate()

            Else

                objFormScheduleAddUpdate = New formScheduleAddUpdate

                ' Opens as seperate form.
                objFormScheduleAddUpdate.TopLevel = True

                objFormScheduleAddUpdate.formScheduleAddUpdateNameTextBox.Text() = ""
                objFormScheduleAddUpdate.formScheduleAddUpdateIDLabelText.Text() = ""

                ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                ' This allows the new form to be located on top of form X10ManagerDesktop.
                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(50, 100)

                ' Set default Location for new form to be Shown.
                objFormScheduleAddUpdate.Location = objLocation

                objFormScheduleAddUpdate.Show()

            End If

            objFormScheduleAddUpdate.BringToFront()

        Catch ex As Exception
            strStatus = "menuSchedule_Add_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuSchedule_Add_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objLocation = Nothing
            objFormScheduleAddUpdate = Nothing
        End Try

    End Sub ' END - menuSchedule_Add_Click()

    Private Sub menuSchedule_Edit_Click(objSender As Object, objEventArgs As EventArgs) Handles menuSchedule_Edit.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormScheduleEdit As formScheduleEdit = Nothing

        Try

            If objFormCollection.OfType(Of formScheduleEdit).Any Then

                objFormScheduleEdit = objFormCollection.Item("formScheduleEdit")

                ' formScheduleEdit_GetSchedulesDataSet() As String
                strStatus = objFormScheduleEdit.formScheduleEdit_GetSchedulesDataSet()
                If (strStatus = "") Then
                    objFormScheduleEdit.Activate()
                Else
                    Windows.Forms.MessageBox.Show("menuSchedule_Edit_Click(): " & strStatus, "menuSchedule_Edit_Click", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formScheduleEdit_GetSchedulesDataSet()

            Else

                objFormScheduleEdit = New formScheduleEdit

                ' Open form in Parent form.
                objFormScheduleEdit.TopLevel = False
                objFormScheduleEdit.Parent = Me

                objFormScheduleEdit.formScheduleEdit_BringToFrontLabel.Text() = "Y"

                objFormScheduleEdit.Show()

            End If

            objFormScheduleEdit.BringToFront()

        Catch ex As Exception
            strStatus = "menuSchedule_Edit_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuSchedule_Edit_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objFormScheduleEdit = Nothing
        End Try

    End Sub ' END - menuSchedule_Edit_Click()

    Private Sub menuMacro_Add_Click(objSender As Object, objEventArgs As EventArgs) Handles menuMacro_Add.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            If objFormCollection.OfType(Of formMacroInitiatorAddUpdate).Any Then

                objFormMacroInitiatorAddUpdate = objFormCollection.Item("formMacroInitiatorAddUpdate")

                objFormMacroInitiatorAddUpdate.Activate()

            Else

                objFormMacroInitiatorAddUpdate = New formMacroInitiatorAddUpdate

                ' Opens as seperate form.
                objFormMacroInitiatorAddUpdate.TopLevel = True

                objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdateInitiatorNameTextBox.Text() = ""
                objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdateIDLabelText.Text() = ""

                ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                ' This allows the new form to be located on top of form X10ManagerDesktop.
                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(50, 100)

                ' Set default Location for new form to be Shown.
                objFormMacroInitiatorAddUpdate.Location = objLocation

                objFormMacroInitiatorAddUpdate.Show()

            End If

            objFormMacroInitiatorAddUpdate.BringToFront()

        Catch ex As Exception
            strStatus = "menuMacro_Add_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuMacro_Add_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objLocation = Nothing
            objFormMacroInitiatorAddUpdate = Nothing
        End Try

    End Sub ' END - menuMacro_Add_Click()

    Private Sub menuMacro_Edit_Click(objSender As Object, objEventArgs As EventArgs) Handles menuMacro_Edit.Click
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormMacroInitiatorEdit As formMacroInitiatorEdit = Nothing

        Try

            If objFormCollection.OfType(Of formMacroInitiatorEdit).Any Then

                objFormMacroInitiatorEdit = objFormCollection.Item("formMacroInitiatorEdit")

                ' formMacroInitiatorEdit_GetMacroInitiatorsDataSet() As String
                strStatus = objFormMacroInitiatorEdit.formMacroInitiatorEdit_GetMacroInitiatorsDataSet()
                If (strStatus = "") Then
                    objFormMacroInitiatorEdit.Activate()
                Else
                    Windows.Forms.MessageBox.Show("menuMacro_Edit_Click(): " & strStatus, "menuMacro_Edit_Click", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formMacroInitiatorEdit_GetModulesDataSet()

            Else

                objFormMacroInitiatorEdit = New formMacroInitiatorEdit

                ' Open form in Parent form.
                objFormMacroInitiatorEdit.TopLevel = False
                objFormMacroInitiatorEdit.Parent = Me

                objFormMacroInitiatorEdit.formMacroInitiatorEdit_BringToFrontLabel.Text() = "Y"

                objFormMacroInitiatorEdit.Show()

            End If

            objFormMacroInitiatorEdit.BringToFront()

        Catch ex As Exception
            strStatus = "menuMacro_Edit_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuMacro_Edit_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objFormMacroInitiatorEdit = Nothing
        End Try

    End Sub ' END - menuMacro_Edit_Click()

    Private Sub menuHelp_ViewHelp_Click(objSender As Object, objEventArgs As EventArgs) Handles menuHelp_ViewHelp.Click
        Dim strStatus As String = ""

        Dim strHelpURL As String = ""
        Dim objProcessStartInfo As System.Diagnostics.ProcessStartInfo = Nothing

        Try

            ' My.Application.Info.Description is in "X10ManagerDesktop\My Project\AssemblyInfo.vb"
            '<Assembly: AssemblyDescription("Manage Schedules and Timers for X10 Controllers and Devices")>
            strHelpURL = My.Settings.HelpURL

            objProcessStartInfo = New System.Diagnostics.ProcessStartInfo(strHelpURL)

            System.Diagnostics.Process.Start(objProcessStartInfo)

        Catch ex As Exception
            strStatus = "menuHelp_ViewHelp_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus & vbCrLf & "HelpURL=" & strHelpURL, "menuHelp_ViewHelp_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objProcessStartInfo = Nothing
        End Try

    End Sub ' END - menuHelp_ViewHelp_Click()

    Private Sub menuHelp_AboutX10ManagerDesktop_Click(objSender As Object, objEventArgs As EventArgs) Handles menuHelp_AboutX10ManagerDesktop.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objAssembly As System.Reflection.Assembly = Nothing
        Dim objFileInfo As System.IO.FileInfo = Nothing

        Dim objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting = Nothing

        Dim strDescription As String = ""
        Dim strProduct As String = ""
        Dim strCopyright As String = ""
        Dim strVersion As String = ""

        Dim strMessage As String = ""

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            objAssembly = System.Reflection.Assembly.GetExecutingAssembly()
            objFileInfo = New System.IO.FileInfo(objAssembly.Location)

            ' My.Application.Info.Description is in "X10ManagerDesktop\My Project\AssemblyInfo.vb"
            '<Assembly: AssemblyDescription("Manage Schedules and Timers for X10 Controllers and Devices")>
            strDescription = My.Application.Info.Description

            ' My.Application.Info.ProductName is in "X10ManagerDesktop\My Project\AssemblyInfo.vb"
            '<Assembly: AssemblyProduct("X10ManagerDesktop")>
            strProduct = My.Application.Info.ProductName

            ' My.Application.Info.Copyright is in "X10ManagerDesktop\My Project\AssemblyInfo.vb"
            '<Assembly: AssemblyCopyright("Copyright © March 2020 trekkerphotoart.com")>
            strCopyright = My.Application.Info.Copyright

            strVersion = "Executing Assembly Version: " & System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString() & vbCrLf & "Revised: " & objFileInfo.LastWriteTime.ToString("MMMMMMMM dd, yyyy")
            strVersion &= vbCrLf & vbCrLf & "Program Schema:" & vbCrLf & "  " & nsX10DbMethods.getSchemaVersionCopyright() & vbCrLf & "  Version: " & nsX10DbMethods.getSchemaVersion() & vbCrLf & "  Version Date: " & nsX10DbMethods.getSchemaVersionDate()

            ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
            strStatus = nsX10DbMethods.getX10DbSettings(strConnectionString, strProvider, objX10DbSetting)
            If (strStatus = "") Then
                strVersion &= vbCrLf & vbCrLf & "X10 Database Schema:" & vbCrLf & "  " & objX10DbSetting.schemaVersionCopyright & vbCrLf & "  Version: " & objX10DbSetting.schemaVersion & vbCrLf & "  Version Date: " & objX10DbSetting.schemaVersionDate
            Else
                Windows.Forms.MessageBox.Show(strStatus, "menuHelp_AboutX10ManagerDesktop_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If

            strMessage = vbCrLf & """" & strProduct & """" &
            vbCrLf & strCopyright &
            vbCrLf & vbCrLf & """X10Manager"" (command line)" &
            vbCrLf & strCopyright

            strMessage &= vbCrLf & vbCrLf & strDescription &
            vbCrLf & vbCrLf & strVersion

            strMessage &= vbCrLf & vbCrLf & "This entire project is Licensed under:" & vbCrLf & """CREATIVE COMMONS PUBLIC LICENSE (CCPL)""" &
            vbCrLf & "The ""CCPL"" is found in the ""X10ManagerDesktop Operations Manual"", ""Licensing"" section."

            strMessage &= vbCrLf & vbCrLf & "Credits:"
            strMessage &= vbCrLf & "ParadoxReader.DLL (ParadoxReader) contains source code from" & vbCrLf & """Code Project""," &
            vbCrLf & """Paradox database native .NET reader""" & vbCrLf & "by Petr Bříza, March 17, 2011, v1.2." &
            vbCrLf & "Modifications have been added by Alan Wagner that allow ParadoxReader, as used in X10ManagerDesktop and X10Manager, to read X10 Lighthouse Scene BLOB data." &
            vbCrLf & "Original ParadoxReader source code is Licensed under:" & vbCrLf & """The Code Project Open License (CPOL) 1.02"""

            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
            Call formConsoleMessages.DisplayMessage(strMessage, "About X10ManagerDesktop")

        Catch ex As Exception
            strStatus = "menuHelp_AboutX10ManagerDesktop_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuHelp_AboutX10ManagerDesktop_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objX10DbSetting = Nothing
            objFileInfo = Nothing
            objAssembly = Nothing
        End Try

    End Sub ' END - menuHelp_AboutX10ManagerDesktop_Click()

    Private Sub menuDownload_Click(objSender As Object, objEventArgs As EventArgs) Handles menuDownload.Click
        Dim strStatus As String = ""

        Dim objFormControllerDownload As formControllerDownload = Nothing
        Dim objLocation As System.Drawing.Point = Nothing

        Try

            objFormControllerDownload = New formControllerDownload

            ' Opens as seperate form.
            objFormControllerDownload.TopLevel = True

            ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
            ' This allows the new form to be located on top of form X10ManagerDesktop.
            objLocation = New System.Drawing.Point
            objLocation = Me.Location

            ' Set additional offset
            objLocation.Offset(50, 100)

            ' Set default Location for new form to be Shown.
            objFormControllerDownload.Location = objLocation

            objFormControllerDownload.ShowDialog()

        Catch ex As Exception
            strStatus = "menuDownload_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuDownload_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormControllerDownload = Nothing
        End Try

    End Sub ' END - menuDownload_Click()

    Private Sub menuAllLightsOff_Click(objSender As Object, objEventArgs As EventArgs) Handles menuAllLightsOff.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim strMessage As String = ""

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' strOperation
            '  AllLightsOn | AllLightsOff | AllUnitsOn | AllUnitsOff | Scene
            ' formSceneAddUpdate.sendUnitCommands(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strOperation As String, ByVal intSceneID As Integer, ByVal strSceneName As String, ByRef strMessage As String) As String
            strError = formSceneAddUpdate.sendUnitCommands(strConnectionString, strProvider, "AllLightsOff", -1, "", strMessage)
            If (strError = "") Then

                strMessage &= vbCrLf & vbCrLf & "Success!"

            Else
                strStatus = "Problem sending commands to Modules." & vbCrLf & strError
                Windows.Forms.MessageBox.Show(strStatus, "menuAllLightsOff_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)

                strMessage &= vbCrLf & vbCrLf & strStatus
                strMessage &= vbCrLf & vbCrLf & "Fail!"

            End If ' END - sendUnitCommands(Scene)

            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
            Call formConsoleMessages.DisplayMessage(strMessage, "Send ""AllLightsOff"" commands to Modules")

        Catch ex As Exception
            strStatus = "menuAllLightsOff_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuAllLightsOff_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally

        End Try

    End Sub ' END - menuAllLightsOff_Click()

    Private Sub menuAllLightsOn_Click(objSender As Object, objEventArgs As EventArgs) Handles menuAllLightsOn.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim strMessage As String = ""

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' strOperation
            '  AllLightsOn | AllLightsOff | AllUnitsOn | AllUnitsOff | Scene
            ' formSceneAddUpdate.sendUnitCommands(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strOperation As String, ByVal intSceneID As Integer, ByVal strSceneName As String, ByRef strMessage As String) As String
            strError = formSceneAddUpdate.sendUnitCommands(strConnectionString, strProvider, "AllLightsOn", -1, "", strMessage)
            If (strError = "") Then

                strMessage &= vbCrLf & vbCrLf & "Success!"

            Else
                strStatus = "Problem sending commands to Modules." & vbCrLf & strError
                Windows.Forms.MessageBox.Show(strStatus, "menuAllLightsOn_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)

                strMessage &= vbCrLf & vbCrLf & strStatus
                strMessage &= vbCrLf & vbCrLf & "Fail!"

            End If ' END - sendUnitCommands(Scene)

            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
            Call formConsoleMessages.DisplayMessage(strMessage, "Send ""AllLightsOn"" commands to Modules")

        Catch ex As Exception
            strStatus = "menuAllLightsOn_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "menuAllLightsOn_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally

        End Try

    End Sub ' END - menuAllLightsOn_Click()

#End Region ' END Region - MenuMethods

#Region "X10ManagerDesktopMethods"

    '=====================================================================================
    ' Function RefreshOpenForms()
    ' Alan Wagner
    ' 
    ' Used by formFileSettings.formFileSettings_UpdateButton_Click()
    '
    Public Sub RefreshOpenForms()
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormControllerEdit As formControllerEdit = Nothing
        Dim objFormModuleEdit As formModuleEdit = Nothing
        Dim objFormSceneEdit As formSceneEdit = Nothing
        Dim objFormScheduleEdit As formScheduleEdit = Nothing
        Dim objFormMacroInitiatorEdit As formMacroInitiatorEdit = Nothing

        Try

            If objFormCollection.OfType(Of formControllerEdit).Any Then
                objFormControllerEdit = New formControllerEdit
                objFormControllerEdit = objFormCollection.Item("formControllerEdit")
                strStatus = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
                If (strStatus = "") Then
                    objFormControllerEdit.Activate()
                Else
                    Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If
            End If

            If objFormCollection.OfType(Of formModuleEdit).Any Then
                objFormModuleEdit = New formModuleEdit
                objFormModuleEdit = objFormCollection.Item("formModuleEdit")
                strStatus = objFormModuleEdit.formModuleEdit_GetModulesDataSet()
                If (strStatus = "") Then
                    objFormModuleEdit.Activate()
                Else
                    Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If
            End If

            If objFormCollection.OfType(Of formSceneEdit).Any Then
                objFormSceneEdit = New formSceneEdit
                objFormSceneEdit = objFormCollection.Item("formSceneEdit")
                strStatus = objFormSceneEdit.formSceneEdit_GetScenesDataSet()
                If (strStatus = "") Then
                    objFormSceneEdit.Activate()

                    ' Refresh "Modules In Scene" DataSet on any open "Update Scenes" forms.
                    For Each objFormSceneAddUpdate As formSceneAddUpdate In objFormCollection.OfType(Of formSceneAddUpdate)

                        ' RefreshOpenSceneAddUpdateForm(ByRef objFormSceneAddUpdate As formSceneAddUpdate) As String
                        strStatus = RefreshOpenSceneAddUpdateForm(objFormSceneAddUpdate)
                        If (strStatus <> "") Then
                            Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Exit For
                        End If

                    Next

                Else
                    Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If
            End If

            If objFormCollection.OfType(Of formScheduleEdit).Any Then
                objFormScheduleEdit = New formScheduleEdit
                objFormScheduleEdit = objFormCollection.Item("formScheduleEdit")
                strStatus = objFormScheduleEdit.formScheduleEdit_GetSchedulesDataSet()
                If (strStatus = "") Then
                    objFormScheduleEdit.Activate()

                    ' Refresh "Events" DataSet on any open "Update Schedules" forms.
                    For Each objFormScheduleAddUpdate As formScheduleAddUpdate In objFormCollection.OfType(Of formScheduleAddUpdate)

                        ' RefreshOpenScheduleAddUpdateForm(ByRef objFormScheduleAddUpdate As formScheduleAddUpdate) As String
                        strStatus = RefreshOpenScheduleAddUpdateForm(objFormScheduleAddUpdate)
                        If (strStatus <> "") Then
                            Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Exit For
                        End If

                    Next

                Else
                    Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If
            End If

            If objFormCollection.OfType(Of formMacroInitiatorEdit).Any Then
                objFormMacroInitiatorEdit = New formMacroInitiatorEdit
                objFormMacroInitiatorEdit = objFormCollection.Item("formMacroInitiatorEdit")
                strStatus = objFormMacroInitiatorEdit.formMacroInitiatorEdit_GetMacroInitiatorsDataSet()
                If (strStatus = "") Then
                    objFormMacroInitiatorEdit.Activate()

                    ' Refresh "Macros" DataSet on any open "Update MacroInitiators" forms.
                    For Each objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate In objFormCollection.OfType(Of formMacroInitiatorAddUpdate)

                        ' RefreshOpenMacroInitiatorAddUpdateForm(ByRef objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate) As String
                        strStatus = RefreshOpenMacroInitiatorAddUpdateForm(objFormMacroInitiatorAddUpdate)
                        If (strStatus <> "") Then
                            Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Exit For
                        End If

                    Next

                    ' Refresh "MacroCommands" DataSet on any open "Update Macros" forms.
                    For Each objFormMacroAddUpdate As formMacroAddUpdate In objFormCollection.OfType(Of formMacroAddUpdate)

                        ' RefreshOpenMacroAddUpdateForm(ByRef objFormMacroAddUpdate As formMacroAddUpdate) As String
                        strStatus = RefreshOpenMacroAddUpdateForm(objFormMacroAddUpdate)
                        If (strStatus <> "") Then
                            Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Exit For
                        End If

                    Next

                Else
                    Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If
            End If

        Catch ex As Exception
            strStatus = "RefreshOpenForms(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "RefreshOpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
            objFormModuleEdit = Nothing
            objFormSceneEdit = Nothing
            objFormScheduleEdit = Nothing
            objFormMacroInitiatorEdit = Nothing
        End Try

    End Sub ' END - RefreshOpenForms()

    '=====================================================================================
    ' Function RefreshOpenControllerEditForm()
    ' Alan Wagner
    ' Refresh "Controllers" DataSet on any open "Edit Controllers" forms.
    '
    Public Function RefreshOpenControllerEditForm(ByRef objFormControllerEdit As formControllerEdit) As String
        Dim strStatus As String = ""

        Try

            ' formScheduleAddUpdate_GetEventsDataSet(ByVal intScheduleID As Integer) As String
            strStatus = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
            If (strStatus = "") Then
                objFormControllerEdit.formControllerEditDataGridView.Visible = True
                objFormControllerEdit.Activate()
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "RefreshOpenControllerEditForm(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "RefreshOpenControllerEditForm(): Exception: " & ex.Message
            End If
        End Try

        Return strStatus

    End Function ' END - RefreshOpenControllerEditForm()

    '=====================================================================================
    ' Function RefreshOpenSceneAddUpdateForm()
    ' Alan Wagner
    ' Refresh "Modules In Scene" DataSet on open "Update Scenes" form.
    '
    Public Function RefreshOpenSceneAddUpdateForm(ByRef objFormSceneAddUpdate As formSceneAddUpdate) As String
        Dim strStatus As String = ""

        Dim objDataRowViewSceneHouseCode As System.Data.DataRowView = Nothing
        Dim strSceneHouseCodeLetter = ""

        Try

            If (objFormSceneAddUpdate.formSceneAddUpdateRestrictHouseCodeCheckBox.Checked) Then
                objDataRowViewSceneHouseCode = objFormSceneAddUpdate.formSceneAddUpdateHouseCodeComboBox.SelectedItem
                If (objDataRowViewSceneHouseCode.Row("HouseCodeID").ToString() = "0") Then
                    strSceneHouseCodeLetter = "%"
                Else
                    strSceneHouseCodeLetter = objDataRowViewSceneHouseCode(1).ToString ' DisplayMember ex: "A"
                End If
            Else
                strSceneHouseCodeLetter = "%"
            End If

            ' formSceneAddUpdate_GetSceneModulesDataSet(ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
            strStatus = objFormSceneAddUpdate.formSceneAddUpdate_GetSceneModulesDataSet(CType(objFormSceneAddUpdate.formSceneAddUpdateIDLabelText.Text(), Integer), strSceneHouseCodeLetter)
            If (strStatus = "") Then
                objFormSceneAddUpdate.formSceneAddUpdateModulesInSceneDataGridView.Visible = True
                objFormSceneAddUpdate.Activate()
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "RefreshOpenSceneAddUpdateForm(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "RefreshOpenSceneAddUpdateForm(): Exception: " & ex.Message
            End If
        Finally
            objDataRowViewSceneHouseCode = Nothing
        End Try

        Return strStatus

    End Function ' END - RefreshOpenSceneAddUpdateForm()

    '=====================================================================================
    ' Function RefreshOpenScheduleAddUpdateForm()
    ' Alan Wagner
    ' Refresh "Events" DataSet on open "Update Schedules" form.
    '
    Public Function RefreshOpenScheduleAddUpdateForm(ByRef objFormScheduleAddUpdate As formScheduleAddUpdate) As String
        Dim strStatus As String = ""

        Try

            ' formScheduleAddUpdate_GetEventsDataSet(ByVal intScheduleID As Integer) As String
            strStatus = objFormScheduleAddUpdate.formScheduleAddUpdate_GetEventsDataSet(CType(objFormScheduleAddUpdate.formScheduleAddUpdateIDLabelText.Text(), Integer))
            If (strStatus = "") Then
                objFormScheduleAddUpdate.formScheduleAddUpdateEventsDataGridView.Visible = True
                objFormScheduleAddUpdate.Activate()
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "RefreshOpenScheduleAddUpdateForm(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "RefreshOpenScheduleAddUpdateForm(): Exception: " & ex.Message
            End If
        End Try

        Return strStatus

    End Function ' END - RefreshOpenScheduleAddUpdateForm()

    '=====================================================================================
    ' Function RefreshOpenMacroInitiatorAddUpdateForm()
    ' Alan Wagner
    ' Refresh "Macros" DataSet on open "Update MacroInitiators" form.
    '
    Private Function RefreshOpenMacroInitiatorAddUpdateForm(ByRef objFormMacroInitiatorAddUpdate As formMacroInitiatorAddUpdate) As String
        Dim strStatus As String = ""

        Try

            ' formMacroInitiatorAddUpdate_GetMacrosDataSet(ByVal intMacroInitiatorID As Integer) As String
            strStatus = objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdate_GetMacrosDataSet(CType(objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdateIDLabelText.Text(), Integer))
            If (strStatus = "") Then
                objFormMacroInitiatorAddUpdate.formMacroInitiatorAddUpdateMacrosDataGridView.Visible = True
                objFormMacroInitiatorAddUpdate.Activate()
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "RefreshOpenMacroInitiatorAddUpdateForm(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "RefreshOpenMacroInitiatorAddUpdateForm(): Exception: " & ex.Message
            End If
        End Try

        Return strStatus

    End Function ' END - RefreshOpenMacroInitiatorAddUpdateForm()

    '=====================================================================================
    ' Function RefreshOpenMacroAddUpdateForm()
    ' Alan Wagner
    ' Refresh "MacroCommands" DataSet on open "Update Macros" form.
    '
    Private Function RefreshOpenMacroAddUpdateForm(ByRef objFormMacroAddUpdate As formMacroAddUpdate) As String
        Dim strStatus As String = ""

        Try

            ' formMacroAddUpdate_GetMacroCommandsDataSet(ByVal intMacroID As Integer) As String
            strStatus = objFormMacroAddUpdate.formMacroAddUpdate_GetMacroCommandsDataSet(CType(objFormMacroAddUpdate.formMacroAddUpdateIDLabelText.Text(), Integer))
            If (strStatus = "") Then
                objFormMacroAddUpdate.formMacroAddUpdateMacroCommandsDataGridView.Visible = True
                objFormMacroAddUpdate.Activate()
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "RefreshOpenMacroAddUpdateForm(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "RefreshOpenMacroAddUpdateForm(): Exception: " & ex.Message
            End If
        End Try

        Return strStatus

    End Function ' END - RefreshOpenMacroAddUpdateForm()

    Private Sub SaveForms()
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Dim objFormControllerEdit As formControllerEdit = Nothing
        Dim objFormModuleEdit As formModuleEdit = Nothing
        Dim objFormSceneEdit As formSceneEdit = Nothing
        Dim objFormScheduleEdit As formScheduleEdit = Nothing
        Dim objFormMacroInitiatorEdit As formMacroInitiatorEdit = Nothing
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Try

            ' Save Open/Close status and Location/Size of form formControllerEdit.
            If objFormCollection.OfType(Of formControllerEdit).Any Then

                My.Settings.FormOpenControllerEdit = "Y"

                objFormControllerEdit = New formControllerEdit
                objFormControllerEdit = objFormCollection.Item("formControllerEdit")

                objLocation = New System.Drawing.Point
                objLocation = objFormControllerEdit.Location

                objSize = New System.Drawing.Size
                objSize = objFormControllerEdit.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not objFormControllerEdit.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = objFormControllerEdit.RestoreBounds.Location
                    objSize = objFormControllerEdit.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)
                objLocation = Nothing
                objSize = Nothing

                My.Settings.FormInitialLocationControllerEdit = strInitialLocationSize

            Else
                My.Settings.FormOpenControllerEdit = "N"
            End If

            ' Save Open/Close status and Location/Size of form formModuleEdit.
            If objFormCollection.OfType(Of formModuleEdit).Any Then

                My.Settings.FormOpenModuleEdit = "Y"

                objFormModuleEdit = New formModuleEdit
                objFormModuleEdit = objFormCollection.Item("formModuleEdit")

                objLocation = New System.Drawing.Point
                objLocation = objFormModuleEdit.Location

                objSize = New System.Drawing.Size
                objSize = objFormModuleEdit.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not objFormModuleEdit.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = objFormModuleEdit.RestoreBounds.Location
                    objSize = objFormModuleEdit.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)
                objLocation = Nothing
                objSize = Nothing

                My.Settings.FormInitialLocationModuleEdit = strInitialLocationSize

            Else
                My.Settings.FormOpenModuleEdit = "N"
            End If

            ' Save Open/Close status and Location/Size of form formSceneEdit.
            If objFormCollection.OfType(Of formSceneEdit).Any Then

                My.Settings.FormOpenSceneEdit = "Y"

                objFormSceneEdit = New formSceneEdit
                objFormSceneEdit = objFormCollection.Item("formSceneEdit")

                objLocation = New System.Drawing.Point
                objLocation = objFormSceneEdit.Location

                objSize = New System.Drawing.Size
                objSize = objFormSceneEdit.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not objFormSceneEdit.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = objFormSceneEdit.RestoreBounds.Location
                    objSize = objFormSceneEdit.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)
                objLocation = Nothing
                objSize = Nothing

                My.Settings.FormInitialLocationSceneEdit = strInitialLocationSize

            Else
                My.Settings.FormOpenSceneEdit = "N"
            End If

            ' Save Open/Close status and Location/Size of form formScheduleEdit.
            If objFormCollection.OfType(Of formScheduleEdit).Any Then

                My.Settings.FormOpenScheduleEdit = "Y"

                objFormScheduleEdit = New formScheduleEdit
                objFormScheduleEdit = objFormCollection.Item("formScheduleEdit")

                objLocation = New System.Drawing.Point
                objLocation = objFormScheduleEdit.Location

                objSize = New System.Drawing.Size
                objSize = objFormScheduleEdit.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not objFormScheduleEdit.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = objFormScheduleEdit.RestoreBounds.Location
                    objSize = objFormScheduleEdit.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)
                objLocation = Nothing
                objSize = Nothing

                My.Settings.FormInitialLocationScheduleEdit = strInitialLocationSize

            Else
                My.Settings.FormOpenScheduleEdit = "N"
            End If

            ' Save Open/Close status and Location/Size of form formMacroInitiatorEdit.
            If objFormCollection.OfType(Of formMacroInitiatorEdit).Any Then

                My.Settings.FormOpenMacroInitiatorEdit = "Y"

                objFormMacroInitiatorEdit = New formMacroInitiatorEdit
                objFormMacroInitiatorEdit = objFormCollection.Item("formMacroInitiatorEdit")

                objLocation = New System.Drawing.Point
                objLocation = objFormMacroInitiatorEdit.Location

                objSize = New System.Drawing.Size
                objSize = objFormMacroInitiatorEdit.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not objFormMacroInitiatorEdit.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = objFormMacroInitiatorEdit.RestoreBounds.Location
                    objSize = objFormMacroInitiatorEdit.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)
                objLocation = Nothing
                objSize = Nothing

                My.Settings.FormInitialLocationMacroInitiatorEdit = strInitialLocationSize

            Else
                My.Settings.FormOpenMacroInitiatorEdit = "N"
            End If

            ' Save Open/Close status and Location/Size of form formConsoleMessages.
            If objFormCollection.OfType(Of formConsoleMessages).Any Then

                My.Settings.FormOpenConsoleMessages = "Y"

                objFormConsoleMessages = New formConsoleMessages
                objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")

                objLocation = New System.Drawing.Point
                objLocation = objFormConsoleMessages.Location

                objSize = New System.Drawing.Size
                objSize = objFormConsoleMessages.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not objFormConsoleMessages.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = objFormConsoleMessages.RestoreBounds.Location
                    objSize = objFormConsoleMessages.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)
                objLocation = Nothing
                objSize = Nothing

                My.Settings.FormInitialLocationConsoleMessages = strInitialLocationSize

            Else
                My.Settings.FormOpenConsoleMessages = "N"
            End If

            My.Settings.Save()

        Catch ex As Exception
            strStatus = "SaveForms(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "SaveForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objSize = Nothing
            objFormCollection = Nothing
            objFormConsoleMessages = Nothing
            objFormControllerEdit = Nothing
            objFormModuleEdit = Nothing
            objFormSceneEdit = Nothing
            objFormScheduleEdit = Nothing
            objFormMacroInitiatorEdit = Nothing
            objFormConsoleMessages = Nothing
        End Try

    End Sub ' END - SaveForms()

    Private Sub OpenForms()
        Dim strStatus As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormControllerEdit As formControllerEdit = Nothing
        Dim objFormModuleEdit As formModuleEdit = Nothing
        Dim objFormSceneEdit As formSceneEdit = Nothing
        Dim objFormScheduleEdit As formScheduleEdit = Nothing
        Dim objFormMacroInitiatorEdit As formMacroInitiatorEdit = Nothing

        Try

            ' Was form formControllerEdit open from a previous session?
            If (Not My.Settings.FormOpenControllerEdit Is Nothing AndAlso My.Settings.FormOpenControllerEdit = "Y") Then

                objFormControllerEdit = New formControllerEdit

                ' Open form in Parent form.
                objFormControllerEdit.TopLevel = False
                objFormControllerEdit.Parent = Me

                objFormControllerEdit.formControllerEdit_BringToFrontLabel.Text() = "Y"

                objFormControllerEdit.Show()

            End If

            ' Was form formModuleEdit open from a previous session?
            If (Not My.Settings.FormOpenModuleEdit Is Nothing AndAlso My.Settings.FormOpenModuleEdit = "Y") Then

                objFormModuleEdit = New formModuleEdit

                ' Open form in Parent form.
                objFormModuleEdit.TopLevel = False
                objFormModuleEdit.Parent = Me

                objFormModuleEdit.formModuleEdit_BringToFrontLabel.Text() = "Y"

                objFormModuleEdit.Show()

            End If

            ' Was form formSceneEdit open from a previous session?
            If (Not My.Settings.FormOpenSceneEdit Is Nothing AndAlso My.Settings.FormOpenSceneEdit = "Y") Then

                objFormSceneEdit = New formSceneEdit

                ' Open form in Parent form.
                objFormSceneEdit.TopLevel = False
                objFormSceneEdit.Parent = Me

                objFormSceneEdit.formSceneEdit_BringToFrontLabel.Text() = "Y"

                objFormSceneEdit.Show()

            End If

            ' Was form formScheduleEdit open from a previous session?
            If (Not My.Settings.FormOpenScheduleEdit Is Nothing AndAlso My.Settings.FormOpenScheduleEdit = "Y") Then

                objFormScheduleEdit = New formScheduleEdit

                ' Open form in Parent form.
                objFormScheduleEdit.TopLevel = False
                objFormScheduleEdit.Parent = Me

                objFormScheduleEdit.formScheduleEdit_BringToFrontLabel.Text() = "Y"

                objFormScheduleEdit.Show()

            End If

            ' Was form formMacroInitiatorEdit open from a previous session?
            If (Not My.Settings.FormOpenMacroInitiatorEdit Is Nothing AndAlso My.Settings.FormOpenMacroInitiatorEdit = "Y") Then

                objFormMacroInitiatorEdit = New formMacroInitiatorEdit

                ' Open form in Parent form.
                objFormMacroInitiatorEdit.TopLevel = False
                objFormMacroInitiatorEdit.Parent = Me

                objFormMacroInitiatorEdit.formMacroInitiatorEdit_BringToFrontLabel.Text() = "Y"

                objFormMacroInitiatorEdit.Show()

            End If

        Catch ex As Exception
            strStatus = "OpenForms(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "OpenForms()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
            objFormModuleEdit = Nothing
            objFormSceneEdit = Nothing
            objFormScheduleEdit = Nothing
            objFormMacroInitiatorEdit = Nothing
        End Try

    End Sub ' END - OpenForms()

#End Region ' END Region - X10ManagerDesktopMethods

End Class ' END Class - TrekkerPhotoArt
