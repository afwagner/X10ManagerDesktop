﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formSceneEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.formSceneEditDataGridView = New System.Windows.Forms.DataGridView()
        Me.formSceneEdit_BringToFrontLabel = New System.Windows.Forms.Label()
        CType(Me.formSceneEditDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'formSceneEditDataGridView
        '
        Me.formSceneEditDataGridView.AllowUserToAddRows = False
        Me.formSceneEditDataGridView.AllowUserToDeleteRows = False
        Me.formSceneEditDataGridView.AllowUserToResizeRows = False
        Me.formSceneEditDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formSceneEditDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formSceneEditDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.formSceneEditDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.formSceneEditDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.formSceneEditDataGridView.Name = "formSceneEditDataGridView"
        Me.formSceneEditDataGridView.ReadOnly = True
        Me.formSceneEditDataGridView.ShowCellToolTips = False
        Me.formSceneEditDataGridView.ShowEditingIcon = False
        Me.formSceneEditDataGridView.Size = New System.Drawing.Size(675, 358)
        Me.formSceneEditDataGridView.TabIndex = 2
        '
        'formSceneEdit_BringToFrontLabel
        '
        Me.formSceneEdit_BringToFrontLabel.AutoSize = True
        Me.formSceneEdit_BringToFrontLabel.Location = New System.Drawing.Point(12, 9)
        Me.formSceneEdit_BringToFrontLabel.Name = "formSceneEdit_BringToFrontLabel"
        Me.formSceneEdit_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formSceneEdit_BringToFrontLabel.TabIndex = 3
        Me.formSceneEdit_BringToFrontLabel.Text = "Y | N"
        Me.formSceneEdit_BringToFrontLabel.Visible = False
        '
        'formSceneEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(675, 358)
        Me.Controls.Add(Me.formSceneEdit_BringToFrontLabel)
        Me.Controls.Add(Me.formSceneEditDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formSceneEdit"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Scene Edit"
        CType(Me.formSceneEditDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formSceneEditDataGridView As DataGridView
    Friend WithEvents formSceneEdit_BringToFrontLabel As Label
End Class
