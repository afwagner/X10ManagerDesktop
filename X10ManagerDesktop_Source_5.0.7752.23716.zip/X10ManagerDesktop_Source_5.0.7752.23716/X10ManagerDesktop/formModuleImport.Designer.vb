﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formModuleImport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formModuleImport))
        Me.formModuleImport_StatusLabel = New System.Windows.Forms.Label()
        Me.formModuleImport_ImportButton = New System.Windows.Forms.Button()
        Me.formModuleImport_CancelButton = New System.Windows.Forms.Button()
        Me.formModuleImport_OpenFileDialog = New System.Windows.Forms.OpenFileDialog()
        Me.formModuleImport_BrowseButton = New System.Windows.Forms.Button()
        Me.formModuleImportImportFileLabelExample = New System.Windows.Forms.Label()
        Me.formModuleImportImportFileTextBox = New System.Windows.Forms.TextBox()
        Me.formModuleImportImportFileLabel = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel05 = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel04 = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel06 = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel07 = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel08 = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel02 = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel01 = New System.Windows.Forms.Label()
        Me.formModuleImportFileLabel03 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'formModuleImport_StatusLabel
        '
        Me.formModuleImport_StatusLabel.AutoSize = True
        Me.formModuleImport_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formModuleImport_StatusLabel.Location = New System.Drawing.Point(102, 257)
        Me.formModuleImport_StatusLabel.Name = "formModuleImport_StatusLabel"
        Me.formModuleImport_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formModuleImport_StatusLabel.TabIndex = 12
        Me.formModuleImport_StatusLabel.Text = "Success | Fail"
        '
        'formModuleImport_ImportButton
        '
        Me.formModuleImport_ImportButton.Location = New System.Drawing.Point(21, 254)
        Me.formModuleImport_ImportButton.Name = "formModuleImport_ImportButton"
        Me.formModuleImport_ImportButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleImport_ImportButton.TabIndex = 11
        Me.formModuleImport_ImportButton.Text = "Import"
        Me.formModuleImport_ImportButton.UseVisualStyleBackColor = True
        '
        'formModuleImport_CancelButton
        '
        Me.formModuleImport_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formModuleImport_CancelButton.Location = New System.Drawing.Point(625, 251)
        Me.formModuleImport_CancelButton.Name = "formModuleImport_CancelButton"
        Me.formModuleImport_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleImport_CancelButton.TabIndex = 10
        Me.formModuleImport_CancelButton.Text = "Cancel"
        Me.formModuleImport_CancelButton.UseMnemonic = False
        Me.formModuleImport_CancelButton.UseVisualStyleBackColor = True
        '
        'formModuleImport_OpenFileDialog
        '
        Me.formModuleImport_OpenFileDialog.FileName = "X10Db_Modules.csv"
        '
        'formModuleImport_BrowseButton
        '
        Me.formModuleImport_BrowseButton.Location = New System.Drawing.Point(21, 197)
        Me.formModuleImport_BrowseButton.Name = "formModuleImport_BrowseButton"
        Me.formModuleImport_BrowseButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleImport_BrowseButton.TabIndex = 21
        Me.formModuleImport_BrowseButton.Text = "Browse"
        Me.formModuleImport_BrowseButton.UseVisualStyleBackColor = True
        '
        'formModuleImportImportFileLabelExample
        '
        Me.formModuleImportImportFileLabelExample.AutoSize = True
        Me.formModuleImportImportFileLabelExample.Location = New System.Drawing.Point(118, 202)
        Me.formModuleImportImportFileLabelExample.Name = "formModuleImportImportFileLabelExample"
        Me.formModuleImportImportFileLabelExample.Size = New System.Drawing.Size(182, 13)
        Me.formModuleImportImportFileLabelExample.TabIndex = 20
        Me.formModuleImportImportFileLabelExample.Text = "ex: Documents\X10Db_Modules.csv"
        '
        'formModuleImportImportFileTextBox
        '
        Me.formModuleImportImportFileTextBox.Location = New System.Drawing.Point(105, 178)
        Me.formModuleImportImportFileTextBox.Name = "formModuleImportImportFileTextBox"
        Me.formModuleImportImportFileTextBox.Size = New System.Drawing.Size(595, 20)
        Me.formModuleImportImportFileTextBox.TabIndex = 19
        '
        'formModuleImportImportFileLabel
        '
        Me.formModuleImportImportFileLabel.AutoSize = True
        Me.formModuleImportImportFileLabel.Location = New System.Drawing.Point(38, 181)
        Me.formModuleImportImportFileLabel.Name = "formModuleImportImportFileLabel"
        Me.formModuleImportImportFileLabel.Size = New System.Drawing.Size(58, 13)
        Me.formModuleImportImportFileLabel.TabIndex = 18
        Me.formModuleImportImportFileLabel.Text = "Import File:"
        '
        'formModuleImportFileLabel05
        '
        Me.formModuleImportFileLabel05.AutoSize = True
        Me.formModuleImportFileLabel05.Location = New System.Drawing.Point(13, 87)
        Me.formModuleImportFileLabel05.Name = "formModuleImportFileLabel05"
        Me.formModuleImportFileLabel05.Size = New System.Drawing.Size(687, 13)
        Me.formModuleImportFileLabel05.TabIndex = 22
        Me.formModuleImportFileLabel05.Text = """ControllerName"",""UnitCode"",""UnitName"",""UnitDescription"",""UnitEnabledYN"",""UnitDim" &
    "merYN"",""UnitLightingYN"",""UnitExtendedCommandsYN"""
        '
        'formModuleImportFileLabel04
        '
        Me.formModuleImportFileLabel04.AutoSize = True
        Me.formModuleImportFileLabel04.Location = New System.Drawing.Point(13, 74)
        Me.formModuleImportFileLabel04.Name = "formModuleImportFileLabel04"
        Me.formModuleImportFileLabel04.Size = New System.Drawing.Size(70, 13)
        Me.formModuleImportFileLabel04.TabIndex = 23
        Me.formModuleImportFileLabel04.Text = "Header Row:"
        '
        'formModuleImportFileLabel06
        '
        Me.formModuleImportFileLabel06.AutoSize = True
        Me.formModuleImportFileLabel06.Location = New System.Drawing.Point(12, 111)
        Me.formModuleImportFileLabel06.Name = "formModuleImportFileLabel06"
        Me.formModuleImportFileLabel06.Size = New System.Drawing.Size(106, 13)
        Me.formModuleImportFileLabel06.TabIndex = 24
        Me.formModuleImportFileLabel06.Text = "Data Row Examples:"
        '
        'formModuleImportFileLabel07
        '
        Me.formModuleImportFileLabel07.AutoSize = True
        Me.formModuleImportFileLabel07.Location = New System.Drawing.Point(12, 124)
        Me.formModuleImportFileLabel07.Name = "formModuleImportFileLabel07"
        Me.formModuleImportFileLabel07.Size = New System.Drawing.Size(394, 13)
        Me.formModuleImportFileLabel07.TabIndex = 25
        Me.formModuleImportFileLabel07.Text = """House Lighting CP290"",""J1"",""OutGar"",""Outside Garage Lights"",""Y"",""N"",""Y"",""N"""
        '
        'formModuleImportFileLabel08
        '
        Me.formModuleImportFileLabel08.AutoSize = True
        Me.formModuleImportFileLabel08.Location = New System.Drawing.Point(12, 137)
        Me.formModuleImportFileLabel08.Name = "formModuleImportFileLabel08"
        Me.formModuleImportFileLabel08.Size = New System.Drawing.Size(526, 13)
        Me.formModuleImportFileLabel08.TabIndex = 26
        Me.formModuleImportFileLabel08.Text = """Test CP290"",""J16"",""Den Test Dimmer Module"",""Dimmer LED Test Light in Dimmer Modu" &
    "le"",""Y"",""Y"",""Y"",""N"""
        '
        'formModuleImportFileLabel02
        '
        Me.formModuleImportFileLabel02.AutoSize = True
        Me.formModuleImportFileLabel02.Location = New System.Drawing.Point(27, 34)
        Me.formModuleImportFileLabel02.Name = "formModuleImportFileLabel02"
        Me.formModuleImportFileLabel02.Size = New System.Drawing.Size(237, 13)
        Me.formModuleImportFileLabel02.TabIndex = 27
        Me.formModuleImportFileLabel02.Text = "Comma Delimited, each Cell with Double Quotes."
        '
        'formModuleImportFileLabel01
        '
        Me.formModuleImportFileLabel01.AutoSize = True
        Me.formModuleImportFileLabel01.Location = New System.Drawing.Point(12, 21)
        Me.formModuleImportFileLabel01.Name = "formModuleImportFileLabel01"
        Me.formModuleImportFileLabel01.Size = New System.Drawing.Size(117, 13)
        Me.formModuleImportFileLabel01.TabIndex = 28
        Me.formModuleImportFileLabel01.Text = "CSV Import File Format:"
        '
        'formModuleImportFileLabel03
        '
        Me.formModuleImportFileLabel03.AutoSize = True
        Me.formModuleImportFileLabel03.Location = New System.Drawing.Point(27, 47)
        Me.formModuleImportFileLabel03.Name = "formModuleImportFileLabel03"
        Me.formModuleImportFileLabel03.Size = New System.Drawing.Size(300, 13)
        Me.formModuleImportFileLabel03.TabIndex = 29
        Me.formModuleImportFileLabel03.Text = """.csv"" Extension for file name.  Example: X10Db_Modules.csv"
        '
        'formModuleImport
        '
        Me.AcceptButton = Me.formModuleImport_ImportButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formModuleImport_CancelButton
        Me.ClientSize = New System.Drawing.Size(715, 292)
        Me.Controls.Add(Me.formModuleImportFileLabel03)
        Me.Controls.Add(Me.formModuleImportFileLabel01)
        Me.Controls.Add(Me.formModuleImportFileLabel02)
        Me.Controls.Add(Me.formModuleImportFileLabel08)
        Me.Controls.Add(Me.formModuleImportFileLabel07)
        Me.Controls.Add(Me.formModuleImportFileLabel06)
        Me.Controls.Add(Me.formModuleImportFileLabel04)
        Me.Controls.Add(Me.formModuleImportFileLabel05)
        Me.Controls.Add(Me.formModuleImport_BrowseButton)
        Me.Controls.Add(Me.formModuleImportImportFileLabelExample)
        Me.Controls.Add(Me.formModuleImportImportFileTextBox)
        Me.Controls.Add(Me.formModuleImportImportFileLabel)
        Me.Controls.Add(Me.formModuleImport_StatusLabel)
        Me.Controls.Add(Me.formModuleImport_ImportButton)
        Me.Controls.Add(Me.formModuleImport_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formModuleImport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Module Import"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formModuleImport_StatusLabel As Label
    Friend WithEvents formModuleImport_ImportButton As Button
    Friend WithEvents formModuleImport_CancelButton As Button
    Friend WithEvents formModuleImport_OpenFileDialog As OpenFileDialog
    Friend WithEvents formModuleImport_BrowseButton As Button
    Friend WithEvents formModuleImportImportFileLabelExample As Label
    Friend WithEvents formModuleImportImportFileTextBox As TextBox
    Friend WithEvents formModuleImportImportFileLabel As Label
    Friend WithEvents formModuleImportFileLabel05 As Label
    Friend WithEvents formModuleImportFileLabel04 As Label
    Friend WithEvents formModuleImportFileLabel06 As Label
    Friend WithEvents formModuleImportFileLabel07 As Label
    Friend WithEvents formModuleImportFileLabel08 As Label
    Friend WithEvents formModuleImportFileLabel02 As Label
    Friend WithEvents formModuleImportFileLabel01 As Label
    Friend WithEvents formModuleImportFileLabel03 As Label
End Class
