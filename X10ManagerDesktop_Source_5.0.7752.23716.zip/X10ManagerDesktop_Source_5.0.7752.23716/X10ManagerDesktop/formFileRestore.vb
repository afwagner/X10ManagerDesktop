﻿
' Name: formFileRestore.vb
' By: Alan Wagner
' Date: June 2020

Public Class formFileRestore

#Region "X10ManagerDesktopFileRestoreMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Try

            Me.BringToFront()

            formFileRestore_StatusLabel.Text = ""

            strTryStep = "formFileRestore_FormRestore"
            ' formFileRestore_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formFileRestore_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                formFileRestoreLocationLabel.Text() = X10ManagerDesktop.backupDirectoryPath
                formFileRestore_CancelButton.Select()

            Else
                Windows.Forms.MessageBox.Show("Main(formFileRestore): " & strStatus, "Main(formFileRestore)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - formFileRestore_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formFileRestore): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formFileRestore)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try

    End Sub ' END Sub - Main(formFileRestore)

    Private Sub formFileRestore_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formFileRestore_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formFileRestore_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formFileRestore_FormClosingHandler(): " & strStatus, "formFileRestore_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formFileImport_FormSave()

    End Sub ' END Sub - formFileRestore_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopFileRestoreMainMethods

#Region "formMethods"

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formFileRestore_RestoreButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileRestore_RestoreButton.Click
        Dim strStatus As String = ""
        Dim strTryStep As String = ""
        Dim strMessage As String = ""
        Dim strOperationMessage As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objOpenForms As System.Windows.Forms.FormCollection = System.Windows.Forms.Application.OpenForms
        Dim objForm As System.Windows.Forms.Form = Nothing
        Dim objOpenFormsList As System.Collections.Generic.List(Of System.Windows.Forms.Form) = Nothing
        Dim bProceedWithRestoreQuestion As Boolean = True
        Dim bProceedWithRestore As Boolean = True

        Try

            strTryStep = "ConnectionStrings"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "OpenFormsCount"
            If (objOpenForms.Count > 0) Then

                strTryStep = "NewObjectOpenFormsList"
                objOpenFormsList = New System.Collections.Generic.List(Of System.Windows.Forms.Form)

                strTryStep = "CheckForOpenForms"
                For Each objForm In objOpenForms

                    If (Microsoft.VisualBasic.InStr(1, objForm.Name.ToString(), "AddUpdate", vbTextCompare) > 1 Or Microsoft.VisualBasic.InStr(1, objForm.Name.ToString(), "Messages", vbTextCompare) > 1) Then

                        objOpenFormsList.Add(objForm)

                    End If

                Next ' END - CheckForOpenForms

            End If ' END - OpenFormsCount

            strTryStep = "FormsToClose?"
            If (Not objOpenFormsList Is Nothing AndAlso objOpenFormsList.Count > 0) Then

                strTryStep = "ProceedAndOpenFormsQuestion"
                If (Windows.Forms.MessageBox.Show("******Important******" & vbCrLf & "Existing X10 Database Contents and Settings" & vbCrLf & "will be replaced by this Restore." & vbCrLf & vbCrLf & "There is also unsaved work." & vbCrLf & "Close Opened Forms and proceed with Restore?", "Close", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Warning) = Windows.Forms.DialogResult.No) Then

                    ' Stop the Restore.
                    bProceedWithRestore = False

                Else

                    strTryStep = "CloseEachOpenForm"
                    If (objOpenFormsList.Count > 0) Then
                        For Each objForm In objOpenFormsList
                            strTryStep = "CloseForm"
                            strMessage &= vbCrLf & "  Close Form: " & objForm.Name.ToString()
                            objForm.Close()
                        Next
                        strMessage &= vbCrLf
                    End If

                End If ' END - ProceedAndOpenFormsQuestion

            Else

                strTryStep = "ProceedQuestion"
                If (Windows.Forms.MessageBox.Show("******Important******" & vbCrLf & "Existing X10 Database Contents and Settings" & vbCrLf & "will be replaced by this Restore." & vbCrLf & vbCrLf & "Proceed with Restore?", "Close", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Warning) = Windows.Forms.DialogResult.No) Then

                    ' Stop the Restore.
                    bProceedWithRestore = False

                End If ' END - ProceedQuestion

            End If ' END - FormsToClose?

            strTryStep = "bProceedWithRestore"
            If bProceedWithRestore Then

                formFileRestore_StatusLabel.Text = "Start Restore: Please Wait.."
                formFileRestore_StatusLabel.ForeColor = System.Drawing.Color.Green
                Me.Refresh()

                strTryStep = "getX10DbTableContents"
                ' putX10DbTableContents(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strDestinationDirectoryPath As String, ByRef strMessage As String) As String
                strStatus = putX10DbTableContents(strConnectionString, strProvider, formFileRestoreLocationLabel.Text(), strOperationMessage)
                If (strStatus = "") Then

                    strMessage &= strOperationMessage & vbCrLf & vbCrLf & "Success!"
                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                    Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")

                    formFileRestore_RestoreButton.Visible = False
                    formFileRestore_StatusLabel.Text = "Success"
                    formFileRestore_StatusLabel.ForeColor = System.Drawing.Color.Green
                    formFileRestore_CancelButton.Text() = "Done"

                    Windows.Forms.MessageBox.Show("X10ManagerDesktop will need restarting for Restored settings to take effect.", "formFileRestore_RestoreButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Warning)

                Else

                    strMessage &= strOperationMessage & vbCrLf & vbCrLf & "Fail!"
                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                    Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")

                    formFileRestore_RestoreButton.Visible = False
                    formFileRestore_StatusLabel.Text = "Fail"
                    formFileRestore_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formFileRestore_CancelButton.Text() = "Cancel"

                End If ' END - putX10DbTableContents()

            End If ' END - bProceedWithRestore

        Catch ex As Exception
            strStatus = "formFileRestore_RestoreButton_Click(): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formFileRestore_RestoreButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formFileRestore_RestoreButton.Visible = False
            formFileRestore_StatusLabel.Text = "Fail"
            formFileRestore_StatusLabel.ForeColor = System.Drawing.Color.Red
            formFileRestore_CancelButton.Text() = "Cancel"
        Finally
            objOpenForms = Nothing
            objForm = Nothing
            objOpenFormsList = Nothing
        End Try

    End Sub ' END - formFileRestore_RestoreButton_Click()

    '=====================================================================================
    ' Function putX10DbTableContents()
    ' Alan Wagner
    '
    ' Same procedure to TrekkerPhotoArt.X10Include.X10DbMethods.putX10DbTableContents().
    ' This procedure Trekkerphotoart.formFileRestore.putX10DbTableContents() does have:
    '  1) Procedure formConsoleMessages.DisplayMessage() To allow status updates durring Restore operation.
    '  2) Create an instance of TrekkerPhotoArt.X10Include.X10DbMethods so non-static methods can be called from here.
    ' This procedure Trekkerphotoart.formFileRestore.putX10DbTableContents() does not have:
    '  1) Send messages to bX10OutputConsoleMessages Or bX10OutputTroubleShootMessages
    '
    Private Function putX10DbTableContents(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strSourceDirectory As String, ByRef strMessage As String) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strSourceDirectoryFullPath As String = ""

        Try

            strTryStep = "SourceDirectory"
            If (strSourceDirectory = "") Then
                strStatus = "putX10DbTableContents(): Missing Backup Directory."
            Else

                strTryStep = "GetFullPath"
                ' ex: "D:\Lighthou\X10Manager\X10DbBackup\"
                If (Microsoft.VisualBasic.InStrRev(strSourceDirectory, "\", -1, vbTextCompare) = strSourceDirectory.Length()) Then
                    strSourceDirectoryFullPath = System.IO.Path.GetFullPath(strSourceDirectory)
                Else
                    strSourceDirectoryFullPath = System.IO.Path.GetFullPath(strSourceDirectory & "\")
                End If

                strTryStep = "Exists"
                If (Not System.IO.Directory.Exists(strSourceDirectoryFullPath)) Then
                    strStatus = "putX10DbTableContents(): Backup Directory Full Path not found: " & strSourceDirectoryFullPath
                Else

                    strMessage &= vbCrLf & "Restore X10 Database from Backup directory: " & vbCrLf & """" & strSourceDirectoryFullPath & """"
                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                    Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")

                    strTryStep = "nsX10DbMethods.verifyBackupSchemaVersion()"
                    ' nsX10DbMethods.verifyBackupSchemaVersion(ByVal strSourceDirectory As String) As String
                    strError = nsX10DbMethods.verifyBackupSchemaVersion(strSourceDirectoryFullPath)
                    If (strError = "") Then

                        strMessage &= vbCrLf & "  verifyBackupSchemaVersion(): Success!"
                        strMessage &= vbCrLf & "  createX10DbTablesAll(): Start.  Please wait..."
                        ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                        Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")

                        strTryStep = "nsX10DbMethods.createX10DbTablesAll()"
                        ' nsX10DbMethods.createX10DbTablesAll(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String) As String
                        strError = nsX10DbMethods.createX10DbTablesAll(strX10DbConnectionString, strX10DbProvider)
                        If (strError = "") Then
                            strMessage &= vbCrLf & "  createX10DbTablesAll(): Success!"
                            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                            Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")

                            strTryStep = "nsX10DbMethods.PutDb(Controllers)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_Controllers.csv", "Controllers", "INSERT", "ControllerID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_Controllers.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(Controllers): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(Controllers): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(Controllers)

                            strTryStep = "nsX10DbMethods.PutDb(SerialPorts)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_SerialPorts.csv", "SerialPorts", "INSERT", "SerialPortID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_SerialPorts.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(SerialPorts): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(SerialPorts): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(SerialPorts)

                            strTryStep = "nsX10DbMethods.PutDb(USBPorts)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_USBPorts.csv", "USBPorts", "INSERT", "USBPortID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_USBPorts.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(USBPorts): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(USBPorts): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(USBPorts)

                            strTryStep = "nsX10DbMethods.PutDb(Events)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_Events.csv", "Events", "INSERT", "EventID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_Events.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(Events): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(Events): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(Events)

                            strTryStep = "nsX10DbMethods.PutDb(MacroCommands)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_MacroCommands.csv", "MacroCommands", "INSERT", "MacroCommandID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_MacroCommands.csv"

                                strTryStep = "nsX10DbMethods.PutDb(Macros)"
                                ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                                strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_Macros.csv", "Macros", "INSERT", "MacroID", False)
                                If (strError = "") Then
                                    strMessage &= vbCrLf & "  Restored: X10Db_Macros.csv"
                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")

                                    strTryStep = "nsX10DbMethods.PutDb(MacroInitiators)"
                                    ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                                    strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_MacroInitiators.csv", "MacroInitiators", "INSERT", "MacroInitiatorID", False)
                                    If (strError = "") Then
                                        strMessage &= vbCrLf & "  Restored: X10Db_MacroInitiators.csv"
                                        ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                        Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                                    Else
                                        If (strStatus = "") Then
                                            strStatus = "putX10DbTableContents(MacroInitiators): " & strError
                                        Else
                                            strStatus &= vbCrLf & "putX10DbTableContents(MacroInitiators): " & strError
                                        End If
                                    End If ' END - nsX10DbMethods.PutDb(MacroInitiators)

                                Else
                                    If (strStatus = "") Then
                                        strStatus = "putX10DbTableContents(Macros): " & strError
                                    Else
                                        strStatus &= vbCrLf & "putX10DbTableContents(Macros): " & strError
                                    End If
                                End If ' END - nsX10DbMethods.PutDb(Macros)

                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(MacroCommands): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(MacroCommands): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(MacroCommands)

                            strTryStep = "nsX10DbMethods.PutDb(NextIDs)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_NextIDs.csv", "NextIDs", "UPDATE", "NextID", True)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_NextIDs.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(NextIDs): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(NextIDs): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(NextIDs)

                            strTryStep = "nsX10DbMethods.PutDb(Scenes)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_Scenes.csv", "Scenes", "INSERT", "SceneID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_Scenes.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(Scenes): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(Scenes): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(Scenes)

                            strTryStep = "nsX10DbMethods.PutDb(SceneUnits)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_SceneUnits.csv", "SceneUnits", "INSERT", "SceneUnitID", True)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_SceneUnits.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(SceneUnits): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(SceneUnits): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(SceneUnits)

                            strTryStep = "nsX10DbMethods.PutDb(Schedules)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_Schedules.csv", "Schedules", "INSERT", "ScheduleID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_Schedules.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(Schedules): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(Schedules): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(Schedules)

                            strTryStep = "nsX10DbMethods.PutDb(Settings)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_Settings.csv", "Settings", "UPDATE", "SettingID", True)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_Settings.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(Settings): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(Settings): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(Settings)

                            strTryStep = "nsX10DbMethods.PutDb(Units)"
                            ' nsX10DbMethods.PutDb(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByVal strTableName As String, ByVal strInsertUpdate As String, ByVal strIndexColumnName As String, ByVal bAutoNumberIndex As Boolean) As String
                            strError = nsX10DbMethods.PutDb(strX10DbConnectionString, strX10DbProvider, strSourceDirectoryFullPath & "X10Db_Units.csv", "Units", "INSERT", "UnitID", False)
                            If (strError = "") Then
                                strMessage &= vbCrLf & "  Restored: X10Db_Units.csv"
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Restore Database and Settings")
                            Else
                                If (strStatus = "") Then
                                    strStatus = "putX10DbTableContents(Units): " & strError
                                Else
                                    strStatus &= vbCrLf & "putX10DbTableContents(Units): " & strError
                                End If
                            End If ' END - nsX10DbMethods.PutDb(Units)

                        Else
                            strMessage &= vbCrLf & "Problem with re-creating X10 Db Tables."
                            strStatus = "putX10DbTableContents(NextIDs): " & strError
                        End If ' END - nsX10DbMethods.createX10DbTablesAll()

                    Else
                        strMessage &= vbCrLf & "Problem with Backup Schema Versions."
                        strStatus = "putX10DbTableContents(NextIDs): " & strError
                    End If ' END - nsX10DbMethods.verifyBackupSchemaVersion()

                End If ' END - Exists

            End If ' END - SourceDirectory

        Catch ex As Exception
            strMessage &= vbCrLf & "Exception occurred while Restoring X10 Db Table backups."
            If (strStatus = "") Then
                strStatus = "putX10DbTableContents(" & strTryStep & "): Exception: " & ex.Message.ToString()
            Else
                strStatus &= vbCrLf & "putX10DbTableContents(" & strTryStep & "): Exception: " & ex.Message.ToString()
            End If
        End Try

        Return strStatus

    End Function ' END - putX10DbTableContents()

    Private Sub formFileRestore_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileRestore_CancelButton.Click

        Me.Close()

    End Sub ' END - formFileRestore_CancelButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formFileRestore_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationFileRestore" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formFileRestore_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(425, 325)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationFileRestore Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationFileRestore.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationFileRestore.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formFileRestore_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formFileRestore_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formFileRestore_FormRestore()

    '=====================================================================================
    ' Function formFileRestore_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationFileRestore" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formFileRestore_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationFileRestore = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationFileRestore = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formFileRestore_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formFileRestore_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formFileRestore_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class