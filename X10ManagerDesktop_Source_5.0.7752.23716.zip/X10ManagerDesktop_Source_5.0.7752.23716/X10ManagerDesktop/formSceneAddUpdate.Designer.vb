﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formSceneAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formSceneAddUpdate))
        Me.formSceneAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formSceneAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formSceneAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formSceneAddUpdateNameLabel = New System.Windows.Forms.Label()
        Me.formSceneAddUpdateIDLabel = New System.Windows.Forms.Label()
        Me.formSceneAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formSceneAddUpdateNameTextBox = New System.Windows.Forms.TextBox()
        Me.formSceneAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formSceneAddUpdateDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.formSceneAddUpdateDescriptionLabel = New System.Windows.Forms.Label()
        Me.formSceneAddUpdateRestrictHouseCodeCheckBox = New System.Windows.Forms.CheckBox()
        Me.formSceneAddUpdateRestrictHouseCodeLabel = New System.Windows.Forms.Label()
        Me.formSceneAddUpdateHouseCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formSceneAddUpdateHouseCodeLabel = New System.Windows.Forms.Label()
        Me.formSceneAddUpdate_ClearAllButton = New System.Windows.Forms.Button()
        Me.formSceneAddUpdate_SetAllOffButton = New System.Windows.Forms.Button()
        Me.formSceneAddUpdate_SetAllOnButton = New System.Windows.Forms.Button()
        Me.formSceneAddUpdate_TestSceneModulesButton = New System.Windows.Forms.Button()
        Me.formSceneAddUpdateModulesInSceneDataGridView = New System.Windows.Forms.DataGridView()
        Me.formSceneAddUpdateModulesInSceneLabel = New System.Windows.Forms.Label()
        Me.formSceneAddUpdateOperationsGroupBox = New System.Windows.Forms.GroupBox()
        CType(Me.formSceneAddUpdateModulesInSceneDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.formSceneAddUpdateOperationsGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'formSceneAddUpdate_DeleteButton
        '
        Me.formSceneAddUpdate_DeleteButton.Location = New System.Drawing.Point(316, 37)
        Me.formSceneAddUpdate_DeleteButton.Name = "formSceneAddUpdate_DeleteButton"
        Me.formSceneAddUpdate_DeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.formSceneAddUpdate_DeleteButton.TabIndex = 0
        Me.formSceneAddUpdate_DeleteButton.Text = "Delete"
        Me.formSceneAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdate_CancelButton
        '
        Me.formSceneAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formSceneAddUpdate_CancelButton.Location = New System.Drawing.Point(496, 470)
        Me.formSceneAddUpdate_CancelButton.Name = "formSceneAddUpdate_CancelButton"
        Me.formSceneAddUpdate_CancelButton.Size = New System.Drawing.Size(79, 23)
        Me.formSceneAddUpdate_CancelButton.TabIndex = 1
        Me.formSceneAddUpdate_CancelButton.Text = "Cancel"
        Me.formSceneAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdate_AddUpdateButton
        '
        Me.formSceneAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(24, 470)
        Me.formSceneAddUpdate_AddUpdateButton.Name = "formSceneAddUpdate_AddUpdateButton"
        Me.formSceneAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(89, 23)
        Me.formSceneAddUpdate_AddUpdateButton.TabIndex = 2
        Me.formSceneAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formSceneAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdateNameLabel
        '
        Me.formSceneAddUpdateNameLabel.AutoSize = True
        Me.formSceneAddUpdateNameLabel.Location = New System.Drawing.Point(37, 15)
        Me.formSceneAddUpdateNameLabel.Name = "formSceneAddUpdateNameLabel"
        Me.formSceneAddUpdateNameLabel.Size = New System.Drawing.Size(38, 13)
        Me.formSceneAddUpdateNameLabel.TabIndex = 3
        Me.formSceneAddUpdateNameLabel.Text = "Name:"
        '
        'formSceneAddUpdateIDLabel
        '
        Me.formSceneAddUpdateIDLabel.AutoSize = True
        Me.formSceneAddUpdateIDLabel.Location = New System.Drawing.Point(54, 42)
        Me.formSceneAddUpdateIDLabel.Name = "formSceneAddUpdateIDLabel"
        Me.formSceneAddUpdateIDLabel.Size = New System.Drawing.Size(21, 13)
        Me.formSceneAddUpdateIDLabel.TabIndex = 4
        Me.formSceneAddUpdateIDLabel.Text = "ID:"
        '
        'formSceneAddUpdateIDLabelText
        '
        Me.formSceneAddUpdateIDLabelText.AutoSize = True
        Me.formSceneAddUpdateIDLabelText.Location = New System.Drawing.Point(78, 42)
        Me.formSceneAddUpdateIDLabelText.Name = "formSceneAddUpdateIDLabelText"
        Me.formSceneAddUpdateIDLabelText.Size = New System.Drawing.Size(170, 13)
        Me.formSceneAddUpdateIDLabelText.TabIndex = 5
        Me.formSceneAddUpdateIDLabelText.Text = "formSceneAddUpdateIDLabelText"
        '
        'formSceneAddUpdateNameTextBox
        '
        Me.formSceneAddUpdateNameTextBox.Location = New System.Drawing.Point(81, 12)
        Me.formSceneAddUpdateNameTextBox.MaxLength = 40
        Me.formSceneAddUpdateNameTextBox.Name = "formSceneAddUpdateNameTextBox"
        Me.formSceneAddUpdateNameTextBox.Size = New System.Drawing.Size(310, 20)
        Me.formSceneAddUpdateNameTextBox.TabIndex = 6
        Me.formSceneAddUpdateNameTextBox.Text = "formSceneAddUpdateNameTextBox"
        '
        'formSceneAddUpdate_StatusLabel
        '
        Me.formSceneAddUpdate_StatusLabel.AutoSize = True
        Me.formSceneAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formSceneAddUpdate_StatusLabel.Location = New System.Drawing.Point(119, 473)
        Me.formSceneAddUpdate_StatusLabel.Name = "formSceneAddUpdate_StatusLabel"
        Me.formSceneAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formSceneAddUpdate_StatusLabel.TabIndex = 7
        Me.formSceneAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formSceneAddUpdateDescriptionTextBox
        '
        Me.formSceneAddUpdateDescriptionTextBox.Location = New System.Drawing.Point(81, 66)
        Me.formSceneAddUpdateDescriptionTextBox.MaxLength = 100
        Me.formSceneAddUpdateDescriptionTextBox.Name = "formSceneAddUpdateDescriptionTextBox"
        Me.formSceneAddUpdateDescriptionTextBox.Size = New System.Drawing.Size(310, 20)
        Me.formSceneAddUpdateDescriptionTextBox.TabIndex = 19
        '
        'formSceneAddUpdateDescriptionLabel
        '
        Me.formSceneAddUpdateDescriptionLabel.AutoSize = True
        Me.formSceneAddUpdateDescriptionLabel.Location = New System.Drawing.Point(12, 69)
        Me.formSceneAddUpdateDescriptionLabel.Name = "formSceneAddUpdateDescriptionLabel"
        Me.formSceneAddUpdateDescriptionLabel.Size = New System.Drawing.Size(63, 13)
        Me.formSceneAddUpdateDescriptionLabel.TabIndex = 18
        Me.formSceneAddUpdateDescriptionLabel.Text = "Description:"
        '
        'formSceneAddUpdateRestrictHouseCodeCheckBox
        '
        Me.formSceneAddUpdateRestrictHouseCodeCheckBox.AutoSize = True
        Me.formSceneAddUpdateRestrictHouseCodeCheckBox.Location = New System.Drawing.Point(376, 95)
        Me.formSceneAddUpdateRestrictHouseCodeCheckBox.Name = "formSceneAddUpdateRestrictHouseCodeCheckBox"
        Me.formSceneAddUpdateRestrictHouseCodeCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.formSceneAddUpdateRestrictHouseCodeCheckBox.TabIndex = 31
        Me.formSceneAddUpdateRestrictHouseCodeCheckBox.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdateRestrictHouseCodeLabel
        '
        Me.formSceneAddUpdateRestrictHouseCodeLabel.AutoSize = True
        Me.formSceneAddUpdateRestrictHouseCodeLabel.Location = New System.Drawing.Point(245, 95)
        Me.formSceneAddUpdateRestrictHouseCodeLabel.Name = "formSceneAddUpdateRestrictHouseCodeLabel"
        Me.formSceneAddUpdateRestrictHouseCodeLabel.Size = New System.Drawing.Size(125, 13)
        Me.formSceneAddUpdateRestrictHouseCodeLabel.TabIndex = 30
        Me.formSceneAddUpdateRestrictHouseCodeLabel.Text = "Current house code only:"
        '
        'formSceneAddUpdateHouseCodeComboBox
        '
        Me.formSceneAddUpdateHouseCodeComboBox.FormattingEnabled = True
        Me.formSceneAddUpdateHouseCodeComboBox.Location = New System.Drawing.Point(81, 92)
        Me.formSceneAddUpdateHouseCodeComboBox.Name = "formSceneAddUpdateHouseCodeComboBox"
        Me.formSceneAddUpdateHouseCodeComboBox.Size = New System.Drawing.Size(127, 21)
        Me.formSceneAddUpdateHouseCodeComboBox.TabIndex = 29
        '
        'formSceneAddUpdateHouseCodeLabel
        '
        Me.formSceneAddUpdateHouseCodeLabel.AutoSize = True
        Me.formSceneAddUpdateHouseCodeLabel.Location = New System.Drawing.Point(6, 95)
        Me.formSceneAddUpdateHouseCodeLabel.Name = "formSceneAddUpdateHouseCodeLabel"
        Me.formSceneAddUpdateHouseCodeLabel.Size = New System.Drawing.Size(69, 13)
        Me.formSceneAddUpdateHouseCodeLabel.TabIndex = 28
        Me.formSceneAddUpdateHouseCodeLabel.Text = "House Code:"
        '
        'formSceneAddUpdate_ClearAllButton
        '
        Me.formSceneAddUpdate_ClearAllButton.Location = New System.Drawing.Point(261, 440)
        Me.formSceneAddUpdate_ClearAllButton.Name = "formSceneAddUpdate_ClearAllButton"
        Me.formSceneAddUpdate_ClearAllButton.Size = New System.Drawing.Size(79, 23)
        Me.formSceneAddUpdate_ClearAllButton.TabIndex = 32
        Me.formSceneAddUpdate_ClearAllButton.Text = "Clear All"
        Me.formSceneAddUpdate_ClearAllButton.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdate_SetAllOffButton
        '
        Me.formSceneAddUpdate_SetAllOffButton.Location = New System.Drawing.Point(220, 411)
        Me.formSceneAddUpdate_SetAllOffButton.Name = "formSceneAddUpdate_SetAllOffButton"
        Me.formSceneAddUpdate_SetAllOffButton.Size = New System.Drawing.Size(79, 23)
        Me.formSceneAddUpdate_SetAllOffButton.TabIndex = 33
        Me.formSceneAddUpdate_SetAllOffButton.Text = "Set All Off"
        Me.formSceneAddUpdate_SetAllOffButton.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdate_SetAllOnButton
        '
        Me.formSceneAddUpdate_SetAllOnButton.Location = New System.Drawing.Point(301, 411)
        Me.formSceneAddUpdate_SetAllOnButton.Name = "formSceneAddUpdate_SetAllOnButton"
        Me.formSceneAddUpdate_SetAllOnButton.Size = New System.Drawing.Size(79, 23)
        Me.formSceneAddUpdate_SetAllOnButton.TabIndex = 34
        Me.formSceneAddUpdate_SetAllOnButton.Text = "Set All On"
        Me.formSceneAddUpdate_SetAllOnButton.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdate_TestSceneModulesButton
        '
        Me.formSceneAddUpdate_TestSceneModulesButton.Location = New System.Drawing.Point(211, 19)
        Me.formSceneAddUpdate_TestSceneModulesButton.Name = "formSceneAddUpdate_TestSceneModulesButton"
        Me.formSceneAddUpdate_TestSceneModulesButton.Size = New System.Drawing.Size(147, 23)
        Me.formSceneAddUpdate_TestSceneModulesButton.TabIndex = 35
        Me.formSceneAddUpdate_TestSceneModulesButton.Text = "Test Modules In Scene"
        Me.formSceneAddUpdate_TestSceneModulesButton.UseVisualStyleBackColor = True
        '
        'formSceneAddUpdateModulesInSceneDataGridView
        '
        Me.formSceneAddUpdateModulesInSceneDataGridView.AllowDrop = True
        Me.formSceneAddUpdateModulesInSceneDataGridView.AllowUserToAddRows = False
        Me.formSceneAddUpdateModulesInSceneDataGridView.AllowUserToDeleteRows = False
        Me.formSceneAddUpdateModulesInSceneDataGridView.AllowUserToResizeColumns = False
        Me.formSceneAddUpdateModulesInSceneDataGridView.AllowUserToResizeRows = False
        Me.formSceneAddUpdateModulesInSceneDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formSceneAddUpdateModulesInSceneDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formSceneAddUpdateModulesInSceneDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.formSceneAddUpdateModulesInSceneDataGridView.Location = New System.Drawing.Point(0, 143)
        Me.formSceneAddUpdateModulesInSceneDataGridView.Name = "formSceneAddUpdateModulesInSceneDataGridView"
        Me.formSceneAddUpdateModulesInSceneDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.formSceneAddUpdateModulesInSceneDataGridView.ShowCellToolTips = False
        Me.formSceneAddUpdateModulesInSceneDataGridView.ShowEditingIcon = False
        Me.formSceneAddUpdateModulesInSceneDataGridView.Size = New System.Drawing.Size(599, 263)
        Me.formSceneAddUpdateModulesInSceneDataGridView.TabIndex = 2
        '
        'formSceneAddUpdateModulesInSceneLabel
        '
        Me.formSceneAddUpdateModulesInSceneLabel.AutoSize = True
        Me.formSceneAddUpdateModulesInSceneLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formSceneAddUpdateModulesInSceneLabel.Location = New System.Drawing.Point(6, 123)
        Me.formSceneAddUpdateModulesInSceneLabel.Name = "formSceneAddUpdateModulesInSceneLabel"
        Me.formSceneAddUpdateModulesInSceneLabel.Size = New System.Drawing.Size(120, 17)
        Me.formSceneAddUpdateModulesInSceneLabel.TabIndex = 38
        Me.formSceneAddUpdateModulesInSceneLabel.Text = "Modules In Scene"
        '
        'formSceneAddUpdateOperationsGroupBox
        '
        Me.formSceneAddUpdateOperationsGroupBox.BackColor = System.Drawing.SystemColors.Control
        Me.formSceneAddUpdateOperationsGroupBox.Controls.Add(Me.formSceneAddUpdate_TestSceneModulesButton)
        Me.formSceneAddUpdateOperationsGroupBox.Location = New System.Drawing.Point(9, 499)
        Me.formSceneAddUpdateOperationsGroupBox.Name = "formSceneAddUpdateOperationsGroupBox"
        Me.formSceneAddUpdateOperationsGroupBox.Size = New System.Drawing.Size(578, 54)
        Me.formSceneAddUpdateOperationsGroupBox.TabIndex = 39
        Me.formSceneAddUpdateOperationsGroupBox.TabStop = False
        '
        'formSceneAddUpdate
        '
        Me.AcceptButton = Me.formSceneAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formSceneAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(600, 562)
        Me.Controls.Add(Me.formSceneAddUpdateOperationsGroupBox)
        Me.Controls.Add(Me.formSceneAddUpdateModulesInSceneLabel)
        Me.Controls.Add(Me.formSceneAddUpdateModulesInSceneDataGridView)
        Me.Controls.Add(Me.formSceneAddUpdate_SetAllOnButton)
        Me.Controls.Add(Me.formSceneAddUpdate_SetAllOffButton)
        Me.Controls.Add(Me.formSceneAddUpdate_ClearAllButton)
        Me.Controls.Add(Me.formSceneAddUpdateRestrictHouseCodeCheckBox)
        Me.Controls.Add(Me.formSceneAddUpdateRestrictHouseCodeLabel)
        Me.Controls.Add(Me.formSceneAddUpdateHouseCodeComboBox)
        Me.Controls.Add(Me.formSceneAddUpdateHouseCodeLabel)
        Me.Controls.Add(Me.formSceneAddUpdateDescriptionTextBox)
        Me.Controls.Add(Me.formSceneAddUpdateDescriptionLabel)
        Me.Controls.Add(Me.formSceneAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formSceneAddUpdateNameTextBox)
        Me.Controls.Add(Me.formSceneAddUpdateIDLabelText)
        Me.Controls.Add(Me.formSceneAddUpdateIDLabel)
        Me.Controls.Add(Me.formSceneAddUpdateNameLabel)
        Me.Controls.Add(Me.formSceneAddUpdate_AddUpdateButton)
        Me.Controls.Add(Me.formSceneAddUpdate_CancelButton)
        Me.Controls.Add(Me.formSceneAddUpdate_DeleteButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formSceneAddUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Scene Add / Update"
        CType(Me.formSceneAddUpdateModulesInSceneDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.formSceneAddUpdateOperationsGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formSceneAddUpdate_DeleteButton As Button
    Friend WithEvents formSceneAddUpdate_CancelButton As Button
    Friend WithEvents formSceneAddUpdate_AddUpdateButton As Button
    Friend WithEvents formSceneAddUpdateNameLabel As Label
    Friend WithEvents formSceneAddUpdateIDLabel As Label
    Friend WithEvents formSceneAddUpdateIDLabelText As Label
    Friend WithEvents formSceneAddUpdateNameTextBox As TextBox
    Friend WithEvents formSceneAddUpdate_StatusLabel As Label
    Friend WithEvents formSceneAddUpdateDescriptionTextBox As TextBox
    Friend WithEvents formSceneAddUpdateDescriptionLabel As Label
    Friend WithEvents formSceneAddUpdateRestrictHouseCodeCheckBox As CheckBox
    Friend WithEvents formSceneAddUpdateRestrictHouseCodeLabel As Label
    Friend WithEvents formSceneAddUpdateHouseCodeComboBox As ComboBox
    Friend WithEvents formSceneAddUpdateHouseCodeLabel As Label
    Friend WithEvents formSceneAddUpdate_ClearAllButton As Button
    Friend WithEvents formSceneAddUpdate_SetAllOffButton As Button
    Friend WithEvents formSceneAddUpdate_SetAllOnButton As Button
    Friend WithEvents formSceneAddUpdate_TestSceneModulesButton As Button
    Friend WithEvents formSceneAddUpdateModulesInSceneDataGridView As DataGridView
    Friend WithEvents formSceneAddUpdateModulesInSceneLabel As Label
    Friend WithEvents formSceneAddUpdateOperationsGroupBox As GroupBox
End Class
