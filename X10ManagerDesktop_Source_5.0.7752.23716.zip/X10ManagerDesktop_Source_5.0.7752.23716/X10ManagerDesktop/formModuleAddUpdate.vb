﻿
' Name: formModuleAddUpdate.vb
' By: Alan Wagner
' Date: March 2020

Public Class formModuleAddUpdate

#Region "X10ManagerDesktopModuleAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objX10DbUnit As TrekkerPhotoArt.X10Include.X10DbUnit = Nothing
        Dim intUnitID As Integer = -1

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Try

            Me.BringToFront()

            strTryStep = "formModuleAddUpdate_FormRestore"
            ' formModuleAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formModuleAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formModuleAddUpdateIDLabelText"
                If (formModuleAddUpdateIDLabelText.Text() = "" Or formModuleAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddModule"

                    formModuleAddUpdateIDLabelText.Text() = ""

                    ' Set the caption bar text of the form.
                    Me.Text = "Add Module"

                    formModuleAddUpdate_AddUpdateButton.Text() = "Add"
                    formModuleAddUpdate_AddUpdateButton.Select()
                    formModuleAddUpdate_AddUpdateButton.Visible = True
                    formModuleAddUpdate_StatusLabel.Visible = True
                    formModuleAddUpdate_StatusLabel.Text = ""

                    formModuleAddUpdate_CancelButton.Text() = "Cancel"

                    formModuleAddUpdate_DeleteButton.Visible = False
                    formModuleAddUpdate_DeleteButton.Text() = "Delete"

                    formModuleAddUpdateNameLabel.Visible = True
                    formModuleAddUpdateNameTextBox.Visible = True
                    formModuleAddUpdateNameTextBox.Text() = ""

                    formModuleAddUpdateEnabledCheckBox.Visible = True
                    formModuleAddUpdateEnabledCheckBox.Checked = True
                    formModuleAddUpdateEnabledCheckBox.Enabled = True

                    formModuleAddUpdateDescriptionLabel.Visible = True
                    formModuleAddUpdateDescriptionTextBox.Visible = True
                    formModuleAddUpdateDescriptionTextBox.Text() = ""


                    formModuleAddUpdateControllersLabel.Visible = True
                    formModuleAddUpdateControllerActiveLabel.Visible = True

                    strTryStep = "Add_generateControllersComboBox"
                    ' generateControllersComboBox(ByVal intControllerID As Integer) As String
                    strStatus = generateControllersComboBox(-1)
                    If (strStatus = "") Then
                        formModuleAddUpdateControllersComboBox.Visible = True
                        formModuleAddUpdateControllerActiveLabelText.Visible = True
                        formModuleAddUpdateControllerActiveLabelText.Text() = ""
                    Else
                        formModuleAddUpdateControllersComboBox.Visible = False
                        formModuleAddUpdateControllerActiveLabelText.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formModuleAddUpdate_CancelButton.Select()
                        formModuleAddUpdate_AddUpdateButton.Visible = False
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formModuleAddUpdateHouseCodeLabel.Visible = True

                    strTryStep = "Add_generateHouseCodesComboBox"
                    ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                    strStatus = generateHouseCodesComboBox("")
                    If (strStatus = "") Then
                        formModuleAddUpdateHouseCodeComboBox.Visible = True
                    Else
                        formModuleAddUpdateHouseCodeComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formModuleAddUpdate_CancelButton.Select()
                        formModuleAddUpdate_AddUpdateButton.Visible = False
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formModuleAddUpdateModuleCodeLabel.Visible = True

                    strTryStep = "Add_generateModuleCodesComboBox"
                    ' generateModuleCodesComboBox(ByVal strModuleCode As String) As String
                    strStatus = generateModuleCodesComboBox("")
                    If (strStatus = "") Then
                        formModuleAddUpdateModuleCodeComboBox.Visible = True
                    Else
                        formModuleAddUpdateModuleCodeComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formModuleAddUpdate_CancelButton.Select()
                        formModuleAddUpdate_AddUpdateButton.Visible = False
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formModuleAddUpdateDimmerLabel.Visible = True
                    formModuleAddUpdateDimmerCheckBox.Visible = True
                    formModuleAddUpdateDimmerCheckBox.Checked = False

                    formModuleAddUpdateControlLightsLabel.Visible = True
                    formModuleAddUpdateControlLightsCheckBox.Visible = True
                    formModuleAddUpdateControlLightsCheckBox.Checked = False

                    formModuleAddUpdateExtendedCommandsLabel.Visible = True
                    formModuleAddUpdateExtendedCommandsCheckBox.Checked = False

                    formModuleAddUpdateOperationsGroupBox.Visible = False
                    formModuleAddUpdate_TestButton.Visible = False
                    formModuleAddUpdateOnOffLabel.Visible = False
                    formModuleAddUpdateOnOffComboBox.Visible = False

                Else
                    strTryStep = "UpdateModule"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Module"

                    formModuleAddUpdate_AddUpdateButton.Text() = "Update"
                    formModuleAddUpdate_AddUpdateButton.Select()
                    formModuleAddUpdate_AddUpdateButton.Visible = True
                    formModuleAddUpdate_StatusLabel.Visible = True
                    formModuleAddUpdate_StatusLabel.Text = ""

                    formModuleAddUpdate_CancelButton.Text() = "Done"

                    formModuleAddUpdate_DeleteButton.Visible = True
                    formModuleAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "UnitID"
                    intUnitID = CType(formModuleAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbModule"
                    ' nsX10DbMethods.getX10DbModule(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intUnitID As Integer, ByRef objX10DbUnit As TrekkerPhotoArt.X10Include.X10DbUnit) As String
                    strStatus = nsX10DbMethods.getX10DbModule(strConnectionString, strProvider, intUnitID, objX10DbUnit)
                    If (strStatus = "") Then

                        formModuleAddUpdateIDLabelText.Text() = objX10DbUnit.UnitID.ToString()

                        formModuleAddUpdateNameLabel.Visible = True
                        formModuleAddUpdateNameTextBox.Visible = True
                        formModuleAddUpdateNameTextBox.Text() = objX10DbUnit.UnitName

                        formModuleAddUpdateDescriptionLabel.Visible = True
                        formModuleAddUpdateDescriptionTextBox.Visible = True
                        formModuleAddUpdateDescriptionTextBox.Text() = objX10DbUnit.UnitDescription

                        Select Case objX10DbUnit.UnitEnabled
                            Case 0
                                formModuleAddUpdateEnabledCheckBox.Checked = False
                            Case 1
                                formModuleAddUpdateEnabledCheckBox.Checked = True
                        End Select
                        formModuleAddUpdateEnabledCheckBox.Visible = True
                        formModuleAddUpdateEnabledCheckBox.Enabled = True


                        formModuleAddUpdateControllersLabel.Visible = True

                        strTryStep = "Update_generateControllersComboBox"
                        ' generateControllersComboBox(ByVal intControllerID As Integer) As String
                        strStatus = generateControllersComboBox(objX10DbUnit.ControllerID)
                        If (strStatus = "") Then

                            ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                            strStatus = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, objX10DbUnit.ControllerID, objX10DbController)
                            If (strStatus = "") Then

                                formModuleAddUpdateControllerActiveLabelText.Visible = True
                                Select Case objX10DbController.ControllerActive
                                    Case 0
                                        formModuleAddUpdateControllerActiveLabelText.Text() = "No"
                                    Case 1
                                        formModuleAddUpdateControllerActiveLabelText.Text() = "Yes"
                                End Select

                            Else
                                formModuleAddUpdateControllerActiveLabelText.Visible = False
                                Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formModuleAddUpdate_CancelButton.Select()
                                formModuleAddUpdate_CancelButton.Text() = "Cancel"
                            End If

                        Else
                            formModuleAddUpdateControllersComboBox.Visible = False
                            formModuleAddUpdateControllerActiveLabelText.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formModuleAddUpdate_CancelButton.Select()
                            formModuleAddUpdate_AddUpdateButton.Visible = False
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formModuleAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        formModuleAddUpdateHouseCodeLabel.Visible = True

                        strTryStep = "Update_generateHouseCodesComboBox"
                        ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                        strStatus = generateHouseCodesComboBox(objX10DbUnit.UnitHouseCode)
                        If (strStatus = "") Then
                            formModuleAddUpdateHouseCodeComboBox.Visible = True
                        Else
                            formModuleAddUpdateHouseCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formModuleAddUpdate_CancelButton.Select()
                            formModuleAddUpdate_AddUpdateButton.Visible = False
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formModuleAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        formModuleAddUpdateModuleCodeLabel.Visible = True

                        strTryStep = "Update_generateModuleCodesComboBox"
                        ' generateModuleCodesComboBox(ByVal strModuleCode As String) As String
                        strStatus = generateModuleCodesComboBox(objX10DbUnit.UnitModuleCode)
                        If (strStatus = "") Then
                            formModuleAddUpdateModuleCodeComboBox.Visible = True
                        Else
                            formModuleAddUpdateModuleCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formModuleAddUpdate_CancelButton.Select()
                            formModuleAddUpdate_AddUpdateButton.Visible = False
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formModuleAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        formModuleAddUpdateDimmerLabel.Visible = True
                        formModuleAddUpdateDimmerCheckBox.Visible = True
                        If (objX10DbUnit.UnitDimmer = 1) Then
                            formModuleAddUpdateDimmerCheckBox.Checked = True
                        Else
                            formModuleAddUpdateDimmerCheckBox.Checked = False
                        End If


                        formModuleAddUpdateControlLightsLabel.Visible = True
                        formModuleAddUpdateControlLightsCheckBox.Visible = True
                        If (objX10DbUnit.UnitLighting = 1) Then
                            formModuleAddUpdateControlLightsCheckBox.Checked = True
                        Else
                            formModuleAddUpdateControlLightsCheckBox.Checked = False
                        End If


                        formModuleAddUpdateExtendedCommandsLabel.Visible = True

                        If (objX10DbUnit.UnitExtendedCommands = 1) Then
                            formModuleAddUpdateExtendedCommandsCheckBox.Checked = True
                        Else
                            formModuleAddUpdateExtendedCommandsCheckBox.Checked = False
                        End If


                        formModuleAddUpdateOperationsGroupBox.Visible = True
                        formModuleAddUpdate_TestButton.Visible = True

                        formModuleAddUpdateOnOffLabel.Visible = True

                        ' generateOnOffComboBox(ByVal intUnitDimmer As Integer) As String
                        strStatus = generateOnOffComboBox(objX10DbUnit.UnitDimmer)
                        If (strStatus = "") Then
                            formModuleAddUpdateOnOffComboBox.Visible = True
                        Else
                            formModuleAddUpdateOnOffComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formModuleAddUpdate_CancelButton.Select()
                            formModuleAddUpdate_AddUpdateButton.Visible = False
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formModuleAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Module from X10 db." & vbCrLf & strStatus, "Main(formModuleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formModuleAddUpdate_CancelButton.Select()
                        formModuleAddUpdate_AddUpdateButton.Visible = False
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getX10DbModule(()

                End If ' END - formModuleAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formModuleAddUpdate): " & strStatus, "Main(formModuleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formModuleAddUpdate_StatusLabel.Text = "Fail"
                formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formModuleAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formModuleAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formModuleAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleAddUpdate_StatusLabel.Text = "Fail"
            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbController = Nothing
            objX10DbUnit = Nothing
        End Try

    End Sub ' END Sub - Main(formModuleAddUpdate)

    Private Sub formModuleAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formMain_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formModuleAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formModuleAddUpdate_FormClosingHandler(): " & strStatus, "formModuleAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formModuleAddUpdate_FormSave()

    End Sub ' END Sub - formModuleAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopModuleAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function generateControllersComboBox()
    ' Alan Wagner
    '
    Private Function generateControllersComboBox(ByVal intControllerID As Integer) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""
        Dim objDataTableControllers As New System.Data.DataTable

        Dim objDataRowViewController As System.Data.DataRowView = Nothing
        Dim intSelectedIndex As Integer = 0

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()

                sqlString = "SELECT ControllerID, ControllerName+' ['+ControllerType+']' AS Controller " &
                        "FROM (Controllers INNER JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID) " &
                        "UNION " &
                        "SELECT -1 AS ControllerID, 'Select Controller...' AS Controller FROM Controllers " &
                        "ORDER BY ControllerID ASC"

                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableControllers)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            If (objDataTableControllers.Rows.Count() > 0) Then

                With formModuleAddUpdateControllersComboBox
                    .DisplayMember = "Controller"
                    .ValueMember = "ControllerID"
                    .DataSource = objDataTableControllers
                End With

                If (intControllerID = -1) Then
                    formModuleAddUpdateControllersComboBox.SelectedIndex = 0
                Else
                    formModuleAddUpdateControllersComboBox.SelectedIndex = formModuleAddUpdateControllersComboBox.FindString(intControllerID.ToString)

                    For intSelectedIndex = 0 To formModuleAddUpdateControllersComboBox.Items.Count - 1

                        objDataRowViewController = formModuleAddUpdateControllersComboBox.Items(intSelectedIndex)

                        If (intControllerID = CType(objDataRowViewController.Row("ControllerID").ToString(), Integer)) Then
                            formModuleAddUpdateControllersComboBox.SelectedIndex = intSelectedIndex
                            Exit For
                        End If

                    Next

                End If

            Else
                strStatus = "generateControllersComboBox(): No X10 Controllers found."
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "generateControllersComboBox(): Exception: " & ex.Message
            Else
                strStatus = "generateControllersComboBox(): Exception: " & ex.Message
            End If
        Finally
            objDataRowViewController = Nothing
            objDataTableControllers = Nothing
        End Try

        Return strStatus

    End Function ' END - generateControllersComboBox()

    '=====================================================================================
    ' Function generateHouseCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateHouseCodesComboBox(ByVal strHouseCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableHouseCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT HouseCodeID, HouseCode FROM HouseCodes UNION SELECT 0 AS HouseCodeID, 'Select HouseCode...' AS HouseCode FROM HouseCodes ORDER BY HouseCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableHouseCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formModuleAddUpdateHouseCodeComboBox
                .DisplayMember = "HouseCode"
                .ValueMember = "HouseCodeID"
                .DataSource = objDataTableHouseCodes
            End With

            If (strHouseCode = "") Then
                formModuleAddUpdateHouseCodeComboBox.SelectedIndex = 0
            Else
                formModuleAddUpdateHouseCodeComboBox.SelectedIndex = formModuleAddUpdateHouseCodeComboBox.FindString(strHouseCode)
            End If

        Catch ex As Exception
            strStatus = "generateHouseCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableHouseCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateHouseCodesComboBox()

    '=====================================================================================
    ' Function generateModuleCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateModuleCodesComboBox(ByVal strModuleCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableModuleCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT ModuleCodeID, ModuleCode FROM ModuleCodes UNION SELECT 0 AS ModuleCodeID, 'Select UnitCode...' AS ModuleCode FROM ModuleCodes ORDER BY ModuleCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableModuleCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formModuleAddUpdateModuleCodeComboBox
                .DisplayMember = "ModuleCode"
                .ValueMember = "ModuleCodeID"
                .DataSource = objDataTableModuleCodes
            End With

            If (strModuleCode = "") Then
                formModuleAddUpdateModuleCodeComboBox.SelectedIndex = 0
            Else
                formModuleAddUpdateModuleCodeComboBox.SelectedIndex = formModuleAddUpdateModuleCodeComboBox.FindString(strModuleCode)
            End If

        Catch ex As Exception
            strStatus = "generateModuleCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableModuleCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateModuleCodesComboBox()

    '=====================================================================================
    ' Function generateOnOffComboBox()
    ' Alan Wagner
    '
    Private Function generateOnOffComboBox(ByVal intUnitDimmer As Integer) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataTableOnOff As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            Select Case intUnitDimmer
                Case 1

                    sqlString = "SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='Dimmer' " &
                        "ORDER BY ComboBoxs.ValueMember DESC;"

                Case 0

                    sqlString = "SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='Switch' " &
                        "ORDER BY ComboBoxs.ValueMember ASC;"

            End Select

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableOnOff)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formModuleAddUpdateOnOffComboBox
                .DisplayMember = "DisplayMember"
                .ValueMember = "ValueMember"
                .DataSource = objDataTableOnOff
            End With

            formModuleAddUpdateOnOffComboBox.SelectedIndex = 0

        Catch ex As Exception
            strStatus = "generateOnOffComboBox(): Exception: " & ex.Message
        Finally
            objDataTableOnOff = Nothing
        End Try

        Return strStatus

    End Function ' END - generateOnOffComboBox()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formModuleAddUpdateControllersComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles formModuleAddUpdateControllersComboBox.SelectionChangeCommitted
        'formModuleAddUpdateControllersComboBox.SelectedIndexChanged

        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataRowView As System.Data.DataRowView = Nothing
        Dim strController As String = ""
        Dim intControllerID As Integer = -1

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        formModuleAddUpdateControllerActiveLabelText.Visible = False

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            objDataRowView = formModuleAddUpdateControllersComboBox.SelectedItem
            intControllerID = CType(objDataRowView(0).ToString, Integer)
            strController = objDataRowView(1).ToString ' ex: "Test CP290"

            If (intControllerID = -1) Then
                formModuleAddUpdateControllerActiveLabelText.Text() = ""
            Else

                ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                strStatus = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, intControllerID, objX10DbController)
                If (strStatus = "") Then

                    formModuleAddUpdateControllerActiveLabelText.Visible = True
                    Select Case objX10DbController.ControllerActive
                        Case 0
                            formModuleAddUpdateControllerActiveLabelText.Text() = "No"
                        Case 1
                            formModuleAddUpdateControllerActiveLabelText.Text() = "Yes"
                    End Select

                Else
                    strStatus = "formModuleAddUpdateControllersComboBox_SelectedIndexChanged(): " & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdateControllersComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If

            End If

        Catch ex As Exception
            strStatus = "formModuleAddUpdateControllersComboBox_SelectedIndexChanged(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdateControllersComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objX10DbController = Nothing
            objDataRowView = Nothing
        End Try

    End Sub ' END - formModuleAddUpdateControllersComboBox_SelectedIndexChanged()

    Private Sub formModuleAddUpdateDimmerCheckBox_Click(sender As System.Object, e As System.EventArgs) Handles formModuleAddUpdateDimmerCheckBox.Click
        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim intUnitDimmer As Integer = 0

        Try

            Select Case formModuleAddUpdateDimmerCheckBox.Checked
                Case True
                    intUnitDimmer = 1
                Case False
                    intUnitDimmer = 0
            End Select

            ' generateOnOffComboBox(ByVal intUnitDimmer As Integer) As String
            strError = generateOnOffComboBox(intUnitDimmer)
            If (strError = "") Then
                formModuleAddUpdateOnOffComboBox.Visible = True
            Else
                formModuleAddUpdateOnOffComboBox.Visible = False
                strStatus = "formModuleAddUpdateDimmerCheckBox_Click(): " & strError
                Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdateDimmerCheckBox_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            strStatus = "formModuleAddUpdateDimmerCheckBox_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdateDimmerCheckBox_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try

    End Sub ' END - formModuleAddUpdateDimmerCheckBox_Click()

    Private Sub formModuleAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objDataRowViewController As System.Data.DataRowView = Nothing
        Dim objDataRowViewModuleHouseCode As System.Data.DataRowView = Nothing
        Dim objDataRowViewModuleUnitCode As System.Data.DataRowView = Nothing

        Dim objX10DbUnit As TrekkerPhotoArt.X10Include.X10DbUnit = Nothing
        Dim objX10DbUnitTest As TrekkerPhotoArt.X10Include.X10DbUnit = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormModuleEdit As formModuleEdit = Nothing

        Dim intUnitDimmer As Integer = 0

        Dim intControllerActive As Integer = 0

        Try

            formModuleAddUpdate_StatusLabel.Text = ""
            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString

            strTryStep = "ProviderName"
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "NewObjectX10DbUnit"
            objX10DbUnit = New TrekkerPhotoArt.X10Include.X10DbUnit


            strTryStep = "MissingModuleName"
            If (formModuleAddUpdateNameTextBox.Text.Trim() = "") Then
                strStatus = "Missing Module Name."
            Else
                strTryStep = "UnitName"
                objX10DbUnit.UnitName = formModuleAddUpdateNameTextBox.Text().Trim()
            End If


            strTryStep = "DataRowViewController"
            objDataRowViewController = formModuleAddUpdateControllersComboBox.SelectedItem

            strTryStep = "IsControllerSelected?"
            If (objDataRowViewController.Row("ControllerID").ToString() = "0") Then
                ' No
                objX10DbUnit.ControllerID = -1
            Else
                ' Yes
                strTryStep = "ControllerID"
                objX10DbUnit.ControllerID = CType(objDataRowViewController.Row("ControllerID").ToString(), Integer)
            End If ' END - IsControllerSelected?


            strTryStep = "DataRowViewModuleHouseCode"
            objDataRowViewModuleHouseCode = formModuleAddUpdateHouseCodeComboBox.SelectedItem

            strTryStep = "IsModuleHouseCodeSelected?"
            If (objDataRowViewModuleHouseCode.Row("HouseCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing Module House Code."
                Else
                    strStatus &= vbCrLf & "Missing Module House Code."
                End If
            Else
                strTryStep = "UnitHouseCode"
                objX10DbUnit.UnitHouseCode = objDataRowViewModuleHouseCode(1).ToString ' DisplayMember ex: "A"
            End If ' END -IsModuleHouseCodeSelected?


            strTryStep = "DataRowViewModuleUnitCode"
            objDataRowViewModuleUnitCode = formModuleAddUpdateModuleCodeComboBox.SelectedItem

            strTryStep = "IsModuleUnitCodeSelected?"
            If (objDataRowViewModuleUnitCode.Row("ModuleCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing Module Unit Code."
                Else
                    strStatus &= vbCrLf & "Missing Module Unit Code."
                End If
            Else
                strTryStep = "UnitModuleCode"
                objX10DbUnit.UnitModuleCode = objDataRowViewModuleUnitCode(1).ToString ' DisplayMember ex: "1"
            End If ' END - IsModuleUnitCodeSelected?


            strTryStep = "WasSomethingMissing"
            If (strStatus = "") Then

                ' Verify the Module Name has not already been used.

                strTryStep = "nsX10DbMethods.getX10DbModule"
                ' nsX10DbMethods.getX10DbModule(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strUnitName As String, ByRef objX10DbUnit As TrekkerPhotoArt.X10Include.X10DbUnit) As String
                strError = nsX10DbMethods.getX10DbModule(strConnectionString, strProvider, objX10DbUnit.UnitName, objX10DbUnitTest)
                If (strError = "") Then

                    ' Was a Module found?
                    strTryStep = "WasModuleFound"
                    If (Not objX10DbUnitTest Is Nothing AndAlso objX10DbUnitTest.UnitID >= 0) Then
                        ' A Module was found with the specified Module Name.

                        ' Add or Modify Module?
                        strTryStep = "ModuleFound_AddModifyModule"
                        If (formModuleAddUpdate_AddUpdateButton.Text() = "Add") Then
                            strTryStep = "ModuleFound_AddModule"
                            strStatus = "Unable to Add the Module. The Module Name has already been used by another Module."
                            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else
                            ' Modify Module
                            strTryStep = "ModuleFound_ModifyModule"

                            strTryStep = "ModuleFound_ModifyModule_UnitID"
                            objX10DbUnit.UnitID = CType(formModuleAddUpdateIDLabelText.Text(), Integer)

                            If (objX10DbUnitTest.UnitID <> objX10DbUnit.UnitID) Then
                                strStatus = "Unable to Update Module information. The new Module Name has already been used by another Module."
                                Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formModuleAddUpdate_StatusLabel.Text = "Fail"
                                formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        End If ' END - Add or Modify Module?

                    Else
                        ' Nothing found.
                        strTryStep = "NothingFound_AddModifyModule"

                        If (formModuleAddUpdate_AddUpdateButton.Text() = "Add") Then
                            ' Add Module
                            objX10DbUnit.UnitID = -1
                        Else
                            ' Modify Module
                            objX10DbUnit.UnitID = CType(formModuleAddUpdateIDLabelText.Text(), Integer)
                        End If ' END - Add or Modify Module

                    End If ' END - Was a Module found?

                Else
                    strStatus = "Problem determining if Module Name has already been used." & vbCrLf & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formModuleAddUpdate_StatusLabel.Text = "Fail"
                    formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                End If ' END - nsX10DbMethods.getX10DbModule()
                If (strStatus = "") Then

                    strTryStep = "formModuleAddUpdateEnabledCheckBox"
                    Select Case formModuleAddUpdateEnabledCheckBox.Checked
                        Case False
                            objX10DbUnit.UnitEnabled = 0
                        Case True
                            objX10DbUnit.UnitEnabled = 1
                    End Select

                    strTryStep = "UnitDescription"
                    objX10DbUnit.UnitDescription = formModuleAddUpdateDescriptionTextBox.Text().Trim()

                    strTryStep = "nsX10DbMethods.UnitHouseCodeToUnitHouseNumber"
                    objX10DbUnit.UnitHouseNumber = nsX10DbMethods.UnitHouseCodeToUnitHouseNumber(objX10DbUnit.UnitHouseCode)

                    strTryStep = "nsX10DbMethods.UnitModuleCodeToUnitModuleNumber"
                    objX10DbUnit.UnitModuleNumber = nsX10DbMethods.UnitModuleCodeToUnitModuleNumber(objX10DbUnit.UnitModuleCode)

                    strTryStep = "UnitCode"
                    objX10DbUnit.UnitCode = objX10DbUnit.UnitHouseCode & objX10DbUnit.UnitModuleCode

                    strTryStep = "UnitDimmer"
                    If (formModuleAddUpdateDimmerCheckBox.Checked) Then
                        objX10DbUnit.UnitDimmer = 1
                    Else
                        objX10DbUnit.UnitDimmer = 0
                    End If

                    strTryStep = "UnitLighting"
                    If (formModuleAddUpdateControlLightsCheckBox.Checked) Then
                        objX10DbUnit.UnitLighting = 1
                    Else
                        objX10DbUnit.UnitLighting = 0
                    End If

                    strTryStep = "UnitExtendedCommands"
                    If (formModuleAddUpdateExtendedCommandsCheckBox.Checked) Then
                        objX10DbUnit.UnitExtendedCommands = 1
                    Else
                        objX10DbUnit.UnitExtendedCommands = 0
                    End If

                    objX10DbUnit.UnitLastCommand = ""
                    objX10DbUnit.UnitLastBrightDimAmount = 0
                    objX10DbUnit.UnitLastExtendedData = 0
                    objX10DbUnit.UnitLastExtendedCommand = 0

                    strTryStep = "nsX10DbMethods.addUpdateModuleToX10db"
                    ' nsX10DbMethods.addUpdateModuleToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbUnit As TrekkerPhotoArt.X10Include.X10DbUnit, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.addUpdateModuleToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbUnit, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then
                            formModuleAddUpdateIDLabelText.Text() = objX10DbUnit.UnitID.ToString()

                            If (formModuleAddUpdate_AddUpdateButton.Text() = "Add") Then
                                formModuleAddUpdate_AddUpdateButton.Text() = "Update"
                                formModuleAddUpdate_StatusLabel.Text = "Successfully Added"
                                formModuleAddUpdate_DeleteButton.Visible = True
                            Else
                                formModuleAddUpdate_StatusLabel.Text = "Successfully Updated"
                            End If

                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formModuleAddUpdate_CancelButton.Text() = "Done"

                            objFormModuleEdit = New formModuleEdit
                            objFormModuleEdit.formModuleEdit_BringToFrontLabel.Text() = "N"

                            formModuleAddUpdateOperationsGroupBox.Visible = True
                            formModuleAddUpdate_TestButton.Visible = True
                            formModuleAddUpdateOnOffLabel.Visible = True

                            strTryStep = "generateOnOffComboBox"
                            ' generateOnOffComboBox(ByVal intUnitDimmer As Integer) As String
                            strStatus = generateOnOffComboBox(objX10DbUnit.UnitDimmer)
                            If (strStatus = "") Then
                                formModuleAddUpdateOnOffComboBox.Visible = True
                            Else
                                formModuleAddUpdateOnOffComboBox.Visible = False
                                Windows.Forms.MessageBox.Show("formModuleAddUpdate_AddUpdateButton_Click(): " & strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If

                            ' Refresh DataSet on Form formModuleEdit if it's active.
                            strTryStep = "RefreshDataSetOnFormModuleEdit"
                            If objFormCollection.OfType(Of formModuleEdit).Any Then

                                objFormModuleEdit = objFormCollection.Item("formModuleEdit")

                                ' formModuleEdit_GetModulesDataSet() As String
                                strStatus = objFormModuleEdit.formModuleEdit_GetModulesDataSet()
                                If (strStatus = "") Then
                                    objFormModuleEdit.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formModuleAddUpdate_AddUpdateButton_Click(): " & strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formModuleEdit_GetModulesDataSet()

                            End If

                            ' Refresh "Modules In Scene" DataSet on any open "Update Scenes" forms.
                            strTryStep = "RefreshDataSetOnFormSceneAddUpdate"
                            If objFormCollection.OfType(Of formSceneAddUpdate).Any Then
                                For Each objFormSceneAddUpdate As formSceneAddUpdate In objFormCollection.OfType(Of formSceneAddUpdate)

                                    strTryStep = "X10ManagerDesktop.RefreshOpenSceneAddUpdateForm"
                                    ' X10ManagerDesktop.RefreshOpenSceneAddUpdateForm(ByRef objFormSceneAddUpdate As formSceneAddUpdate) As String
                                    strStatus = X10ManagerDesktop.RefreshOpenSceneAddUpdateForm(objFormSceneAddUpdate)
                                    If (strStatus <> "") Then
                                        Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                                        Exit For
                                    End If

                                Next
                            End If

                        Else
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formModuleAddUpdate_CancelButton.Text() = "Cancel"
                            If (formModuleAddUpdate_AddUpdateButton.Text() = "Add") Then
                                Windows.Forms.MessageBox.Show("Problem adding Module to X10 Db.", "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Else
                                Windows.Forms.MessageBox.Show("Problem modifying Module to X10 Db.", "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If
                        End If ' END - RowsAffected

                    Else
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                        If (formModuleAddUpdate_AddUpdateButton.Text() = "Add") Then
                            Windows.Forms.MessageBox.Show("Problem adding Module to X10 Db." & vbCrLf & strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Else
                            Windows.Forms.MessageBox.Show("Problem modifying Module to X10 Db." & vbCrLf & strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If
                    End If ' END - nsX10DbMethods.addUpdateModuleToX10db()

                End If ' END - nsX10DbMethods.getX10DbModule(Status)

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formModuleAddUpdate_StatusLabel.Text = "Fail"
                formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            End If ' END - WasSomethingMissing

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "formModuleAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formModuleAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            End If

            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleAddUpdate_StatusLabel.Text = "Fail"
            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDataRowViewController = Nothing
            objDataRowViewModuleHouseCode = Nothing
            objDataRowViewModuleUnitCode = Nothing
            objFormCollection = Nothing
            objFormModuleEdit = Nothing
            objX10DbUnitTest = Nothing
            objX10DbUnit = Nothing
        End Try

    End Sub ' END - formModuleAddUpdate_AddUpdateButton_Click()

    Private Sub formModuleAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formModuleAddUpdate_CancelButton_Click()

    Private Sub formModuleAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objX10DbUnit As TrekkerPhotoArt.X10Include.X10DbUnit = Nothing
        Dim intUnitID As Integer = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormModuleEdit As formModuleEdit = Nothing

        Try

            If (formModuleAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing ModuleID", "formModuleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                If Windows.Forms.MessageBox.Show("Confirm removal of Module" & vbCrLf & """" & formModuleAddUpdateNameTextBox.Text() & """ [" & formModuleAddUpdateIDLabelText.Text() & "]?", "Confirm", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Stop) = Windows.Forms.DialogResult.Yes Then

                    intUnitID = CType(formModuleAddUpdateIDLabelText.Text(), Integer)

                    objX10DbUnit = New TrekkerPhotoArt.X10Include.X10DbUnit
                    objX10DbUnit.UnitID = intUnitID
                    objX10DbUnit.UnitName = formModuleAddUpdateNameTextBox.Text()
                    objX10DbUnit.UnitDescription = ""


                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    ' nsX10DbMethods.removeX10ModulefromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbUnit As TrekkerPhotoArt.X10Include.X10DbUnit, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.removeX10ModuleFromX10Db(strConnectionString, strProvider, objX10DbUnit, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then

                            formModuleAddUpdateIDLabelText.Text() = ""
                            formModuleAddUpdate_AddUpdateButton.Text() = "Add"
                            formModuleAddUpdate_StatusLabel.Text = "Successfully Deleted"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formModuleAddUpdate_CancelButton.Text() = "Done"
                            formModuleAddUpdate_DeleteButton.Visible = False

                            objFormModuleEdit = New formModuleEdit
                            objFormModuleEdit.formModuleEdit_BringToFrontLabel.Text() = "N"

                            ' Refresh DataSet on Form formModuleEdit if it's active.
                            If objFormCollection.OfType(Of formModuleEdit).Any Then

                                objFormModuleEdit = objFormCollection.Item("formModuleEdit")

                                ' The row has been deleted.
                                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormModuleEdit = -1
                                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormModuleEdit = -1

                                ' formModuleEdit_GetModulesDataSet() As String
                                strStatus = objFormModuleEdit.formModuleEdit_GetModulesDataSet()
                                If (strStatus = "") Then
                                    objFormModuleEdit.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formModuleAddUpdate_DeleteButton_Click(): " & strStatus, "formModuleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formModuleEdit_GetModulesDataSet()

                            End If

                        Else
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formModuleAddUpdate_CancelButton.Text() = "Cancel"
                            Windows.Forms.MessageBox.Show("Problem removing Module from X10 Db.", "formModuleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If ' END - RowsAffected

                    Else
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Module from X10 Db." & vbCrLf & strStatus, "formModuleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - nsX10DbMethods.addUpdateModuleToX10db()

                End If ' END - Confirm removal of Module?

            End If ' END - Is there a ModuleID?

        Catch ex As Exception
            strStatus = "formModuleAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleAddUpdate_StatusLabel.Text = "Fail"
            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormModuleEdit = Nothing
            objX10DbUnit = Nothing
        End Try

    End Sub ' END - formModuleAddUpdate_DeleteButton_Click()

    Private Sub formModuleAddUpdate_TestButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleAddUpdate_TestButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataRowViewController As System.Data.DataRowView = Nothing
        Dim intControllerID As Integer = -1
        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing

        Dim objDataRowViewModuleHouseCode As System.Data.DataRowView = Nothing
        Dim strUnitHouseCode As String = ""

        Dim objDataRowViewModuleUnitCode As System.Data.DataRowView = Nothing
        Dim strUnitModuleCode As String = ""

        Dim strDimmer As String = ""

        Dim objDataRowViewOnOff As System.Data.DataRowView = Nothing
        Dim strOnOff As String = ""

        Dim intUnitOnOff As Integer = -1
        Dim intUnitLevel As Integer = -1
        Dim strUnitCommandType As String = ""

        Dim strPortName As String = ""
        Dim intX10Status As Integer = -1
        Dim objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload) = Nothing
        Dim objX10CP290CommandUpload As TrekkerPhotoArt.X10Include.X10CP290CommandUpload = Nothing

        Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
        Dim objSendUnitCommandClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendUnitCommandClass = Nothing
        Dim objSendFunctionCommandPowerLineClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendFunctionCommandPowerLineClass = Nothing
        Dim objX10ExtendedCommand As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.x10ExtendedCommand = Nothing

        Dim strStandardExtended As String = "S"
        Dim bytExtendedData As Byte = 0
        Dim bytExtendedCommand As Byte = 0

        Dim intPointer As Integer = 0
        Dim bFirst As Boolean = True

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Dim strMessage As String = ""

        Try

            If (formModuleAddUpdateControllerActiveLabelText.Text().ToUpper = "YES") Then

                strTryStep = "formConsoleMessages"
                If objFormCollection.OfType(Of formConsoleMessages).Any Then
                    objFormConsoleMessages = New formConsoleMessages
                    objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")
                    objFormConsoleMessages.Close()
                    objFormConsoleMessages = Nothing
                End If

                strTryStep = "ConnectionString"
                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString

                strTryStep = "ProviderName"
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName


                strTryStep = "DataRowViewController"
                objDataRowViewController = formModuleAddUpdateControllersComboBox.SelectedItem

                strTryStep = "IsControllerSelected"
                If (objDataRowViewController.Row("ControllerID").ToString() = "0") Then
                    ' No
                    strStatus = "Missing Controller."
                Else
                    ' Yes

                    strTryStep = "ControllerID"
                    intControllerID = CType(objDataRowViewController.Row("ControllerID").ToString(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbController"
                    ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                    strError = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, intControllerID, objX10DbController)
                    If (strError = "") Then

                        If (objX10DbController Is Nothing) Then
                            strStatus = "executeOperationX10CM15A(): getX10DbController(): Controller ID""" & intControllerID.ToString() & """ not found in X10Db."
                            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else

                            strTryStep = "SelectCaseControllerTypeGetPort"
                            Select Case objX10DbController.ControllerType.ToUpper()
                                Case "CM15A"

                                    strTryStep = "nsX10DbMethods.getX10DbUSBPort"
                                    ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                                    strError = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                                    If (strError = "") Then

                                        strTryStep = "nsX10CM15AMethods.getX10ControllerStatus"
                                        ' getX10ControllerStatusClass getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                        objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                        If (objGetX10ControllerStatusClass.status <> "") Then
                                            strStatus = "Problem sending MacroInitiator Trigger to Controller." & vbCrLf & objGetX10ControllerStatusClass.status
                                            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            formModuleAddUpdate_StatusLabel.Text = "Fail"
                                            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                        End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                                    Else
                                        strStatus = "Problem geting Controller's USB Port Information." & vbCrLf & strError
                                        Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    End If ' END - nsX10DbMethods.getX10DbUSBPort()

                            End Select ' END - SelectCaseControllerTypeGetPort

                        End If

                    Else
                        strStatus = "Problem geting Controller Information." & vbCrLf & strError
                        Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    End If ' END - nsX10DbMethods.getX10DbController()

                End If


                strTryStep = "DataRowViewModuleHouseCode"
                objDataRowViewModuleHouseCode = formModuleAddUpdateHouseCodeComboBox.SelectedItem

                strTryStep = "IsModuleHouseCodeSelected?"
                If (objDataRowViewModuleHouseCode.Row("HouseCodeID").ToString() = "0") Then
                    If (strStatus = "") Then
                        strStatus = "Missing Module House Code."
                    Else
                        strStatus &= vbCrLf & "Missing Module House Code."
                    End If
                Else
                    strTryStep = "UnitHouseCode"
                    strUnitHouseCode = objDataRowViewModuleHouseCode(1).ToString ' DisplayMember ex: "A"
                End If


                strTryStep = "DataRowViewModuleUnitCode"
                objDataRowViewModuleUnitCode = formModuleAddUpdateModuleCodeComboBox.SelectedItem

                strTryStep = "IsModuleUnitCodeSelected?"
                If (objDataRowViewModuleUnitCode.Row("ModuleCodeID").ToString() = "0") Then
                    If (strStatus = "") Then
                        strStatus = "Missing Module Unit Code."
                    Else
                        strStatus &= vbCrLf & "Missing Module Unit Code."
                    End If
                Else
                    strTryStep = "UnitModuleCode"
                    strUnitModuleCode = objDataRowViewModuleUnitCode(1).ToString ' DisplayMember ex: "1"
                End If


                strTryStep = "WasSomethingMissing"
                If (strStatus = "") Then

                    strTryStep = "Dimmer"
                    If (formModuleAddUpdateDimmerCheckBox.Checked) Then
                        strDimmer = "Y"
                    Else
                        strDimmer = "N"
                    End If

                    strTryStep = "DataRowViewOnOff"
                    objDataRowViewOnOff = formModuleAddUpdateOnOffComboBox.SelectedItem

                    strTryStep = "DisplayMember"
                    ' Switch
                    ' "Off", "On"
                    ' Dimmer
                    ' "100%", "94%", "88%", "81%", "75%", "69%", "63%", "56%", "50%", "44%", "38%", "31%", "25%", "19%", "13%", "6%", "Off"
                    strOnOff = objDataRowViewOnOff.Row("DisplayMember").ToString()

                    strTryStep = "nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues"
                    ' nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(ByVal strDimmer As String, ByVal strOnOff As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer) As String
                    strStatus = nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(strDimmer, strOnOff, intUnitOnOff, intUnitLevel)
                    If (strStatus = "") Then

                        strTryStep = "SelectCaseControllerType"
                        Select Case objX10DbController.ControllerType.ToUpper()
                            Case "CP290"

                                strMessage = "  Name: " & formModuleAddUpdateNameTextBox.Text() & " [" & strUnitHouseCode & strUnitModuleCode & "]"
                                strMessage &= vbCrLf & "  Send Module Direct Command."
                                strMessage &= vbCrLf & "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"

                                Select Case strDimmer.ToUpper()
                                    Case "Y"
                                        strMessage &= vbCrLf & "  Set Dimmer to " & strOnOff
                                    Case "N"
                                        strMessage &= vbCrLf & "  Set Switch to " & strOnOff
                                End Select

                                strMessage &= vbCrLf & vbCrLf & "Sending to Module...Please wait......."
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Test Module on Controller " & objX10DbController.ControllerType.ToUpper())

                                strTryStep = "nsX10CP290Methods.sendUnitCommand"
                                ' nsX10CP290Methods.sendUnitCommand(ByVal strPortName As String, ByVal strUnitHouseCode As String, ByVal strUnitModuleCodes As String, ByVal strDimmer As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer, ByRef intX10Status As Integer, ByRef objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload)) As String
                                strError = nsX10CP290Methods.sendUnitCommand(objX10DbController.Port, strUnitHouseCode, strUnitModuleCode, strDimmer, intUnitOnOff, intUnitLevel, intX10Status, objX10CP290CommandUploads)
                                If (strError = "") Then

                                    strMessage &= vbCrLf & "  Send Module Direct Command - Complete."

                                    strTryStep = "getX10CP290CommandUploads"
                                    If (Not objX10CP290CommandUploads Is Nothing AndAlso objX10CP290CommandUploads.Count > 0) Then

                                        For Each objX10CP290CommandUpload In objX10CP290CommandUploads

                                            strMessage &= vbCrLf & "  CommandUpload[" & objX10CP290CommandUpload.CommandUploadID.ToString() & "]:"
                                            strMessage &= vbCrLf & "    Function=" & objX10CP290CommandUpload.strFunction
                                            strMessage &= vbCrLf & "    Housecode=" & objX10CP290CommandUpload.strHousecode
                                            strMessage &= vbCrLf & "    X10UnitCodes18=" & objX10CP290CommandUpload.strX10UnitCodes18
                                            strMessage &= vbCrLf & "    X10UnitCodes916=" & objX10CP290CommandUpload.strX10UnitCodes916
                                            strMessage &= vbCrLf & "    BaseHousecode=" & objX10CP290CommandUpload.strBaseHousecode
                                            strMessage &= vbCrLf & "    X10Status=" & objX10CP290CommandUpload.strX10Status

                                        Next

                                    End If

                                    strMessage &= vbCrLf & "  Controller Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status)
                                    strMessage &= vbCrLf & vbCrLf & "Success!"

                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Test Module on Controller " & objX10DbController.ControllerType.ToUpper())

                                    formModuleAddUpdate_StatusLabel.Text = "Success"
                                    formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                    formModuleAddUpdate_CancelButton.Text() = "Done"

                                Else
                                    strStatus = "Problem sending Command to Module." & vbCrLf & strError
                                    Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formModuleAddUpdate_StatusLabel.Text = "Fail"
                                    formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formModuleAddUpdate_CancelButton.Text() = "Cancel"

                                    strMessage &= vbCrLf & vbCrLf & strStatus
                                    strMessage &= vbCrLf & vbCrLf & "Fail!"
                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Test Module on Controller " & objX10DbController.ControllerType.ToUpper())

                                End If ' END - nsX10CP290Methods.sendUnitCommand()

                            Case "CM15A"

                                strMessage = "  Name: " & formModuleAddUpdateNameTextBox.Text() & " [" & strUnitHouseCode & strUnitModuleCode & "]"
                                strMessage &= vbCrLf & "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"

                                Select Case strStandardExtended
                                    Case "S"
                                        strMessage &= vbCrLf & "  Send Module Direct Standard Command."
                                        Select Case strDimmer.ToUpper()
                                            Case "Y"
                                                strMessage &= vbCrLf & "  Set Dimmer Module to " & strOnOff
                                            Case "N"
                                                strMessage &= vbCrLf & "  Set Switch Module to " & strOnOff
                                        End Select
                                    Case "E"
                                        ' x10ExtendedCommand getX10ExtendedCommandFromCode(byte byteCommandCode)
                                        objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(bytExtendedCommand)

                                        strMessage &= vbCrLf & "  Send Module Direct Extended Command."
                                        strMessage &= vbCrLf & "    ExtendedCommand=0x" + bytExtendedCommand.ToString("X02").ToLower()
                                        strMessage &= vbCrLf & "    Extended Command Description: " & objX10ExtendedCommand.commandDescription
                                        strMessage &= vbCrLf & "    ExtendedData=0x" + bytExtendedData.ToString("X02").ToLower()
                                End Select

                                strMessage &= vbCrLf & vbCrLf & "Sending to Module...Please wait......."
                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                Call formConsoleMessages.DisplayMessage(strMessage, "Test Module on Controller " & objX10DbController.ControllerType.ToUpper())

                                strTryStep = "nsX10CM15AMethods.sendUnitCommand"
                                ' sendUnitCommandClass sendUnitCommand(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strX10DbConnectionString, string strX10DbProvider, string strStandardExtended, string strUnitHouseCodeLetter, string strUnitModuleCode, string strUnitDimmerYN, string strBrightenDim, int intUnitOnOff, int intUnitLevel, byte bytExtendedData, byte bytExtendedCommand)
                                objSendUnitCommandClass = nsX10CM15AMethods.sendUnitCommand(objX10DbController, objX10DbUSBPort, strConnectionString, strProvider, strStandardExtended, strUnitHouseCode, strUnitModuleCode, strDimmer, "", intUnitOnOff, intUnitLevel, bytExtendedData, bytExtendedCommand)
                                If (objSendUnitCommandClass.status = "") Then

                                    strMessage &= vbCrLf & "  Send to Module " & objSendUnitCommandClass.unitHouseCodeLetter & objSendUnitCommandClass.unitModuleCode & " - Complete."

                                    Select Case objSendUnitCommandClass.standardExtended.ToUpper()
                                        Case "S"
                                            strMessage &= vbCrLf & "  Direct Standard Command was sent."
                                            Select Case strDimmer.ToUpper()
                                                Case "Y"
                                                    strMessage &= vbCrLf & "  Set Dimmer to " & strOnOff
                                                Case "N"
                                                    strMessage &= vbCrLf & "  Set Switch to " & strOnOff
                                            End Select
                                        Case "E"
                                            ' x10ExtendedCommand getX10ExtendedCommandFromCode(byte byteCommandCode)
                                            objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(objSendUnitCommandClass.extendedCommand)

                                            strMessage &= vbCrLf & "  Direct Extended Command was sent."
                                            strMessage &= vbCrLf & "    ExtendedCommand=0x" & objSendUnitCommandClass.extendedCommand.ToString("X02").ToLower()
                                            strMessage &= vbCrLf & "    Extended Command Description: " & objX10ExtendedCommand.commandDescription
                                            strMessage &= vbCrLf & "    ExtendedData=0x" & objSendUnitCommandClass.extendedData.ToString("X02").ToLower()
                                    End Select

                                    strTryStep = "CheckForNOOP"
                                    If (Not objSendUnitCommandClass.objSendAddressCommandPowerLineClass Is Nothing AndAlso objSendUnitCommandClass.objSendFunctionCommandPowerLineClasses.Count > 0) Then

                                        If (objSendUnitCommandClass.objSendAddressCommandPowerLineClass.retryReason <> "") Then
                                            strMessage &= vbCrLf & "sendAddressCommandPowerLineClass.retryReason[" & nsX10CM15AMethods.x10BinaryValueToHouseCode(objSendUnitCommandClass.objSendAddressCommandPowerLineClass.unitHouseCode) & nsX10CM15AMethods.x10BinaryValueToDeviceCode(objSendUnitCommandClass.objSendAddressCommandPowerLineClass.unitModuleCode) & "]: " & objSendUnitCommandClass.objSendAddressCommandPowerLineClass.retryReason
                                        End If

                                        strTryStep = "ForEachObjectSendFunctionCommandPowerLineClass"
                                        For Each objSendFunctionCommandPowerLineClass In objSendUnitCommandClass.objSendFunctionCommandPowerLineClasses

                                            strMessage &= vbCrLf & vbCrLf & "  Function/Command Codes:"
                                            strMessage &= vbCrLf & "   Function Code: 0x" & objSendFunctionCommandPowerLineClass.unitFunctionCode.ToString("X02").ToLower()
                                            strMessage &= vbCrLf & "   Function Name: " & nsX10CM15AMethods.x10FunctionCodeToString(objSendFunctionCommandPowerLineClass.unitFunctionCode)
                                            Select Case objSendUnitCommandClass.standardExtended.ToUpper()
                                                Case "S"
                                                    If (strDimmer.ToUpper() = "Y") Then
                                                        strMessage &= vbCrLf & "   Previous saved Command: " & objSendFunctionCommandPowerLineClass.previousUnitLastCommand
                                                        strMessage &= vbCrLf & "   Previous saved Bright/Dim Ammount: " & objSendFunctionCommandPowerLineClass.previousUnitLastBrightDimAmount.ToString() & " = 0x" & objSendFunctionCommandPowerLineClass.previousUnitLastBrightDimAmount.ToString("X02").ToLower()
                                                        strMessage &= vbCrLf & "   Specified Dim Amount: " & objSendUnitCommandClass.dimAmount.ToString() & " = 0x" & objSendUnitCommandClass.dimAmount.ToString("X02").ToLower()
                                                        strMessage &= vbCrLf & "   Bright/Dim Amount sent to Unit: " & objSendFunctionCommandPowerLineClass.unitBrightDimAmount.ToString() & " = 0x" & objSendFunctionCommandPowerLineClass.unitBrightDimAmount.ToString("X02").ToLower()
                                                        strMessage &= vbCrLf & "   New saved Command: " & objSendFunctionCommandPowerLineClass.newUnitLastCommand
                                                        strMessage &= vbCrLf & "   New saved Bright/Dim Ammount: " & objSendFunctionCommandPowerLineClass.newUnitLastBrightDimAmount.ToString() & " = 0x" & objSendFunctionCommandPowerLineClass.newUnitLastBrightDimAmount.ToString("X02").ToLower()
                                                    End If
                                                Case "E"
                                                    ' x10ExtendedCommand getX10ExtendedCommandFromCode(byte byteCommandCode)
                                                    objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(objSendFunctionCommandPowerLineClass.unitExtendedCommand)

                                                    strMessage &= vbCrLf & "   Extended Command: 0x" & objSendFunctionCommandPowerLineClass.unitExtendedCommand.ToString("X02").ToLower()
                                                    strMessage &= vbCrLf & "   Extended Command Description: " & objX10ExtendedCommand.commandDescription
                                                    strMessage &= vbCrLf & "   Extended Data: 0x" & objSendFunctionCommandPowerLineClass.unitExtendedData.ToString("X02").ToLower()
                                            End Select

                                            If (objSendFunctionCommandPowerLineClass.retryReason <> "") Then
                                                strMessage &= vbCrLf & "sendFunctionCommandPowerLine.retryReason: " & objSendFunctionCommandPowerLineClass.retryReason
                                            End If

                                        Next ' END - ForEachObjectSendFunctionCommandPowerLineClasses.Count

                                    Else
                                        strMessage &= vbCrLf & vbCrLf & "No Operation Sending Powerline Command."
                                    End If ' END - CheckForNOOP

                                    strMessage &= vbCrLf & vbCrLf & "Success!"

                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Test Module on Controller " & objX10DbController.ControllerType.ToUpper())

                                    formModuleAddUpdate_StatusLabel.Text = "Success"
                                    formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                    formModuleAddUpdate_CancelButton.Text() = "Done"

                                Else
                                    strStatus = "Problem sending Command to Module." & vbCrLf & objSendUnitCommandClass.status
                                    Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formModuleAddUpdate_StatusLabel.Text = "Fail"
                                    formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formModuleAddUpdate_CancelButton.Text() = "Cancel"

                                    strMessage &= vbCrLf & vbCrLf & strStatus
                                    strMessage &= vbCrLf & vbCrLf & "Fail!"
                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Test Module on Controller " & objX10DbController.ControllerType.ToUpper())

                                End If ' END - nsX10CM15AMethods.sendUnitCommand()

                            Case "WM100"
                                strTryStep = ""


                            Case Else
                                Windows.Forms.MessageBox.Show("Missing or Unknown Controller Model """ & objX10DbController.ControllerType & """.", "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formModuleAddUpdate_StatusLabel.Text = "Fail"
                                formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formModuleAddUpdate_CancelButton.Text() = "Cancel"
                        End Select ' END - SelectCaseControllerType

                    Else
                        Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formModuleAddUpdate_StatusLabel.Text = "Fail"
                        formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formModuleAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues()

                Else
                    Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formModuleAddUpdate_StatusLabel.Text = "Fail"
                    formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formModuleAddUpdate_CancelButton.Text() = "Cancel"
                End If ' END - WasSomethingMissing

            Else
                Windows.Forms.MessageBox.Show("formModuleAddUpdate_TestButton_Click(): Controller is NOT Active: Unable to Test Module.", "formModuleAddUpdate_TestButton_Click():", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formModuleAddUpdate_StatusLabel.Text = "Fail"
                formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formModuleAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formModuleAddUpdateControllerActiveLabelText

        Catch ex As Exception
            strStatus = "formModuleAddUpdate_TestButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formModuleAddUpdate_TestButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleAddUpdate_StatusLabel.Text = "Fail"
            formModuleAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10ExtendedCommand = Nothing
            objSendFunctionCommandPowerLineClass = Nothing
            objSendUnitCommandClass = Nothing
            objGetX10ControllerStatusClass = Nothing
            objX10DbUSBPort = Nothing
            objDataRowViewController = Nothing
            objX10DbController = Nothing
            objDataRowViewModuleHouseCode = Nothing
            objDataRowViewModuleUnitCode = Nothing
            objDataRowViewOnOff = Nothing
            objX10CP290CommandUploads = Nothing
            objX10CP290CommandUpload = Nothing
            objFormCollection = Nothing
            objFormConsoleMessages = Nothing
        End Try

    End Sub ' END - formModuleAddUpdate_TestButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formModuleAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formModuleAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(530, 430)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationModuleAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationModuleAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationModuleAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formModuleAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formModuleAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formModuleAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formModuleAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formModuleAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationModuleAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationModuleAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formModuleAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formModuleAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formModuleAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class