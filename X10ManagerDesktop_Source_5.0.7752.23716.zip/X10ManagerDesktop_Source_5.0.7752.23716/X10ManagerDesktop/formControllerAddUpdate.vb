﻿Imports System.Configuration

' Name: formControllerAddUpdate.vb
' By: Alan Wagner
' Date: March 2020

Public Class formControllerAddUpdate

#Region "X10ManagerDesktopControllerAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objDataTableControllerTypes As New System.Data.DataTable

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim intControllerID As Integer = -1

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim strMessage As String = ""

        Try

            Me.BringToFront()

            strTryStep = "formControllerAddUpdate_FormRestore"
            ' formControllerAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formControllerAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "UsingConnectionDataTableControllerTypes"
                ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
                Using objConnection As New System.Data.OleDb.OleDbConnection(System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString)

                    strTryStep = "UsingConnectionDataTableControllerTypesOpen"
                    objConnection.Open()

                    strTryStep = "UsingConnectionDataTableControllerTypesOleDbDataAdapter"
                    Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT ControllerTypeID, ControllerType FROM ControllerTypes UNION SELECT 0 AS ControllerTypeID, 'Select Model...' AS ControllerType FROM ControllerTypes ORDER BY ControllerTypeID ASC", objConnection)

                    strTryStep = "UsingConnectionDataTableControllerTypesFill"
                    objOleDbDataAdapter.Fill(objDataTableControllerTypes)

                    strTryStep = "UsingConnectionDataTableControllerTypesClose"
                    objConnection.Close()
                    objOleDbDataAdapter = Nothing

                End Using

                strTryStep = "WithFormControllerAddUpdateModelComboBox"
                With formControllerAddUpdateModelComboBox
                    .DisplayMember = "ControllerType"
                    .ValueMember = "ControllerTypeID"
                    .DataSource = objDataTableControllerTypes
                End With
                formControllerAddUpdateModelComboBox.SelectedIndex = 0

                strTryStep = "formControllerAddUpdateIDLabelText"
                If (formControllerAddUpdateIDLabelText.Text() = "" Or formControllerAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddController"

                    formControllerAddUpdateIDLabelText.Text() = ""

                    ' Set the caption bar text of the form.
                    Me.Text = "Add Controller"

                    formControllerAddUpdate_AddUpdateButton.Text() = "Add"
                    formControllerAddUpdate_AddUpdateButton.Select()
                    formControllerAddUpdate_StatusLabel.Visible = True
                    formControllerAddUpdate_StatusLabel.Text = ""

                    formControllerAddUpdate_CancelButton.Text() = "Cancel"

                    formControllerAddUpdate_DeleteButton.Visible = False
                    formControllerAddUpdate_DeleteButton.Text() = "Delete"

                    formControllerAddUpdateNameLabel.Visible = True
                    formControllerAddUpdateNameTextBox.Visible = True
                    formControllerAddUpdateNameTextBox.Text() = ""

                    formControllerAddUpdateActiveCheckBox.Checked = True
                    formControllerAddUpdateActiveCheckBox.Enabled = True
                    formControllerAddUpdateActiveCheckBox.Visible = True

                    formControllerAddUpdateDescriptionLabel.Visible = True
                    formControllerAddUpdateDescriptionTextBox.Visible = True
                    formControllerAddUpdateDescriptionTextBox.Text() = ""

                    formControllerAddUpdateMacroSupportLabel.Visible = True
                    formControllerAddUpdateMacroSupportLabelText.Visible = True
                    formControllerAddUpdateMacroSupportLabelText.Text() = ""

                    formControllerAddUpdateExtendedCommandsLabel.Visible = True
                    formControllerAddUpdateExtendedCommandsLabelText.Visible = True
                    formControllerAddUpdateExtendedCommandsLabelText.Text() = ""

                    formControllerAddUpdateHouseCodeLabel.Visible = False
                    formControllerAddUpdateHouseCodeComboBox.Visible = False
                    formControllerAddUpdateHouseCodeInfoLabel.Visible = False
                    formControllerAddUpdateHouseCodeInfoLabel.Text() = ""

                    formControllerAddUpdateModelLabel.Visible = True
                    formControllerAddUpdateModelComboBox.Visible = True

                    formControllerAddUpdatePortLabel.Visible = False
                    formControllerAddUpdatePortComboBox.Visible = False
                    formControllerAddUpdatePortValueLabel.Visible = False
                    formControllerAddUpdatePortValueLabel.Text() = ""
                    formControllerAddUpdatePortInfoLabel.Visible = False

                    formControllerAddUpdateAppKeyLabel.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Text() = ""

                    formControllerAddUpdateUIDLabel.Visible = False
                    formControllerAddUpdateUIDTextBox.Visible = False
                    formControllerAddUpdateUIDTextBox.Text() = ""

                    formControllerAddUpdateTransceiverHouseCodesLabel.Visible = False
                    formControllerAddUpdateTransceiverHouseCodesPanel.Visible = False

                    formControllerAddUpdateDuskDawnResolutionLabel.Visible = False
                    formControllerAddUpdateDuskDawnResolutionComboBox.Visible = False

                    formControllerAddUpdateOperationsGroupBox.Visible = False
                    formControllerAddUpdate_GetStatusButton.Visible = False
                    formControllerAddUpdate_SetClockButton.Visible = False
                    formControllerAddUpdateSetClockText1Label.Visible = False
                    formControllerAddUpdateSetClockText2Label.Visible = False
                    formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                    formControllerAddUpdate_DownloadButton.Visible = False
                    formControllerAddUpdate_ClearButton.Visible = False
                    formControllerAddUpdate_ExportButton.Visible = False

                Else
                    strTryStep = "UpdateController"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Controller"

                    formControllerAddUpdate_AddUpdateButton.Text() = "Update"
                    formControllerAddUpdate_AddUpdateButton.Select()
                    formControllerAddUpdate_StatusLabel.Visible = True
                    formControllerAddUpdate_StatusLabel.Text = ""

                    formControllerAddUpdate_CancelButton.Text() = "Done"

                    formControllerAddUpdate_DeleteButton.Visible = True
                    formControllerAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "ControllerID"
                    intControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbController"
                    ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                    strStatus = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, intControllerID, objX10DbController)
                    If (strStatus = "") Then

                        formControllerAddUpdateIDLabelText.Text() = objX10DbController.ControllerID.ToString()

                        formControllerAddUpdateNameLabel.Visible = True
                        formControllerAddUpdateNameTextBox.Visible = True
                        formControllerAddUpdateNameTextBox.Text() = objX10DbController.ControllerName

                        Select Case objX10DbController.ControllerActive
                            Case 0
                                formControllerAddUpdateActiveCheckBox.Checked = False
                            Case 1
                                formControllerAddUpdateActiveCheckBox.Checked = True
                        End Select
                        formControllerAddUpdateActiveCheckBox.Enabled = True
                        formControllerAddUpdateActiveCheckBox.Visible = True

                        formControllerAddUpdateDescriptionLabel.Visible = True
                        formControllerAddUpdateDescriptionTextBox.Visible = True
                        formControllerAddUpdateDescriptionTextBox.Text() = objX10DbController.ControllerDescription

                        Select Case objX10DbController.ControllerMacros
                            Case 0
                                formControllerAddUpdateMacroSupportLabelText.Text() = "No"
                            Case 1
                                formControllerAddUpdateMacroSupportLabelText.Text() = "Yes"
                        End Select
                        formControllerAddUpdateMacroSupportLabel.Visible = True
                        formControllerAddUpdateMacroSupportLabelText.Visible = True

                        Select Case objX10DbController.ControllerExtendedCommands
                            Case 0
                                formControllerAddUpdateExtendedCommandsLabelText.Text() = "No"
                            Case 1
                                formControllerAddUpdateExtendedCommandsLabelText.Text() = "Yes"
                        End Select
                        formControllerAddUpdateExtendedCommandsLabel.Visible = True
                        formControllerAddUpdateExtendedCommandsLabelText.Visible = True

                        formControllerAddUpdateModelLabel.Visible = True
                        ' ex: "CP290" | "CM15A" | "WM100"
                        formControllerAddUpdateModelComboBox.SelectedIndex = formControllerAddUpdateModelComboBox.FindString(objX10DbController.ControllerType)
                        formControllerAddUpdateModelComboBox.Visible = True

                        strTryStep = "UpdateController_SelectCaseControllerType"
                        ' ex: "CP290" | "CM15A" | "WM100"
                        Select Case objX10DbController.ControllerType.ToUpper()
                            Case "CP290"
                                strTryStep = "UpdateController_SelectCaseControllerType_CP290"


                                formControllerAddUpdateHouseCodeLabel.Visible = True

                                ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                                strStatus = generateHouseCodesComboBox(objX10DbController.HouseCode)
                                If (strStatus = "") Then
                                    formControllerAddUpdateHouseCodeComboBox.Visible = True
                                    formControllerAddUpdateHouseCodeInfoLabel.Visible = True
                                    formControllerAddUpdateHouseCodeInfoLabel.Text() = "Controller Base On/Off Swithces"
                                Else
                                    formControllerAddUpdateHouseCodeComboBox.Visible = False
                                    formControllerAddUpdateHouseCodeInfoLabel.Visible = False
                                    formControllerAddUpdateHouseCodeInfoLabel.Text() = ""
                                    Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If


                                formControllerAddUpdatePortLabel.Visible = True

                                ' generateSerialPortsComboBox(ByVal strSerialPort As String) As String
                                strStatus = generateSerialPortsComboBox(objX10DbController.Port)
                                If (strStatus = "") Then
                                    formControllerAddUpdatePortComboBox.Visible = True

                                    If (formControllerAddUpdatePortComboBox.SelectedIndex <= 0) Then
                                        Windows.Forms.MessageBox.Show("Missing Port selection", "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                    End If

                                Else
                                    formControllerAddUpdatePortComboBox.Visible = False
                                    Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If


                                formControllerAddUpdatePortValueLabel.Visible = False
                                formControllerAddUpdatePortValueLabel.Text() = objX10DbController.Port


                                formControllerAddUpdatePortInfoLabel.Visible = True
                                formControllerAddUpdatePortInfoLabel.Text() = "600 baud, no parity, 8 data bits, 1 stop bit"

                                formControllerAddUpdateAppKeyLabel.Visible = False
                                formControllerAddUpdateAppKeyTextBox.Visible = False
                                formControllerAddUpdateAppKeyTextBox.Text() = ""

                                formControllerAddUpdateUIDLabel.Visible = False
                                formControllerAddUpdateUIDTextBox.Visible = False
                                formControllerAddUpdateUIDTextBox.Text() = ""

                                formControllerAddUpdateTransceiverHouseCodesLabel.Visible = False
                                formControllerAddUpdateTransceiverHouseCodesPanel.Visible = False

                                formControllerAddUpdateDuskDawnResolutionLabel.Visible = False
                                formControllerAddUpdateDuskDawnResolutionComboBox.Visible = False

                                formControllerAddUpdateOperationsGroupBox.Visible = True
                                formControllerAddUpdate_GetStatusButton.Visible = True
                                formControllerAddUpdate_SetClockButton.Visible = True
                                formControllerAddUpdateSetClockText1Label.Visible = False
                                formControllerAddUpdateSetClockText2Label.Visible = False
                                formControllerAddUpdate_SetBaseHouseCodeButton.Visible = True
                                formControllerAddUpdate_DownloadButton.Visible = True
                                formControllerAddUpdate_ClearButton.Visible = True
                                formControllerAddUpdate_ExportButton.Visible = True

                            Case "CM15A"
                                strTryStep = "UpdateController_SelectCaseControllerType_CM15A"


                                formControllerAddUpdateHouseCodeLabel.Visible = True

                                ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                                strStatus = generateHouseCodesComboBox(objX10DbController.HouseCode)
                                If (strStatus = "") Then
                                    formControllerAddUpdateHouseCodeComboBox.Visible = True
                                    formControllerAddUpdateHouseCodeInfoLabel.Visible = True
                                    formControllerAddUpdateHouseCodeInfoLabel.Text() = "Monitored House Code"
                                Else
                                    formControllerAddUpdateHouseCodeComboBox.Visible = False
                                    formControllerAddUpdateHouseCodeInfoLabel.Visible = False
                                    formControllerAddUpdateHouseCodeInfoLabel.Text() = ""
                                    Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If


                                formControllerAddUpdatePortLabel.Visible = True

                                ' generateUSBPortsComboBox(ByVal strUSBPortHub As String, ByVal intControllerActive As Integer) As String
                                strStatus = generateUSBPortsComboBox(objX10DbController.Port & "." & objX10DbController.Hub, objX10DbController.ControllerActive)
                                If (strStatus = "") Then
                                    formControllerAddUpdatePortComboBox.Visible = True

                                    If (formControllerAddUpdatePortComboBox.SelectedIndex <= 0) Then
                                        Windows.Forms.MessageBox.Show("Missing Port selection", "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                    End If

                                Else
                                    formControllerAddUpdatePortComboBox.Visible = False
                                    Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If


                                formControllerAddUpdatePortValueLabel.Visible = False
                                formControllerAddUpdatePortValueLabel.Text() = objX10DbController.Port & "." & objX10DbController.Hub

                                formControllerAddUpdatePortInfoLabel.Visible = True
                                formControllerAddUpdatePortInfoLabel.Text() = "X10 USB ActiveHome (ACPI-compliant)"


                                formControllerAddUpdateAppKeyLabel.Visible = False
                                formControllerAddUpdateAppKeyTextBox.Visible = False
                                formControllerAddUpdateAppKeyTextBox.Text() = ""

                                formControllerAddUpdateUIDLabel.Visible = False
                                formControllerAddUpdateUIDTextBox.Visible = False
                                formControllerAddUpdateUIDTextBox.Text() = ""

                                formControllerAddUpdateTransceiverHouseCodesLabel.Visible = True
                                formControllerAddUpdateTransceiverHouseCodesPanel.Visible = True
                                Call setTransceiverHouseCodesCheckBox(objX10DbController.TransceiverHouseCodes)


                                formControllerAddUpdateDuskDawnResolutionLabel.Visible = True

                                ' generateDuskDawnResolutionComboBox(ByVal bytDuskDawnResolution As Byte) As String
                                strStatus = generateDuskDawnResolutionComboBox(objX10DbController.DuskDawnResolution)
                                If (strStatus = "") Then
                                    formControllerAddUpdateDuskDawnResolutionComboBox.Visible = True
                                Else
                                    formControllerAddUpdateDuskDawnResolutionComboBox.Visible = False
                                    Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If


                                formControllerAddUpdateOperationsGroupBox.Visible = True
                                formControllerAddUpdate_GetStatusButton.Visible = True
                                formControllerAddUpdate_SetClockButton.Visible = True
                                formControllerAddUpdateSetClockText1Label.Visible = True
                                formControllerAddUpdateSetClockText2Label.Visible = True
                                formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                                formControllerAddUpdate_DownloadButton.Visible = True
                                formControllerAddUpdate_ClearButton.Visible = True
                                formControllerAddUpdate_ExportButton.Visible = True

                            Case "WM100"
                                strTryStep = "UpdateController_SelectCaseControllerType_WM100"

                                formControllerAddUpdateHouseCodeLabel.Visible = False
                                formControllerAddUpdateHouseCodeComboBox.Visible = False

                                formControllerAddUpdatePortLabel.Visible = True
                                formControllerAddUpdatePortComboBox.Visible = False
                                formControllerAddUpdatePortValueLabel.Visible = True
                                formControllerAddUpdatePortValueLabel.Text() = objX10DbController.Port
                                formControllerAddUpdatePortInfoLabel.Visible = False

                                formControllerAddUpdateAppKeyLabel.Visible = True
                                formControllerAddUpdateAppKeyTextBox.Visible = True
                                formControllerAddUpdateAppKeyTextBox.Text() = objX10DbController.AppKey

                                formControllerAddUpdateUIDLabel.Visible = True
                                formControllerAddUpdateUIDTextBox.Visible = True
                                formControllerAddUpdateUIDTextBox.Text() = objX10DbController.UID

                                formControllerAddUpdateTransceiverHouseCodesLabel.Visible = False
                                formControllerAddUpdateTransceiverHouseCodesPanel.Visible = False

                                formControllerAddUpdateDuskDawnResolutionLabel.Visible = False
                                formControllerAddUpdateDuskDawnResolutionComboBox.Visible = False

                                formControllerAddUpdateOperationsGroupBox.Visible = True
                                formControllerAddUpdate_GetStatusButton.Visible = True
                                formControllerAddUpdate_SetClockButton.Visible = True
                                formControllerAddUpdateSetClockText1Label.Visible = False
                                formControllerAddUpdateSetClockText2Label.Visible = False
                                formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                                formControllerAddUpdate_DownloadButton.Visible = True
                                formControllerAddUpdate_ExportButton.Visible = False

                            Case Else

                                formControllerAddUpdateOperationsGroupBox.Visible = False
                                formControllerAddUpdate_GetStatusButton.Visible = False
                                formControllerAddUpdate_SetClockButton.Visible = False
                                formControllerAddUpdateSetClockText1Label.Visible = False
                                formControllerAddUpdateSetClockText2Label.Visible = False
                                formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                                formControllerAddUpdate_DownloadButton.Visible = False
                                formControllerAddUpdate_ClearButton.Visible = False
                                formControllerAddUpdate_ExportButton.Visible = False

                                Windows.Forms.MessageBox.Show("Main(formControllerAddUpdate): Unknown Controller Model for Update: """ & objX10DbController.ControllerType & """", "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        End Select ' END  - UpdateController_SelectCaseControllerType

                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Controller from X10 db." & vbCrLf & strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getX10DbController()


                    strMessage = "  Success Getting Controller " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]!"
                    Call formConsoleMessages.DisplayMessage(strMessage, "Update Controller")

                End If ' END - formControllerAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formControllerAddUpdate): " & strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formControllerAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbController = Nothing
            objDataTableControllerTypes = Nothing
        End Try

    End Sub ' END Sub - Main(formControllerAddUpdate)

    Private Sub formControllerAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formControllerAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formControllerAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formControllerAddUpdate_FormClosingHandler(): " & strStatus, "formControllerAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formControllerAddUpdate_FormSave()

    End Sub ' END Sub - formControllerAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopControllerAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function generateHouseCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateHouseCodesComboBox(ByVal strHouseCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableHouseCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT HouseCodeID, HouseCode FROM HouseCodes UNION SELECT 0 AS HouseCodeID, 'Select HouseCode...' AS HouseCode FROM HouseCodes ORDER BY HouseCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableHouseCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formControllerAddUpdateHouseCodeComboBox
                .DisplayMember = "HouseCode"
                .ValueMember = "HouseCodeID"
                .DataSource = objDataTableHouseCodes
            End With

            If (strHouseCode = "") Then
                formControllerAddUpdateHouseCodeComboBox.SelectedIndex = 0
            Else
                formControllerAddUpdateHouseCodeComboBox.SelectedIndex = formControllerAddUpdateHouseCodeComboBox.FindString(strHouseCode)
            End If

        Catch ex As Exception
            strStatus = "generateHouseCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableHouseCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateHouseCodesComboBox()

    '=====================================================================================
    ' Function generateSerialPortsComboBox()
    ' Alan Wagner
    '
    Private Function generateSerialPortsComboBox(ByVal strSerialPort As String) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableSerialPorts As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' nsX10DbMethods.getSerialPortsPutX10Db(ByVal strConnectionString As String, ByVal strProvider As String) As String
            strError = nsX10DbMethods.getSerialPortsPutX10Db(strConnectionString, strProvider)
            If (strError = "") Then

                ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
                Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                    objConnection.Open()
                    Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT SerialPortID AS PortID, SerialPort AS Port FROM SerialPorts UNION SELECT 0 AS PortID, 'Select Port...' AS Port FROM SerialPorts ORDER BY PortID ASC", objConnection)
                    objOleDbDataAdapter.Fill(objDataTableSerialPorts)
                    objConnection.Close()
                    objOleDbDataAdapter = Nothing
                End Using

                With formControllerAddUpdatePortComboBox
                    .DisplayMember = "Port"
                    .ValueMember = "PortID"
                    .DataSource = objDataTableSerialPorts
                End With

                If (strSerialPort = "") Then
                    formControllerAddUpdatePortComboBox.SelectedIndex = 0
                Else
                    formControllerAddUpdatePortComboBox.SelectedIndex = formControllerAddUpdatePortComboBox.FindString(strSerialPort)
                End If

            Else
                strStatus = "generateSerialPortsComboBox(): " & strError
            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "generateSerialPortsComboBox(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "generateSerialPortsComboBox(): Exception: " & ex.Message
            End If

        Finally
            objDataTableSerialPorts = Nothing
        End Try

        Return strStatus

    End Function ' END - generateSerialPortsComboBox()

    '=====================================================================================
    ' Function generateUSBPortsComboBox()
    ' Alan Wagner
    '
    Private Function generateUSBPortsComboBox(ByVal strUSBPortHub As String, ByVal intControllerActive As Integer) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableSerialPorts As New System.Data.DataTable

        Try

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "ControllerActive"
            If (intControllerActive = 1) Then

                strTryStep = "nsX10DbMethods.getUSBPortsPutX10Db"
                ' nsX10DbMethods.getUSBPortsPutX10Db(ByVal strConnectionString As String, ByVal strProvider As String) As String
                strError = nsX10DbMethods.getUSBPortsPutX10Db(strConnectionString, strProvider)
                If (strError <> "") Then
                    Windows.Forms.MessageBox.Show(strError & vbCrLf & "Using last known USB Port setting." & vbCrLf & "Is the Controller connected and powered on?", "generateUSBPortsComboBox()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Warning)
                End If

            Else
                Windows.Forms.MessageBox.Show("Controller ""Active"" is not checked." & vbCrLf & "USB port search for Controller was not performed." & vbCrLf & "Using last known USB Port setting.", "generateUSBPortsComboBox()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Warning)
            End If

            strTryStep = "OleDbConnection"
            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT USBPortID AS PortID, USBPort+'.'+USBHub AS Port FROM USBPorts WHERE USBDeviceType='USB' AND USBPortID>-1 UNION SELECT -1 AS PortID, 'Select USB Port.Hub' AS Port FROM USBPorts WHERE USBPortID=-1 ORDER BY PortID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableSerialPorts)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            strTryStep = "WithFormControllerAddUpdatePortComboBox"
            With formControllerAddUpdatePortComboBox
                .DisplayMember = "Port"
                .ValueMember = "PortID"
                .DataSource = objDataTableSerialPorts
            End With

            strTryStep = "USBPortHub"
            If (strUSBPortHub = "") Then

                strTryStep = "NoUSBPortHub_formControllerAddUpdatePortComboBox.SelectedIndex=0"
                formControllerAddUpdatePortComboBox.SelectedIndex = 0

            Else

                strTryStep = "formControllerAddUpdatePortComboBox.FindString"
                ' Returns the index of the first item in the ComboBox beyond the specified index that contains the specified string. The search is not case sensitive.
                ' The zero-based index of the first item found; returns -1 if no match is found.
                ' public int FindString (string s, int startIndex);
                If (formControllerAddUpdatePortComboBox.FindString(strUSBPortHub, 0) > 0) Then
                    formControllerAddUpdatePortComboBox.SelectedIndex = formControllerAddUpdatePortComboBox.FindString(strUSBPortHub, 0)
                Else
                    formControllerAddUpdatePortComboBox.SelectedIndex = 0
                End If

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "generateUSBPortsComboBox(" & strTryStep & "): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "generateUSBPortsComboBox(" & strTryStep & "): Exception: " & ex.Message
            End If

        Finally
            objDataTableSerialPorts = Nothing
        End Try

        Return strStatus

    End Function ' END - generateUSBPortsComboBox()

    '=====================================================================================
    ' Function getTransceiverHouseCodesCheckBox()
    ' Alan Wagner
    '
    Private Sub getTransceiverHouseCodesCheckBox(ByRef strTransceiverHouseCodes As String, ByRef objTransceiverHouseCodeMap As TrekkerPhotoArt.X10Include.X10DbHouseCodeMap)
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        strTransceiverHouseCodes = ""

        If formControllerAddUpdateHouseCodeACheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "A"
            Else
                strTransceiverHouseCodes &= ",A"
            End If
        End If

        If formControllerAddUpdateHouseCodeBCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "B"
            Else
                strTransceiverHouseCodes &= ",B"
            End If
        End If

        If formControllerAddUpdateHouseCodeCCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "C"
            Else
                strTransceiverHouseCodes &= ",C"
            End If
        End If

        If formControllerAddUpdateHouseCodeDCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "D"
            Else
                strTransceiverHouseCodes &= ",D"
            End If
        End If

        If formControllerAddUpdateHouseCodeECheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "E"
            Else
                strTransceiverHouseCodes &= ",E"
            End If
        End If

        If formControllerAddUpdateHouseCodeFCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "F"
            Else
                strTransceiverHouseCodes &= ",F"
            End If
        End If

        If formControllerAddUpdateHouseCodeGCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "G"
            Else
                strTransceiverHouseCodes &= ",G"
            End If
        End If

        If formControllerAddUpdateHouseCodeHCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "H"
            Else
                strTransceiverHouseCodes &= ",H"
            End If
        End If

        If formControllerAddUpdateHouseCodeICheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "I"
            Else
                strTransceiverHouseCodes &= ",I"
            End If
        End If

        If formControllerAddUpdateHouseCodeJCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "J"
            Else
                strTransceiverHouseCodes &= ",J"
            End If
        End If

        If formControllerAddUpdateHouseCodeKCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "K"
            Else
                strTransceiverHouseCodes &= ",K"
            End If
        End If

        If formControllerAddUpdateHouseCodeLCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "L"
            Else
                strTransceiverHouseCodes &= ",L"
            End If
        End If

        If formControllerAddUpdateHouseCodeMCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "M"
            Else
                strTransceiverHouseCodes &= ",M"
            End If
        End If

        If formControllerAddUpdateHouseCodeNCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "N"
            Else
                strTransceiverHouseCodes &= ",N"
            End If
        End If

        If formControllerAddUpdateHouseCodeOCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "O"
            Else
                strTransceiverHouseCodes &= ",O"
            End If
        End If

        If formControllerAddUpdateHouseCodePCheckBox.Checked Then
            If (strTransceiverHouseCodes = "") Then
                strTransceiverHouseCodes = "P"
            Else
                strTransceiverHouseCodes &= ",P"
            End If
        End If

        If (strTransceiverHouseCodes.Length = 0) Then
            objTransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
            objTransceiverHouseCodeMap.status = ""
            objTransceiverHouseCodeMap.byte1 = 0
            objTransceiverHouseCodeMap.byte2 = 0
        Else
            ' x10HouseCodesToHouseCodeMap(ByVal strHouseCodes As String) As X10DbHouseCodeMap
            objTransceiverHouseCodeMap = nsX10DbMethods.x10HouseCodesToHouseCodeMap(strTransceiverHouseCodes)
        End If

    End Sub ' END - getTransceiverHouseCodesCheckBox()

    '=====================================================================================
    ' Function getDuskDawnResolutionFromSelectedIndex()
    ' Alan Wagner
    '
    Private Function getDuskDawnResolutionFromSelectedIndex(ByVal intSelectedIndex As Integer) As Byte

        Select Case intSelectedIndex
            Case 0
                Return 0
            Case 1
                Return 8
            Case 2
                Return 16
            Case 3
                Return 32
            Case Else
                Return 0
        End Select

    End Function ' ENd - getDuskDawnResolutionFromSelectedIndex()

    '=====================================================================================
    ' Function setTransceiverHouseCodesCheckBox()
    ' Alan Wagner
    '
    Private Sub setTransceiverHouseCodesCheckBox(ByVal strTransceiverHouseCodes As String)

        Dim arrHouseCodes() As String = Nothing
        Dim arrSpearator() As Char = {","}
        Dim intPointer As Integer = 0

        formControllerAddUpdateHouseCodeACheckBox.Checked = False
        formControllerAddUpdateHouseCodeBCheckBox.Checked = False
        formControllerAddUpdateHouseCodeCCheckBox.Checked = False
        formControllerAddUpdateHouseCodeDCheckBox.Checked = False
        formControllerAddUpdateHouseCodeECheckBox.Checked = False
        formControllerAddUpdateHouseCodeFCheckBox.Checked = False
        formControllerAddUpdateHouseCodeGCheckBox.Checked = False
        formControllerAddUpdateHouseCodeHCheckBox.Checked = False
        formControllerAddUpdateHouseCodeICheckBox.Checked = False
        formControllerAddUpdateHouseCodeJCheckBox.Checked = False
        formControllerAddUpdateHouseCodeKCheckBox.Checked = False
        formControllerAddUpdateHouseCodeLCheckBox.Checked = False
        formControllerAddUpdateHouseCodeMCheckBox.Checked = False
        formControllerAddUpdateHouseCodeNCheckBox.Checked = False
        formControllerAddUpdateHouseCodeOCheckBox.Checked = False
        formControllerAddUpdateHouseCodePCheckBox.Checked = False

        If (strTransceiverHouseCodes.Length > 0) Then

            arrHouseCodes = strTransceiverHouseCodes.Split(arrSpearator, System.StringSplitOptions.None)

            If (arrHouseCodes.Count > 0) Then

                For intPointer = 0 To arrHouseCodes.Count - 1 Step 1

                    Select Case arrHouseCodes(intPointer).ToUpper()
                        Case "A"
                            formControllerAddUpdateHouseCodeACheckBox.Checked = True
                        Case "B"
                            formControllerAddUpdateHouseCodeBCheckBox.Checked = True
                        Case "C"
                            formControllerAddUpdateHouseCodeCCheckBox.Checked = True
                        Case "D"
                            formControllerAddUpdateHouseCodeDCheckBox.Checked = True
                        Case "E"
                            formControllerAddUpdateHouseCodeECheckBox.Checked = True
                        Case "F"
                            formControllerAddUpdateHouseCodeFCheckBox.Checked = True
                        Case "G"
                            formControllerAddUpdateHouseCodeGCheckBox.Checked = True
                        Case "H"
                            formControllerAddUpdateHouseCodeHCheckBox.Checked = True
                        Case "I"
                            formControllerAddUpdateHouseCodeICheckBox.Checked = True
                        Case "J"
                            formControllerAddUpdateHouseCodeJCheckBox.Checked = True
                        Case "K"
                            formControllerAddUpdateHouseCodeKCheckBox.Checked = True
                        Case "L"
                            formControllerAddUpdateHouseCodeLCheckBox.Checked = True
                        Case "M"
                            formControllerAddUpdateHouseCodeMCheckBox.Checked = True
                        Case "N"
                            formControllerAddUpdateHouseCodeNCheckBox.Checked = True
                        Case "O"
                            formControllerAddUpdateHouseCodeOCheckBox.Checked = True
                        Case "P"
                            formControllerAddUpdateHouseCodePCheckBox.Checked = True
                    End Select

                Next

            End If

        End If

    End Sub ' END - setTransceiverHouseCodesCheckBox()

    '=====================================================================================
    ' Function generateDuskDawnResolutionComboBox()
    ' Alan Wagner
    '
    ' Dusk Dawn Resolution for CM15A X10 Controller must be in Multiples of 8 (ex: 8 or 16 or 32).
    '
    Private Function generateDuskDawnResolutionComboBox(ByVal bytDuskDawnResolution As Byte) As String
        Dim strStatus As String = ""

        Try

            formControllerAddUpdateDuskDawnResolutionComboBox.Items.Insert(0, "Select Resolution...")
            formControllerAddUpdateDuskDawnResolutionComboBox.Items.Insert(1, "8 Days")
            formControllerAddUpdateDuskDawnResolutionComboBox.Items.Insert(2, "16 Days")
            formControllerAddUpdateDuskDawnResolutionComboBox.Items.Insert(3, "32 Days")

            Select Case bytDuskDawnResolution
                Case 0
                    formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex = 0
                Case 8
                    formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex = 1
                Case 16
                    formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex = 2
                Case 32
                    formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex = 3
                Case Else
                    formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex = 0
                    strStatus = "generateDuskDawnResolutionComboBox(): Invalid Dusk/Dawn Resolution Value found in X10 Database """ & bytDuskDawnResolution.ToString() & """ days.  Need to specify 8, 16, 32 days."
            End Select

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "generateDuskDawnResolutionComboBox(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "generateDuskDawnResolutionComboBox(): Exception: " & ex.Message
            End If
        End Try

        Return strStatus

    End Function ' END - generateDuskDawnResolutionComboBox()

    '=====================================================================================
    ' checkScheduleForModules()
    ' Alan Wagner
    '
    Private Function checkControllerForModules(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef intModuleCount As Integer) As String
        Dim strStatus As String = ""
        Dim strTryStep As String = ""
        Dim bAllOK As Boolean = True

        Dim objFactory As System.Data.Common.DbProviderFactory = Nothing

        Dim sqlString As String = ""

        intModuleCount = 0

        Try

            strTryStep = "GetFactory"
            objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

            strTryStep = "CreateConnection"
            Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                strTryStep = "ConnectionString"
                objDbConnection.ConnectionString = strConnectionString

                strTryStep = "Connection.Open"
                objDbConnection.Open()

                strTryStep = "CreateCommand"
                Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                    strTryStep = "sqlString"
                    sqlString = "SELECT Units.ControllerID,COUNT(Units.UnitID) AS countUnits " &
                                    "FROM (Units INNER JOIN Controllers on Controllers.ControllerID=Units.ControllerID) " &
                                    "WHERE Units.ControllerID=" & intControllerID.ToString() & " " &
                                    "GROUP BY Units.ControllerID;"

                    strTryStep = "CommandText"
                    objDbCommand.CommandText = sqlString

                    strTryStep = "CommandTimeout"
                    objDbCommand.CommandTimeout = 30 ' Seconds

                    strTryStep = "CommandType"
                    ' Text              - An SQL text command (default).
                    ' StoredProcedure   - To call a stored procedure.
                    ' TableDirect       - All rows and columns of the named table or tables will be returned.
                    objDbCommand.CommandType() = CommandType.Text

                    strTryStep = "ExecuteReader"
                    ' ExecuteReader     - Executes commands that return rows.
                    '   System.Data.CommandBehavior.Default          - The query may return multiple result sets. ExecuteReader(CommandBehavior.Default) is functionally equivalent to calling ExecuteReader().
                    '   System.Data.CommandBehavior.SingleResult     - The query returns a single result set.
                    '   System.Data.CommandBehavior.SchemaOnly       - The query returns column information only.
                    '   System.Data.CommandBehavior.KeyInfo          - The query returns column and primary key information.
                    '   System.Data.CommandBehavior.SingleRow        - The query is expected to return a single row of the first result set.
                    '   System.Data.CommandBehavior.SequentialAccess - Provides a way for the DataReader to handle rows that contain columns with large binary values. You can then use the GetBytes or GetChars method to specify a byte location to start the read operation.
                    '   System.Data.CommandBehavior.CloseConnection  - When the command is executed, the associated Connection object is closed when the associated DataReader object is closed.
                    ' ExecuteNonQuery   - Executes commands such as Transact-SQL INSERT, DELETE, UPDATE, and SET statements.
                    ' ExecuteScalar     - Retrieves a single value (for example, an aggregate value) from a database.
                    ' ExecuteXmlReader  - Sends the CommandText to the Connection and builds an XmlReader object.
                    Using objDbDataReader As System.Data.Common.DbDataReader = objDbCommand.ExecuteReader(System.Data.CommandBehavior.SingleRow)

                        strTryStep = "HasRows"
                        If objDbDataReader.HasRows() Then

                            strTryStep = "Read"
                            While objDbDataReader.Read() And bAllOK

                                strTryStep = "ModuleCount"
                                intModuleCount = CType(objDbDataReader("countUnits"), Integer)

                            End While

                        End If ' END - HasRows

                    End Using ' END - ExecuteReader

                End Using ' END - CreateCommand

                strTryStep = "Connection.Close"
                objDbConnection.Close()

            End Using ' END - CreateConnection

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "checkScheduleForModules(" & strTryStep & "): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "checkScheduleForModules(" & strTryStep & "): Exception: " & ex.Message
            End If
        Finally
            objFactory = Nothing
        End Try

        Return strStatus

    End Function ' END - checkScheduleForModules()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formControllerAddUpdateModelComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdateModelComboBox.SelectionChangeCommitted
        'formControllerAddUpdateModelComboBox.SelectedIndexChanged

        Dim strStatus As String = ""

        Dim objDataRowView As System.Data.DataRowView = Nothing
        Dim strControllerType As String = ""
        Dim strControllerTypeID As String = ""

        Try

            objDataRowView = formControllerAddUpdateModelComboBox.SelectedItem
            strControllerTypeID = objDataRowView(0).ToString
            strControllerType = objDataRowView(1).ToString ' ex: "CP290"

            Select Case strControllerType.ToUpper()
                Case "CP290"


                    formControllerAddUpdateHouseCodeLabel.Visible = True

                    ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                    strStatus = generateHouseCodesComboBox("")
                    If (strStatus = "") Then
                        formControllerAddUpdateHouseCodeComboBox.Visible = True
                        formControllerAddUpdateHouseCodeInfoLabel.Visible = True
                        formControllerAddUpdateHouseCodeInfoLabel.Text() = "Controller Base On/Off Swithces"
                    Else
                        formControllerAddUpdateHouseCodeComboBox.Visible = False
                        formControllerAddUpdateHouseCodeInfoLabel.Visible = False
                        formControllerAddUpdateHouseCodeInfoLabel.Text() = ""
                        Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdateModelComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If


                    formControllerAddUpdatePortLabel.Visible = True

                    ' generateSerialPortsComboBox(ByVal strSerialPort As String) As String
                    strStatus = generateSerialPortsComboBox("")
                    If (strStatus = "") Then
                        formControllerAddUpdatePortComboBox.Visible = True
                    Else
                        formControllerAddUpdatePortComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdateModelComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If


                    formControllerAddUpdatePortValueLabel.Visible = False
                    formControllerAddUpdatePortValueLabel.Text() = ""

                    formControllerAddUpdatePortInfoLabel.Visible = True
                    formControllerAddUpdatePortInfoLabel.Text() = "600 baud, no parity, 8 data bits, 1 stop bit"

                    formControllerAddUpdateAppKeyLabel.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Text() = ""

                    formControllerAddUpdateUIDLabel.Visible = False
                    formControllerAddUpdateUIDTextBox.Visible = False
                    formControllerAddUpdateUIDTextBox.Text() = ""

                    formControllerAddUpdateTransceiverHouseCodesLabel.Visible = False
                    formControllerAddUpdateTransceiverHouseCodesPanel.Visible = False

                    formControllerAddUpdateDuskDawnResolutionLabel.Visible = False
                    formControllerAddUpdateDuskDawnResolutionComboBox.Visible = False

                Case "CM15A"

                    formControllerAddUpdateHouseCodeLabel.Visible = True

                    ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                    strStatus = generateHouseCodesComboBox("")
                    If (strStatus = "") Then
                        formControllerAddUpdateHouseCodeComboBox.Visible = True
                        formControllerAddUpdateHouseCodeInfoLabel.Visible = True
                        formControllerAddUpdateHouseCodeInfoLabel.Text() = "Monitored House Code"
                    Else
                        formControllerAddUpdateHouseCodeComboBox.Visible = False
                        formControllerAddUpdateHouseCodeInfoLabel.Visible = False
                        formControllerAddUpdateHouseCodeInfoLabel.Text() = ""
                        Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdateModelComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If


                    formControllerAddUpdatePortLabel.Visible = True

                    ' generateUSBPortsComboBox(ByVal strUSBPortHub As String, ByVal intControllerActive As Integer) As String
                    strStatus = generateUSBPortsComboBox("", 1)
                    If (strStatus = "") Then
                        formControllerAddUpdatePortComboBox.Visible = True
                    Else
                        formControllerAddUpdatePortComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdateModelComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If


                    formControllerAddUpdatePortValueLabel.Visible = False
                    formControllerAddUpdatePortValueLabel.Text() = ""

                    formControllerAddUpdatePortInfoLabel.Visible = True
                    formControllerAddUpdatePortInfoLabel.Text() = "X10 USB ActiveHome (ACPI-compliant)"

                    formControllerAddUpdateAppKeyLabel.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Text() = ""

                    formControllerAddUpdateUIDLabel.Visible = False
                    formControllerAddUpdateUIDTextBox.Visible = False
                    formControllerAddUpdateUIDTextBox.Text() = ""

                    formControllerAddUpdateTransceiverHouseCodesLabel.Visible = True
                    formControllerAddUpdateTransceiverHouseCodesPanel.Visible = True
                    Call setTransceiverHouseCodesCheckBox("")


                    formControllerAddUpdateDuskDawnResolutionLabel.Visible = True

                    ' generateDuskDawnResolutionComboBox(ByVal bytDuskDawnResolution As Byte) As String
                    strStatus = generateDuskDawnResolutionComboBox(0)
                    If (strStatus = "") Then
                        formControllerAddUpdateDuskDawnResolutionComboBox.Visible = True
                    Else
                        formControllerAddUpdateDuskDawnResolutionComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                Case "WM100"

                    formControllerAddUpdateHouseCodeLabel.Visible = False
                    formControllerAddUpdateHouseCodeComboBox.Visible = False
                    formControllerAddUpdateHouseCodeInfoLabel.Visible = False

                    formControllerAddUpdatePortLabel.Visible = True

                    formControllerAddUpdatePortComboBox.Visible = False

                    formControllerAddUpdatePortValueLabel.Visible = True
                    formControllerAddUpdatePortValueLabel.Text() = "WIFI"

                    formControllerAddUpdatePortInfoLabel.Visible = False
                    formControllerAddUpdatePortInfoLabel.Text() = ""


                    formControllerAddUpdateAppKeyLabel.Visible = True
                    formControllerAddUpdateAppKeyTextBox.Visible = True
                    formControllerAddUpdateAppKeyTextBox.Text() = ""

                    formControllerAddUpdateUIDLabel.Visible = True
                    formControllerAddUpdateUIDTextBox.Visible = True
                    formControllerAddUpdateUIDTextBox.Text() = ""

                    formControllerAddUpdateTransceiverHouseCodesLabel.Visible = False
                    formControllerAddUpdateTransceiverHouseCodesPanel.Visible = False

                    formControllerAddUpdateDuskDawnResolutionLabel.Visible = False
                    formControllerAddUpdateDuskDawnResolutionComboBox.Visible = False

                Case Else

                    formControllerAddUpdateHouseCodeLabel.Visible = False
                    formControllerAddUpdateHouseCodeComboBox.Visible = False
                    formControllerAddUpdateHouseCodeInfoLabel.Visible = False

                    formControllerAddUpdatePortLabel.Visible = False

                    formControllerAddUpdatePortComboBox.Visible = False

                    formControllerAddUpdatePortValueLabel.Visible = False
                    formControllerAddUpdatePortValueLabel.Text() = ""

                    formControllerAddUpdatePortInfoLabel.Visible = False
                    formControllerAddUpdatePortInfoLabel.Text() = ""


                    formControllerAddUpdateAppKeyLabel.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Visible = False
                    formControllerAddUpdateAppKeyTextBox.Text() = ""

                    formControllerAddUpdateUIDLabel.Visible = False
                    formControllerAddUpdateUIDTextBox.Visible = False
                    formControllerAddUpdateUIDTextBox.Text() = ""

            End Select

            formControllerAddUpdateActiveCheckBox.Checked = True
            formControllerAddUpdateActiveCheckBox.Enabled = True
            formControllerAddUpdateActiveCheckBox.Visible = True

            formControllerAddUpdateOperationsGroupBox.Visible = False
            formControllerAddUpdate_GetStatusButton.Visible = False
            formControllerAddUpdate_SetClockButton.Visible = False
            formControllerAddUpdateSetClockText1Label.Visible = False
            formControllerAddUpdateSetClockText2Label.Visible = False
            formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
            formControllerAddUpdate_DownloadButton.Visible = False
            formControllerAddUpdate_ClearButton.Visible = False
            formControllerAddUpdate_ExportButton.Visible = False

        Catch ex As Exception
            strStatus = "formControllerAddUpdateModelComboBox_SelectedIndexChanged(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdateModelComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objDataRowView = Nothing
        End Try

    End Sub ' END - formControllerAddUpdateModelComboBox_SelectedIndexChanged()

    Private Sub formControllerAddUpdatePortComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdatePortComboBox.SelectionChangeCommitted

        ' Get the Selected Serial Port.
        Dim objDataRowViewPort As System.Data.DataRowView = formControllerAddUpdatePortComboBox.SelectedItem
        formControllerAddUpdatePortValueLabel.Text() = objDataRowViewPort(1).ToString
        objDataRowViewPort = Nothing

    End Sub ' END - formControllerAddUpdatePortComboBox_SelectedIndexChanged()


    Private Sub formControllerAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing
        Dim strControllerType As String = ""
        Dim strControllerTypeID As String = ""

        Dim objDataRowViewPort As System.Data.DataRowView = Nothing
        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing

        Dim arrPortHub() As String = Nothing
        Dim arrSpearator() As Char = {"."}

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim intControllerID As Integer = -1

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormControllerEdit As formControllerEdit = Nothing

        Try

            formControllerAddUpdate_StatusLabel.Text = ""
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            If (formControllerAddUpdateNameTextBox.Text.Trim() = "") Then
                strStatus = "Missing Controller Name."
            End If

            ' Was Something Missing?
            If (strStatus = "") Then

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                ' Verify the Controller Name has not already been used.

                strTryStep = "nsX10DbMethods.getX10DbController"
                ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strControllerName As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                strError = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, formControllerAddUpdateNameTextBox.Text.Trim(), objX10DbController)
                If (strError = "") Then

                    ' Was a Controller found?
                    If (Not objX10DbController Is Nothing AndAlso objX10DbController.ControllerID >= 0) Then
                        ' A Controller was found with the specified Controller Name.

                        ' Add or Modify Controller?
                        If (formControllerAddUpdate_AddUpdateButton.Text() = "Add") Then
                            strStatus = "Unable to Add the Controller. The Controller Name has already been used by another Controller."
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else
                            ' Modify Controller

                            intControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)

                            If (objX10DbController.ControllerID <> intControllerID) Then
                                strStatus = "Unable to Update Controller information. The new Controller Name has already been used by another Controller."
                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        End If ' END - Add or Modify Controller?

                    Else
                        ' Nothing found.
                        If (formControllerAddUpdate_AddUpdateButton.Text() = "Add") Then
                            ' Add Controller
                            intControllerID = -1
                        Else
                            ' Modify Controller
                            intControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)
                        End If ' END - Add or Modify Controller
                    End If ' END - Was a Controller found?

                Else
                    strStatus = "Problem determining if Controller Name has already been used." & vbCrLf & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                End If ' END - nsX10DbMethods.getX10DbController()
                If (strStatus = "") Then

                    strTryStep = "formControllerAddUpdateModelComboBox"
                    objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                    strControllerTypeID = objDataRowViewControllerModel(0).ToString
                    strControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CP290"

                    strTryStep = "NewObjectX10DbController"
                    objX10DbController = Nothing
                    objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController
                    objX10DbController.ControllerID = intControllerID
                    objX10DbController.ControllerName = formControllerAddUpdateNameTextBox.Text().Trim()
                    objX10DbController.ControllerTypeID = CType(strControllerTypeID, Integer)
                    objX10DbController.ControllerType = strControllerType           ' ex: "CP290" | "CM15A" | "WM100"
                    objX10DbController.ControllerDescription = formControllerAddUpdateDescriptionTextBox.Text().Trim()

                    strTryStep = "formControllerAddUpdateActiveCheckBox"
                    Select Case formControllerAddUpdateActiveCheckBox.Checked
                        Case False
                            objX10DbController.ControllerActive = 0
                        Case True
                            objX10DbController.ControllerActive = 1
                    End Select

                    strTryStep = "SelectCaseControllerType"
                    Select Case objX10DbController.ControllerType.ToUpper()
                        Case "CP290"

                            strTryStep = "CP290_formControllerAddUpdateHouseCodeComboBox"
                            objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                            objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "A"

                            objX10DbController.TransceiverHouseCodes = ""
                            objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                            objX10DbController.TransceiverHouseCodeMap.status = ""
                            objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                            objX10DbController.TransceiverHouseCodeMap.byte2 = 0

                            strTryStep = "CP290_formControllerAddUpdatePortComboBox"
                            objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                            objX10DbController.Port = objDataRowViewPort(1).ToString ' ex: "COM3"

                            objX10DbController.Hub = ""
                            objX10DbController.AppKey = ""
                            objX10DbController.UID = ""
                            objX10DbController.DuskDawnResolution = 0

                            If (objX10DbController.HouseCode = "" Or objX10DbController.Port = "") Then
                                objX10DbController = Nothing
                                Windows.Forms.MessageBox.Show("Missing Controller's HouseCode or Serial Port.", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        Case "CM15A"

                            strTryStep = "CM15A_formControllerAddUpdateHouseCodeComboBox"
                            objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                            objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "A"

                            strTryStep = "CM15A_formControllerAddUpdatePortComboBox"
                            objX10DbController.Port = ""
                            objX10DbController.Hub = ""
                            If (formControllerAddUpdatePortComboBox.SelectedIndex > 0) Then

                                objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                                arrPortHub = objDataRowViewPort(1).ToString().Split(arrSpearator, System.StringSplitOptions.None) ' ex: "0003.0004"
                                If (arrPortHub.Length > 1) Then
                                    objX10DbController.Port = arrPortHub(0)  ' ex: "0003"
                                    objX10DbController.Hub = arrPortHub(1)  ' ex: "0004"
                                End If

                            End If ' END - CM15A_formControllerAddUpdatePortComboBox

                            objX10DbController.AppKey = ""
                            objX10DbController.UID = ""

                            strTryStep = "CM15A_getDuskDawnResolutionFromSelectedIndex"
                            ' Dusk Dawn Resolution for CM15A X10 Controller must be in Multiples of 8 (ex: 8 or 16 or 32).
                            objX10DbController.DuskDawnResolution = getDuskDawnResolutionFromSelectedIndex(formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex)

                            strTryStep = "CM15A_getTransceiverHouseCodesCheckBox"
                            ' getTransceiverHouseCodesCheckBox(ByRef strTransceiverHouseCodes As String, ByRef objTransceiverHouseCodeMap As TrekkerPhotoArt.X10Include.X10DbHouseCodeMap)
                            Call getTransceiverHouseCodesCheckBox(objX10DbController.TransceiverHouseCodes, objX10DbController.TransceiverHouseCodeMap)
                            If (objX10DbController.TransceiverHouseCodeMap.status = "") Then

                                If (objX10DbController.HouseCode = "" Or objX10DbController.Port = "" Or objX10DbController.Hub = "" Or objX10DbController.DuskDawnResolution = 0) Then
                                    objX10DbController = Nothing
                                    Windows.Forms.MessageBox.Show("Missing Controller's HouseCode or USB Port.Hub or Dusk/Dawn Resolution", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                End If

                            Else
                                objX10DbController = Nothing
                                Windows.Forms.MessageBox.Show("Problem with Controller's selected Transceiver House Code(s): " & objX10DbController.TransceiverHouseCodeMap.status, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        Case "WM100"

                            objX10DbController.HouseCode = ""

                            objX10DbController.TransceiverHouseCodes = ""
                            objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                            objX10DbController.TransceiverHouseCodeMap.status = ""
                            objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                            objX10DbController.TransceiverHouseCodeMap.byte2 = 0

                            strTryStep = "WM100_formControllerAddUpdatePortValueLabel"
                            objX10DbController.Port = formControllerAddUpdatePortValueLabel.Text()  ' ex: "WIFI"
                            objX10DbController.Hub = ""
                            objX10DbController.AppKey = formControllerAddUpdateAppKeyTextBox.Text() ' ex: "26d884ce-9f25-948537"
                            objX10DbController.UID = formControllerAddUpdateUIDTextBox.Text()       ' ex: "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"
                            objX10DbController.DuskDawnResolution = 0

                            If (objX10DbController.AppKey = "" Or objX10DbController.UID = "") Then
                                objX10DbController = Nothing
                                Windows.Forms.MessageBox.Show("Missing Controller's AppKey or UID.", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        Case Else
                            objX10DbController = Nothing
                            Windows.Forms.MessageBox.Show("Missing or Unknown Controller Model """ & objX10DbController.ControllerType & """.", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    End Select

                    If (Not objX10DbController Is Nothing) Then

                        strTryStep = "nsX10DbMethods.addUpdateControllerToX10db"
                        ' nsX10DbMethods.addUpdateControllerToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intRowsAffected As Integer) As String
                        strStatus = nsX10DbMethods.addUpdateControllerToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbController, intRowsAffected)
                        If (strStatus = "") Then

                            If (intRowsAffected > 0) Then
                                formControllerAddUpdateIDLabelText.Text() = objX10DbController.ControllerID.ToString()

                                If (formControllerAddUpdate_AddUpdateButton.Text() = "Add") Then
                                    formControllerAddUpdate_AddUpdateButton.Text() = "Update"
                                    formControllerAddUpdate_StatusLabel.Text = "Successfully Added"
                                    formControllerAddUpdate_DeleteButton.Visible = True
                                Else
                                    formControllerAddUpdate_StatusLabel.Text = "Successfully Updated"
                                End If

                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                formControllerAddUpdate_CancelButton.Text() = "Done"

                                objFormControllerEdit = New formControllerEdit
                                objFormControllerEdit.formControllerEdit_BringToFrontLabel.Text() = "N"

                                formControllerAddUpdateOperationsGroupBox.Visible = True
                                Select Case objX10DbController.ControllerType.ToUpper()
                                    Case "CP290"
                                        formControllerAddUpdate_GetStatusButton.Visible = True
                                        formControllerAddUpdate_SetBaseHouseCodeButton.Visible = True
                                        formControllerAddUpdate_SetClockButton.Visible = True
                                        formControllerAddUpdate_DownloadButton.Visible = True
                                    Case "CM15A"
                                        formControllerAddUpdate_GetStatusButton.Visible = True
                                        formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                                        formControllerAddUpdate_SetClockButton.Visible = True
                                        formControllerAddUpdate_DownloadButton.Visible = True
                                    Case "WM100"
                                        formControllerAddUpdate_GetStatusButton.Visible = True
                                        formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                                        formControllerAddUpdate_SetClockButton.Visible = True
                                        formControllerAddUpdate_DownloadButton.Visible = True
                                    Case Else
                                        formControllerAddUpdate_GetStatusButton.Visible = False
                                        formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                                        formControllerAddUpdate_SetClockButton.Visible = False
                                        formControllerAddUpdate_DownloadButton.Visible = False
                                End Select

                                ' Refresh DataSet on Form formControllerEdit if it's active.
                                If objFormCollection.OfType(Of formControllerEdit).Any Then

                                    objFormControllerEdit = objFormCollection.Item("formControllerEdit")

                                    ' formControllerEdit_GetControllersDataSet() As String
                                    strStatus = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
                                    If (strStatus = "") Then
                                        objFormControllerEdit.Activate()
                                    Else
                                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_AddUpdateButton_Click(): " & strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    End If ' END - formControllerEdit_GetControllersDataSet()

                                End If

                            Else
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                If (formControllerAddUpdate_AddUpdateButton.Text() = "Add") Then
                                    Windows.Forms.MessageBox.Show("Problem adding Controller to X10 Db.", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                Else
                                    Windows.Forms.MessageBox.Show("Problem modifying Controller to X10 Db.", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If
                            End If

                        Else
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            If (formControllerAddUpdate_AddUpdateButton.Text() = "Add") Then
                                Windows.Forms.MessageBox.Show("Problem adding Controller to X10 Db." & vbCrLf & strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Else
                                Windows.Forms.MessageBox.Show("Problem modifying Controller to X10 Db." & vbCrLf & strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If
                        End If ' END - nsX10DbMethods.addUpdateControllerToX10db()

                    End If

                End If ' END - nsX10DbMethods.getX10DbController()

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            End If ' END - Was Something Missing?

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_AddUpdateButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
            objX10DbController = Nothing
            objDataRowViewControllerModel = Nothing
            objDataRowViewHouseCode = Nothing
            objDataRowViewPort = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_AddUpdateButton_Click()

    Private Sub formControllerAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formControllerAddUpdate_CancelButton_Click()

    Private Sub formControllerAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing
        Dim strControllerType As String = ""
        Dim strControllerTypeID As String = ""

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim intControllerID As Integer = Nothing

        Dim intModuleCount As Integer = 0

        Dim bRemoveController As Boolean = False

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormControllerEdit As formControllerEdit = Nothing

        Try

            formControllerAddUpdate_StatusLabel.Text = ""
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

            If (formControllerAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing ControllerID", "formControllerAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                intControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)

                ' checkControllerForModules(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef intModuleCount As Integer) As String
                strStatus = checkControllerForModules(strConnectionString, strProvider, intControllerID, intModuleCount)
                If (strStatus = "") Then

                    If (intModuleCount > 0) Then
                        If Windows.Forms.MessageBox.Show("Confirm removal of Controller" & vbCrLf & """" & formControllerAddUpdateNameTextBox.Text() & """ [" & formControllerAddUpdateIDLabelText.Text() & "]?" & vbCrLf & vbCrLf & "Important! Controller has " & intModuleCount.ToString() & " assigned Module(s).  Unless the Module(s) are re-assinged to another Controller, they will also be removed.", "Confirm", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Stop) = Windows.Forms.DialogResult.Yes Then
                            bRemoveController = True
                        End If ' END - Confirm removal of Controller?
                    Else
                        If Windows.Forms.MessageBox.Show("Confirm removal of Controller" & vbCrLf & """" & formControllerAddUpdateNameTextBox.Text() & """ [" & formControllerAddUpdateIDLabelText.Text() & "]?", "Confirm", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Stop) = Windows.Forms.DialogResult.Yes Then
                            bRemoveController = True
                        End If ' END - Confirm removal of Controller?
                    End If

                Else
                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                    Windows.Forms.MessageBox.Show("Problem removing Controller from X10 Db." & vbCrLf & strStatus, "formControllerAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - checkControllerForModules()

                If bRemoveController Then

                    objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                    strControllerTypeID = objDataRowViewControllerModel(0).ToString
                    strControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CP290"

                    objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController
                    objX10DbController.ControllerID = intControllerID
                    objX10DbController.ControllerName = formControllerAddUpdateNameTextBox.Text()
                    objX10DbController.ControllerTypeID = CType(strControllerTypeID, Integer)
                    objX10DbController.ControllerType = strControllerType           ' ex: "CP290" | "CM15A" | "WM100"
                    objX10DbController.ControllerDescription = ""
                    objX10DbController.HouseCode = ""
                    objX10DbController.Port = ""
                    objX10DbController.AppKey = ""
                    objX10DbController.UID = ""

                    ' nsX10DbMethods.removeX10ControllerfromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.removeX10ControllerFromX10Db(strConnectionString, strProvider, objX10DbController, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then

                            formControllerAddUpdateIDLabelText.Text() = ""
                            formControllerAddUpdate_AddUpdateButton.Text() = "Add"
                            formControllerAddUpdate_StatusLabel.Text = "Successfully Deleted"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formControllerAddUpdate_CancelButton.Text() = "Done"
                            formControllerAddUpdate_DeleteButton.Visible = False

                            formControllerAddUpdateOperationsGroupBox.Visible = False
                            formControllerAddUpdate_GetStatusButton.Visible = False
                            formControllerAddUpdate_SetBaseHouseCodeButton.Visible = False
                            formControllerAddUpdate_SetClockButton.Visible = False
                            formControllerAddUpdate_DownloadButton.Visible = False

                            objFormControllerEdit = New formControllerEdit
                            objFormControllerEdit.formControllerEdit_BringToFrontLabel.Text() = "N"

                            ' Refresh DataSet on Form formControllerEdit if it's active.
                            If objFormCollection.OfType(Of formControllerEdit).Any Then

                                objFormControllerEdit = objFormCollection.Item("formControllerEdit")

                                ' The row has been deleted.
                                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormControllerEdit = -1
                                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormControllerEdit = -1

                                ' formControllerEdit_GetControllersDataSet() As String
                                strStatus = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
                                If (strStatus = "") Then
                                    objFormControllerEdit.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formControllerAddUpdate_DeleteButton_Click(): " & strStatus, "formControllerAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formControllerEdit_GetControllersDataSet()

                            End If

                        Else
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            Windows.Forms.MessageBox.Show("Problem removing Controller from X10 Db.", "formControllerAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If ' END - RowsAffected

                    Else
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Controller from X10 Db." & vbCrLf & strStatus, "formControllerAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - nsX10DbMethods.addUpdateControllerToX10db()

                End If ' END = bRemoveController

            End If ' END - Is there a ControllerID?

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
            objX10DbController = Nothing
            objDataRowViewControllerModel = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_DeleteButton_Click()


    Private Sub formControllerAddUpdate_GetStatusButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_GetStatusButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing
        Dim objDataRowViewPort As System.Data.DataRowView = Nothing
        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing

        Dim arrPortHub() As String = Nothing
        Dim arrSpearator() As Char = {"."}

        Dim intX10Status As Integer = -1
        Dim intMINUTES As Integer = -1
        Dim intHOURS As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intBday As Integer = -1
        Dim intHC As Integer = -1

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing
        Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
        Dim objGetX10TransceiverSetupClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10TransceiverSetupClass = Nothing
        Dim objGetX10DuskDawnClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10DuskDawnClass = Nothing
        Dim objGetX10MemoryVersionStampClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10MemoryVersionStampClass = Nothing

        Dim objDayOfYearDate As System.DateTime = Nothing

        Dim strMessage As String = ""

        Try

            If formControllerAddUpdateActiveCheckBox.Checked Then

                objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                objX10DbController.ControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)
                objX10DbController.ControllerName = formControllerAddUpdateNameTextBox.Text()

                objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                objX10DbController.ControllerTypeID = objDataRowViewControllerModel(0).ToString
                objX10DbController.ControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CP290"

                objX10DbController.Port = ""
                objX10DbController.Hub = ""
                objX10DbController.HouseCode = ""
                objX10DbController.AppKey = ""
                objX10DbController.UID = ""

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                strMessage = "  Getting Controller " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "] Status."
                strMessage &= vbCrLf & "  Please Wait...."
                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                Call formConsoleMessages.DisplayMessage(strMessage, "Get Status")

                Select Case objX10DbController.ControllerType.ToUpper()
                    Case "CP290"

                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                        objX10DbController.Port = objDataRowViewPort(1).ToString ' ex: "COM3"

                        objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                        objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                        ' nsX10CP290Methods.getX10Time(ByVal strPortName As String, ByRef intX10Status As Integer, ByRef intMINUTES As Integer, ByRef intHOURS As Integer, ByRef intBday As Integer, ByRef intHC As Integer) As String
                        strStatus = nsX10CP290Methods.getX10Time(objX10DbController.Port, intX10Status, intMINUTES, intHOURS, intBday, intHC)
                        If (strStatus = "") Then

                            If (intHOURS = 12) Then
                                ' PM
                                strAMPM = "PM"
                                intHourAMPM = intHOURS
                            ElseIf (intHOURS > 12) Then
                                ' PM
                                strAMPM = "PM"
                                intHourAMPM = intHOURS - 12
                            ElseIf (intHOURS = 0) Then
                                ' AM
                                strAMPM = "AM"
                                intHourAMPM = 12
                            Else
                                ' AM
                                strAMPM = "AM"
                                intHourAMPM = intHOURS
                            End If

                            strMessage = "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"
                            strMessage &= vbCrLf & "  Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status)
                            strMessage &= vbCrLf & "  Time: " & nsX10DbMethods.DayCodeToStringOfFullDays(intBday) & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString, 2) & " " & strAMPM
                            strMessage &= vbCrLf & "  Base House Code: " & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHC)
                            strMessage &= vbCrLf & vbCrLf & "Success!"
                            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                            Call formConsoleMessages.DisplayMessage(strMessage, "Get Status")

                            formControllerAddUpdate_StatusLabel.Text = "Success"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formControllerAddUpdate_CancelButton.Text() = "Done"

                        Else
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        End If ' END - nsX10CP290Methods.getX10Time()

                    Case "CM15A"

                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                        arrPortHub = objDataRowViewPort(1).ToString().Split(arrSpearator, System.StringSplitOptions.None) ' ex: "0003.0004"
                        If (arrPortHub.Length > 1) Then
                            objX10DbController.Port = arrPortHub(0)  ' ex: "0003"
                            objX10DbController.Hub = arrPortHub(1)  ' ex: "0004"
                        End If

                        objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                        objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                        ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                        strStatus = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                        If (strStatus = "") Then

                            If (objX10DbUSBPort Is Nothing) Then
                                strStatus = "getX10DbUSBPort(): USB Port=""" & objX10DbController.Port & """ Hub=""" & objX10DbController.Hub & """ not found in X10Db."
                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            Else

                                ' getX10ControllerStatusClass nsX10CM15AMethods.getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                If (objGetX10ControllerStatusClass.status = "") Then

                                    If (objGetX10ControllerStatusClass.currentTimeHours = 12) Then
                                        ' PM
                                        strAMPM = "PM"
                                        intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                    ElseIf (objGetX10ControllerStatusClass.currentTimeHours > 12) Then
                                        ' PM
                                        strAMPM = "PM"
                                        intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours - 12
                                    ElseIf (objGetX10ControllerStatusClass.currentTimeHours = 0) Then
                                        ' AM
                                        strAMPM = "AM"
                                        intHourAMPM = 12
                                    Else
                                        ' AM
                                        strAMPM = "AM"
                                        intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                    End If

                                    ' getX10TransceiverSetupClass nsX10CM15AMethods.getX10TransceiverSetup(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                    objGetX10TransceiverSetupClass = nsX10CM15AMethods.getX10TransceiverSetup(objX10DbController, objX10DbUSBPort)
                                    If (objGetX10TransceiverSetupClass.status = "") Then

                                        ' getX10DuskDawnClass nsX10CM15AMethods.getX10DuskDawn(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                        objGetX10DuskDawnClass = nsX10CM15AMethods.getX10DuskDawn(objX10DbController, objX10DbUSBPort)
                                        If (objGetX10DuskDawnClass.status = "") Then

                                            strMessage = "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"

                                            ' TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_StartOfTimerInitiatorsMemoryAddress = 0x0018
                                            If (objGetX10DuskDawnClass.startOfMacroInitiatorsMemoryAddress = 0 Or objGetX10DuskDawnClass.startOfMacroInitiatorsMemoryAddress = TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.CM15A_StartOfTimerInitiatorsMemoryAddress) Then
                                                strMessage &= vbCrLf & "  Status: OK - Timer/Macro Initiators NOT Programmed"
                                            Else
                                                strMessage &= vbCrLf & "  Status: OK - Timer/Macro Initiators Programmed"
                                            End If

                                            strMessage &= vbCrLf & "  Firmware Revision Level: " & objGetX10ControllerStatusClass.firmwareRevisionLevel
                                            strMessage &= vbCrLf & "  Battery Timer: " & objGetX10ControllerStatusClass.batteryTimer.ToString()
                                            strMessage &= vbCrLf & "  Time: " & intHourAMPM.ToString().PadLeft(2, "0") & ":" & objGetX10ControllerStatusClass.currentTimeMinutes.ToString().PadLeft(2, "0") & ":" & objGetX10ControllerStatusClass.currentTimeSeconds.ToString().PadLeft(2, "0") & " " & strAMPM
                                            strMessage &= vbCrLf & "  Day of Week: " & objGetX10ControllerStatusClass.currentTimeDayOfWeek
                                            strMessage &= vbCrLf & "  Year Day: " & objGetX10ControllerStatusClass.currentTimeYearDay.ToString()
                                            strMessage &= vbCrLf & "  Year Day Date: " & objGetX10ControllerStatusClass.objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")
                                            strMessage &= vbCrLf & "  Monitored House Code: " & objGetX10ControllerStatusClass.monitoredHouseCode

                                            strMessage &= vbCrLf & "  Monitored Devices Currently Addressed:"
                                            strMessage &= vbCrLf & "    Odd  0x" & (CType(((objGetX10ControllerStatusClass.monitoredDevicesCurrentlyAddressed >> 8) And &HFF), Byte)).ToString("X02").ToLower() & " = " & System.Convert.ToString(CType(((objGetX10ControllerStatusClass.monitoredDevicesCurrentlyAddressed >> 8) And &HFF), Byte), 2).PadLeft(8, "0") & ": " & nsX10CM15AMethods.x10DeviceCodeMapToStringOdd(CType(((objGetX10ControllerStatusClass.monitoredDevicesCurrentlyAddressed >> 8) And &HFF), Byte))
                                            strMessage &= vbCrLf & "    Even 0x" & (CType((objGetX10ControllerStatusClass.monitoredDevicesCurrentlyAddressed And &HFF), Byte)).ToString("X02").ToLower() & " = " & System.Convert.ToString(CType((objGetX10ControllerStatusClass.monitoredDevicesCurrentlyAddressed And &HFF), Byte), 2).PadLeft(8, "0") & ": " & nsX10CM15AMethods.x10DeviceCodeMapToStringEven(CType((objGetX10ControllerStatusClass.monitoredDevicesCurrentlyAddressed And &HFF), Byte))

                                            strMessage &= vbCrLf & "  Monitored Devices On/Off Status:"
                                            strMessage &= vbCrLf & "    Odd  0x" & (CType(((objGetX10ControllerStatusClass.monitoredDevicesOnOffStatus >> 8) And &HFF), Byte)).ToString("X02").ToLower() & " = " & System.Convert.ToString(CType(((objGetX10ControllerStatusClass.monitoredDevicesOnOffStatus >> 8) And &HFF), Byte), 2).PadLeft(8, "0") & ": " & nsX10CM15AMethods.x10DeviceCodeMapToStringOdd(CType(((objGetX10ControllerStatusClass.monitoredDevicesOnOffStatus >> 8) And &HFF), Byte))
                                            strMessage &= vbCrLf & "    Even 0x" & (CType((objGetX10ControllerStatusClass.monitoredDevicesOnOffStatus And &HFF), Byte)).ToString("X02").ToLower() & " = " & System.Convert.ToString(CType((objGetX10ControllerStatusClass.monitoredDevicesOnOffStatus And &HFF), Byte), 2).PadLeft(8, "0") & ": " & nsX10CM15AMethods.x10DeviceCodeMapToStringEven(CType((objGetX10ControllerStatusClass.monitoredDevicesOnOffStatus And &HFF), Byte))

                                            strMessage &= vbCrLf & "  Monitored Devices Dimmer Status:"
                                            strMessage &= vbCrLf & "    Odd  0x" & (CType(((objGetX10ControllerStatusClass.monitoredDevicesDimStatus >> 8) And &HFF), Byte)).ToString("X02").ToLower() & " = " & System.Convert.ToString(CType(((objGetX10ControllerStatusClass.monitoredDevicesDimStatus >> 8) And &HFF), Byte), 2).PadLeft(8, "0") & ": " & nsX10CM15AMethods.x10DeviceCodeMapToStringOdd(CType(((objGetX10ControllerStatusClass.monitoredDevicesDimStatus >> 8) And &HFF), Byte))
                                            strMessage &= vbCrLf & "    Even 0x" & (CType((objGetX10ControllerStatusClass.monitoredDevicesDimStatus And &HFF), Byte)).ToString("X02").ToLower() & " = " & System.Convert.ToString(CType((objGetX10ControllerStatusClass.monitoredDevicesDimStatus And &HFF), Byte), 2).PadLeft(8, "0") & ": " & nsX10CM15AMethods.x10DeviceCodeMapToStringEven(CType((objGetX10ControllerStatusClass.monitoredDevicesDimStatus And &HFF), Byte))

                                            strMessage &= vbCrLf & "  Transceiver House Codes: " & objGetX10TransceiverSetupClass.TransceiverHouseCodes

                                            objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objGetX10DuskDawnClass.dayOfYearDaylightSavingsTurnForward)
                                            strMessage &= vbCrLf & "  Daylight Savings Turn Forward: " + objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                            objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objGetX10DuskDawnClass.dayOfYearDaylightSavingsTurnBackward)
                                            strMessage &= vbCrLf & "  Daylight Savings Turn Backward: " + objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                            strMessage &= vbCrLf & "  Dusk/Dawn Resolution: " + objGetX10DuskDawnClass.duskDawnResolution.ToString() + " days"
                                            If (objGetX10DuskDawnClass.startOfDuskDawnTableMemoryAddress = 0) Then
                                                strMessage &= vbCrLf & "  No Dusk/Dawn table entries were found."
                                            Else
                                                strMessage &= vbCrLf & "  Number of Dusk/Dawn table entries: " + objGetX10DuskDawnClass.objGetX10DuskDawnTableEntryClasses.Count.ToString()
                                            End If

                                            ' getX10MemoryVersionStampClass nsX10CM15AMethods.getX10MemoryVersionStamp(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                            objGetX10MemoryVersionStampClass = nsX10CM15AMethods.getX10MemoryVersionStamp(objX10DbController, objX10DbUSBPort)
                                            If (objGetX10MemoryVersionStampClass.status = "") Then

                                                strMessage &= vbCrLf & "  Memory Version:"
                                                strMessage &= vbCrLf & "    " & objGetX10MemoryVersionStampClass.dtmVersion.ToLongDateString() & " " + objGetX10MemoryVersionStampClass.dtmVersion.ToLongTimeString() & " (UTC" + System.TimeZoneInfo.Local.GetUtcOffset(objGetX10MemoryVersionStampClass.dtmVersion).TotalHours.ToString() & ")"
                                                strMessage &= vbCrLf & vbCrLf & "Success!"
                                                ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                                Call formConsoleMessages.DisplayMessage(strMessage, "Get Status")

                                                formControllerAddUpdate_StatusLabel.Text = "Success"
                                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                                formControllerAddUpdate_CancelButton.Text() = "Done"

                                            Else
                                                Windows.Forms.MessageBox.Show(objGetX10MemoryVersionStampClass.status, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                            End If ' END - nsX10CM15AMethods.getX10MemoryVersionStamp()

                                        Else
                                            Windows.Forms.MessageBox.Show(objGetX10DuskDawnClass.status, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                        End If ' END - nsX10CM15AMethods.getX10DuskDawn()

                                    Else
                                        Windows.Forms.MessageBox.Show(objGetX10TransceiverSetupClass.status, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                    End If ' END - nsX10CM15AMethods.getX10TransceiverSetup()

                                Else
                                    Windows.Forms.MessageBox.Show(objGetX10ControllerStatusClass.status, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                            End If

                        Else
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        End If ' END - nsX10DbMethods.getX10DbUSBPort()

                    Case "WM100"

                        objX10DbController.Port = formControllerAddUpdatePortValueLabel.Text()  ' ex: "WIFI"
                        objX10DbController.AppKey = formControllerAddUpdateAppKeyTextBox.Text() ' ex: "26d884ce-9f25-948537"
                        objX10DbController.UID = formControllerAddUpdateUIDTextBox.Text()       ' ex: "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"


                    Case Else
                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_GetStatusButton_Click(): Unknown Controller Model: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                End Select ' END  - UpdateController_SelectCaseControllerType

            Else
                Windows.Forms.MessageBox.Show("formControllerAddUpdate_GetStatusButton_Click(): Controller Active NOT checked: Unable to Get Controller Status.", "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdateActiveCheckBox

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_GetStatusButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_GetStatusButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbController = Nothing
            objX10DbUSBPort = Nothing
            objDataRowViewHouseCode = Nothing
            objGetX10ControllerStatusClass = Nothing
            objGetX10TransceiverSetupClass = Nothing
            objGetX10DuskDawnClass = Nothing
            objGetX10MemoryVersionStampClass = Nothing
            objDayOfYearDate = Nothing
            objDataRowViewControllerModel = Nothing
            objDataRowViewPort = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_GetStatusButton_Click()

    Private Sub formControllerAddUpdate_SetBaseHouseCodeButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_SetBaseHouseCodeButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing
        Dim strControllerType As String = ""

        Dim strControllerName As String = ""

        Dim objDataRowViewPort As System.Data.DataRowView = Nothing
        Dim strPortName As String = ""

        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing
        Dim strHouseCode As String = ""
        Dim intHousecode As Integer = -1

        Dim intX10Status As Integer = -1
        Dim intMINUTES As Integer = -1
        Dim intHOURS As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intBday As Integer = -1
        Dim intHC As Integer = -1

        Dim strMessage As String = ""

        Try

            If formControllerAddUpdateActiveCheckBox.Checked Then

                formControllerAddUpdate_StatusLabel.Text = ""
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

                objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                strControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CP290"

                strControllerName = formControllerAddUpdateNameTextBox.Text()

                strMessage = "  Set Controller " & strControllerName & " [" & strControllerType & "] Base House Code."
                strMessage &= vbCrLf & vbCrLf & "Please wait......."
                Call formConsoleMessages.DisplayMessage(strMessage, "Set Base House Code")

                Select Case strControllerType.ToUpper()
                    Case "CP290"

                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                        strPortName = objDataRowViewPort(1).ToString ' ex: "COM3"

                        objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                        strHouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                        ' nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(ByVal strHouseCode As String, ByRef intHousecode As Integer) As String
                        strStatus = nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(strHouseCode, intHousecode)
                        If (strStatus = "") Then

                            ' nsX10CP290Methods.downloadX10BaseHousecode(ByVal strPortName As String, ByVal intHousecode As Integer) As String
                            strStatus = nsX10CP290Methods.downloadX10BaseHousecode(strPortName, intHousecode)
                            If (strStatus = "") Then

                                ' nsX10CP290Methods.getX10Time(ByVal strPortName As String, ByRef intX10Status As Integer, ByRef intMINUTES As Integer, ByRef intHOURS As Integer, ByRef intBday As Integer, ByRef intHC As Integer) As String
                                strStatus = nsX10CP290Methods.getX10Time(strPortName, intX10Status, intMINUTES, intHOURS, intBday, intHC)
                                If (strStatus = "") Then

                                    If (intHOURS = 12) Then
                                        ' PM
                                        strAMPM = "PM"
                                        intHourAMPM = intHOURS
                                    ElseIf (intHOURS > 12) Then
                                        ' PM
                                        strAMPM = "PM"
                                        intHourAMPM = intHOURS - 12
                                    ElseIf (intHOURS = 0) Then
                                        ' AM
                                        strAMPM = "AM"
                                        intHourAMPM = 12
                                    Else
                                        ' AM
                                        strAMPM = "AM"
                                        intHourAMPM = intHOURS
                                    End If

                                    strMessage = "  Name: " & strControllerName & " [" & strControllerType & "]"
                                    strMessage &= vbCrLf & "  Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status)
                                    strMessage &= vbCrLf & "  Time: " & nsX10DbMethods.DayCodeToStringOfFullDays(intBday) & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString, 2) & " " & strAMPM
                                    strMessage &= vbCrLf & "  Base House Code: " & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHC)
                                    strMessage &= vbCrLf & vbCrLf & "Success!"
                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Set Base House Code")

                                    formControllerAddUpdate_StatusLabel.Text = "Success"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                    formControllerAddUpdate_CancelButton.Text() = "Done"

                                Else
                                    Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetBaseHouseCodeButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If ' END - nsX10CP290Methods.getX10Time()

                            Else
                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetBaseHouseCodeButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            End If ' END - nsX10CP290Methods.downloadX10BaseHousecode()

                        Else
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetBaseHouseCodeButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        End If ' END - nsX10CP290Methods.x10HouseCodeAsStringToBinary()

                    Case "CM15A"

                    Case "WM100"

                    Case Else
                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_SetBaseHouseCodeButton_Click(): Unknown Controller Model: """ & strControllerType & """", "formControllerAddUpdate_SetBaseHouseCodeButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                End Select ' END  - UpdateController_SelectCaseControllerType

            Else
                Windows.Forms.MessageBox.Show("formControllerAddUpdate_SetBaseHouseCodeButton_Click(): Controller Active NOT checked: Unable to Set Controller Base House Code.", "formControllerAddUpdate_SetBaseHouseCodeButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdateActiveCheckBox

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_SetBaseHouseCodeButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetBaseHouseCodeButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDataRowViewControllerModel = Nothing
            objDataRowViewPort = Nothing
            objDataRowViewHouseCode = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_SetBaseHouseCodeButton_Click()

    Private Sub formControllerAddUpdate_SetClockButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_SetClockButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim sqlString As String = ""
        Dim intRowsAffected As Integer = -1

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing
        Dim objDataRowViewPort As System.Data.DataRowView = Nothing
        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing

        Dim arrPortHub() As String = Nothing
        Dim arrSpearator() As Char = {"."}

        Dim intX10Status As Integer = -1
        Dim intMINUTES As Integer = -1
        Dim intHOURS As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intBday As Integer = -1
        Dim intHC As Integer = -1

        Dim objDateTimeNow As System.DateTime = System.DateTime.Now()

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing
        Dim objSetX10TimeClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.setX10TimeClass = Nothing
        Dim objPutX10TransceiverSetupClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putX10TransceiverSetupClass = Nothing
        Dim bClearTransceiverSetup As Boolean = False
        Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
        Dim objGetX10TransceiverSetupClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10TransceiverSetupClass = Nothing
        Dim objGetX10DuskDawnClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10DuskDawnClass = Nothing
        Dim objGetX10MemoryVersionStampClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10MemoryVersionStampClass = Nothing

        Dim objDayOfYearDate As System.DateTime = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormControllerEdit As formControllerEdit = Nothing

        Dim strMessage As String = ""

        Try

            If formControllerAddUpdateActiveCheckBox.Checked Then

                formControllerAddUpdate_StatusLabel.Text = ""
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

                objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                objX10DbController.ControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)
                objX10DbController.ControllerName = formControllerAddUpdateNameTextBox.Text()

                objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                objX10DbController.ControllerTypeID = objDataRowViewControllerModel(0).ToString
                objX10DbController.ControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CP290"

                objX10DbController.Port = ""
                objX10DbController.Hub = ""
                objX10DbController.HouseCode = ""
                objX10DbController.AppKey = ""
                objX10DbController.UID = ""
                objX10DbController.TransceiverHouseCodes = ""

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                Select Case objX10DbController.ControllerType.ToUpper()
                    Case "CP290"

                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                        objX10DbController.Port = objDataRowViewPort(1).ToString ' ex: "COM3"

                        objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                        objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                        objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                        objX10DbController.TransceiverHouseCodeMap.status = ""
                        objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                        objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                        objX10DbController.DuskDawnResolution = 0

                        strMessage = "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"

                        strMessage &= vbCrLf & "Set CP290 Clock to:" & vbCrLf & "  " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & " " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") "

                        strMessage &= vbCrLf & vbCrLf & "Please wait......."
                        Call formConsoleMessages.DisplayMessage(strMessage, "Set Clock")

                        ' nsX10CP290Methods.setX10Time(ByVal strPortName As String, ByVal dtmNow As System.DateTime, ByRef intgX10Status As Integer, ByRef intgMINUTES As Integer, ByRef intgHOURS As Integer, ByRef intgBday As Integer, ByRef intgHC As Integer) As String
                        strStatus = nsX10CP290Methods.setX10Time(objX10DbController.Port, objDateTimeNow, intX10Status, intMINUTES, intHOURS, intBday, intHC)
                        If (strStatus = "") Then

                            If (intHOURS = 12) Then
                                ' PM
                                strAMPM = "PM"
                                intHourAMPM = intHOURS
                            ElseIf (intHOURS > 12) Then
                                ' PM
                                strAMPM = "PM"
                                intHourAMPM = intHOURS - 12
                            ElseIf (intHOURS = 0) Then
                                ' AM
                                strAMPM = "AM"
                                intHourAMPM = 12
                            Else
                                ' AM
                                strAMPM = "AM"
                                intHourAMPM = intHOURS
                            End If

                            strMessage &= vbCrLf & "  Controller Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status)
                            strMessage &= vbCrLf & "  Time: " & nsX10DbMethods.DayCodeToStringOfFullDays(intBday) & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString, 2) & " " & strAMPM
                            strMessage &= vbCrLf & "  Base House Code: " & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHC)
                            strMessage &= vbCrLf & vbCrLf & "Success!"
                            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                            Call formConsoleMessages.DisplayMessage(strMessage, "Set Clock")

                            formControllerAddUpdate_StatusLabel.Text = "Success"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formControllerAddUpdate_CancelButton.Text() = "Done"

                        Else
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        End If ' END - nsX10CP290Methods.setX10Time()

                    Case "CM15A"

                        ' Dusk Dawn Resolution for CM15A X10 Controller must be in Multiples of 8 (ex: 8 or 16 or 32).
                        objX10DbController.DuskDawnResolution = getDuskDawnResolutionFromSelectedIndex(formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex)
                        If (objX10DbController.DuskDawnResolution = 0) Then
                            objX10DbController = Nothing
                            Windows.Forms.MessageBox.Show("Missing Controller's Dusk/Dawn Resolution", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else

                            strMessage = "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"

                            objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                            arrPortHub = objDataRowViewPort(1).ToString().Split(arrSpearator, System.StringSplitOptions.None) ' ex: "0003.0004"
                            If (arrPortHub.Length > 1) Then
                                objX10DbController.Port = arrPortHub(0)  ' ex: "0003"
                                objX10DbController.Hub = arrPortHub(1)  ' ex: "0004"
                            End If

                            ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                            strStatus = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                            If (strStatus = "") Then

                                If (objX10DbUSBPort Is Nothing) Then
                                    strStatus = "getX10DbUSBPort(): USB Port=""" & objX10DbController.Port & """ Hub=""" & objX10DbController.Hub & """ not found in X10Db."
                                    Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                Else

                                    objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                                    objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                                    Call getTransceiverHouseCodesCheckBox(objX10DbController.TransceiverHouseCodes, objX10DbController.TransceiverHouseCodeMap)
                                    If (objX10DbController.TransceiverHouseCodeMap.status = "") Then

                                        If (objX10DbController.TransceiverHouseCodes = "") Then
                                            bClearTransceiverSetup = True
                                            strMessage &= vbCrLf & "Clear Transceiver Setup: No Transceiver House Codes are checked."
                                        Else
                                            bClearTransceiverSetup = False
                                            strMessage &= vbCrLf & "Set Transceiver Setup:" & vbCrLf & "  Transceiver House Codes: " & objX10DbController.TransceiverHouseCodes.Replace(",", "")
                                        End If

                                        strMessage &= vbCrLf & "Update to X10 Db Controllers table:"
                                        strMessage &= vbCrLf & "  Monitored House Code: " & objX10DbController.HouseCode
                                        strMessage &= vbCrLf & "  Transceiver House Codes: " & objX10DbController.TransceiverHouseCodes
                                        strMessage &= vbCrLf & "  Dusk/Dawn Resolution: " & objX10DbController.DuskDawnResolution.ToString()
                                        sqlString = "UPDATE Controllers SET HouseCode='" & objX10DbController.HouseCode & "',TransceiverHouseCodes='" & objX10DbController.TransceiverHouseCodes & "',DuskDawnResolution=" & objX10DbController.DuskDawnResolution.ToString() & " WHERE ControllerID=" & objX10DbController.ControllerID.ToString() & ";"
                                        ' nsX10DbMethods.executeNonQueryX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal sqlString As String, ByRef intRowsAffected As Integer) As String
                                        strStatus = nsX10DbMethods.executeNonQueryX10db(strConnectionString, strProvider, sqlString, intRowsAffected)
                                        If (strStatus = "" And intRowsAffected > 0) Then

                                            strMessage &= vbCrLf & "Set CM15A Clock to:" & vbCrLf & "  " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & " " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") "

                                            strMessage &= vbCrLf & vbCrLf & "Please wait......."
                                            Call formConsoleMessages.DisplayMessage(strMessage, "Set Clock")

                                            ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                            objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "N", "N", "N")
                                            If (objSetX10TimeClass.status = "") Then

                                                ' putX10TransceiverSetupClass nsX10CM15AMethods.putX10TransceiverSetup(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, bool bClearTransceiverSetup)
                                                objPutX10TransceiverSetupClass = nsX10CM15AMethods.putX10TransceiverSetup(objX10DbController, objX10DbUSBPort, bClearTransceiverSetup)
                                                If (objPutX10TransceiverSetupClass.status = "") Then

                                                    strMessage &= vbCrLf & "Get CM15A Controller Status:"
                                                    ' getX10ControllerStatusClass nsX10CM15AMethods.getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                    objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                                    If (objGetX10ControllerStatusClass.status = "") Then

                                                        If (objGetX10ControllerStatusClass.currentTimeHours = 12) Then
                                                            ' PM
                                                            strAMPM = "PM"
                                                            intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                        ElseIf (objGetX10ControllerStatusClass.currentTimeHours > 12) Then
                                                            ' PM
                                                            strAMPM = "PM"
                                                            intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours - 12
                                                        ElseIf (objGetX10ControllerStatusClass.currentTimeHours = 0) Then
                                                            ' AM
                                                            strAMPM = "AM"
                                                            intHourAMPM = 12
                                                        Else
                                                            ' AM
                                                            strAMPM = "AM"
                                                            intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                        End If

                                                        strMessage &= vbCrLf & "  Controller Status: OK"
                                                        strMessage &= vbCrLf & "  Firmware Revision Level: " & objGetX10ControllerStatusClass.firmwareRevisionLevel
                                                        strMessage &= vbCrLf & "  Battery Timer: " & objGetX10ControllerStatusClass.batteryTimer.ToString()
                                                        strMessage &= vbCrLf & "  Time: " & objGetX10ControllerStatusClass.currentTimeDayOfWeek & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeMinutes.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeSeconds.ToString, 2) & " " & strAMPM
                                                        strMessage &= vbCrLf & "  Year Day: " & objGetX10ControllerStatusClass.currentTimeYearDay.ToString()
                                                        strMessage &= vbCrLf & "  Year Day Date: " & objGetX10ControllerStatusClass.objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")
                                                        strMessage &= vbCrLf & "  Monitored House Code: " & objGetX10ControllerStatusClass.monitoredHouseCode

                                                        ' getX10TransceiverSetupClass nsX10CM15AMethods.getX10TransceiverSetup(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                        objGetX10TransceiverSetupClass = nsX10CM15AMethods.getX10TransceiverSetup(objX10DbController, objX10DbUSBPort)
                                                        If (objGetX10TransceiverSetupClass.status = "") Then

                                                            ' getX10DuskDawnClass nsX10CM15AMethods.getX10DuskDawn(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                            objGetX10DuskDawnClass = nsX10CM15AMethods.getX10DuskDawn(objX10DbController, objX10DbUSBPort)
                                                            If (objGetX10DuskDawnClass.status = "") Then

                                                                strMessage &= vbCrLf & "  Transceiver House Codes: " & objGetX10TransceiverSetupClass.TransceiverHouseCodes

                                                                objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objGetX10DuskDawnClass.dayOfYearDaylightSavingsTurnForward)
                                                                strMessage &= vbCrLf & "  Daylight Savings Turn Forward: " + objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                                                objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objGetX10DuskDawnClass.dayOfYearDaylightSavingsTurnBackward)
                                                                strMessage &= vbCrLf & "  Daylight Savings Turn Backward: " + objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                                                strMessage &= vbCrLf & "  Dusk/Dawn Resolution: " + objGetX10DuskDawnClass.duskDawnResolution.ToString() + " days"
                                                                If (objGetX10DuskDawnClass.startOfDuskDawnTableMemoryAddress = 0) Then
                                                                    strMessage &= vbCrLf & "  No Dusk/Dawn table entries were found."
                                                                Else
                                                                    strMessage &= vbCrLf & "  Number of Dusk/Dawn table entries: " + objGetX10DuskDawnClass.objGetX10DuskDawnTableEntryClasses.Count.ToString()
                                                                End If

                                                                ' getX10MemoryVersionStampClass nsX10CM15AMethods.getX10MemoryVersionStamp(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                                objGetX10MemoryVersionStampClass = nsX10CM15AMethods.getX10MemoryVersionStamp(objX10DbController, objX10DbUSBPort)
                                                                If (objGetX10MemoryVersionStampClass.status = "") Then

                                                                    strMessage &= vbCrLf & "  Memory Version:"
                                                                    strMessage &= vbCrLf & "    " & objGetX10MemoryVersionStampClass.dtmVersion.ToLongDateString() & " " + objGetX10MemoryVersionStampClass.dtmVersion.ToLongTimeString() & " (UTC" + System.TimeZoneInfo.Local.GetUtcOffset(objGetX10MemoryVersionStampClass.dtmVersion).TotalHours.ToString() & ")"

                                                                    strMessage &= vbCrLf & "NOTE: Daylight Savings and Dusk/Dawn settings occur when"
                                                                    strMessage &= vbCrLf & "      """ & formControllerAddUpdate_DownloadButton.Text() & """ is performed."
                                                                    strMessage &= vbCrLf & vbCrLf & "Success!"
                                                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                                                    Call formConsoleMessages.DisplayMessage(strMessage, "Set Clock")

                                                                    formControllerAddUpdate_StatusLabel.Text = "Success"
                                                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                                                    formControllerAddUpdate_CancelButton.Text() = "Done"

                                                                    ' Refresh DataSet on Form formControllerEdit if it's active.
                                                                    If objFormCollection.OfType(Of formControllerEdit).Any Then

                                                                        objFormControllerEdit = objFormCollection.Item("formControllerEdit")

                                                                        ' formControllerEdit_GetControllersDataSet() As String
                                                                        strStatus = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
                                                                        If (strStatus = "") Then
                                                                            objFormControllerEdit.Activate()
                                                                        Else
                                                                            Windows.Forms.MessageBox.Show("formControllerAddUpdate_SetClockButton_Click(): " & strStatus, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                                        End If ' END - formControllerEdit_GetControllersDataSet()

                                                                    End If

                                                                Else
                                                                    Windows.Forms.MessageBox.Show(objGetX10MemoryVersionStampClass.status, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                                End If ' END - nsX10CM15AMethods.getX10MemoryVersionStamp()

                                                            Else
                                                                Windows.Forms.MessageBox.Show(objGetX10DuskDawnClass.status, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                            End If ' END - nsX10CM15AMethods.getX10DuskDawn()

                                                        Else
                                                            Windows.Forms.MessageBox.Show(objGetX10TransceiverSetupClass.status, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                        End If ' END - nsX10CM15AMethods.getX10TransceiverSetup()

                                                    Else
                                                        Windows.Forms.MessageBox.Show(objGetX10ControllerStatusClass.status, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                    End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                                                Else
                                                    Windows.Forms.MessageBox.Show(objPutX10TransceiverSetupClass.status, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                End If ' END - nsX10CM15AMethods.putX10TransceiverSetup()

                                            Else
                                                Windows.Forms.MessageBox.Show(objSetX10TimeClass.status, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                            End If ' END - nsX10CM15AMethods.setX10Time()

                                        Else
                                            If (strStatus <> "") Then
                                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            Else
                                                Windows.Forms.MessageBox.Show("executeNonQueryX10db(): No rows were affected for X10 Db Controllers table Update of TransceiverHouseCodes.", "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            End If
                                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                        End If ' END - nsX10DbMethods.executeNonQueryX10db(UpdateControllersTable)

                                    Else
                                        Windows.Forms.MessageBox.Show("Problem with Controller's selected Transceiver House Code(s): " & objX10DbController.TransceiverHouseCodeMap.status, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                    End If ' END - getTransceiverHouseCodesCheckBox()

                                End If

                            Else
                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            End If ' END - nsX10DbMethods.getX10DbUSBPort()

                        End If ' END - DuskDawnResolution

                    Case "WM100"

                        objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                        objX10DbController.TransceiverHouseCodeMap.status = ""
                        objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                        objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                        objX10DbController.DuskDawnResolution = 0

                        objX10DbController.Port = formControllerAddUpdatePortValueLabel.Text()  ' ex: "WIFI"
                        objX10DbController.AppKey = formControllerAddUpdateAppKeyTextBox.Text() ' ex: "26d884ce-9f25-948537"
                        objX10DbController.UID = formControllerAddUpdateUIDTextBox.Text()       ' ex: "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"


                    Case Else
                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_SetClockButton_Click(): Unknown Controller Model: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                End Select ' END  - UpdateController_SelectCaseControllerType

            Else
                Windows.Forms.MessageBox.Show("formControllerAddUpdate_SetClockButton_Click(): Controller Active NOT checked: Unable to Set Controller Clock.", "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdateActiveCheckBox

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_SetClockButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_SetClockButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbController = Nothing
            objDataRowViewHouseCode = Nothing
            objX10DbUSBPort = Nothing
            objSetX10TimeClass = Nothing
            objPutX10TransceiverSetupClass = Nothing
            objGetX10ControllerStatusClass = Nothing
            objGetX10TransceiverSetupClass = Nothing
            objGetX10DuskDawnClass = Nothing
            objGetX10MemoryVersionStampClass = Nothing
            objDayOfYearDate = Nothing
            objDataRowViewControllerModel = Nothing
            objDataRowViewPort = Nothing
            objDateTimeNow = Nothing
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_SetClockButton_Click()

    Private Sub formControllerAddUpdate_DownloadButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_DownloadButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsSunTimeMethods As New TrekkerPhotoArt.X10Include.SunTimeMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""
        Dim bAllOK As Boolean = True

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim sqlString As String = ""
        Dim intRowsAffected As Integer = -1

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing

        Dim objDataRowViewPort As System.Data.DataRowView = Nothing

        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing
        Dim intHousecode As Integer = -1

        Dim arrPortHub() As String = Nothing
        Dim arrSpearator() As Char = {"."}

        Dim intX10Status As Integer = -1
        Dim intMINUTES As Integer = -1
        Dim intHOURS As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intBday As Integer = -1
        Dim intHC As Integer = -1

        Dim objDateTimeNow As System.DateTime = System.DateTime.Now()

        Dim objTimeZone As TrekkerPhotoArt.X10Include.TimeZone = Nothing
        Dim strSunriseTime As String = ""
        Dim strSunsetTime As String = ""

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing
        Dim objSetX10TimeClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.setX10TimeClass = Nothing
        Dim objPutX10TransceiverSetupClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putX10TransceiverSetupClass = Nothing
        Dim bClearTransceiverSetup As Boolean = False
        Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
        Dim objPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putToX10MemoryClass = Nothing
        Dim objVerifyPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.verifyPutToX10MemoryClass = Nothing
        Dim strMemoryOutputFilename As String = ""

        Dim objDayOfYearDate As System.DateTime = System.DateTime.MinValue

        Dim intTimersCompiled As Integer = 0
        Dim intX10DbTimersCount As Integer = 0
        Dim intX10TimerCount As Integer = 0
        Dim intTimerMatchedCount As Integer = 0

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormControllerEdit As formControllerEdit = Nothing
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Dim strMessage As String = ""

        Try

            If formControllerAddUpdateActiveCheckBox.Checked Then

                If objFormCollection.OfType(Of formConsoleMessages).Any Then
                    objFormConsoleMessages = New formConsoleMessages
                    objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")
                    objFormConsoleMessages.Close()
                    objFormConsoleMessages = Nothing
                End If

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                formControllerAddUpdate_StatusLabel.Text = ""
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

                objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                objX10DbController.ControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)
                objX10DbController.ControllerName = formControllerAddUpdateNameTextBox.Text()
                objX10DbController.ControllerActive = 1

                objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                objX10DbController.ControllerTypeID = objDataRowViewControllerModel(0).ToString
                objX10DbController.ControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CP290"

                objX10DbController.Port = ""
                objX10DbController.Hub = ""
                objX10DbController.HouseCode = ""
                objX10DbController.AppKey = ""
                objX10DbController.UID = ""
                objX10DbController.TransceiverHouseCodes = ""

                Select Case objX10DbController.ControllerType.ToUpper()
                    Case "CP290"

                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                        objX10DbController.Port = objDataRowViewPort(1).ToString ' ex: "COM3"

                        objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                        objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                        objX10DbController.TransceiverHouseCodes = ""
                        objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                        objX10DbController.TransceiverHouseCodeMap.status = ""
                        objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                        objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                        objX10DbController.DuskDawnResolution = 0

                    Case "CM15A"

                        ' Dusk Dawn Resolution for CM15A X10 Controller must be in Multiples of 8 (ex: 8 or 16 or 32).
                        objX10DbController.DuskDawnResolution = getDuskDawnResolutionFromSelectedIndex(formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex)
                        If (objX10DbController.DuskDawnResolution = 0) Then
                            objX10DbController = Nothing
                            Windows.Forms.MessageBox.Show("Missing Controller's Dusk/Dawn Resolution", "formControllerAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            bAllOK = False
                        Else

                            objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                            arrPortHub = objDataRowViewPort(1).ToString().Split(arrSpearator, System.StringSplitOptions.None) ' ex: "0003.0004"
                            If (arrPortHub.Length > 1) Then
                                objX10DbController.Port = arrPortHub(0)  ' ex: "0003"
                                objX10DbController.Hub = arrPortHub(1)  ' ex: "0004"
                            End If

                            objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                            objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                            Call getTransceiverHouseCodesCheckBox(objX10DbController.TransceiverHouseCodes, objX10DbController.TransceiverHouseCodeMap)
                            If (objX10DbController.TransceiverHouseCodeMap.status <> "") Then
                                Windows.Forms.MessageBox.Show("Problem with Controller's selected Transceiver House Code(s): " & objX10DbController.TransceiverHouseCodeMap.status, "formControllerAddUpdate_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                bAllOK = False
                            End If ' END - getTransceiverHouseCodesCheckBox()

                        End If

                    Case "WM100"

                        objX10DbController.Port = formControllerAddUpdatePortValueLabel.Text()  ' ex: "WIFI"
                        objX10DbController.AppKey = formControllerAddUpdateAppKeyTextBox.Text() ' ex: "26d884ce-9f25-948537"
                        objX10DbController.UID = formControllerAddUpdateUIDTextBox.Text()       ' ex: "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"

                        objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                        objX10DbController.TransceiverHouseCodeMap.status = ""
                        objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                        objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                        objX10DbController.DuskDawnResolution = 0

                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_DownloadButton_Click(): Controller Download not executed: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        bAllOK = False

                    Case Else
                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_DownloadButton_Click(): Unknown Controller Type: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        bAllOK = False
                End Select ' END  - UpdateController_SelectCaseControllerType

                If bAllOK Then

                    ' formControllerDownload.downloadEventsToController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal bPutX10DbSunTimes As Boolean, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef strMessage As String) As String
                    strStatus = formControllerDownload.downloadEventsToController(strConnectionString, strProvider, True, objX10DbController, strMessage)
                    If (strStatus = "") Then
                        formControllerAddUpdate_StatusLabel.Text = "Success"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                        formControllerAddUpdate_CancelButton.Text() = "Done"
                    Else
                        Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - formControllerDownload.downloadEventsToController()

                End If ' END - bAllOK

            Else
                Windows.Forms.MessageBox.Show("formControllerAddUpdate_DownloadButton_Click(): Controller Active NOT checked: Unable to perform Controller Download.", "formControllerAddUpdate_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdateActiveCheckBox

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_DownloadButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDayOfYearDate = Nothing
            objVerifyPutToX10MemoryClass = Nothing
            objPutToX10MemoryClass = Nothing
            objGetX10ControllerStatusClass = Nothing
            objSetX10TimeClass = Nothing
            objX10DbUSBPort = Nothing
            objX10DbController = Nothing
            objPutX10TransceiverSetupClass = Nothing
            objDataRowViewHouseCode = Nothing
            objDataRowViewControllerModel = Nothing
            objDataRowViewPort = Nothing
            objDateTimeNow = Nothing
            objTimeZone = Nothing
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
            objFormConsoleMessages = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_DownloadButton_Click()

    Private Sub formControllerAddUpdate_ClearButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_ClearButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsSunTimeMethods As New TrekkerPhotoArt.X10Include.SunTimeMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim sqlString As String = ""
        Dim intRowsAffected As Integer = -1

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing

        Dim objDataRowViewPort As System.Data.DataRowView = Nothing

        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing
        Dim intHousecode As Integer = -1

        Dim arrPortHub() As String = Nothing
        Dim arrSpearator() As Char = {"."}

        Dim intX10Status As Integer = -1
        Dim intMINUTES As Integer = -1
        Dim intHOURS As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intBday As Integer = -1
        Dim intHC As Integer = -1

        Dim objDateTimeNow As System.DateTime = System.DateTime.Now()

        Dim objTimeZone As TrekkerPhotoArt.X10Include.TimeZone = Nothing
        Dim strSunriseTime As String = ""
        Dim strSunsetTime As String = ""

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing
        Dim objSetX10TimeClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.setX10TimeClass = Nothing
        Dim objPutX10TransceiverSetupClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putX10TransceiverSetupClass = Nothing
        Dim bClearTransceiverSetup As Boolean = False
        Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
        Dim objPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putToX10MemoryClass = Nothing
        Dim objVerifyPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.verifyPutToX10MemoryClass = Nothing
        Dim strMemoryOutputFilename As String = ""

        Dim objDayOfYearDate As System.DateTime = System.DateTime.MinValue

        Dim intTimersCompiled As Integer = 0
        Dim intX10DbTimersCount As Integer = 0
        Dim intX10TimerCount As Integer = 0
        Dim intTimerMatchedCount As Integer = 0

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormControllerEdit As formControllerEdit = Nothing
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Dim strMessage As String = ""

        Try

            If formControllerAddUpdateActiveCheckBox.Checked Then

                If objFormCollection.OfType(Of formConsoleMessages).Any Then
                    objFormConsoleMessages = New formConsoleMessages
                    objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")
                    objFormConsoleMessages.Close()
                    objFormConsoleMessages = Nothing
                End If

                formControllerAddUpdate_StatusLabel.Text = ""
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

                objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                objX10DbController.ControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)
                objX10DbController.ControllerName = formControllerAddUpdateNameTextBox.Text()

                objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                objX10DbController.ControllerTypeID = objDataRowViewControllerModel(0).ToString
                objX10DbController.ControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CP290"

                objX10DbController.Port = ""
                objX10DbController.Hub = ""
                objX10DbController.HouseCode = ""
                objX10DbController.AppKey = ""
                objX10DbController.UID = ""
                objX10DbController.TransceiverHouseCodes = ""

                strMessage = "Start Clear Memory for Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]"

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                ' nsSunTimeMethods.getTimeZone(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone) As String
                strStatus = nsSunTimeMethods.getTimeZone(objTimeZone)
                If (strStatus = "") Then

                    ' nsSunTimeMethods.SunTimes(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
                    strStatus = nsSunTimeMethods.SunTimes(objTimeZone, CType(X10ManagerDesktop.latitude, Double), CType(X10ManagerDesktop.longitude, Double), strSunriseTime, strSunsetTime)
                    If (strStatus = "") Then

                        strMessage &= vbCrLf & "Put X10Db Sun Times:" & vbCrLf & "  SunriseTime=" & strSunriseTime & " SunsetTime=" & strSunsetTime
                        ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                        strStatus = nsX10DbMethods.putX10DbSunTimes(strConnectionString, strProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                        If (strStatus = "") Then

                            Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                            Select Case objX10DbController.ControllerType.ToUpper()
                                Case "CP290"

                                    objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                                    objX10DbController.Port = objDataRowViewPort(1).ToString ' ex: "COM3"

                                    objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                                    objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                                    objX10DbController.TransceiverHouseCodes = ""
                                    objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                                    objX10DbController.TransceiverHouseCodeMap.status = ""
                                    objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                                    objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                                    objX10DbController.DuskDawnResolution = 0

                                    strMessage &= vbCrLf & "Update to X10 Db Controllers table:"
                                    strMessage &= vbCrLf & "  Base House Code: " & objX10DbController.HouseCode
                                    sqlString = "UPDATE Controllers SET HouseCode='" & objX10DbController.HouseCode & "',TransceiverHouseCodes='',DuskDawnResolution=0 WHERE ControllerID=" & objX10DbController.ControllerID.ToString() & ";"
                                    ' nsX10DbMethods.executeNonQueryX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal sqlString As String, ByRef intRowsAffected As Integer) As String
                                    strStatus = nsX10DbMethods.executeNonQueryX10db(strConnectionString, strProvider, sqlString, intRowsAffected)
                                    If (strStatus = "" And intRowsAffected > 0) Then

                                        ' nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(ByVal strHouseCode As String, ByRef intHousecode As Integer) As String
                                        strStatus = nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(objX10DbController.HouseCode, intHousecode)
                                        If (strStatus = "") Then

                                            strMessage &= vbCrLf & "Download X10 Base Housecode (Clears Memory)"
                                            strMessage &= vbCrLf & "Set CP290 Clock to:" & vbCrLf & "  " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & " " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") "
                                            Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                            ' nsX10CP290Methods.downloadX10BaseHousecode(ByVal strPortName As String, ByVal intHousecode As Integer) As String
                                            strStatus = nsX10CP290Methods.downloadX10BaseHousecode(objX10DbController.Port, intHousecode)
                                            If (strStatus = "") Then

                                                ' nsX10CP290Methods.setX10Time(ByVal strPortName As String, ByVal dtmNow As System.DateTime, ByRef intgX10Status As Integer, ByRef intgMINUTES As Integer, ByRef intgHOURS As Integer, ByRef intgBday As Integer, ByRef intgHC As Integer) As String
                                                strStatus = nsX10CP290Methods.setX10Time(objX10DbController.Port, objDateTimeNow, intX10Status, intMINUTES, intHOURS, intBday, intHC)
                                                If (strStatus = "") Then

                                                    If (intHOURS = 12) Then
                                                        ' PM
                                                        strAMPM = "PM"
                                                        intHourAMPM = intHOURS
                                                    ElseIf (intHOURS > 12) Then
                                                        ' PM
                                                        strAMPM = "PM"
                                                        intHourAMPM = intHOURS - 12
                                                    ElseIf (intHOURS = 0) Then
                                                        ' AM
                                                        strAMPM = "AM"
                                                        intHourAMPM = 12
                                                    Else
                                                        ' AM
                                                        strAMPM = "AM"
                                                        intHourAMPM = intHOURS
                                                    End If

                                                    strMessage &= vbCrLf & vbCrLf & "Success Clearing Controller Memory!"
                                                    strMessage &= vbCrLf & "  Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status)
                                                    strMessage &= vbCrLf & "  Time: " & nsX10DbMethods.DayCodeToStringOfFullDays(intBday) & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString, 2) & " " & strAMPM
                                                    strMessage &= vbCrLf & "  Base House Code: " & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHC)
                                                    strMessage &= vbCrLf & vbCrLf & "Success!" & vbCrLf
                                                    Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                                    formControllerAddUpdate_StatusLabel.Text = "Success"
                                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                                    formControllerAddUpdate_CancelButton.Text() = "Done"

                                                Else
                                                    Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                End If ' END - nsX10CP290Methods.setX10Time()

                                            Else
                                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                            End If ' END - nsX10CP290Methods.downloadX10BaseHousecode()

                                        Else
                                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                        End If ' END - nsX10CP290Methods.x10HouseCodeAsStringToBinary()

                                    Else
                                        Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                    End If ' END - nsX10DbMethods.executeNonQueryX10db()

                                Case "CM15A"

                                    ' Dusk Dawn Resolution for CM15A X10 Controller must be in Multiples of 8 (ex: 8 or 16 or 32).
                                    objX10DbController.DuskDawnResolution = getDuskDawnResolutionFromSelectedIndex(formControllerAddUpdateDuskDawnResolutionComboBox.SelectedIndex)
                                    If (objX10DbController.DuskDawnResolution = 0) Then
                                        objX10DbController = Nothing
                                        Windows.Forms.MessageBox.Show("Missing Controller's Dusk/Dawn Resolution", "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    Else

                                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                                        arrPortHub = objDataRowViewPort(1).ToString().Split(arrSpearator, System.StringSplitOptions.None) ' ex: "0003.0004"
                                        If (arrPortHub.Length > 1) Then
                                            objX10DbController.Port = arrPortHub(0)  ' ex: "0003"
                                            objX10DbController.Hub = arrPortHub(1)  ' ex: "0004"
                                        End If

                                        objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                                        objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                                        ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                                        strStatus = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                                        If (strStatus = "") Then

                                            If (objX10DbUSBPort Is Nothing) Then
                                                strStatus = "getX10DbUSBPort(): USB Port=""" & objX10DbController.Port & """ Hub=""" & objX10DbController.Hub & """ not found in X10Db."
                                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                            Else

                                                Call getTransceiverHouseCodesCheckBox(objX10DbController.TransceiverHouseCodes, objX10DbController.TransceiverHouseCodeMap)
                                                If (objX10DbController.TransceiverHouseCodeMap.status = "") Then

                                                    strMessage &= vbCrLf & "Update to X10 Db Controllers table:"
                                                    strMessage &= vbCrLf & "  Monitored House Code: " & objX10DbController.HouseCode
                                                    strMessage &= vbCrLf & "  Transceiver House Codes: " & objX10DbController.TransceiverHouseCodes
                                                    strMessage &= vbCrLf & "  Dusk/Dawn Resolution: " & objX10DbController.DuskDawnResolution.ToString()
                                                    sqlString = "UPDATE Controllers SET HouseCode='" & objX10DbController.HouseCode & "',TransceiverHouseCodes='" & objX10DbController.TransceiverHouseCodes & "',DuskDawnResolution=" & objX10DbController.DuskDawnResolution.ToString() & " WHERE ControllerID=" & objX10DbController.ControllerID.ToString() & ";"
                                                    ' nsX10DbMethods.executeNonQueryX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal sqlString As String, ByRef intRowsAffected As Integer) As String
                                                    strStatus = nsX10DbMethods.executeNonQueryX10db(strConnectionString, strProvider, sqlString, intRowsAffected)
                                                    If (strStatus = "" And intRowsAffected > 0) Then

                                                        strMessage &= vbCrLf & "Set CM15A Clock to:"
                                                        strMessage &= vbCrLf & "  " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & "  " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") "
                                                        strMessage &= vbCrLf & "    With:" & vbCrLf & "      Purge Timers" & vbCrLf & "      Clear Battery Timer" & vbCrLf & "      Clear Monitored Status"
                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                                        ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                                        objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "Y", "Y", "Y")
                                                        If (objSetX10TimeClass.status = "") Then

                                                            strMessage &= vbCrLf & "Get CM15A Controller Status:"
                                                            ' getX10ControllerStatusClass nsX10CM15AMethods.getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                            objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                                            If (objGetX10ControllerStatusClass.status = "") Then

                                                                If (objGetX10ControllerStatusClass.currentTimeHours = 12) Then
                                                                    ' PM
                                                                    strAMPM = "PM"
                                                                    intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                                ElseIf (objGetX10ControllerStatusClass.currentTimeHours > 12) Then
                                                                    ' PM
                                                                    strAMPM = "PM"
                                                                    intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours - 12
                                                                ElseIf (objGetX10ControllerStatusClass.currentTimeHours = 0) Then
                                                                    ' AM
                                                                    strAMPM = "AM"
                                                                    intHourAMPM = 12
                                                                Else
                                                                    ' AM
                                                                    strAMPM = "AM"
                                                                    intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                                End If

                                                                strMessage &= vbCrLf & "  Controller Status: OK"
                                                                strMessage &= vbCrLf & "  Time: " & objGetX10ControllerStatusClass.currentTimeDayOfWeek & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeMinutes.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeSeconds.ToString, 2) & " " & strAMPM
                                                                strMessage &= vbCrLf & "  Year Day Date: " & objGetX10ControllerStatusClass.objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")
                                                                strMessage &= vbCrLf & "  Monitored House Code: " & objGetX10ControllerStatusClass.monitoredHouseCode

                                                                strMessage &= vbCrLf & vbCrLf & "Clear Controller Memory... Please wait......."
                                                                Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                                                ' putToX10MemoryClass putToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, double dblLatitude, double dblLongitude, string strScheduleName, int intScheduleID, string strX10DbConnectionString, string strX10DbProvider, bool bClearOnly)
                                                                objPutToX10MemoryClass = nsX10CM15AMethods.putToX10Memory(objX10DbController, objX10DbUSBPort, CType(X10ManagerDesktop.latitude, Double), CType(X10ManagerDesktop.longitude, Double), "", -1, strConnectionString, strProvider, True)
                                                                If (objPutToX10MemoryClass.status = "") Then

                                                                    strMessage &= vbCrLf & "Success Clearing Controller Memory!"
                                                                    strMessage &= vbCrLf & "  Memory Version:"
                                                                    strMessage &= vbCrLf & "    " & objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp.ToLongDateString() & " " & objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp.ToLocalTime().ToString("HH:mm:ss") & " (UTC" & System.TimeZoneInfo.Local.GetUtcOffset(objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp).TotalHours.ToString() & ")"

                                                                    strMessage &= vbCrLf & "  Daylight Savings:"
                                                                    objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objPutToX10MemoryClass.objX10DuskDawnClass.dayOfYearDaylightSavingsTurnForward)
                                                                    strMessage &= vbCrLf & "    Turn Forward: " & objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                                                    objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objPutToX10MemoryClass.objX10DuskDawnClass.dayOfYearDaylightSavingsTurnBackward)
                                                                    strMessage &= vbCrLf & "    Turn Backward: " & objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                                                    strMessage &= vbCrLf & "  Dusk Dawn Resolution: " + objPutToX10MemoryClass.objX10DuskDawnClass.duskDawnResolution.ToString() & " days"
                                                                    If (objPutToX10MemoryClass.objX10DuskDawnClass.startOfDuskDawnTableMemoryAddress = 0) Then
                                                                        strMessage &= vbCrLf & "    ERROR: startOfDuskDawnTableMemoryAddress not set."
                                                                    Else
                                                                        strMessage &= vbCrLf & "    Number of Dusk/Dawn table entries: " & objPutToX10MemoryClass.objX10DuskDawnClass.objX10DuskDawnTableEntryClasses.Count.ToString()
                                                                    End If

                                                                    strMessage &= vbCrLf & "  Transceive on Housecodes: " & objPutToX10MemoryClass.objX10TransceiverSetupClass.TransceiverHouseCodes

                                                                    strMessage &= vbCrLf & vbCrLf & "Verify... Please wait......."
                                                                    Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                                                    strMemoryOutputFilename = X10ManagerDesktop.backupDirectoryPath & "clearX10Memory_" & objX10DbController.ControllerType & "_" & objX10DbController.ControllerName.Replace(" ", "") & ".txt"

                                                                    ' verifyPutToX10MemoryClass verifyPutToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, ref putToX10MemoryClass objPutToX10MemoryClass, bool bClearOnly, string strFilename)
                                                                    objVerifyPutToX10MemoryClass = nsX10CM15AMethods.verifyPutToX10Memory(objX10DbController, objX10DbUSBPort, objPutToX10MemoryClass, True, strMemoryOutputFilename)
                                                                    If (objVerifyPutToX10MemoryClass.status = "") Then

                                                                        strMessage &= vbCrLf & "Controller Memory loacations have matched!" & vbCrLf
                                                                        strMessage &= vbCrLf & "Controller Memory Annotations found in file:" & vbCrLf & strMemoryOutputFilename
                                                                        strMessage &= vbCrLf & vbCrLf & "Success!" & vbCrLf
                                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                                                        formControllerAddUpdate_StatusLabel.Text = "Success"
                                                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                                                        formControllerAddUpdate_CancelButton.Text() = "Done"

                                                                    Else

                                                                        strMessage &= vbCrLf & "Controller Memory loacations have NOT matched!" & vbCrLf
                                                                        strMessage &= vbCrLf & objVerifyPutToX10MemoryClass.status
                                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                                                        Windows.Forms.MessageBox.Show(objVerifyPutToX10MemoryClass.status, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                                    End If ' END - verifyPutToX10Memory()

                                                                Else

                                                                    strMessage &= vbCrLf & "Clear Controller Memory has Failed!" & vbCrLf
                                                                    strMessage &= vbCrLf & objPutToX10MemoryClass.status
                                                                    Call formConsoleMessages.DisplayMessage(strMessage, "Clear Controller Memory")

                                                                    Windows.Forms.MessageBox.Show(objPutToX10MemoryClass.status, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                                End If ' END - nsX10CM15AMethods.putToX10Memory()

                                                                ' Refresh DataSet on Form formControllerEdit if it's active.
                                                                If objFormCollection.OfType(Of formControllerEdit).Any Then

                                                                    objFormControllerEdit = objFormCollection.Item("formControllerEdit")

                                                                    ' formControllerEdit_GetControllersDataSet() As String
                                                                    strStatus = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
                                                                    If (strStatus = "") Then
                                                                        objFormControllerEdit.Activate()
                                                                    Else
                                                                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_ClearButton_Click(): " & strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                                    End If ' END - formControllerEdit_GetControllersDataSet()

                                                                End If

                                                            Else
                                                                Windows.Forms.MessageBox.Show(objGetX10ControllerStatusClass.status, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                            End If ' END - nsX10CM15AMethods.getX10ControllerStatus()

                                                        Else
                                                            Windows.Forms.MessageBox.Show(objSetX10TimeClass.status, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                        End If ' END - nsX10CM15AMethods.setX10Time()

                                                    Else
                                                        If (strStatus <> "") Then
                                                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                        Else
                                                            Windows.Forms.MessageBox.Show("executeNonQueryX10db(): No rows were affected for X10 Db Controllers table Update of TransceiverHouseCodes.", "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                        End If
                                                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                    End If ' END - nsX10DbMethods.executeNonQueryX10db(UpdateControllersTable)

                                                Else
                                                    Windows.Forms.MessageBox.Show("Problem with Controller's selected Transceiver House Code(s): " & objX10DbController.TransceiverHouseCodeMap.status, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                                End If ' END - getTransceiverHouseCodesCheckBox()

                                            End If ' END - USBPort Check

                                        Else
                                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                        End If ' END - nsX10DbMethods.getX10DbUSBPort()

                                    End If ' END - DuskDawnResolution

                                Case "WM100"

                                    objX10DbController.Port = formControllerAddUpdatePortValueLabel.Text()  ' ex: "WIFI"
                                    objX10DbController.AppKey = formControllerAddUpdateAppKeyTextBox.Text() ' ex: "26d884ce-9f25-948537"
                                    objX10DbController.UID = formControllerAddUpdateUIDTextBox.Text()       ' ex: "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"

                                    objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                                    objX10DbController.TransceiverHouseCodeMap.status = ""
                                    objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                                    objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                                    objX10DbController.DuskDawnResolution = 0

                                    Windows.Forms.MessageBox.Show("formControllerAddUpdate_ClearButton_Click(): Controller Memory Clear not executed: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"

                                Case Else
                                    Windows.Forms.MessageBox.Show("formControllerAddUpdate_ClearButton_Click(): Unknown Controller Model: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            End Select ' END  - UpdateController_SelectCaseControllerType

                        Else
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        End If ' END - nsX10DbMethods.putX10DbSunTimes()

                    Else
                        Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsSunTimeMethods.SunTimes()

                Else
                    Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                End If ' END - nsSunTimeMethods.getTimeZone()

            Else
                Windows.Forms.MessageBox.Show("formControllerAddUpdate_ClearButton_Click(): Controller Active NOT checked: Unable to Clear Controller Memory.", "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdateActiveCheckBox

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_DownloadButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ClearButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDayOfYearDate = Nothing
            objVerifyPutToX10MemoryClass = Nothing
            objPutToX10MemoryClass = Nothing
            objGetX10ControllerStatusClass = Nothing
            objSetX10TimeClass = Nothing
            objX10DbUSBPort = Nothing
            objX10DbController = Nothing
            objPutX10TransceiverSetupClass = Nothing
            objDataRowViewHouseCode = Nothing
            objDataRowViewControllerModel = Nothing
            objDataRowViewPort = Nothing
            objDateTimeNow = Nothing
            objTimeZone = Nothing
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
            objFormConsoleMessages = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_ClearButton_Click()

    Private Sub formControllerAddUpdate_ExportButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerAddUpdate_ExportButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing
        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing
        Dim objGetX10MemoryPutToFileClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10MemoryPutToFileClass = Nothing

        Dim objDataRowViewControllerModel As System.Data.DataRowView = Nothing
        Dim objDataRowViewPort As System.Data.DataRowView = Nothing
        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing

        Dim arrPortHub() As String = Nothing
        Dim arrSpearator() As Char = {"."}

        Dim strExportFileName As String = ""
        Dim strExportCSVFileName As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Dim strMessage As String = ""

        Try

            If formControllerAddUpdateActiveCheckBox.Checked Then

                If objFormCollection.OfType(Of formConsoleMessages).Any Then
                    objFormConsoleMessages = New formConsoleMessages
                    objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")
                    objFormConsoleMessages.Close()
                    objFormConsoleMessages = Nothing
                End If

                objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                objX10DbController.ControllerID = CType(formControllerAddUpdateIDLabelText.Text(), Integer)
                objX10DbController.ControllerName = formControllerAddUpdateNameTextBox.Text()
                objX10DbController.ControllerActive = 1

                objDataRowViewControllerModel = formControllerAddUpdateModelComboBox.SelectedItem
                objX10DbController.ControllerTypeID = objDataRowViewControllerModel(0).ToString
                objX10DbController.ControllerType = objDataRowViewControllerModel(1).ToString ' ex: "CM15A"

                objX10DbController.Port = ""
                objX10DbController.Hub = ""
                objX10DbController.HouseCode = ""
                objX10DbController.AppKey = ""
                objX10DbController.UID = ""
                objX10DbController.TransceiverHouseCodes = ""
                objX10DbController.DuskDawnResolution = 0

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                formControllerAddUpdate_StatusLabel.Text = ""
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Black

                Select Case objX10DbController.ControllerType.ToUpper()
                    Case "CP290"

                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                        objX10DbController.Port = objDataRowViewPort(1).ToString ' ex: "COM3"

                        objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                        objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                        objX10DbController.TransceiverHouseCodes = ""
                        objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                        objX10DbController.TransceiverHouseCodeMap.status = ""
                        objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                        objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                        objX10DbController.DuskDawnResolution = 0

                        formControllerAddUpdate_SaveFileDialog.Filter = "CSV files (*.csv)|*.csv"

                        If (formControllerAddUpdate_SaveFileDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then

                            strExportFileName = formControllerAddUpdate_SaveFileDialog.FileName

                            strMessage = "Start Export memory from Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]"
                            strMessage &= vbCrLf & vbCrLf & "Please wait......."

                            Call formConsoleMessages.DisplayMessage(strMessage, "Export memory from Controller")

                            ' nsX10CP290Methods.getX10TimersPutToFile(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strFilename As String, ByRef strCSVFilename As String) As String
                            strStatus = nsX10CP290Methods.getX10TimersPutToFile(objX10DbController, strExportFileName, strExportCSVFileName)
                            If (strStatus = "") Then

                                strMessage &= vbCrLf & vbCrLf & "Finish Export memory from Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]"
                                strMessage &= vbCrLf & "Memory output is found in file:"
                                strMessage &= vbCrLf & strExportCSVFileName

                                strMessage &= vbCrLf & vbCrLf & "Success!"

                                Call formConsoleMessages.DisplayMessage(strMessage, "Export memory from Controller")

                                formControllerAddUpdate_StatusLabel.Text = "Success"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                formControllerAddUpdate_CancelButton.Text() = "Done"

                            Else
                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            End If ' END - nsX10CP290Methods.getX10TimersPutToFile()

                        End If ' END - ShowDialog()

                    Case "CM15A"

                        objDataRowViewPort = formControllerAddUpdatePortComboBox.SelectedItem
                        arrPortHub = objDataRowViewPort(1).ToString().Split(arrSpearator, System.StringSplitOptions.None) ' ex: "0003.0004"
                        If (arrPortHub.Length > 1) Then
                            objX10DbController.Port = arrPortHub(0)  ' ex: "0003"
                            objX10DbController.Hub = arrPortHub(1)  ' ex: "0004"
                        End If

                        ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                        strStatus = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                        If (strStatus = "") Then

                            If (objX10DbUSBPort Is Nothing) Then
                                strStatus = "getX10DbUSBPort(): USB Port=""" & objX10DbController.Port & """ Hub=""" & objX10DbController.Hub & """ not found in X10Db."
                                Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerAddUpdate_StatusLabel.Text = "Fail"
                                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerAddUpdate_CancelButton.Text() = "Cancel"
                            Else

                                objDataRowViewHouseCode = formControllerAddUpdateHouseCodeComboBox.SelectedItem
                                objX10DbController.HouseCode = objDataRowViewHouseCode(1).ToString ' ex: "J"

                                Call getTransceiverHouseCodesCheckBox(objX10DbController.TransceiverHouseCodes, objX10DbController.TransceiverHouseCodeMap)
                                If (objX10DbController.TransceiverHouseCodeMap.status = "") Then

                                    formControllerAddUpdate_SaveFileDialog.Filter = "Text files (*.txt)|*.txt"

                                    If (formControllerAddUpdate_SaveFileDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then

                                        strExportFileName = formControllerAddUpdate_SaveFileDialog.FileName

                                        strMessage = "Start Export memory from Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]"
                                        strMessage &= vbCrLf & vbCrLf & "Please wait......."

                                        Call formConsoleMessages.DisplayMessage(strMessage, "Export memory from Controller")

                                        ' getX10MemoryPutToFileClass nsX10CM15AMethods.getX10MemoryPutToFile(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strFilename)
                                        objGetX10MemoryPutToFileClass = nsX10CM15AMethods.getX10MemoryPutToFile(objX10DbController, objX10DbUSBPort, strExportFileName)
                                        If (objGetX10MemoryPutToFileClass.status = "") Then

                                            strMessage &= vbCrLf & vbCrLf & "Finish Export memory from Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]"
                                            strMessage &= vbCrLf & "Memory was read " & objGetX10MemoryPutToFileClass.objGetX10MemoryClasses.Count.ToString() & " times."
                                            strMessage &= vbCrLf & "  memoryAddressStart=0x" & objGetX10MemoryPutToFileClass.memoryAddressStart.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  memoryAddressEnd=0x" & objGetX10MemoryPutToFileClass.memoryAddressEnd.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  versionStamp: " & objGetX10MemoryPutToFileClass.objGetX10MemoryVersionStampClass.dtmVersion.ToLongDateString() & " " & objGetX10MemoryPutToFileClass.objGetX10MemoryVersionStampClass.dtmVersion.ToLongTimeString() & " (UTC" + System.TimeZoneInfo.Local.GetUtcOffset(objGetX10MemoryPutToFileClass.objGetX10MemoryVersionStampClass.dtmVersion).TotalHours.ToString() & ")"
                                            strMessage &= vbCrLf & "  startOfTimerInitiatorsMemoryAddress=0x" & objGetX10MemoryPutToFileClass.startOfTimerInitiatorsMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  endOfTimerInitiatorsMemoryAddress=0x" & objGetX10MemoryPutToFileClass.endOfTimerInitiatorsMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  startOfTimerConditionsMemoryAddress=0x" & objGetX10MemoryPutToFileClass.startOfTimerConditionsMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  startOfMacroInitiatorsMemoryAddress=0x" & objGetX10MemoryPutToFileClass.startOfMacroInitiatorsMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  endOfMacroInitiatorsMemoryAddress=0x" & objGetX10MemoryPutToFileClass.endOfMacroInitiatorsMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  startOfMacrosMemoryAddress=0x" & objGetX10MemoryPutToFileClass.startOfMacrosMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  lastMacroBlockEndStartMemoryAddress=0x" & objGetX10MemoryPutToFileClass.lastMacroBlockEndStartMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  endOfMacrosMemoryAddress=0x" & objGetX10MemoryPutToFileClass.endOfMacrosMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  startOfUnusedSpaceMemoryAddress=0x" & objGetX10MemoryPutToFileClass.startOfUnusedSpaceMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  endOfUnusedSpaceMemoryAddress=0x" & objGetX10MemoryPutToFileClass.endOfUnusedSpaceMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  startOfDuskDawnTableMemoryAddress=0x" & objGetX10MemoryPutToFileClass.startOfDuskDawnTableMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  endOfDuskDawnTableMemoryAddress=0x" & objGetX10MemoryPutToFileClass.endOfDuskDawnTableMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  versionStampMemoryAddress=0x" & objGetX10MemoryPutToFileClass.versionStampMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "  lastMemoryAddress=0x" & objGetX10MemoryPutToFileClass.lastMemoryAddress.ToString("X04").ToLower()
                                            strMessage &= vbCrLf & "Memory output is found in file:"
                                            strMessage &= vbCrLf & strExportFileName

                                            strMessage &= vbCrLf & vbCrLf & "Success!"

                                            Call formConsoleMessages.DisplayMessage(strMessage, "Export memory from Controller")

                                            formControllerAddUpdate_StatusLabel.Text = "Success"
                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                            formControllerAddUpdate_CancelButton.Text() = "Done"

                                        Else
                                            Windows.Forms.MessageBox.Show(objGetX10MemoryPutToFileClass.status, "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                        End If ' END - nsX10CM15AMethods.getX10MemoryPutToFile()

                                    End If ' END - ShowDialog()

                                Else
                                    Windows.Forms.MessageBox.Show("Problem with Controller's selected Transceiver House Code(s): " & objX10DbController.TransceiverHouseCodeMap.status, "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    formControllerAddUpdate_StatusLabel.Text = "Fail"
                                    formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                    formControllerAddUpdate_CancelButton.Text() = "Cancel"
                                End If ' END - getTransceiverHouseCodesCheckBox()

                            End If

                        Else
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerAddUpdate_StatusLabel.Text = "Fail"
                            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerAddUpdate_CancelButton.Text() = "Cancel"
                        End If ' END - nsX10DbMethods.getX10DbUSBPort()

                    Case "WM100"

                        objX10DbController.Port = formControllerAddUpdatePortValueLabel.Text()  ' ex: "WIFI"
                        objX10DbController.AppKey = formControllerAddUpdateAppKeyTextBox.Text() ' ex: "26d884ce-9f25-948537"
                        objX10DbController.UID = formControllerAddUpdateUIDTextBox.Text()       ' ex: "Fc5wGsTuvuWiuv6iFn2Kz6ArduMCDVt99u"

                        objX10DbController.TransceiverHouseCodeMap = New TrekkerPhotoArt.X10Include.X10DbHouseCodeMap
                        objX10DbController.TransceiverHouseCodeMap.status = ""
                        objX10DbController.TransceiverHouseCodeMap.byte1 = 0
                        objX10DbController.TransceiverHouseCodeMap.byte2 = 0
                        objX10DbController.DuskDawnResolution = 0

                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_ExportButton_Click(): Controller Export not executed: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"

                    Case Else
                        Windows.Forms.MessageBox.Show("formControllerAddUpdate_ExportButton_Click(): Unknown Controller Model: """ & objX10DbController.ControllerType & """", "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formControllerAddUpdate_StatusLabel.Text = "Fail"
                        formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formControllerAddUpdate_CancelButton.Text() = "Cancel"
                End Select ' END  - SelectCaseControllerType

            Else
                Windows.Forms.MessageBox.Show("formControllerAddUpdate_ExportButton_Click(): Controller Active NOT checked: Unable to Export Controller Memory.", "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerAddUpdate_StatusLabel.Text = "Fail"
                formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdateActiveCheckBox

        Catch ex As Exception
            strStatus = "formControllerAddUpdate_ExportButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerAddUpdate_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerAddUpdate_StatusLabel.Text = "Fail"
            formControllerAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDataRowViewHouseCode = Nothing
            objDataRowViewPort = Nothing
            objDataRowViewControllerModel = Nothing
            objGetX10MemoryPutToFileClass = Nothing
            objX10DbUSBPort = Nothing
            objX10DbController = Nothing
            objFormCollection = Nothing
            objFormConsoleMessages = Nothing
        End Try

    End Sub ' END - formControllerAddUpdate_ExportButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formControllerAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationControllerAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formControllerAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(515, 595)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationControllerAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationControllerAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationControllerAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formControllerAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formControllerAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formControllerAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formControllerAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationControllerAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formControllerAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationControllerAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationControllerAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formControllerAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formControllerAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formControllerAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formControllerAddUpdate