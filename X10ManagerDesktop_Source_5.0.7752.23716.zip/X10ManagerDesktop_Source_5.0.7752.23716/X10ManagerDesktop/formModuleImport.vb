﻿
' Name: formModuleImport.vb
' By: Alan Wagner
' Date: November 2020

Public Class formModuleImport

#Region "X10ManagerDesktopModuleImportMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strInstallerAssemblyLocation As String = ""
        Dim strInstallerAssemblyLocationDrive As String = ""
        Dim strInstallerAssemblyLocationExecutable As String = ""
        Dim bInstallerAssemblyLocationFound As Boolean = False

        Try

            Me.BringToFront()

            formModuleImport_ImportButton.Visible = False

            formModuleImport_StatusLabel.Text = ""
            formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Black
            formModuleImport_CancelButton.Text() = "Cancel"
            formModuleImport_CancelButton.Select()

            strTryStep = "formModuleImport_FormRestore"
            ' formModuleImport_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formModuleImport_FormRestore(objSender, objEventArgs)
            If (strStatus <> "") Then
                Windows.Forms.MessageBox.Show("Main(formModuleImport): " & strStatus, "Main(formModuleImport)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formModuleImport_ImportButton.Visible = False
                formModuleImport_StatusLabel.Text = "Fail"
                formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Red
                formModuleImport_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdate_FormRestore()

        Catch ex As Exception

            If (ex.InnerException Is Nothing) Then
                strError = "Main(formModuleImport): Exception: TryStep=" & strTryStep & ": " & ex.Message.ToString()
            Else
                strError = "Main(formModuleImport): Exception: TryStep=" & strTryStep & ": " & ex.Message.ToString() & vbCrLf & "InnerException: " & ex.InnerException.ToString
            End If

            If (strStatus = "") Then
                strStatus = strError
            Else
                strStatus &= vbCrLf & strError
            End If

            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleImport)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleImport_ImportButton.Visible = False
            formModuleImport_StatusLabel.Text = "Fail"
            formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleImport_CancelButton.Text() = "Cancel"

        End Try

    End Sub ' END Sub - Main(formModuleImport)

    Private Sub formModuleImport_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formModuleImport_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formModuleImport_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formModuleImport_FormClosingHandler(): " & strStatus, "formModuleImport_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formFileSettings_FormSave()

    End Sub ' END Sub - formModuleImport_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopModuleImportMainMethods

#Region "formMethods"

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formModuleImport_BrowseButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleImport_BrowseButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim intRecordCount As Integer = 0
        Dim intModulesAddedCount As Integer = 0
        Dim intModulesUpdatedCount As Integer = 0
        Dim strModulesAddedList As String = ""
        Dim strModulesUpdatedList As String = ""

        Dim strMessage As String = ""

        Try

            formModuleImport_ImportButton.Visible = False
            formModuleImport_StatusLabel.Text = ""
            formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Black

            formModuleImport_OpenFileDialog.Filter = "CSV files (*.csv)|*.csv"

            If (formModuleImport_OpenFileDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then

                formModuleImportImportFileTextBox.Text = formModuleImport_OpenFileDialog.FileName()

                ' Header Row:
                ' "ControllerName","UnitCode","UnitName","UnitDescription","UnitEnabledYN","UnitDimmerYN","UnitLightingYN","UnitExtendedCommandsYN"
                '
                ' Example Record Rows:
                ' "House Lighting CP290","J1","OutGar","Outside Garage Lights","Y","N","Y","N"
                ' "Test CP290","J16","Den Test Dimmer Module","Dimmer LED Test Light in Dimmer Module","Y","Y","Y","N"

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                strMessage = vbCrLf & vbCrLf & "Verifying Import file """ & formModuleImportImportFileTextBox.Text & """"
                strMessage &= vbCrLf & "Please wait......."
                Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

                ' nsX10DbMethods.importModulesFromCSVFileToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByVal strFilename As String, ByVal bVerifyOnly As Boolean, ByRef intRecordCount As Integer, ByRef intModulesAddedCount As Integer, ByRef intModulesUpdatedCount As Integer, ByRef strModulesAddedList As String, ByRef strModulesUpdatedList As String) As String
                strError = nsX10DbMethods.importModulesFromCSVFiletoX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, formModuleImportImportFileTextBox.Text, True, intRecordCount, intModulesAddedCount, intModulesUpdatedCount, strModulesAddedList, strModulesUpdatedList)
                If (strError = "") Then

                    strMessage &= vbCrLf & vbCrLf & "RecordCount=" & intRecordCount.ToString()
                    strMessage &= vbCrLf & "ModulesToBeAddedCount=" & intModulesAddedCount.ToString()
                    If (strModulesAddedList.Length() > 0) Then
                        strMessage &= vbCrLf & strModulesAddedList
                    End If
                    strMessage &= vbCrLf & "ModulesToBeUpdatedCount=" & intModulesUpdatedCount.ToString()
                    If (strModulesUpdatedList.Length() > 0) Then
                        strMessage &= vbCrLf & strModulesUpdatedList
                    End If
                    strMessage &= vbCrLf & "Successful Verify!"
                    Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

                    formModuleImport_StatusLabel.Text = "Successful Verify!   Click ""Import"" button to continue."
                    formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Green
                    formModuleImport_CancelButton.Text() = "Cancel"

                    formModuleImport_ImportButton.Visible = True

                Else
                    strStatus = "formModuleImport_BrowseButton_Click(Verify): " & strError

                    strMessage &= vbCrLf & vbCrLf & "Problem with Verify!"
                    strMessage &= vbCrLf & strStatus
                    Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

                    Windows.Forms.MessageBox.Show(strStatus, "formModuleImport_BrowseButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formModuleImport_ImportButton.Visible = False
                    formModuleImport_StatusLabel.Text = "Fail"
                    formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formModuleImport_CancelButton.Text() = "Cancel"
                End If ' END - nsX10DbMethods.importModulesFromCSVFileToX10db(Verify)

            End If ' END - DialogResult

        Catch ex As Exception
            strStatus = "formModuleImport_BrowseButton_Click(): Exception: " & ex.Message

            strMessage &= vbCrLf & vbCrLf & strStatus
            Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

            Windows.Forms.MessageBox.Show(strStatus, "formModuleImport_BrowseButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleImport_ImportButton.Visible = False
            formModuleImport_StatusLabel.Text = "Fail"
            formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleImport_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formModuleImport_BrowseButton_Click()

    Private Sub formModuleImport_ImportButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleImport_ImportButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim intRecordCount As Integer = 0
        Dim intModulesAddedCount As Integer = 0
        Dim intModulesUpdatedCount As Integer = 0
        Dim strModulesAddedList As String = ""
        Dim strModulesUpdatedList As String = ""

        Dim strMessage As String = ""

        Try

            ' Header Row:
            ' "ControllerName","UnitCode","UnitName","UnitDescription","UnitEnabledYN","UnitDimmerYN","UnitLightingYN","UnitExtendedCommandsYN"
            '
            ' Example Record Rows:
            ' "House Lighting CP290","J1","OutGar","Outside Garage Lights","Y","N","Y","N"
            ' "Test CP290","J16","Den Test Dimmer Module","Dimmer LED Test Light in Dimmer Module","Y","Y","Y","N"

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strMessage &= vbCrLf & vbCrLf & "Importing file """ & formModuleImportImportFileTextBox.Text & """"
            strMessage &= vbCrLf & "Please wait......."
            Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

            ' nsX10DbMethods.importModulesFromCSVFileToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByVal strFilename As String, ByVal bVerifyOnly As Boolean, ByRef intRecordCount As Integer, ByRef intModulesAddedCount As Integer, ByRef intModulesUpdatedCount As Integer, ByRef strModulesAddedList As String, ByRef strModulesUpdatedList As String) As String
            strError = nsX10DbMethods.importModulesFromCSVFiletoX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, formModuleImportImportFileTextBox.Text, False, intRecordCount, intModulesAddedCount, intModulesUpdatedCount, strModulesAddedList, strModulesUpdatedList)
            If (strError = "") Then

                strMessage &= vbCrLf & vbCrLf & "RecordCount=" & intRecordCount.ToString()
                strMessage &= vbCrLf & "ModulesAddedCount=" & intModulesAddedCount.ToString()
                If (strModulesAddedList.Length() > 0) Then
                    strMessage &= vbCrLf & strModulesAddedList
                End If
                strMessage &= vbCrLf & "ModulesUpdatedCount=" & intModulesUpdatedCount.ToString()
                If (strModulesUpdatedList.Length() > 0) Then
                    strMessage &= vbCrLf & strModulesUpdatedList
                End If
                strMessage &= vbCrLf & "Successful Import!"
                Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

                formModuleImport_StatusLabel.Text = "Successful Import!"
                formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Green
                formModuleImport_CancelButton.Text() = "Done"

            Else
                strStatus = "formModuleImport_ImportButton_Click(Import): " & strError

                strMessage &= vbCrLf & vbCrLf & "Problem with Import!"
                strMessage &= vbCrLf & strStatus
                Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

                Windows.Forms.MessageBox.Show(strStatus, "formModuleImport_ImportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formModuleImport_ImportButton.Visible = False
                formModuleImport_StatusLabel.Text = "Fail"
                formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Red
                formModuleImport_CancelButton.Text() = "Cancel"
            End If ' END - nsX10DbMethods.importModulesFromCSVFileToX10db(Import)

        Catch ex As Exception
            strStatus = "formModuleImport_ImportButton_Click(): Exception: " & ex.Message

            strMessage &= vbCrLf & vbCrLf & strStatus
            Call formConsoleMessages.DisplayMessage(strMessage, "Module Import from File")

            Windows.Forms.MessageBox.Show(strStatus, "formModuleImport_ImportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleImport_ImportButton.Visible = False
            formModuleImport_StatusLabel.Text = "Fail"
            formModuleImport_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleImport_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formModuleImport_ImportButton_Click()

    Private Sub formModuleImport_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleImport_CancelButton.Click

        Me.Close()

    End Sub ' END - formModuleImport_CancelButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formModuleImport_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleImport" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formModuleImport_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(735, 335)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationModuleImport Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationModuleImport.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationModuleImport.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception
            strStatus = "formModuleImport_FormRestore(): Exception: " & ex.Message
        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formModuleImport_FormRestore()

    '=====================================================================================
    ' Function formModuleImport_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleImport" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formModuleImport_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationModuleImport = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationModuleImport = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception
            strStatus = "formModuleImport_FormSave(): Exception: " & ex.Message
        End Try

        Return strStatus

    End Function ' END - formModuleImport_FormSave()

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles formModuleImportFileLabel05.Click

    End Sub

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formModuleImport