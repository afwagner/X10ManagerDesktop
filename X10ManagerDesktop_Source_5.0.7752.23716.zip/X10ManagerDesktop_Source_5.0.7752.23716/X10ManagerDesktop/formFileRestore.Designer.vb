﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formFileRestore
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formFileRestore))
        Me.formFileRestore_CancelButton = New System.Windows.Forms.Button()
        Me.formFileRestore_RestoreButton = New System.Windows.Forms.Button()
        Me.formFileRestoreLocationLabel = New System.Windows.Forms.Label()
        Me.formFileRestoreLocationLabelNote = New System.Windows.Forms.Label()
        Me.formFileRestoreLocationLabelText = New System.Windows.Forms.Label()
        Me.formFileRestore_StatusLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'formFileRestore_CancelButton
        '
        Me.formFileRestore_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formFileRestore_CancelButton.Location = New System.Drawing.Point(317, 246)
        Me.formFileRestore_CancelButton.Name = "formFileRestore_CancelButton"
        Me.formFileRestore_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formFileRestore_CancelButton.TabIndex = 1
        Me.formFileRestore_CancelButton.Text = "Cancel"
        Me.formFileRestore_CancelButton.UseVisualStyleBackColor = True
        '
        'formFileRestore_RestoreButton
        '
        Me.formFileRestore_RestoreButton.Location = New System.Drawing.Point(12, 246)
        Me.formFileRestore_RestoreButton.Name = "formFileRestore_RestoreButton"
        Me.formFileRestore_RestoreButton.Size = New System.Drawing.Size(75, 23)
        Me.formFileRestore_RestoreButton.TabIndex = 8
        Me.formFileRestore_RestoreButton.Text = "Restore"
        Me.formFileRestore_RestoreButton.UseVisualStyleBackColor = True
        '
        'formFileRestoreLocationLabel
        '
        Me.formFileRestoreLocationLabel.AutoSize = True
        Me.formFileRestoreLocationLabel.Location = New System.Drawing.Point(9, 44)
        Me.formFileRestoreLocationLabel.Name = "formFileRestoreLocationLabel"
        Me.formFileRestoreLocationLabel.Size = New System.Drawing.Size(147, 13)
        Me.formFileRestoreLocationLabel.TabIndex = 7
        Me.formFileRestoreLocationLabel.Text = "formFileRestoreLocationLabel"
        '
        'formFileRestoreLocationLabelNote
        '
        Me.formFileRestoreLocationLabelNote.AutoSize = True
        Me.formFileRestoreLocationLabelNote.Location = New System.Drawing.Point(9, 67)
        Me.formFileRestoreLocationLabelNote.Name = "formFileRestoreLocationLabelNote"
        Me.formFileRestoreLocationLabelNote.Size = New System.Drawing.Size(264, 13)
        Me.formFileRestoreLocationLabelNote.TabIndex = 6
        Me.formFileRestoreLocationLabelNote.Text = "Note: Location can be changed via ""File"" - ""Settings""."
        '
        'formFileRestoreLocationLabelText
        '
        Me.formFileRestoreLocationLabelText.AutoSize = True
        Me.formFileRestoreLocationLabelText.Location = New System.Drawing.Point(9, 21)
        Me.formFileRestoreLocationLabelText.Name = "formFileRestoreLocationLabelText"
        Me.formFileRestoreLocationLabelText.Size = New System.Drawing.Size(129, 13)
        Me.formFileRestoreLocationLabelText.TabIndex = 5
        Me.formFileRestoreLocationLabelText.Text = "Backup/Restore location:"
        '
        'formFileRestore_StatusLabel
        '
        Me.formFileRestore_StatusLabel.AutoSize = True
        Me.formFileRestore_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formFileRestore_StatusLabel.Location = New System.Drawing.Point(93, 249)
        Me.formFileRestore_StatusLabel.Name = "formFileRestore_StatusLabel"
        Me.formFileRestore_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formFileRestore_StatusLabel.TabIndex = 9
        Me.formFileRestore_StatusLabel.Text = "Success | Fail"
        '
        'formFileRestore
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formFileRestore_CancelButton
        Me.ClientSize = New System.Drawing.Size(405, 282)
        Me.Controls.Add(Me.formFileRestore_StatusLabel)
        Me.Controls.Add(Me.formFileRestore_RestoreButton)
        Me.Controls.Add(Me.formFileRestoreLocationLabel)
        Me.Controls.Add(Me.formFileRestoreLocationLabelNote)
        Me.Controls.Add(Me.formFileRestoreLocationLabelText)
        Me.Controls.Add(Me.formFileRestore_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formFileRestore"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Restore Database and Settings"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formFileRestore_CancelButton As Button
    Friend WithEvents formFileRestore_RestoreButton As Button
    Friend WithEvents formFileRestoreLocationLabel As Label
    Friend WithEvents formFileRestoreLocationLabelNote As Label
    Friend WithEvents formFileRestoreLocationLabelText As Label
    Friend WithEvents formFileRestore_StatusLabel As Label
End Class
