﻿
' Name: formSceneAddUpdate.vb
' By: Alan Wagner
' Date: March 2020

Public Class formSceneAddUpdate

#Region "X10ManagerDesktopSceneAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene = Nothing
        Dim intSceneID As Integer = -1
        Dim strSceneHouseCodeLetter As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Try

            Me.BringToFront()

            strTryStep = "formSceneAddUpdate_FormRestore"
            ' formSceneAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formSceneAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formSceneAddUpdateIDLabelText"
                If (formSceneAddUpdateIDLabelText.Text() = "" Or formSceneAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddScene"

                    formSceneAddUpdateIDLabelText.Text() = ""

                    ' Set the caption bar text of the form.
                    Me.Text = "Add Scene"

                    formSceneAddUpdate_AddUpdateButton.Text() = "Add"
                    formSceneAddUpdate_AddUpdateButton.Select()
                    formSceneAddUpdate_StatusLabel.Visible = True
                    formSceneAddUpdate_StatusLabel.Text = ""

                    formSceneAddUpdate_CancelButton.Text() = "Cancel"

                    formSceneAddUpdate_DeleteButton.Visible = False
                    formSceneAddUpdate_DeleteButton.Text() = "Delete"

                    formSceneAddUpdateNameLabel.Visible = True
                    formSceneAddUpdateNameTextBox.Visible = True
                    formSceneAddUpdateNameTextBox.Text() = ""

                    formSceneAddUpdateDescriptionLabel.Visible = True
                    formSceneAddUpdateDescriptionTextBox.Visible = True
                    formSceneAddUpdateDescriptionTextBox.Text() = ""


                    formSceneAddUpdateHouseCodeLabel.Visible = True

                    strTryStep = "Add_generateHouseCodesComboBox"
                    ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                    strStatus = generateHouseCodesComboBox("")
                    If (strStatus = "") Then
                        formSceneAddUpdateHouseCodeComboBox.Visible = True
                    Else
                        formSceneAddUpdateHouseCodeComboBox.Visible = False
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formSceneAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formSceneAddUpdate_CancelButton.Text() = "Cancel"
                    End If


                    formSceneAddUpdateRestrictHouseCodeLabel.Visible = True
                    formSceneAddUpdateRestrictHouseCodeCheckBox.Checked = True
                    formSceneAddUpdateRestrictHouseCodeCheckBox.Enabled = False

                    formSceneAddUpdateModulesInSceneLabel.Visible = True

                    strTryStep = "Add_formSceneAddUpdate_GetSceneModulesDataSet"
                    ' formSceneAddUpdate_GetSceneModulesDataSet(ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
                    strStatus = formSceneAddUpdate_GetSceneModulesDataSet(-1, "")
                    If (strStatus = "") Then
                        formSceneAddUpdateModulesInSceneDataGridView.Visible = True
                    Else
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formSceneAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formSceneAddUpdate_CancelButton.Text() = "Cancel"
                    End If

                    formSceneAddUpdate_ClearAllButton.Visible = True
                    formSceneAddUpdate_SetAllOffButton.Visible = True
                    formSceneAddUpdate_SetAllOnButton.Visible = True

                    formSceneAddUpdateOperationsGroupBox.Visible = False
                    formSceneAddUpdate_TestSceneModulesButton.Visible = False

                Else
                    strTryStep = "UpdateScene"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Scene"

                    formSceneAddUpdate_AddUpdateButton.Text() = "Update"
                    formSceneAddUpdate_AddUpdateButton.Select()
                    formSceneAddUpdate_StatusLabel.Visible = True
                    formSceneAddUpdate_StatusLabel.Text = ""

                    formSceneAddUpdate_CancelButton.Text() = "Done"

                    formSceneAddUpdate_DeleteButton.Visible = True
                    formSceneAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "SceneID"
                    intSceneID = CType(formSceneAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbScene"
                    ' nsX10DbMethods.getX10DbScene(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intSceneID As Integer, ByRef objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene) As String
                    strStatus = nsX10DbMethods.getX10DbScene(strConnectionString, strProvider, intSceneID, objX10DbScene)
                    If (strStatus = "") Then

                        formSceneAddUpdateIDLabelText.Text() = objX10DbScene.SceneID.ToString()

                        formSceneAddUpdateNameLabel.Visible = True
                        formSceneAddUpdateNameTextBox.Visible = True
                        formSceneAddUpdateNameTextBox.Text() = objX10DbScene.SceneName

                        formSceneAddUpdateDescriptionLabel.Visible = True
                        formSceneAddUpdateDescriptionTextBox.Visible = True
                        formSceneAddUpdateDescriptionTextBox.Text() = objX10DbScene.SceneDescription


                        formSceneAddUpdateHouseCodeLabel.Visible = True

                        strTryStep = "Update_generateHouseCodesComboBox"
                        ' generateHouseCodesComboBox(ByVal strHouseCode As String) As String
                        strStatus = generateHouseCodesComboBox(objX10DbScene.SceneHouseCodeLetter)
                        If (strStatus = "") Then
                            formSceneAddUpdateHouseCodeComboBox.Visible = True
                        Else
                            formSceneAddUpdateHouseCodeComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formSceneAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formSceneAddUpdate_CancelButton.Text() = "Cancel"
                        End If


                        formSceneAddUpdateRestrictHouseCodeLabel.Visible = True

                        If (objX10DbScene.SceneRestrictHouseCode = 1 And objX10DbScene.SceneHouseCodeLetter <> "") Then
                            strSceneHouseCodeLetter = objX10DbScene.SceneHouseCodeLetter
                        Else
                            ' All House Codes in Scene.
                            ' Wildcard in MS Access GUI is *
                            ' Wildcard via System.Data.OleDb.OleDbConnection is %
                            strSceneHouseCodeLetter = "%"
                        End If


                        formSceneAddUpdateRestrictHouseCodeCheckBox.Visible = True
                        formSceneAddUpdateRestrictHouseCodeCheckBox.Enabled = True

                        If (objX10DbScene.SceneRestrictHouseCode = 1) Then
                            formSceneAddUpdateRestrictHouseCodeCheckBox.Checked = True
                        Else
                            formSceneAddUpdateRestrictHouseCodeCheckBox.Checked = False
                        End If


                        formSceneAddUpdateModulesInSceneLabel.Visible = True

                        strTryStep = "Update_formSceneAddUpdate_GetSceneModulesDataSet"
                        ' formSceneAddUpdate_GetSceneModulesDataSet(ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
                        strStatus = formSceneAddUpdate_GetSceneModulesDataSet(objX10DbScene.SceneID, strSceneHouseCodeLetter)
                        If (strStatus = "") Then
                            formSceneAddUpdateModulesInSceneDataGridView.Visible = True
                        Else
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formSceneAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formSceneAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                        formSceneAddUpdate_ClearAllButton.Visible = True
                        formSceneAddUpdate_SetAllOffButton.Visible = True
                        formSceneAddUpdate_SetAllOnButton.Visible = True

                        formSceneAddUpdateOperationsGroupBox.Visible = True
                        formSceneAddUpdate_TestSceneModulesButton.Visible = True

                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Scene from X10 db." & vbCrLf & strStatus, "Main(formSceneAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formSceneAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getX10DbScene()

                End If ' END - formSceneAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formSceneAddUpdate): " & strStatus, "Main(formSceneAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formSceneAddUpdate_StatusLabel.Text = "Fail"
                formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formSceneAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formSceneAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formSceneAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formSceneAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formSceneAddUpdate_StatusLabel.Text = "Fail"
            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formSceneAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbScene = Nothing
        End Try

    End Sub ' END Sub - Main(formSceneAddUpdate)

    Private Sub formSceneAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formMain_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formSceneAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formSceneAddUpdate_FormClosingHandler(): " & strStatus, "formSceneAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formSceneAddUpdate_FormSave()

    End Sub ' END Sub - formSceneAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopSceneAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function generateHouseCodesComboBox()
    ' Alan Wagner
    '
    Private Function generateHouseCodesComboBox(ByVal strHouseCode As String) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableHouseCodes As New System.Data.DataTable

        Try

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter("SELECT HouseCodeID, HouseCode FROM HouseCodes UNION SELECT 0 AS HouseCodeID, 'Select HouseCode...' AS HouseCode FROM HouseCodes ORDER BY HouseCodeID ASC", objConnection)
                objOleDbDataAdapter.Fill(objDataTableHouseCodes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            With formSceneAddUpdateHouseCodeComboBox
                .DisplayMember = "HouseCode"
                .ValueMember = "HouseCodeID"
                .DataSource = objDataTableHouseCodes
            End With

            If (strHouseCode = "") Then
                formSceneAddUpdateHouseCodeComboBox.SelectedIndex = 0
            Else
                formSceneAddUpdateHouseCodeComboBox.SelectedIndex = formSceneAddUpdateHouseCodeComboBox.FindString(strHouseCode)
            End If

        Catch ex As Exception
            strStatus = "generateHouseCodesComboBox(): Exception: " & ex.Message
        Finally
            objDataTableHouseCodes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateHouseCodesComboBox()

    '=====================================================================================
    ' Function generateOnOffComboBox()
    ' Alan Wagner
    '
    Private Function generateOnOffComboBox(ByVal intSceneUnitID As Integer, ByVal strDimmer As String, ByRef objOnOffComboBoxCell As System.Windows.Forms.DataGridViewComboBoxCell) As String
        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objDataTableOnOff As New System.Data.DataTable
        Dim sqlString As String = ""

        Dim strModuleType As String = ""

        objOnOffComboBoxCell = Nothing

        Try

            Select Case strDimmer
                Case "Y"
                    strModuleType = "Dimmer"
                Case "N"
                    strModuleType = "Switch"
            End Select

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            sqlString = "SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember " &
                        "FROM ((SceneUnits INNER JOIN Units ON Units.UnitID=SceneUnits.UnitID) INNER JOIN ComboBoxs ON ComboBoxs.Name=SWITCH(Units.UnitDimmer=0,'Switch', Units.UnitDimmer=1,'Dimmer') ) " &
                        "WHERE SceneUnits.SceneUnitID=" & intSceneUnitID.ToString() & " " &
                        "UNION " &
                        "SELECT DISTINCT ComboBoxs.DisplayMember, ComboBoxs.ValueMember " &
                        "FROM ComboBoxs " &
                        "WHERE ComboBoxs.Name='" & strModuleType & "' " &
                        "UNION " &
                        "SELECT DISTINCT 'Clear' AS DisplayMember, -1 AS ValueMember " &
                        "FROM ComboBoxs " &
                        "ORDER BY ComboBoxs.ValueMember DESC;"

            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableOnOff)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            objOnOffComboBoxCell = New System.Windows.Forms.DataGridViewComboBoxCell

            With objOnOffComboBoxCell
                .DisplayMember = "DisplayMember"
                .ValueMember = "ValueMember"
                .DataSource = objDataTableOnOff
            End With

            objOnOffComboBoxCell.AutoComplete = True

        Catch ex As Exception
            objOnOffComboBoxCell = Nothing
            strStatus = "generateOnOffComboBox(): Exception: " & ex.Message
        Finally
            objDataTableOnOff = Nothing
        End Try

        Return strStatus

    End Function ' END - generateOnOffComboBox()

    '=====================================================================================
    ' Function setOnOffComboBoxSelectedValue()
    ' Alan Wagner
    '
    Private Function setOnOffComboBoxSelectedValue(ByVal intRowIndex As Integer, ByVal strDimmer As String, ByVal strOnOff As String) As String
        Dim strStatus As String = ""

        Try

            Select Case strDimmer.ToUpper()
                Case "N"
                    ' Switch
                    ' "Clear", "Off", "On"
                    Select Case strOnOff.ToUpper()
                        Case "CLEAR"
                            'Case "CLEAR", ""
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = -1
                        Case "OFF"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 0
                        Case "ON"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 1
                    End Select
                Case "Y"
                    ' Dimmer
                    ' "Clear", "100%", "94%", "88%", "81%", "75%", "69%", "63%", "56%", "50%", "44%", "38%", "31%", "25%", "19%", "13%", "6%", "Off", "On"
                    ' strOnOff values 0 - 15 are the Dimmer's UnitLevel value.
                    Select Case strOnOff.ToUpper()
                        Case "CLEAR"
                            'Case "CLEAR", ""
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = -1
                        Case "0"
                            ' "100%" - Full Bright
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 0
                        Case "1"
                            ' "94%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 1
                        Case "2"
                            ' "88%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 2
                        Case "3"
                            ' "81%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 3
                        Case "4"
                            ' "75%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 4
                        Case "5"
                            ' "69%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 5
                        Case "6"
                            ' "63%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 6
                        Case "7"
                            ' "56%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 7
                        Case "8"
                            ' "50%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 8
                        Case "9"
                            ' "44%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 9
                        Case "10"
                            ' "38%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 10
                        Case "11"
                            ' "31%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 11
                        Case "12"
                            ' "25%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 12
                        Case "13"
                            ' "19%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 13
                        Case "14"
                            ' "13%"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 14
                        Case "15"
                            ' "6%" - Full Dim
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 15
                        Case "OFF"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 16
                        Case "ON"
                            formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex).Cells("On/Off").Value = 17
                    End Select
            End Select

        Catch ex As Exception
            strStatus = "setOnOffComboBoxSelectedValue(): Exception: " & ex.Message
        End Try

        Return strStatus

    End Function ' END - setOnOffComboBoxSelectedValue()

    '=====================================================================================
    ' formSceneAddUpdate_GetSceneModulesDataSet()
    ' Alan Wagner
    '
    Public Function formSceneAddUpdate_GetSceneModulesDataSet(ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objFactory As System.Data.Common.DbProviderFactory = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataGridViewColumn As System.Windows.Forms.DataGridViewColumn = Nothing
        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim objDataGridViewTextBoxCell As System.Windows.Forms.DataGridViewTextBoxCell = Nothing
        Dim objDataGridViewComboBoxCell As System.Windows.Forms.DataGridViewComboBoxCell = Nothing

        Dim intRowIndex As Integer = -1

        Dim intSceneUnitID As Integer = -1
        Dim strDimmer As String = ""
        Dim strOnOff As String = ""
        Dim intUnitOnOff As Integer = -1
        Dim intUnitLevel As Integer = -1
        Dim intUnitID As Integer = -1
        Dim bSetSelectedOnOff As Boolean = False

        Dim intColumnSceneUnitID As Integer = 8    ' Column that contains SceneUnitID.
        Dim intColumnUnitOnOff As Integer = 9    ' Column that contains UnitOnOff.
        Dim intColumnUnitLevel As Integer = 10    ' Column that contains UnitLevel.
        Dim intColumnUnitID As Integer = 11    ' Column that contains UnitID.

        Dim bShowAdvancedInformation As Boolean = False

        Try

            strTryStep = "bShowAdvancedInformation"
            Select Case X10ManagerDesktop.showAdvancedInformation
                Case 0
                    bShowAdvancedInformation = False
                Case 1
                    bShowAdvancedInformation = True
            End Select

            strTryStep = "Columns.Count"
            If (formSceneAddUpdateModulesInSceneDataGridView.Columns.Count < 1) Then

                strTryStep = "WithFormSceneAddUpdateDataGridView"
                With formSceneAddUpdateModulesInSceneDataGridView
                    .AllowDrop = True
                    .AutoGenerateColumns = False
                    .AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
                    .AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
                    .AllowUserToAddRows = False
                    .AllowUserToDeleteRows = False
                    .AllowUserToOrderColumns = False
                    .AllowUserToResizeColumns = False
                    .AllowUserToResizeRows = False
                    .ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
                    .EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
                    .ReadOnly = False
                    .RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
                    .ShowCellToolTips = False
                    .ShowEditingIcon = False

                    strTryStep = "DataGridViewColumn_Code"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Code"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Code"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Controller"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Controller"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Controller"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Name"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Name"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Name"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_OnOff"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "On/Off"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = False
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewComboBoxCell()
                    objDataGridViewColumn.DataPropertyName = "On/Off"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Description"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Description"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Description"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Dimmer"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Dimmer"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Dimmer"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_ModuleEnabled"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "ModuleEnabled"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "ModuleEnabled"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_ControllerActive"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "ControllerActive"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "ControllerActive"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_ID" ' SceneUnits.SceneUnitID
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "ID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "ID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_UnitOnOff"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "UnitOnOff"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "UnitOnOff"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_UnitLevel"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "UnitLevel"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "UnitLevel"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_UnitID"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "UnitID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "UnitID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                End With ' END - WithFormSceneAddUpdateDataGridView

            Else

                strTryStep = "SelectCaseShowAdvancedInformation"
                Select Case bShowAdvancedInformation
                    Case True
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnSceneUnitID).Visible = True
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnUnitOnOff).Visible = True
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnUnitLevel).Visible = True
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnUnitID).Visible = True
                    Case False
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnSceneUnitID).Visible = False
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnUnitOnOff).Visible = False
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnUnitLevel).Visible = False
                        formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnUnitID).Visible = False
                End Select

            End If ' END - Columns.Count

            strTryStep = "Rows.Count"
            If (formSceneAddUpdateModulesInSceneDataGridView.Rows.Count > 0) Then
                strTryStep = "Rows.Clear"
                formSceneAddUpdateModulesInSceneDataGridView.Rows.Clear()
            End If ' END - Rows.Count

            strTryStep = "ConnectionStrings"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "GetFactory"
            objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

            strTryStep = "sqlString"
            sqlString = "Select Units.UnitCode As [Code]," &
                            "IIf(Controllers.ControllerID Is Null,'', Controllers.ControllerName+' ['+ControllerTypes.ControllerType+']') AS [Controller], IIf(Controllers.ControllerID Is Null,'', SWITCH (Controllers.ControllerActive=0,'N',Controllers.ControllerActive=1,'Y')) AS [ControllerActive]," &
                            "Units.UnitName AS [Name], Units.UnitDescription AS [Description]," &
                            "SWITCH (Units.UnitDimmer=0,'N',Units.UnitDimmer=1,'Y') AS [Dimmer]," &
                            "SWITCH( SceneUnits.UnitOnOff=0, 'Off', SceneUnits.UnitOnOff=1 AND Units.UnitDimmer=0, 'On', SceneUnits.UnitOnOff=1 AND Units.UnitDimmer=1 AND SceneUnits.UnitLevel=17, 'On', SceneUnits.UnitOnOff=1 AND Units.UnitDimmer=1 AND SceneUnits.UnitLevel>-1 AND SceneUnits.UnitLevel<16, TRIM(STR(SceneUnits.UnitLevel)) ) AS [On/Off]," &
                            "SceneUnits.UnitOnOff," &
                            "SceneUnits.UnitLevel," &
                            "SceneUnits.SceneUnitID AS [ID]," &
                            "Units.UnitHouseNumber AS [HN]," &
                            "Units.UnitModuleNumber AS [MN]," &
                            "Units.UnitID," &
                            "SWITCH (Units.UnitEnabled=0,'N',Units.UnitEnabled=1,'Y') AS [ModuleEnabled] " &
                            "FROM ((((Units INNER JOIN SceneUnits ON SceneUnits.UnitID=Units.UnitID) INNER JOIN Scenes ON Scenes.SceneID=SceneUnits.SceneID) LEFT JOIN Controllers ON Controllers.ControllerID=Units.ControllerID) LEFT JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID) " &
                            "WHERE Scenes.SceneID=" & intSceneID.ToString() & " " &
                            "AND Units.UnitHouseCode Like '" & strSceneHouseCodeLetter & "' " &
                            "UNION " &
                            "SELECT Units.UnitCode AS [Code]," &
                            "IIf(Controllers.ControllerID Is Null,'', Controllers.ControllerName+' ['+ControllerTypes.ControllerType+']') AS [Controller], IIf(Controllers.ControllerID Is Null,'', SWITCH (Controllers.ControllerActive=0,'N',Controllers.ControllerActive=1,'Y')) AS [ControllerActive]," &
                            "Units.UnitName AS [Name], Units.UnitDescription AS [Description]," &
                            "SWITCH (Units.UnitDimmer=0,'N',Units.UnitDimmer=1,'Y') AS [Dimmer]," &
                            "'' AS [On/Off]," &
                            "-1 AS [UnitOnOff]," &
                            "-1 AS [UnitLevel]," &
                            "-1 AS [ID]," &
                            "Units.UnitHouseNumber AS [HN]," &
                            "Units.UnitModuleNumber AS [MN]," &
                            "Units.UnitID," &
                            "SWITCH (Units.UnitEnabled=0,'N',Units.UnitEnabled=1,'Y') AS [ModuleEnabled] " &
                            "FROM ((Units LEFT JOIN Controllers ON Controllers.ControllerID=Units.ControllerID) LEFT JOIN ControllerTypes ON ControllerTypes.ControllerTypeID=Controllers.ControllerTypeID) " &
                            "WHERE NOT Units.UnitID IN (SELECT Units.UnitID FROM ((Units INNER JOIN SceneUnits ON SceneUnits.UnitID=Units.UnitID) INNER JOIN Scenes ON Scenes.SceneID=SceneUnits.SceneID) WHERE SceneUnits.SceneID=" & intSceneID.ToString() & ") " &
                            "AND Units.UnitHouseCode Like '" & strSceneHouseCodeLetter & "' " &
                            "ORDER BY [HN], [MN], [Controller];"

            strTryStep = "CreateConnection"
            Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                strTryStep = "ConnectionString"
                objDbConnection.ConnectionString = strConnectionString

                strTryStep = "Connection.Open"
                objDbConnection.Open()

                strTryStep = "CreateCommand"
                Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                    strTryStep = "CommandText"
                    objDbCommand.CommandText = sqlString

                    strTryStep = "CommandTimeout"
                    objDbCommand.CommandTimeout = 30 ' Seconds

                    strTryStep = "CommandType"
                    ' Text              - An SQL text command (default).
                    ' StoredProcedure   - To call a stored procedure.
                    ' TableDirect       - All rows and columns of the named table or tables will be returned.
                    objDbCommand.CommandType() = CommandType.Text

                    strTryStep = "ExecuteReader"
                    ' ExecuteReader     - Executes commands that return rows.
                    '   System.Data.CommandBehavior.Default          - The query may return multiple result sets. ExecuteReader(CommandBehavior.Default) is functionally equivalent to calling ExecuteReader().
                    '   System.Data.CommandBehavior.SingleResult     - The query returns a single result set.
                    '   System.Data.CommandBehavior.SchemaOnly       - The query returns column information only.
                    '   System.Data.CommandBehavior.KeyInfo          - The query returns column and primary key information.
                    '   System.Data.CommandBehavior.SingleRow        - The query is expected to return a single row of the first result set.
                    '   System.Data.CommandBehavior.SequentialAccess - Provides a way for the DataReader to handle rows that contain columns with large binary values. You can then use the GetBytes or GetChars method to specify a byte location to start the read operation.
                    '   System.Data.CommandBehavior.CloseConnection  - When the command is executed, the associated Connection object is closed when the associated DataReader object is closed.
                    ' ExecuteNonQuery   - Executes commands such as Transact-SQL INSERT, DELETE, UPDATE, and SET statements.
                    ' ExecuteScalar     - Retrieves a single value (for example, an aggregate value) from a database.
                    ' ExecuteXmlReader  - Sends the CommandText to the Connection and builds an XmlReader object.
                    Using objDbDataReader As System.Data.Common.DbDataReader = objDbCommand.ExecuteReader(System.Data.CommandBehavior.Default)

                        strTryStep = "HasRows"
                        If objDbDataReader.HasRows() Then

                            strTryStep = "Read"
                            While objDbDataReader.Read()
                                intRowIndex = intRowIndex + 1
                                bSetSelectedOnOff = False

                                strTryStep = "SceneUnitID" ' SceneUnits.SceneUnitID
                                intSceneUnitID = CType(objDbDataReader("ID"), Integer)

                                strTryStep = "Dimmer"
                                strDimmer = objDbDataReader("Dimmer")

                                strTryStep = "OnOff"
                                If (Microsoft.VisualBasic.IsDBNull(objDbDataReader("On/Off"))) Then
                                    strOnOff = ""
                                Else
                                    strOnOff = objDbDataReader("On/Off").ToString()
                                End If

                                strTryStep = "UnitOnOff"
                                intUnitOnOff = CType(objDbDataReader("UnitOnOff"), Integer)

                                strTryStep = "UnitLevel"
                                intUnitLevel = CType(objDbDataReader("UnitLevel"), Integer)

                                strTryStep = "UnitID"
                                intUnitID = CType(objDbDataReader("UnitID"), Integer)

                                strTryStep = "NewObjectDataGridViewRow"
                                objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                                strTryStep = "Add_Code"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("Code").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_Controller"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("Controller").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_Name"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("Name").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "generateOnOffComboBox"
                                ' generateOnOffComboBox(ByVal intSceneUnitID As Integer, ByVal strDimmer As String, ByRef objOnOffComboBoxCell As System.Windows.Forms.DataGridViewComboBoxCell) As String
                                strError = generateOnOffComboBox(intSceneUnitID, strDimmer, objDataGridViewComboBoxCell)
                                If (strError = "") Then

                                    strTryStep = "Add_OnOff"
                                    objDataGridViewRow.Cells.Add(objDataGridViewComboBoxCell)
                                    bSetSelectedOnOff = True

                                Else

                                    If (strStatus = "") Then
                                        strStatus = "formSceneAddUpdate_GetSceneModulesDataSet(): " & strError
                                    Else
                                        strStatus &= vbCrLf & "formSceneAddUpdate_GetSceneModulesDataSet(): " & strError
                                    End If

                                    strTryStep = "Add_OnOff_ComboBoxFail"
                                    objDataGridViewComboBoxCell = New System.Windows.Forms.DataGridViewComboBoxCell
                                    objDataGridViewRow.Cells.Add(objDataGridViewComboBoxCell)
                                    bSetSelectedOnOff = False

                                End If ' END - generateOnOffComboBox()
                                objDataGridViewComboBoxCell = Nothing

                                strTryStep = "Add_Description"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("Description").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_Dimmer"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = strDimmer
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_ModuleEnabled"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("ModuleEnabled").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_ControllerActive"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("ControllerActive").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_ID" ' SceneUnits.SceneUnitID
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = intSceneUnitID.ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_UnitOnOff"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = intUnitOnOff.ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_UnitLevel"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = intUnitLevel.ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_UnitID"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = intUnitID.ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Rows.Add"
                                formSceneAddUpdateModulesInSceneDataGridView.Rows.Add(objDataGridViewRow)

                                strTryStep = "bSetSelectedOnOff"
                                If bSetSelectedOnOff Then

                                    'strStatus &= vbCrLf & "formSceneAddUpdate_GetSceneModulesDataSet(): DataGridViewRow=" & intRowIndex.ToString()
                                    'strStatus &= vbCrLf & "  Dimmer=" & strDimmer
                                    'strStatus &= vbCrLf & "  OnOff=" & strOnOff

                                    strTryStep = "setSelectedOnOffComboBox"
                                    ' This can only be done after row is added.
                                    ' setOnOffComboBoxSelectedValue(ByVal intRowIndex As Integer, ByVal strDimmer As String, ByVal strOnOff As String) As String
                                    strError = setOnOffComboBoxSelectedValue(intRowIndex, strDimmer, strOnOff)
                                    If (strError <> "") Then
                                        If (strStatus = "") Then
                                            strStatus = "formSceneAddUpdate_GetSceneModulesDataSet(): " & strError
                                        Else
                                            strStatus &= vbCrLf & "formSceneAddUpdate_GetSceneModulesDataSet(): " & strError
                                        End If
                                    End If ' END - setSelectedOnOffComboBox()

                                End If

                                objDataGridViewRow = Nothing
                            End While

                        End If ' END - HasRows

                    End Using ' END - ExecuteReader

                End Using ' END - CreateCommand

                strTryStep = "Connection.Close"
                objDbConnection.Close()

            End Using ' END - CreateConnection

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "formSceneAddUpdate_GetSceneModulesDataSet(" & strTryStep & "): Exception: " & ex.Message & vbCrLf & sqlString
            Else
                strStatus &= vbCrLf & "formSceneAddUpdate_GetSceneModulesDataSet(" & strTryStep & "): Exception: " & ex.Message & vbCrLf & sqlString
            End If
        Finally
            objDataGridViewTextBoxCell = Nothing
            objDataGridViewComboBoxCell = Nothing
            objDataGridViewRow = Nothing
            objDataGridViewColumn = Nothing
            objFactory = Nothing
        End Try

        Return strStatus

    End Function ' END - formSceneAddUpdate_GetSceneModulesDataSet()

    '=====================================================================================
    ' Function addUpdateRemoveModulesInSceneToX10Db()
    ' Alan Wagner
    '
    Private Function addUpdateRemoveModulesInSceneToX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objFactory As System.Data.Common.DbProviderFactory = Nothing

        Dim intRowIndex As Integer = 0
        Dim intColumnIndex As Integer = 0
        Dim intCellIndex As Integer = 0
        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing
        Dim objDataGridViewCellCollection As System.Windows.Forms.DataGridViewCellCollection = Nothing

        Dim intSceneUnitID As Integer = -1
        Dim strModuleCode As String = ""
        Dim strModuleName As String = ""
        Dim strDimmer As String = ""
        Dim strOnOff As String = ""
        Dim intUnitOnOff As Integer = -1
        Dim intUnitOnOffNew As Integer = -1
        Dim intUnitLevel As Integer = -1
        Dim intUnitLevelNew As Integer = -1
        Dim intUnitID As Integer = -1
        Dim intBLObValue As Integer = -1

        Dim bSceneUnitID As Boolean = False
        Dim bModuleCode As Boolean = False
        Dim bModuleName As Boolean = False
        Dim bDimmer As Boolean = False
        Dim bOnOff As Boolean = False
        Dim bUnitOnOff As Boolean = False
        Dim bUnitLevel As Boolean = False
        Dim bUnitID As Boolean = False

        Dim sqlString As String = ""
        Dim intRowsAffected As Integer = 0

        Try

            strTryStep = "Rows.Count"
            If (formSceneAddUpdateModulesInSceneDataGridView.Rows.Count > 0) Then

                strTryStep = "GetFactory"
                objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

                strTryStep = "CreateConnection"
                Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                    strTryStep = "ConnectionString"
                    objDbConnection.ConnectionString = strConnectionString

                    strTryStep = "Connection.Open"
                    objDbConnection.Open()

                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewRows"
                    For intRowIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.RowCount - 1 Step 1

                        strTryStep = "NewObjectDataGridViewRow"
                        objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                        strTryStep = "GetDataGridViewRow"
                        objDataGridViewRow = formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex)

                        strTryStep = "ResetRowValues"
                        intSceneUnitID = -1
                        strModuleCode = ""
                        strModuleName = ""
                        strDimmer = ""
                        strOnOff = ""
                        intUnitOnOff = -1
                        intUnitLevel = -1
                        intUnitID = -1
                        intBLObValue = 0

                        bSceneUnitID = False
                        bModuleCode = False
                        bModuleName = False
                        bDimmer = False
                        bOnOff = False
                        bUnitOnOff = False
                        bUnitLevel = False
                        bUnitID = False

                        strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns"
                        For intColumnIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.ColumnCount - 1 Step 1

                            strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name"
                            Select Case formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnIndex).Name.ToUpper()
                                Case "ID"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.SceneUnitID"
                                    intSceneUnitID = CType(objDataGridViewRow.Cells.Item(intColumnIndex).Value, Integer)
                                    bSceneUnitID = True
                                Case "CODE"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.Code"
                                    strModuleCode = objDataGridViewRow.Cells.Item(intColumnIndex).Value
                                    bModuleCode = True
                                Case "NAME"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.Name"
                                    strModuleName = objDataGridViewRow.Cells.Item(intColumnIndex).Value
                                    bModuleName = True
                                Case "DIMMER"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.Dimmer"
                                    strDimmer = objDataGridViewRow.Cells.Item(intColumnIndex).Value
                                    bDimmer = True
                                Case "ON/OFF"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.On/Off"
                                    strOnOff = objDataGridViewRow.Cells.Item(intColumnIndex).FormattedValue
                                    bOnOff = True
                                Case "UNITONOFF"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.UnitOnOff"
                                    intUnitOnOff = CType(objDataGridViewRow.Cells.Item(intColumnIndex).Value, Integer)
                                    bUnitOnOff = True
                                Case "UNITLEVEL"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.UnitLevel"
                                    intUnitLevel = CType(objDataGridViewRow.Cells.Item(intColumnIndex).Value, Integer)
                                    bUnitLevel = True
                                Case "UNITID"
                                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.UnitID"
                                    intUnitID = CType(objDataGridViewRow.Cells.Item(intColumnIndex).Value, Integer)
                                    bUnitID = True
                            End Select

                        Next ' END - ForNextFormSceneAddUpdateDataGridViewColumns

                        strTryStep = "ReadAllValues?"
                        If (bSceneUnitID And bModuleCode And bModuleName And bDimmer And bOnOff And bUnitOnOff And bUnitLevel And bUnitID) Then

                            'strStatus &= vbCrLf & "addUpdateRemoveModulesInSceneToX10Db(): DataGridViewRow=" & intRowIndex.ToString()
                            'strStatus &= vbCrLf & "  SceneUnitID=" & intSceneUnitID.ToString()
                            'strStatus &= vbCrLf & "  ModuleName=" & strModuleName
                            'strStatus &= vbCrLf & "  Dimmer=" & strDimmer
                            'strStatus &= vbCrLf & "  OnOff=" & strOnOff
                            'strStatus &= vbCrLf & "  UnitOnOff=" & intUnitOnOff.ToString()
                            'strStatus &= vbCrLf & "  UnitLevel=" & intUnitLevel.ToString()
                            'strStatus &= vbCrLf & "  UnitID=" & intUnitID.ToString()

                            strTryStep = "ResetSqlString"
                            sqlString = ""

                            strTryStep = "SelectCaseOnOff"
                            Select Case strOnOff.ToUpper()
                                Case "CLEAR", ""
                                    strTryStep = "SelectCaseOnOffClear"

                                    strTryStep = "SceneUnitIDRemove"
                                    If (intSceneUnitID >= 0) Then
                                        ' Remove existing record from SceneUnits table.

                                        strTryStep = "sqlStringDELETE"
                                        sqlString = "DELETE FROM SceneUnits WHERE SceneUnitID=" & intSceneUnitID.ToString() & ";"

                                    End If ' END - SceneUnitIDRemove

                                Case Else
                                    strTryStep = "SelectCaseOnOffElse"
                                    ' Update-or-Add record to SceneUnits table.

                                    strTryStep = "nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues"
                                    ' nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(ByVal strDimmer As String, ByVal strOnOff As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer) As String
                                    strError = nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues(strDimmer, strOnOff, intUnitOnOffNew, intUnitLevelNew)
                                    If (strError = "") Then

                                        strTryStep = "CheckForChange"
                                        If (intUnitOnOffNew <> intUnitOnOff Or intUnitLevelNew <> intUnitLevel) Then
                                            ' On/Off or Level has changed.

                                            strTryStep = "BLObValue"
                                            Select Case strDimmer
                                                Case "Y"

                                                    Select Case intUnitOnOffNew
                                                        Case 0
                                                            intBLObValue = 0
                                                        Case 1
                                                            intBLObValue = (15 - intUnitLevelNew) + 2
                                                    End Select

                                                Case "N"
                                                    intBLObValue = intUnitOnOffNew
                                            End Select

                                            strTryStep = "SceneUnitIDUpdateOrAdd"
                                            If (intSceneUnitID >= 0) Then
                                                ' Update existing record in SceneUnits Table.

                                                strTryStep = "sqlStringUPDATE"
                                                sqlString = "UPDATE SceneUnits " &
                                                    "SET SceneID=" & intSceneID.ToString() &
                                                    ",UnitID=" & intUnitID.ToString() &
                                                    ",BLObValue=" & intBLObValue.ToString() &
                                                    ",UnitOnOff=" & intUnitOnOffNew.ToString() &
                                                    ",UnitLevel=" & intUnitLevelNew.ToString() &
                                                    " WHERE SceneUnitID=" & intSceneUnitID.ToString() & ";"

                                            Else
                                                ' Add new record to SceneUnits Table.

                                                strTryStep = "sqlStringINSERT"
                                                sqlString = "INSERT INTO SceneUnits " &
                                                    "(SceneID,UnitID,BLObValue,UnitOnOff,UnitLevel) " &
                                                    "VALUES " &
                                                    "(" & intSceneID.ToString() &
                                                    "," & intUnitID.ToString() &
                                                    "," & intBLObValue.ToString() &
                                                    "," & intUnitOnOffNew.ToString() &
                                                    "," & intUnitLevelNew.ToString() & ");"

                                            End If ' END - SceneUnitIDUpdateOrAdd

                                        End If ' END - CheckForChange

                                    Else
                                        strStatus = "addUpdateRemoveModulesInSceneToX10Db(): " & strError
                                    End If ' END - nsX10DbMethods.getUnitOnOffAndUnitLevelFromOnOffAndDimmerValues()

                            End Select ' END - SelectCaseOnOff

                            strTryStep = "sqlStringPresent"
                            If (sqlString <> "") Then

                                strTryStep = "CreateCommand"
                                Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                                    strTryStep = "CommandText"
                                    objDbCommand.CommandText = sqlString

                                    strTryStep = "CommandTimeout"
                                    objDbCommand.CommandTimeout = 30 ' Seconds

                                    strTryStep = "CommandType"
                                    ' Text              - An SQL text command (default).
                                    ' StoredProcedure   - To call a stored procedure.
                                    ' TableDirect       - All rows and columns of the named table or tables will be returned.
                                    objDbCommand.CommandType() = CommandType.Text

                                    strTryStep = "ExecuteNonQuery"
                                    intRowsAffected = objDbCommand.ExecuteNonQuery()
                                    If (intRowsAffected <> 1) Then
                                        strStatus = "addUpdateRemoveModulesInSceneToX10Db(): Problem with Module """ & strModuleName & """ Update."
                                        Exit For
                                    End If

                                End Using ' END - CreateCommand

                            End If ' END - sqlStringPresent

                        Else

                            strStatus = "addUpdateRemoveModulesInSceneToX10Db(): Values missing from current DataGridViewRow=" & intRowIndex.ToString()

                            If (Not bSceneUnitID) Then
                                strStatus &= ": SceneUnitID"
                            End If

                            If (Not bModuleCode) Then
                                strStatus &= ": ModuleCode"
                            End If

                            If (Not bModuleName) Then
                                strStatus &= ": ModuleName"
                            End If

                            If (Not bDimmer) Then
                                strStatus &= ": Dimmer"
                            End If

                            If (Not bOnOff) Then
                                strStatus &= ": OnOff"
                            End If

                            If (Not bUnitOnOff) Then
                                strStatus &= ": UnitOnOff"
                            End If

                            If (Not bUnitLevel) Then
                                strStatus &= ": UnitLevel"
                            End If

                            If (Not bUnitID) Then
                                strStatus &= ": UnitID"
                            End If

                        End If ' END - ReadAllValues?

                        objDataGridViewRow = Nothing
                    Next ' END - ForNextFormSceneAddUpdateDataGridViewRows

                    strTryStep = "Connection.Close"
                    objDbConnection.Close()

                End Using ' END - CreateConnection

                If (strStatus = "") Then

                    strTryStep = "formSceneAddUpdate_GetSceneModulesDataSet"
                    ' formSceneAddUpdate_GetSceneModulesDataSet(ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
                    strError = formSceneAddUpdate_GetSceneModulesDataSet(intSceneID, strSceneHouseCodeLetter)
                    If (strError <> "") Then
                        strStatus = "addUpdateRemoveModulesInSceneToX10Db(): " & strError
                    End If ' END - formSceneAddUpdate_GetSceneModulesDataSet()

                End If

            End If ' END - Rows.Count

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "addUpdateRemoveModulesInSceneToX10Db(" & strTryStep & "): Exception: " & ex.Message & vbCrLf & "sqlString=" & sqlString
            Else
                strStatus &= vbCrLf & "addUpdateRemoveModulesInSceneToX10Db(" & strTryStep & "): Exception: " & ex.Message & vbCrLf & "sqlString=" & sqlString
            End If
        Finally
            objDataGridViewCellCollection = Nothing
            objDataGridViewRow = Nothing
            objFactory = Nothing
        End Try

        Return strStatus

    End Function ' END - addUpdateRemoveModulesInSceneToX10Db()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formSceneAddUpdateHouseCodeComboBox_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdateHouseCodeComboBox.SelectionChangeCommitted
        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim objDataRowView As System.Data.DataRowView = Nothing
        Dim strHouseCode As String = ""
        Dim intHouseCodeID As Integer = 0

        Dim intSceneID As Integer = -1

        Try

            If (formSceneAddUpdateIDLabelText.Text() <> "") Then
                intSceneID = CType(formSceneAddUpdateIDLabelText.Text(), Integer)
            End If

            objDataRowView = formSceneAddUpdateHouseCodeComboBox.SelectedItem
            intHouseCodeID = CType(objDataRowView(0), Integer)

            If (Not formSceneAddUpdateRestrictHouseCodeCheckBox.Checked Or intHouseCodeID = 0) Then
                ' All House Codes in Scene.
                ' Wildcard in MS Access GUI is *
                ' Wildcard via System.Data.OleDb.OleDbConnection is %
                strHouseCode = "%"
            Else
                strHouseCode = objDataRowView(1).ToString ' ex: "A"
            End If

            ' formSceneAddUpdate_GetSceneModulesDataSet(ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
            strError = formSceneAddUpdate_GetSceneModulesDataSet(intSceneID, strHouseCode)
            If (strError <> "") Then
                strStatus = "formSceneAddUpdateHouseCodeComboBox_SelectedIndexChanged(): " & strError
                Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdateHouseCodeComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            strStatus = "formSceneAddUpdateHouseCodeComboBox_SelectedIndexChanged(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdateHouseCodeComboBox_SelectedIndexChanged()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objDataRowView = Nothing
        End Try

    End Sub ' END - formSceneAddUpdateHouseCodeComboBox_SelectedIndexChanged()

    Private Sub formSceneAddUpdateRestrictHouseCodeCheckBox_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdateRestrictHouseCodeCheckBox.Click
        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing
        Dim strHouseCode As String = ""
        Dim intHouseCodeID As Integer = 0

        Dim intSceneID As Integer = -1

        Try

            If (formSceneAddUpdateIDLabelText.Text() <> "") Then
                intSceneID = CType(formSceneAddUpdateIDLabelText.Text(), Integer)
            End If

            objDataRowViewHouseCode = formSceneAddUpdateHouseCodeComboBox.SelectedItem
            intHouseCodeID = CType(objDataRowViewHouseCode(0), Integer)

            If (Not formSceneAddUpdateRestrictHouseCodeCheckBox.Checked Or intHouseCodeID = 0) Then
                ' All House Codes in Scene.
                ' Wildcard in MS Access GUI is *
                ' Wildcard via System.Data.OleDb.OleDbConnection is %
                strHouseCode = "%"
            Else
                strHouseCode = objDataRowViewHouseCode(1).ToString ' ex: "A"
            End If

            ' formSceneAddUpdate_GetSceneModulesDataSet(ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
            strError = formSceneAddUpdate_GetSceneModulesDataSet(intSceneID, strHouseCode)
            If (strError <> "") Then
                strStatus = "formSceneAddUpdateRestrictHouseCodeCheckBox_Click(): " & strError
                Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdateRestrictHouseCodeCheckBox_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If

        Catch ex As Exception
            strStatus = "formSceneAddUpdateRestrictHouseCodeCheckBox_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdateRestrictHouseCodeCheckBox_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objDataRowViewHouseCode = Nothing
        End Try

    End Sub ' END - formSceneAddUpdateRestrictHouseCodeCheckBox_Click()

    Private Sub formSceneAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene = Nothing
        Dim objX10DbSceneTest As TrekkerPhotoArt.X10Include.X10DbScene = Nothing

        Dim objDataRowViewSceneHouseCode As System.Data.DataRowView = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormSceneEdit As formSceneEdit = Nothing

        Try

            objX10DbScene = New TrekkerPhotoArt.X10Include.X10DbScene

            If (formSceneAddUpdateNameTextBox.Text.Trim() = "") Then
                strStatus = "Missing Scene Name."
            Else
                objX10DbScene.SceneName = formSceneAddUpdateNameTextBox.Text().Trim()
            End If

            objDataRowViewSceneHouseCode = formSceneAddUpdateHouseCodeComboBox.SelectedItem
            If (objDataRowViewSceneHouseCode.Row("HouseCodeID").ToString() = "0") Then
                If (strStatus = "") Then
                    strStatus = "Missing Scene House Code."
                Else
                    strStatus &= vbCrLf & "Missing Scene House Code."
                End If
            Else
                objX10DbScene.SceneHouseCodeLetter = objDataRowViewSceneHouseCode(1).ToString ' DisplayMember ex: "A"
            End If

            ' Was Something Missing?
            If (strStatus = "") Then

                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                ' Verify the Scene Name has not already been used.

                ' nsX10DbMethods.getX10DbScene(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSceneName As String, ByRef objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene) As String
                strError = nsX10DbMethods.getX10DbScene(strConnectionString, strProvider, objX10DbScene.SceneName, objX10DbSceneTest)
                If (strError = "") Then

                    ' Was a Scene found?
                    If (Not objX10DbSceneTest Is Nothing AndAlso objX10DbSceneTest.SceneID >= 0) Then
                        ' A Scene was found with the specified Scene Name.

                        ' Add or Modify Scene?
                        If (formSceneAddUpdate_AddUpdateButton.Text() = "Add") Then
                            strStatus = "Unable to Add the Scene. The Scene Name has already been used by another Scene."
                            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Else
                            ' Modify Scene

                            objX10DbScene.SceneID = CType(formSceneAddUpdateIDLabelText.Text(), Integer)

                            If (objX10DbSceneTest.SceneID <> objX10DbScene.SceneID) Then
                                strStatus = "Unable to Update Scene information. The new Scene Name has already been used by another Scene."
                                Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formSceneAddUpdate_StatusLabel.Text = "Fail"
                                formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            End If

                        End If ' END - Add or Modify Scene?

                    Else
                        ' Nothing found.
                        If (formSceneAddUpdate_AddUpdateButton.Text() = "Add") Then
                            ' Add Scene
                            objX10DbScene.SceneID = -1
                        Else
                            ' Modify Scene
                            objX10DbScene.SceneID = CType(formSceneAddUpdateIDLabelText.Text(), Integer)
                        End If ' END - Add or Modify Scene
                    End If ' END - Was a Scene found?

                Else
                    strStatus = "Problem determining if Scene Name has already been used." & vbCrLf & strError
                    Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formSceneAddUpdate_StatusLabel.Text = "Fail"
                    formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                End If ' END - nsX10DbMethods.getX10DbScene()
                If (strStatus = "") Then

                    objX10DbScene.SceneDescription = formSceneAddUpdateDescriptionTextBox.Text().Trim()
                    objX10DbScene.SceneHouseCodeNumber = nsX10DbMethods.UnitHouseCodeToUnitHouseNumber(objX10DbScene.SceneHouseCodeLetter)

                    If (formSceneAddUpdateRestrictHouseCodeCheckBox.Checked) Then
                        objX10DbScene.SceneRestrictHouseCode = 1
                    Else
                        objX10DbScene.SceneRestrictHouseCode = 0
                    End If

                    ' nsX10DbMethods.addUpdateSceneToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.addUpdateSceneToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbScene, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then
                            formSceneAddUpdateIDLabelText.Text() = objX10DbScene.SceneID.ToString()

                            ' addUpdateRemoveModulesInSceneToX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intSceneID As Integer, ByVal strSceneHouseCodeLetter As String) As String
                            strStatus = addUpdateRemoveModulesInSceneToX10Db(strConnectionString, strProvider, objX10DbScene.SceneID, objX10DbScene.SceneHouseCodeLetter)
                            If (strStatus = "") Then

                                If (formSceneAddUpdate_AddUpdateButton.Text() = "Add") Then
                                    formSceneAddUpdate_AddUpdateButton.Text() = "Update"
                                    formSceneAddUpdate_StatusLabel.Text = "Successfully Added"
                                    formSceneAddUpdate_DeleteButton.Visible = True
                                Else
                                    formSceneAddUpdate_StatusLabel.Text = "Successfully Updated"
                                End If

                                formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                                formSceneAddUpdate_CancelButton.Text() = "Done"

                                objFormSceneEdit = New formSceneEdit
                                objFormSceneEdit.formSceneEdit_BringToFrontLabel.Text() = "N"

                                formSceneAddUpdateOperationsGroupBox.Visible = True
                                formSceneAddUpdate_TestSceneModulesButton.Visible = True

                                ' Refresh DataSet on Form formSceneEdit if it's active.
                                If objFormCollection.OfType(Of formSceneEdit).Any Then

                                    objFormSceneEdit = objFormCollection.Item("formSceneEdit")

                                    ' formSceneEdit_GetScenesDataSet() As String
                                    strStatus = objFormSceneEdit.formSceneEdit_GetScenesDataSet()
                                    If (strStatus = "") Then
                                        objFormSceneEdit.Activate()
                                    Else
                                        Windows.Forms.MessageBox.Show("formSceneAddUpdate_AddUpdateButton_Click(): " & strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    End If ' END - formSceneEdit_GetScenesDataSet()

                                End If

                                ' Refresh "Events" DataSet on any open "Update Schedules" forms.
                                If objFormCollection.OfType(Of formScheduleEdit).Any Then

                                    For Each objFormScheduleAddUpdate As formScheduleAddUpdate In objFormCollection.OfType(Of formScheduleAddUpdate)

                                        ' X10ManagerDesktop.RefreshOpenScheduleAddUpdateForm(ByRef objFormScheduleAddUpdate As formScheduleAddUpdate) As String
                                        strStatus = X10ManagerDesktop.RefreshOpenScheduleAddUpdateForm(objFormScheduleAddUpdate)
                                        If (strStatus <> "") Then
                                            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                            Exit For
                                        End If

                                    Next
                                End If

                            Else
                                formSceneAddUpdate_StatusLabel.Text = "Fail"
                                formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formSceneAddUpdate_CancelButton.Text() = "Cancel"
                                Windows.Forms.MessageBox.Show("Problem modifying Modules in Scene to X10 Db." & vbCrLf & strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If ' END - addUpdateRemoveModulesInSceneToX10Db()

                        Else
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formSceneAddUpdate_CancelButton.Text() = "Cancel"
                            If (formSceneAddUpdate_AddUpdateButton.Text() = "Add") Then
                                Windows.Forms.MessageBox.Show("Problem adding Scene to X10 Db.", "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            Else
                                Windows.Forms.MessageBox.Show("Problem modifying Scene to X10 Db.", "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            End If
                        End If

                    Else
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formSceneAddUpdate_CancelButton.Text() = "Cancel"
                        If (formSceneAddUpdate_AddUpdateButton.Text() = "Add") Then
                            Windows.Forms.MessageBox.Show("Problem adding Scene to X10 Db." & vbCrLf & strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Else
                            Windows.Forms.MessageBox.Show("Problem modifying Scene to X10 Db." & vbCrLf & strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If
                    End If ' END - nsX10DbMethods.addUpdateSceneToX10db()

                End If ' END - nsX10DbMethods.getX10DbScene()

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formSceneAddUpdate_StatusLabel.Text = "Fail"
                formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            End If ' END - Was Something Missing?

        Catch ex As Exception
            strStatus = "formSceneAddUpdate_AddUpdateButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formSceneAddUpdate_StatusLabel.Text = "Fail"
            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formSceneAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormSceneEdit = Nothing
            objDataRowViewSceneHouseCode = Nothing
            objX10DbSceneTest = Nothing
            objX10DbScene = Nothing
        End Try

    End Sub ' END - formSceneAddUpdate_AddUpdateButton_Click()

    Private Sub formSceneAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formSceneAddUpdate_CancelButton_Click()

    Private Sub formSceneAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene = Nothing
        Dim intSceneID As Integer = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormSceneEdit As formSceneEdit = Nothing

        Try

            If (formSceneAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing SceneID", "formSceneAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                If Windows.Forms.MessageBox.Show("Confirm removal of Scene" & vbCrLf & """" & formSceneAddUpdateNameTextBox.Text() & """ [" & formSceneAddUpdateIDLabelText.Text() & "]?", "Confirm", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Stop) = Windows.Forms.DialogResult.Yes Then

                    intSceneID = CType(formSceneAddUpdateIDLabelText.Text(), Integer)

                    objX10DbScene = New TrekkerPhotoArt.X10Include.X10DbScene
                    objX10DbScene.SceneID = intSceneID
                    objX10DbScene.SceneName = formSceneAddUpdateNameTextBox.Text()
                    objX10DbScene.SceneDescription = ""


                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    ' nsX10DbMethods.removeX10ScenefromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbScene As TrekkerPhotoArt.X10Include.X10DbScene, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.removeX10SceneFromX10Db(strConnectionString, strProvider, objX10DbScene, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then

                            formSceneAddUpdateIDLabelText.Text() = ""
                            formSceneAddUpdate_AddUpdateButton.Text() = "Add"
                            formSceneAddUpdate_StatusLabel.Text = "Successfully Deleted"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formSceneAddUpdate_CancelButton.Text() = "Done"
                            formSceneAddUpdate_DeleteButton.Visible = False

                            objFormSceneEdit = New formSceneEdit
                            objFormSceneEdit.formSceneEdit_BringToFrontLabel.Text() = "N"

                            ' Refresh DataSet on Form formSceneEdit if it's active.
                            If objFormCollection.OfType(Of formSceneEdit).Any Then

                                objFormSceneEdit = objFormCollection.Item("formSceneEdit")

                                ' The row has been deleted.
                                X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormSceneEdit = -1
                                X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormSceneEdit = -1

                                ' formSceneEdit_GetScenesDataSet() As String
                                strStatus = objFormSceneEdit.formSceneEdit_GetScenesDataSet()
                                If (strStatus = "") Then
                                    objFormSceneEdit.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formSceneAddUpdate_DeleteButton_Click(): " & strStatus, "formSceneAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formSceneEdit_GetScenesDataSet()

                            End If

                        Else
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formSceneAddUpdate_CancelButton.Text() = "Cancel"
                            Windows.Forms.MessageBox.Show("Problem removing Scene from X10 Db.", "formSceneAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If ' END - RowsAffected

                    Else
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formSceneAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Scene from X10 Db." & vbCrLf & strStatus, "formSceneAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - nsX10DbMethods.addUpdateSceneToX10db()

                End If ' END - Confirm removal of Scene?

            End If ' END - Is there a SceneID?

        Catch ex As Exception
            strStatus = "formSceneAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formSceneAddUpdate_StatusLabel.Text = "Fail"
            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formSceneAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormSceneEdit = Nothing
            objX10DbScene = Nothing
        End Try

    End Sub ' END - formSceneAddUpdate_DeleteButton_Click()

    Private Sub formSceneAddUpdate_SetAllOffButton_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdate_SetAllOffButton.Click
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim intRowIndex As Integer = 0
        Dim intColumnIndex As Integer = 0
        Dim strDimmer As String = ""

        Dim bDimmer As Boolean = False

        Try

            strTryStep = "Rows.Count"
            If (formSceneAddUpdateModulesInSceneDataGridView.Rows.Count > 0) Then

                strTryStep = "formSceneAddUpdate_CancelButton"
                formSceneAddUpdate_CancelButton.Text() = "Cancel"

                strTryStep = "ForNextFormSceneAddUpdateDataGridViewRows"
                For intRowIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.RowCount - 1 Step 1

                    strTryStep = "NewObjectDataGridViewRow"
                    objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                    strTryStep = "GetDataGridViewRow"
                    objDataGridViewRow = formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex)

                    strTryStep = "ResetRowValues"
                    strDimmer = ""

                    bDimmer = False

                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns"
                    For intColumnIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.ColumnCount - 1 Step 1

                        strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name"
                        Select Case formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnIndex).Name.ToUpper()
                            Case "DIMMER"
                                strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.Dimmer"
                                strDimmer = objDataGridViewRow.Cells.Item(intColumnIndex).Value
                                bDimmer = True
                        End Select

                    Next ' END - ForNextFormSceneAddUpdateDataGridViewColumns

                    strTryStep = "ReadAllValues?"
                    If (bDimmer) Then

                        strTryStep = "setSelectedOnOffComboBox"
                        ' This can only be done after row is added.
                        ' setOnOffComboBoxSelectedValue(ByVal intRowIndex As Integer, ByVal strDimmer As String, ByVal strOnOff As String) As String
                        strError = setOnOffComboBoxSelectedValue(intRowIndex, strDimmer, "Off")
                        If (strError <> "") Then
                            strStatus = "formSceneAddUpdate_SetAllOffButton_Click(): " & strError
                            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_SetAllOffButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            Exit For
                        End If ' END - setSelectedOnOffComboBox()

                    Else

                        strStatus = "formSceneAddUpdate_SetAllOffButton_Click(): Values missing from current DataGridViewRow=" & intRowIndex.ToString()

                        If (Not bDimmer) Then
                            strStatus &= ": Dimmer"
                        End If

                        Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_SetAllOffButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Exit For
                    End If ' END - ReadAllValues?

                    objDataGridViewRow = Nothing
                Next ' END - ForNextFormSceneAddUpdateDataGridViewRows

            End If ' END - Rows.Count

        Catch ex As Exception
            strStatus = "formSceneAddUpdate_SetAllOffButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_SetAllOffButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formSceneAddUpdate_StatusLabel.Text = "Fail"
            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
        Finally
            objDataGridViewRow = Nothing
        End Try

    End Sub ' END - formSceneAddUpdate_SetAllOffButton_Click()

    Private Sub formSceneAddUpdate_SetAllOnButton_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdate_SetAllOnButton.Click
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim intRowIndex As Integer = 0
        Dim intColumnIndex As Integer = 0
        Dim strOnOff As String = ""
        Dim strDimmer As String = ""

        Dim bDimmer As Boolean = False

        Try

            strTryStep = "Rows.Count"
            If (formSceneAddUpdateModulesInSceneDataGridView.Rows.Count > 0) Then

                strTryStep = "formSceneAddUpdate_CancelButton"
                formSceneAddUpdate_CancelButton.Text() = "Cancel"

                strTryStep = "ForNextFormSceneAddUpdateDataGridViewRows"
                For intRowIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.RowCount - 1 Step 1

                    strTryStep = "NewObjectDataGridViewRow"
                    objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                    strTryStep = "GetDataGridViewRow"
                    objDataGridViewRow = formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex)

                    strTryStep = "ResetRowValues"
                    strDimmer = ""

                    bDimmer = False

                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns"
                    For intColumnIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.ColumnCount - 1 Step 1

                        strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name"
                        Select Case formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnIndex).Name.ToUpper()
                            Case "DIMMER"
                                strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.Dimmer"
                                strDimmer = objDataGridViewRow.Cells.Item(intColumnIndex).Value
                                bDimmer = True
                                Exit For
                        End Select

                    Next ' END - ForNextFormSceneAddUpdateDataGridViewColumns

                    strTryStep = "ReadAllValues?"
                    If (bDimmer) Then

                        strTryStep = "OnOff"
                        If (strDimmer = "Y") Then
                            ' Dimmer
                            strOnOff = "0" ' 100% - Full Bright
                        Else
                            ' Switch
                            strOnOff = "On"
                        End If

                        strTryStep = "setSelectedOnOffComboBox"
                        ' This can only be done after row is added.
                        ' setOnOffComboBoxSelectedValue(ByVal intRowIndex As Integer, ByVal strDimmer As String, ByVal strOnOff As String) As String
                        strError = setOnOffComboBoxSelectedValue(intRowIndex, strDimmer, strOnOff)
                        If (strError <> "") Then
                            strStatus = "formSceneAddUpdate_SetAllOnButton_Click(): " & strError
                            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_SetAllOnButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            Exit For
                        End If ' END - setSelectedOnOffComboBox()

                    Else

                        strStatus = "formSceneAddUpdate_SetAllOnButton_Click(): Values missing from current DataGridViewRow=" & intRowIndex.ToString()

                        If (Not bDimmer) Then
                            strStatus &= ": Dimmer"
                        End If

                        Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_SetAllOnButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Exit For
                    End If ' END - ReadAllValues?

                    objDataGridViewRow = Nothing
                Next ' END - ForNextFormSceneAddUpdateDataGridViewRows

            End If ' END - Rows.Count

        Catch ex As Exception
            strStatus = "formSceneAddUpdate_SetAllOnButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_SetAllOnButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formSceneAddUpdate_StatusLabel.Text = "Fail"
            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
        Finally
            objDataGridViewRow = Nothing
        End Try

    End Sub ' END - formSceneAddUpdate_SetAllOnButton_Click()

    Private Sub formSceneAddUpdate_ClearAllButton_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdate_ClearAllButton.Click
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim intRowIndex As Integer = 0
        Dim intColumnIndex As Integer = 0
        Dim strDimmer As String = ""

        Dim bDimmer As Boolean = False

        Try

            strTryStep = "Rows.Count"
            If (formSceneAddUpdateModulesInSceneDataGridView.Rows.Count > 0) Then

                strTryStep = "formSceneAddUpdate_CancelButton"
                formSceneAddUpdate_CancelButton.Text() = "Cancel"

                strTryStep = "ForNextFormSceneAddUpdateDataGridViewRows"
                For intRowIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.RowCount - 1 Step 1

                    strTryStep = "NewObjectDataGridViewRow"
                    objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                    strTryStep = "GetDataGridViewRow"
                    objDataGridViewRow = formSceneAddUpdateModulesInSceneDataGridView.Rows(intRowIndex)

                    strTryStep = "ResetRowValues"
                    strDimmer = ""

                    bDimmer = False

                    strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns"
                    For intColumnIndex = 0 To formSceneAddUpdateModulesInSceneDataGridView.ColumnCount - 1 Step 1

                        strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name"
                        Select Case formSceneAddUpdateModulesInSceneDataGridView.Columns(intColumnIndex).Name.ToUpper()
                            Case "DIMMER"
                                strTryStep = "ForNextFormSceneAddUpdateDataGridViewColumns.Name.Dimmer"
                                strDimmer = objDataGridViewRow.Cells.Item(intColumnIndex).Value
                                bDimmer = True
                        End Select

                    Next ' END - ForNextFormSceneAddUpdateDataGridViewColumns

                    strTryStep = "ReadAllValues?"
                    If (bDimmer) Then

                        strTryStep = "setSelectedOnOffComboBox"
                        ' This can only be done after row is added.
                        ' setOnOffComboBoxSelectedValue(ByVal intRowIndex As Integer, ByVal strDimmer As String, ByVal strOnOff As String) As String
                        strError = setOnOffComboBoxSelectedValue(intRowIndex, strDimmer, "Clear")
                        If (strError <> "") Then
                            strStatus = "formSceneAddUpdate_ClearAllButton_Click(): " & strError
                            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_ClearAllButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formSceneAddUpdate_StatusLabel.Text = "Fail"
                            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            Exit For
                        End If ' END - setSelectedOnOffComboBox()

                    Else

                        strStatus = "formSceneAddUpdate_ClearAllButton_Click(): Values missing from current DataGridViewRow=" & intRowIndex.ToString()

                        If (Not bDimmer) Then
                            strStatus &= ": Dimmer"
                        End If

                        Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_ClearAllButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formSceneAddUpdate_StatusLabel.Text = "Fail"
                        formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        Exit For
                    End If ' END - ReadAllValues?

                    objDataGridViewRow = Nothing
                Next ' END - ForNextFormSceneAddUpdateDataGridViewRows

            End If ' END - Rows.Count

        Catch ex As Exception
            strStatus = "formSceneAddUpdate_ClearAllButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_ClearAllButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formSceneAddUpdate_StatusLabel.Text = "Fail"
            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
        Finally
            objDataGridViewRow = Nothing
        End Try

    End Sub ' END - formSceneAddUpdate_ClearAllButton_Click()

    Private Sub formSceneAddUpdate_TestSceneModulesButton_Click(sender As System.Object, e As System.EventArgs) Handles formSceneAddUpdate_TestSceneModulesButton.Click
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim intSceneID As Integer = -1
        Dim strSceneName As String = ""

        Dim objDataRowViewHouseCode As System.Data.DataRowView = Nothing
        Dim intHouseCodeID As Integer = 0

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Dim strMessage As String = ""

        Try

            strTryStep = "formConsoleMessages"
            If objFormCollection.OfType(Of formConsoleMessages).Any Then
                objFormConsoleMessages = New formConsoleMessages
                objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")
                objFormConsoleMessages.Close()
                objFormConsoleMessages = Nothing
            End If

            strTryStep = "formSceneAddUpdateIDLabelText"
            If (formSceneAddUpdateIDLabelText.Text() <> "") Then
                intSceneID = CType(formSceneAddUpdateIDLabelText.Text(), Integer)
            End If

            strTryStep = "formSceneAddUpdateNameTextBoxText"
            strSceneName = formSceneAddUpdateNameTextBox.Text()

            strTryStep = "formSceneAddUpdateHouseCodeComboBox"
            objDataRowViewHouseCode = formSceneAddUpdateHouseCodeComboBox.SelectedItem
            intHouseCodeID = CType(objDataRowViewHouseCode(0), Integer)

            strTryStep = "ConnectionStrings"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strMessage = "Scene Name: " & strSceneName
            strMessage &= vbCrLf & vbCrLf & "Sending to Modules in Scene...Please wait......."
            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
            Call formConsoleMessages.DisplayMessage(strMessage, "Send ""Scene"" commands to Modules")

            strTryStep = "sendUnitCommands(Scene)"
            ' sendUnitCommands(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strOperation As String, ByVal intSceneID As Integer, ByVal strSceneName As String, ByRef strMessage As String) As String
            strError = sendUnitCommands(strConnectionString, strProvider, "Scene", intSceneID, strSceneName, strMessage)
            If (strError = "") Then

                formSceneAddUpdate_StatusLabel.Text = "Success"
                formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                formSceneAddUpdate_CancelButton.Text() = "Done"

                strMessage &= vbCrLf & vbCrLf & "Success!"

            Else

                strStatus = "Problem sending commands to Modules." & vbCrLf & strError
                Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_TestSceneModulesButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formSceneAddUpdate_StatusLabel.Text = "Fail"
                formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formSceneAddUpdate_CancelButton.Text() = "Cancel"

                strMessage &= vbCrLf & vbCrLf & strStatus
                strMessage &= vbCrLf & vbCrLf & "Fail!"

            End If ' END - sendUnitCommands(Scene)

            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
            Call formConsoleMessages.DisplayMessage(strMessage, "Send ""Scene"" commands to Modules")

        Catch ex As Exception
            strStatus = "formSceneAddUpdate_TestSceneModulesButton_Click(" & strTryStep & "): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneAddUpdate_TestSceneModulesButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formSceneAddUpdate_StatusLabel.Text = "Fail"
            formSceneAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formSceneAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDataRowViewHouseCode = Nothing
            objFormCollection = Nothing
            objFormConsoleMessages = Nothing
        End Try

    End Sub ' END - formSceneAddUpdate_TestSceneModulesButton_Click()

    '=====================================================================================
    ' Function sendUnitCommands()
    ' Alan Wagner
    '
    ' strOperation
    '  AllLightsOn | AllLightsOff | AllUnitsOn | AllUnitsOff | Scene
    '
    Public Function sendUnitCommands(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strOperation As String, ByVal intSceneID As Integer, ByVal strSceneName As String, ByRef strMessage As String) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        Dim objX10DbCompiledUnitCommand As TrekkerPhotoArt.X10Include.X10DbCompiledUnitCommand = Nothing
        Dim objX10DbCompiledUnitCommands As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10DbCompiledUnitCommand) = Nothing
        Dim strExtendedCommand As String = ""

        Dim intX10Status As Integer = -1
        Dim objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload) = Nothing
        Dim objX10CP290CommandUpload As TrekkerPhotoArt.X10Include.X10CP290CommandUpload = Nothing

        Dim objSendUnitCommandSceneClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendUnitCommandSceneClass = Nothing
        Dim objSendAddressCommandPowerLineClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendAddressCommandPowerLineClass = Nothing
        Dim objSendFunctionCommandPowerLineClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.sendFunctionCommandPowerLineClass = Nothing
        Dim objX10ExtendedCommand As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.x10ExtendedCommand = Nothing

        Try

            ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
            Call formConsoleMessages.DisplayMessage(strMessage, "Send """ & strOperation & """ commands to Modules")

            strTryStep = "nsX10DbMethods.compileUnitCommandsFromX10Db(" & strOperation & ")"
            ' nsX10DbMethods.compileUnitCommandsFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strOperation As String, ByVal intSceneID As Integer, ByRef objX10DbCompiledUnitCommands As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10DbCompiledUnitCommand)) As String
            strError = nsX10DbMethods.compileUnitCommandsFromX10Db(strConnectionString, strProvider, strOperation, intSceneID, objX10DbCompiledUnitCommands)
            If (strError = "") Then

                strTryStep = "ObjectX10DbCompiledScenes.Count"
                If (Not objX10DbCompiledUnitCommands Is Nothing AndAlso objX10DbCompiledUnitCommands.Count > 0) Then

                    strTryStep = "ForEachX10DbCompiledUnitCommand"
                    For Each objX10DbCompiledUnitCommand In objX10DbCompiledUnitCommands

                        strTryStep = "NewObjectX10DbController"
                        objX10DbController = New TrekkerPhotoArt.X10Include.X10DbController

                        strTryStep = "GetObjectX10DbController"
                        objX10DbController = objX10DbCompiledUnitCommand.objX10DbController

                        strTryStep = "ControllerType"
                        Select Case objX10DbController.ControllerType.ToUpper()
                            Case "CP290"

                                strTryStep = "nsX10CP290Methods.sendUnitCommand"
                                ' nsX10CP290Methods.sendUnitCommand(ByVal strPortName As String, ByVal strUnitHouseCode As String, ByVal strUnitModuleCodes As String, ByVal strDimmer As String, ByRef intUnitOnOff As Integer, ByRef intUnitLevel As Integer, ByRef intX10Status As Integer, ByRef objX10CP290CommandUploads As System.Collections.Generic.List(Of TrekkerPhotoArt.X10Include.X10CP290CommandUpload)) As String
                                strError = nsX10CP290Methods.sendUnitCommand(objX10DbController.Port, objX10DbCompiledUnitCommand.strUnitHouseCode, objX10DbCompiledUnitCommand.strUnitModuleCodes, objX10DbCompiledUnitCommand.strDimmer, objX10DbCompiledUnitCommand.intUnitOnOff, objX10DbCompiledUnitCommand.intUnitLevel, intX10Status, objX10CP290CommandUploads)
                                If (strError = "") Then

                                    strMessage &= vbCrLf & "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"
                                    strMessage &= vbCrLf & "    UnitHouseCode: " & objX10DbCompiledUnitCommand.strUnitHouseCode
                                    strMessage &= vbCrLf & "    UnitModuleCodes: " & objX10DbCompiledUnitCommand.strUnitModuleCodes

                                    Select Case objX10DbCompiledUnitCommand.strDimmer.ToUpper()
                                        Case "Y"
                                            strMessage &= vbCrLf & "    Set Dimmer to " & objX10DbCompiledUnitCommand.strOnOff
                                        Case "N"
                                            strMessage &= vbCrLf & "    Set Switch to " & objX10DbCompiledUnitCommand.strOnOff
                                    End Select

                                    strTryStep = "getX10CP290CommandUploads"
                                    If (Not objX10CP290CommandUploads Is Nothing AndAlso objX10CP290CommandUploads.Count > 0) Then

                                        For Each objX10CP290CommandUpload In objX10CP290CommandUploads

                                            strMessage &= vbCrLf & "    CommandUpload[" & objX10CP290CommandUpload.CommandUploadID.ToString() & "]:"
                                            strMessage &= vbCrLf & "      Function=" & objX10CP290CommandUpload.strFunction
                                            strMessage &= vbCrLf & "      Housecode=" & objX10CP290CommandUpload.strHousecode
                                            strMessage &= vbCrLf & "      X10UnitCodes18=" & objX10CP290CommandUpload.strX10UnitCodes18
                                            strMessage &= vbCrLf & "      X10UnitCodes916=" & objX10CP290CommandUpload.strX10UnitCodes916
                                            strMessage &= vbCrLf & "      BaseHousecode=" & objX10CP290CommandUpload.strBaseHousecode
                                            strMessage &= vbCrLf & "      X10Status=" & objX10CP290CommandUpload.strX10Status

                                        Next

                                    End If

                                    strMessage &= vbCrLf & "    Controller Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status)

                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Send """ & strOperation & """ commands to Modules")

                                Else
                                    strStatus = "sendUnitCommands(): Problem sending Command to Module:" & vbCrLf & "Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]" & vbCrLf & strError
                                    Exit For
                                End If ' END - nsX10CP290Methods.sendUnitCommand()

                            Case "CM15A"

                                strTryStep = "ExtendedCommand"
                                Select Case objX10DbCompiledUnitCommand.intSendUnitExtendedCommand
                                    Case 0
                                        strExtendedCommand = "S"
                                    Case 1
                                        strExtendedCommand = "E"
                                End Select

                                strTryStep = "nsX10CM15AMethods.sendUnitCommand"
                                ' sendUnitCommandSceneClass sendUnitCommandScene(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, string strX10DbConnectionString, string strX10DbProvider, string strStandardExtended, string strUnitHouseCodeLetter, string strUnitModuleCodes, string strUnitDimmerYN, int intUnitOnOff, int intUnitLevel, byte bytExtendedData, byte bytExtendedCommand)
                                objSendUnitCommandSceneClass = nsX10CM15AMethods.sendUnitCommandScene(objX10DbController, objX10DbCompiledUnitCommand.objX10DbUSBPort, strConnectionString, strProvider, strExtendedCommand, objX10DbCompiledUnitCommand.strUnitHouseCode, objX10DbCompiledUnitCommand.strUnitModuleCodes, objX10DbCompiledUnitCommand.strDimmer, objX10DbCompiledUnitCommand.intUnitOnOff, objX10DbCompiledUnitCommand.intUnitLevel, objX10DbCompiledUnitCommand.bytExtendedData, objX10DbCompiledUnitCommand.bytExtendedCommand)
                                If (objSendUnitCommandSceneClass.status = "") Then

                                    strMessage &= vbCrLf & "  Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]"
                                    strMessage &= vbCrLf & "    UnitHouseCode: " & objX10DbCompiledUnitCommand.strUnitHouseCode
                                    strMessage &= vbCrLf & "    UnitModuleCodes: " & objX10DbCompiledUnitCommand.strUnitModuleCodes

                                    Select Case objSendUnitCommandSceneClass.standardExtended.ToUpper()
                                        Case "S"
                                            strMessage &= vbCrLf & "    Standard Powerline Command:"

                                            Select Case objX10DbCompiledUnitCommand.strDimmer.ToUpper()
                                                Case "Y"
                                                    strMessage &= vbCrLf & "      Set Dimmer to " & objX10DbCompiledUnitCommand.strOnOff

                                                    Select Case objX10DbCompiledUnitCommand.intUnitOnOff
                                                        Case 0
                                                            strMessage &= vbCrLf & "      Unit On/Off: Off"
                                                        Case 1
                                                            strMessage &= vbCrLf & "      Unit On/Off: On"
                                                    End Select

                                                    strMessage &= vbCrLf & "      Dimmer Level: " & objX10DbCompiledUnitCommand.intUnitLevel.ToString()
                                                Case "N"
                                                    strMessage &= vbCrLf & "      Set Switch to " & objX10DbCompiledUnitCommand.strOnOff

                                                    Select Case objX10DbCompiledUnitCommand.intUnitOnOff
                                                        Case 0
                                                            strMessage &= vbCrLf & "      Unit On/Off: Off"
                                                        Case 1
                                                            strMessage &= vbCrLf & "      Unit On/Off: On"
                                                    End Select

                                            End Select

                                        Case "E"
                                            ' x10ExtendedCommand getX10ExtendedCommandFromCode(byte byteCommandCode)
                                            objX10ExtendedCommand = nsX10CM15AMethods.getX10ExtendedCommandFromCode(objX10DbCompiledUnitCommand.bytExtendedCommand)

                                            strMessage &= vbCrLf & "    Extended Powerline Command:"
                                            strMessage &= vbCrLf & "      ExtendedCommand=0x" & objX10DbCompiledUnitCommand.bytExtendedCommand.ToString("X02").ToLower()
                                            strMessage &= vbCrLf & "      Extended Command Description: " & objX10ExtendedCommand.commandDescription
                                            strMessage &= vbCrLf & "      ExtendedData=0x" & objX10DbCompiledUnitCommand.bytExtendedData.ToString("X02").ToLower()
                                    End Select

                                    strTryStep = "ObjectSendAddressCommandPowerLineClassesCount"
                                    If (objSendUnitCommandSceneClass.objSendAddressCommandPowerLineClasses.Count > 0) Then

                                        strTryStep = "ForEachObjectSendAddressCommandPowerLineClass"
                                        For Each objSendAddressCommandPowerLineClass In objSendUnitCommandSceneClass.objSendAddressCommandPowerLineClasses
                                            If (objSendAddressCommandPowerLineClass.retryReason <> "") Then
                                                strMessage &= vbCrLf & "    sendAddressCommandPowerLineClass " & nsX10CM15AMethods.x10BinaryValueToHouseCode(objSendAddressCommandPowerLineClass.unitHouseCode) & nsX10CM15AMethods.x10BinaryValueToDeviceCode(objSendAddressCommandPowerLineClass.unitModuleCode) & ":"
                                                strMessage &= vbCrLf & "      retryReason: " & objSendAddressCommandPowerLineClass.retryReason
                                            End If
                                        Next

                                        strTryStep = "ObjectSendFunctionCommandPowerLineClassesCount"
                                        If (objSendUnitCommandSceneClass.objSendFunctionCommandPowerLineClasses.Count > 0) Then

                                            strTryStep = "ForEachObjectSendFunctionCommandPowerLineClass"
                                            For Each objSendFunctionCommandPowerLineClass In objSendUnitCommandSceneClass.objSendFunctionCommandPowerLineClasses
                                                strMessage &= vbCrLf & "    sendFunctionCommandPowerLine: "
                                                strMessage &= vbCrLf & "      newUnitLastCommand: " & objSendFunctionCommandPowerLineClass.newUnitLastCommand
                                                strMessage &= vbCrLf & "      newUnitLastBrightDimAmount: " & objSendFunctionCommandPowerLineClass.newUnitLastBrightDimAmount.ToString()
                                                If (objSendFunctionCommandPowerLineClass.retryReason <> "") Then
                                                    strMessage &= vbCrLf & "      retryReason:" & objSendFunctionCommandPowerLineClass.retryReason
                                                End If
                                            Next

                                        End If

                                    End If ' END - ObjectSendAddressCommandPowerLineClassesCount

                                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Send """ & strOperation & """ commands to Modules")

                                Else
                                    strStatus = "Problem sending Command to Module:" & vbCrLf & "Controller: " & objX10DbController.ControllerName & " [" & objX10DbController.ControllerType & "]" & vbCrLf & objSendUnitCommandSceneClass.status
                                    Exit For
                                End If ' END - nsX10CM15AMethods.sendUnitCommand()

                            Case "WM100"
                                strTryStep = ""


                            Case Else
                                strStatus = "Missing or Unknown Controller Model """ & objX10DbController.ControllerType & """."
                                Exit For
                        End Select

                        objX10DbController = Nothing
                    Next ' END - ForEachX10DbCompiledUnitCommand

                Else
                    strStatus = "sendUnitCommands():" & vbCrLf & "No Compiled Units were returned for Operation """ & strOperation & """."

                    If (strOperation.ToUpper() = "SCENE") Then
                        strStatus &= vbCrLf & "Are any Controllers for Modules in Scene """ & strSceneName & """ set to Active?"
                    End If

                End If

            Else
                strStatus = "sendUnitCommands(): " & strError
            End If ' END - nsX10DbMethods.compileUnitCommandsFromX10Db()

        Catch ex As Exception
            strStatus = "sendUnitCommands(" & strTryStep & "): Exception: Operation """ & strOperation & """: " & ex.Message
        Finally
            objX10ExtendedCommand = Nothing
            objSendFunctionCommandPowerLineClass = Nothing
            objSendAddressCommandPowerLineClass = Nothing
            objSendUnitCommandSceneClass = Nothing
            objX10CP290CommandUploads = Nothing
            objX10CP290CommandUpload = Nothing
            objX10DbController = Nothing
            objX10DbCompiledUnitCommand = Nothing
            objX10DbCompiledUnitCommands = Nothing
        End Try

        Return strStatus

    End Function ' END - sendUnitCommands()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formSceneAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationSceneAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formSceneAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(620, 605)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationSceneAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationSceneAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationSceneAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formSceneAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formSceneAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formSceneAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formSceneAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationSceneAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formSceneAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationSceneAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationSceneAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formSceneAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formSceneAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formSceneAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formSceneAddUpdate