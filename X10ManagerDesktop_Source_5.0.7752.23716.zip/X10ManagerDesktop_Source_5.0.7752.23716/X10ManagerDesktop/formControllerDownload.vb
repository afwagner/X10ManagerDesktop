﻿
' Name: formControllerDownload.vb
' By: Alan Wagner
' Date: November 2020

Public Class formControllerDownload

#Region "X10ManagerDesktopControllerDownloadMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strInstallerAssemblyLocation As String = ""
        Dim strInstallerAssemblyLocationDrive As String = ""
        Dim strInstallerAssemblyLocationExecutable As String = ""
        Dim bInstallerAssemblyLocationFound As Boolean = False

        Try

            Me.BringToFront()

            formControllerDownload_DownloadButton.Visible = False

            formControllerDownload_StatusLabel.Text = ""
            formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Black
            formControllerDownload_CancelButton.Text() = "Done"
            formControllerDownload_CancelButton.Select()

            strTryStep = "formControllerDownload_FormRestore"
            ' formControllerDownload_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formControllerDownload_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formControllerDownload_GetControllersDataSet"
                ' formControllerDownload_GetControllersDataSet() As String
                strStatus = formControllerDownload_GetControllersDataSet()
                If (strStatus = "") Then
                    formControllerDownload_DownloadButton.Visible = True
                Else
                    Windows.Forms.MessageBox.Show("Main(formControllerDownload): " & strStatus, "Main(formControllerDownload)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formControllerDownload_DownloadButton.Visible = False
                    formControllerDownload_StatusLabel.Text = "Fail"
                    formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formControllerDownload_CancelButton.Text() = "Cancel"
                End If ' END - formControllerDownload_GetControllersDataSet()

            Else
                Windows.Forms.MessageBox.Show("Main(formControllerDownload): " & strStatus, "Main(formControllerDownload)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerDownload_DownloadButton.Visible = False
                formControllerDownload_StatusLabel.Text = "Fail"
                formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerDownload_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdate_FormRestore()

        Catch ex As Exception

            If (ex.InnerException Is Nothing) Then
                strError = "Main(formControllerDownload): Exception: TryStep=" & strTryStep & ": " & ex.Message.ToString()
            Else
                strError = "Main(formControllerDownload): Exception: TryStep=" & strTryStep & ": " & ex.Message.ToString() & vbCrLf & "InnerException: " & ex.InnerException.ToString
            End If

            If (strStatus = "") Then
                strStatus = strError
            Else
                strStatus &= vbCrLf & strError
            End If

            Windows.Forms.MessageBox.Show(strStatus, "Main(formControllerDownload)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerDownload_DownloadButton.Visible = False
            formControllerDownload_StatusLabel.Text = "Fail"
            formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerDownload_CancelButton.Text() = "Cancel"

        End Try

    End Sub ' END Sub - Main(formControllerDownload)

    Private Sub formControllerDownload_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formControllerDownload_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formControllerDownload_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formControllerDownload_FormClosingHandler(): " & strStatus, "formControllerDownload_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formFileSettings_FormSave()

    End Sub ' END Sub - formControllerDownload_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopControllerDownloadMainMethods

#Region "formMethods"

    '=====================================================================================
    ' formControllerDownload_GetControllersDataSet()
    ' Alan Wagner
    '
    Public Function formControllerDownload_GetControllersDataSet() As String
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objFactory As System.Data.Common.DbProviderFactory = Nothing

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""

        Dim objDataGridViewColumn As System.Windows.Forms.DataGridViewColumn = Nothing
        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim objDataGridViewTextBoxCell As System.Windows.Forms.DataGridViewTextBoxCell = Nothing
        Dim objDataGridViewCheckBoxCell As System.Windows.Forms.DataGridViewCheckBoxCell = Nothing

        Dim intRowIndex As Integer = -1

        Dim intControllerActive As Integer = -1
        Dim strControllerName As String = ""
        Dim strControllerType As String = ""
        Dim strControllerDescription As String = ""
        Dim intControllerID As Integer = -1

        Dim intColumnControllerID As Integer = 4    ' Column that contains ControllerID.

        Dim bShowAdvancedInformation As Boolean = False

        Try

            strTryStep = "bShowAdvancedInformation"
            Select Case X10ManagerDesktop.showAdvancedInformation
                Case 0
                    bShowAdvancedInformation = False
                Case 1
                    bShowAdvancedInformation = True
            End Select

            strTryStep = "Columns.Count"
            If (formControllerDownloadControllersDataGridView.Columns.Count < 1) Then

                strTryStep = "WithFormControllerDownloadControllersDataGridView"
                With formControllerDownloadControllersDataGridView
                    .AllowDrop = True
                    .AutoGenerateColumns = False
                    .AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
                    .AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
                    .AllowUserToAddRows = False
                    .AllowUserToDeleteRows = False
                    .AllowUserToOrderColumns = False
                    .AllowUserToResizeColumns = False
                    .AllowUserToResizeRows = False
                    .ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
                    .EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
                    .ReadOnly = False
                    .RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
                    .ShowCellToolTips = False
                    .ShowEditingIcon = False

                    strTryStep = "DataGridViewColumn_Code"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Select"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = False
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewCheckBoxCell(False) ' False - Two State
                    objDataGridViewColumn.DataPropertyName = "Select"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Name"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Name"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Name"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Type"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Type"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Type"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_Description"
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "Description"
                    objDataGridViewColumn.Visible = True
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewComboBoxCell()
                    objDataGridViewColumn.DataPropertyName = "Description"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                    strTryStep = "DataGridViewColumn_ControllerID" ' Controllers.ControllerID
                    objDataGridViewColumn = New System.Windows.Forms.DataGridViewColumn
                    objDataGridViewColumn.Name = "ControllerID"
                    Select Case bShowAdvancedInformation
                        Case False
                            objDataGridViewColumn.Visible = False
                        Case True
                            objDataGridViewColumn.Visible = True
                    End Select
                    objDataGridViewColumn.ReadOnly = True
                    objDataGridViewColumn.CellTemplate = New System.Windows.Forms.DataGridViewTextBoxCell()
                    objDataGridViewColumn.DataPropertyName = "ControllerID"
                    .Columns.Add(objDataGridViewColumn)
                    objDataGridViewColumn = Nothing

                End With ' END - WithFormSceneAddUpdateDataGridView

            Else

                strTryStep = "SelectCaseShowAdvancedInformation"
                Select Case bShowAdvancedInformation
                    Case True
                        formControllerDownloadControllersDataGridView.Columns(intColumnControllerID).Visible = True
                    Case False
                        formControllerDownloadControllersDataGridView.Columns(intColumnControllerID).Visible = False
                End Select

            End If ' END - Columns.Count

            strTryStep = "Rows.Count"
            If (formControllerDownloadControllersDataGridView.Rows.Count > 0) Then
                strTryStep = "Rows.Clear"
                formControllerDownloadControllersDataGridView.Rows.Clear()
            End If ' END - Rows.Count

            strTryStep = "ConnectionStrings"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "GetFactory"
            objFactory = System.Data.Common.DbProviderFactories.GetFactory(strProvider)

            strTryStep = "sqlString"
            sqlString = "SELECT ControllerActive, ControllerName, ControllerType, ControllerDescription, HouseCode, Port, Hub, AppKey, UID, TransceiverHouseCodes, DuskDawnResolution, ControllerID " &
                "FROM (Controllers INNER JOIN ControllerTypes ON Controllers.ControllerTypeID=ControllerTypes.ControllerTypeID) " &
                "WHERE ControllerID > -1 " &
                "ORDER BY ControllerName, ControllerType ASC;"

            strTryStep = "CreateConnection"
            Using objDbConnection As System.Data.Common.DbConnection = objFactory.CreateConnection()

                strTryStep = "ConnectionString"
                objDbConnection.ConnectionString = strConnectionString

                strTryStep = "Connection.Open"
                objDbConnection.Open()

                strTryStep = "CreateCommand"
                Using objDbCommand As System.Data.Common.DbCommand = objDbConnection.CreateCommand()

                    strTryStep = "CommandText"
                    objDbCommand.CommandText = sqlString

                    strTryStep = "CommandTimeout"
                    objDbCommand.CommandTimeout = 30 ' Seconds

                    strTryStep = "CommandType"
                    ' Text              - An SQL text command (default).
                    ' StoredProcedure   - To call a stored procedure.
                    ' TableDirect       - All rows and columns of the named table or tables will be returned.
                    objDbCommand.CommandType() = CommandType.Text

                    strTryStep = "ExecuteReader"
                    ' ExecuteReader     - Executes commands that return rows.
                    '   System.Data.CommandBehavior.Default          - The query may return multiple result sets. ExecuteReader(CommandBehavior.Default) is functionally equivalent to calling ExecuteReader().
                    '   System.Data.CommandBehavior.SingleResult     - The query returns a single result set.
                    '   System.Data.CommandBehavior.SchemaOnly       - The query returns column information only.
                    '   System.Data.CommandBehavior.KeyInfo          - The query returns column and primary key information.
                    '   System.Data.CommandBehavior.SingleRow        - The query is expected to return a single row of the first result set.
                    '   System.Data.CommandBehavior.SequentialAccess - Provides a way for the DataReader to handle rows that contain columns with large binary values. You can then use the GetBytes or GetChars method to specify a byte location to start the read operation.
                    '   System.Data.CommandBehavior.CloseConnection  - When the command is executed, the associated Connection object is closed when the associated DataReader object is closed.
                    ' ExecuteNonQuery   - Executes commands such as Transact-SQL INSERT, DELETE, UPDATE, and SET statements.
                    ' ExecuteScalar     - Retrieves a single value (for example, an aggregate value) from a database.
                    ' ExecuteXmlReader  - Sends the CommandText to the Connection and builds an XmlReader object.
                    Using objDbDataReader As System.Data.Common.DbDataReader = objDbCommand.ExecuteReader(System.Data.CommandBehavior.Default)

                        strTryStep = "HasRows"
                        If objDbDataReader.HasRows() Then

                            strTryStep = "Read"
                            While objDbDataReader.Read()
                                intRowIndex = intRowIndex + 1

                                strTryStep = "ControllerActive"
                                intControllerActive = CType(objDbDataReader("ControllerActive"), Integer)

                                strTryStep = "ControllerID" ' Controllers.ControllerID
                                intControllerID = CType(objDbDataReader("ControllerID"), Integer)

                                strTryStep = "NewObjectDataGridViewRow"
                                objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                                strTryStep = "Add_ControllerActive"
                                objDataGridViewCheckBoxCell = New System.Windows.Forms.DataGridViewCheckBoxCell
                                Select Case intControllerActive
                                    Case 0
                                        objDataGridViewCheckBoxCell.Value = False
                                    Case 1
                                        objDataGridViewCheckBoxCell.Value = True
                                End Select
                                objDataGridViewRow.Cells.Add(objDataGridViewCheckBoxCell)
                                objDataGridViewCheckBoxCell = Nothing

                                strTryStep = "Add_ControllerName"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("ControllerName").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_ControllerType"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("ControllerType").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_ControllerDescription"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = objDbDataReader("ControllerDescription").ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Add_ControllerID"
                                objDataGridViewTextBoxCell = New System.Windows.Forms.DataGridViewTextBoxCell
                                objDataGridViewTextBoxCell.Value = intControllerID.ToString()
                                objDataGridViewRow.Cells.Add(objDataGridViewTextBoxCell)
                                objDataGridViewTextBoxCell = Nothing

                                strTryStep = "Rows.Add"
                                formControllerDownloadControllersDataGridView.Rows.Add(objDataGridViewRow)

                                objDataGridViewRow = Nothing
                            End While

                        End If ' END - HasRows

                    End Using ' END - ExecuteReader

                End Using ' END - CreateCommand

                strTryStep = "Connection.Close"
                objDbConnection.Close()

            End Using ' END - CreateConnection

        Catch ex As Exception

            If (ex.InnerException Is Nothing) Then
                strError = "formControllerDownload_GetControllersDataSet(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & sqlString
            Else
                strError = "formControllerDownload_GetControllersDataSet(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & "InnerException: " & ex.InnerException.ToString & vbCrLf & sqlString
            End If

            If (strStatus = "") Then
                strStatus = strError
            Else
                strStatus &= vbCrLf & strError
            End If

        Finally
            objDataGridViewTextBoxCell = Nothing
            objDataGridViewCheckBoxCell = Nothing
            objDataGridViewRow = Nothing
            objDataGridViewColumn = Nothing
            objFactory = Nothing
        End Try

        Return strStatus

    End Function ' END - formControllerDownload_GetControllersDataSet()

    Public Function downloadEventsToController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal bPutX10DbSunTimes As Boolean, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef strMessage As String) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods
        Dim nsSunTimeMethods As New TrekkerPhotoArt.X10Include.SunTimeMethods
        Dim nsX10CP290Methods As New TrekkerPhotoArt.X10Include.X10CP290Methods
        Dim nsX10CM15AMethods As New TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods
        Dim nsX10WM100Methods As New TrekkerPhotoArt.X10Include.X10WM100Methods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim sqlString As String = ""
        Dim intRowsAffected As Integer = -1

        Dim intHousecode As Integer = -1

        Dim intX10Status As Integer = -1
        Dim intMINUTES As Integer = -1
        Dim intHOURS As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intBday As Integer = -1
        Dim intHC As Integer = -1

        Dim objDateTimeNow As System.DateTime = System.DateTime.Now()

        Dim objTimeZone As TrekkerPhotoArt.X10Include.TimeZone = Nothing
        Dim strSunriseTime As String = ""
        Dim strSunsetTime As String = ""

        Dim objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort = Nothing
        Dim objSetX10TimeClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.setX10TimeClass = Nothing
        Dim objPutX10TransceiverSetupClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putX10TransceiverSetupClass = Nothing
        Dim bClearTransceiverSetup As Boolean = False
        Dim objGetX10ControllerStatusClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.getX10ControllerStatusClass = Nothing
        Dim objPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.putToX10MemoryClass = Nothing
        Dim objVerifyPutToX10MemoryClass As TrekkerPhotoArt.X10IncludeCM.X10CM15AMethods.verifyPutToX10MemoryClass = Nothing
        Dim strMemoryOutputFilename As String = ""

        Dim objDayOfYearDate As System.DateTime = System.DateTime.MinValue

        Dim intTimersCompiled As Integer = 0
        Dim intX10DbTimersCount As Integer = 0
        Dim intX10TimerCount As Integer = 0
        Dim intTimerMatchedCount As Integer = 0

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormControllerEdit As formControllerEdit = Nothing

        Try

            If (strMessage = "") Then
                strMessage = "Start download to Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]"
            Else
                strMessage &= vbCrLf & vbCrLf & "Start download to Controller """ & objX10DbController.ControllerName & """ [" & objX10DbController.ControllerType & "]"
            End If

            strTryStep = "bPutX10DbSunTimes"
            If bPutX10DbSunTimes Then

                strTryStep = "nsSunTimeMethods.getTimeZone"
                ' nsSunTimeMethods.getTimeZone(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone) As String
                strError = nsSunTimeMethods.getTimeZone(objTimeZone)
                If (strError = "") Then

                    strTryStep = "nsX10DbMethods.putX10DbSunTimes"
                    ' nsSunTimeMethods.SunTimes(ByRef objTimeZone As AlanWagnerApps.RunApplication.TimeZone, ByVal dblLatitude As Double, ByVal dblLongitude As Double, ByRef strSunriseTime As String, ByRef strSunsetTime As String) As String
                    strError = nsSunTimeMethods.SunTimes(objTimeZone, CType(X10ManagerDesktop.latitude, Double), CType(X10ManagerDesktop.longitude, Double), strSunriseTime, strSunsetTime)
                    If (strError = "") Then

                        strTryStep = "nsX10DbMethods.putX10DbSunTimes"
                        strMessage &= vbCrLf & "Put X10Db Sun Times:" & vbCrLf & "  SunriseTime=" & strSunriseTime & " SunsetTime=" & strSunsetTime
                        ' nsX10DbMethods.putX10DbSunTimes(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strSunriseTime As String, ByVal strSunsetTime As String, ByRef intRowsAffected As Integer) As String
                        strError = nsX10DbMethods.putX10DbSunTimes(strConnectionString, strProvider, strSunriseTime, strSunsetTime, intRowsAffected)
                        If (strError <> "") Then
                            strStatus = "downloadEventsToController(): " & strError
                        End If ' END - nsX10DbMethods.putX10DbSunTimes()

                    Else
                        strStatus = "downloadEventsToController(): " & strError
                    End If ' END - nsSunTimeMethods.SunTimes()

                Else
                    strStatus = "downloadEventsToController(): " & strError
                End If ' END - nsSunTimeMethods.getTimeZone()

            End If ' END - bPutX10DbSunTimes

            strTryStep = "StatusOK"
            If (strStatus = "") Then

                strTryStep = "ControllerActive"
                If (objX10DbController.ControllerActive = 1) Then

                    strTryStep = "nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db"
                    strMessage &= vbCrLf & "Compile " & objX10DbController.ControllerType.ToUpper() & " Timers from X10Db Events, place in X10Db."
                    ' nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal intLimitToControllerID As Integer, ByRef intTimersCompiled As Integer) As String
                    strError = nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db(strConnectionString, strProvider, objX10DbController.ControllerID, intTimersCompiled)
                    If (strError = "") Then

                        strTryStep = "TimersCompiled"
                        If (intTimersCompiled > 0) Then

                            strMessage &= vbCrLf & "  " & intTimersCompiled.ToString() & " Timers Compiled from Active Schedules and their Events."
                            Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                            strTryStep = "ControllerType"
                            Select Case objX10DbController.ControllerType.ToUpper()
                                Case "CP290"

                                    strTryStep = "CP290_nsX10DbMethods.executeNonQueryX10db"
                                    strMessage &= vbCrLf & "Update to X10 Db Controllers table:"
                                    strMessage &= vbCrLf & "  Base House Code: " & objX10DbController.HouseCode
                                    sqlString = "UPDATE Controllers SET HouseCode='" & objX10DbController.HouseCode & "',TransceiverHouseCodes='',DuskDawnResolution=0 WHERE ControllerID=" & objX10DbController.ControllerID.ToString() & ";"
                                    ' nsX10DbMethods.executeNonQueryX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal sqlString As String, ByRef intRowsAffected As Integer) As String
                                    strError = nsX10DbMethods.executeNonQueryX10db(strConnectionString, strProvider, sqlString, intRowsAffected)
                                    If (strError = "" And intRowsAffected > 0) Then

                                        strTryStep = "CP290_nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble"
                                        ' nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(ByVal strHouseCode As String, ByRef intHousecode As Integer) As String
                                        strError = nsX10DbMethods.x10HouseCodeAsStringToBinaryUpperNibble(objX10DbController.HouseCode, intHousecode)
                                        If (strError = "") Then

                                            strMessage &= vbCrLf & "Download X10 Base Housecode"
                                            strMessage &= vbCrLf & "Set CP290 Clock to:" & vbCrLf & "  " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & " " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") "
                                            Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                            strTryStep = "CP290_nsX10CP290Methods.downloadX10BaseHousecode"
                                            ' nsX10CP290Methods.downloadX10BaseHousecode(ByVal strPortName As String, ByVal intHousecode As Integer) As String
                                            strError = nsX10CP290Methods.downloadX10BaseHousecode(objX10DbController.Port, intHousecode)
                                            If (strError = "") Then

                                                strTryStep = "CP290_nsX10CP290Methods.setX10Time"
                                                ' nsX10CP290Methods.setX10Time(ByVal strPortName As String, ByVal dtmNow As System.DateTime, ByRef intgX10Status As Integer, ByRef intgMINUTES As Integer, ByRef intgHOURS As Integer, ByRef intgBday As Integer, ByRef intgHC As Integer) As String
                                                strError = nsX10CP290Methods.setX10Time(objX10DbController.Port, objDateTimeNow, intX10Status, intMINUTES, intHOURS, intBday, intHC)
                                                If (strError = "") Then

                                                    If (intHOURS = 12) Then
                                                        ' PM
                                                        strAMPM = "PM"
                                                        intHourAMPM = intHOURS
                                                    ElseIf (intHOURS > 12) Then
                                                        ' PM
                                                        strAMPM = "PM"
                                                        intHourAMPM = intHOURS - 12
                                                    ElseIf (intHOURS = 0) Then
                                                        ' AM
                                                        strAMPM = "AM"
                                                        intHourAMPM = 12
                                                    Else
                                                        ' AM
                                                        strAMPM = "AM"
                                                        intHourAMPM = intHOURS
                                                    End If

                                                    strMessage &= vbCrLf & "  Status: " & nsX10CP290Methods.x10StatusCodeToString(intX10Status)
                                                    strMessage &= vbCrLf & "  Time: " & nsX10DbMethods.DayCodeToStringOfFullDays(intBday) & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(intMINUTES.ToString, 2) & " " & strAMPM
                                                    strMessage &= vbCrLf & "  Base House Code: " & nsX10DbMethods.x10HouseCodeUpperNibbleToString(intHC)

                                                    strMessage &= vbCrLf & "Get X10Db Timers Put X10... Please Wait......."
                                                    Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                    strTryStep = "CP290_nsX10CP290Methods.getX10DbTimersPutX10"
                                                    ' Note: nsX10CP290Methods.getX10DbTimersPutX10() calls nsX10CP290Methods.downloadX10BaseHousecode()
                                                    ' nsX10CP290Methods.getX10DbTimersPutX10(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef intX10DbTimersCount As Integer) As String
                                                    strError = nsX10CP290Methods.getX10DbTimersPutX10(strConnectionString, strProvider, "", -1, intHousecode, objX10DbController, intX10DbTimersCount)
                                                    If (strError = "") Then

                                                        strMessage &= vbCrLf & "  " & intX10DbTimersCount.ToString() & " Timers downladed from X10db to Controller."
                                                        strMessage &= vbCrLf & "Compare X10 Timers To X10Db... Please Wait......."
                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                        strTryStep = "CP290_nsX10CP290Methods.compareX10TimersToX10Db"
                                                        ' nsX10CP290Methods.compareX10TimersToX10Db(ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByVal strConnectionString As String, ByVal strProvider As String, ByVal strScheduleName As String, ByVal intScheduleID As Integer, ByRef intX10TimerCount As Integer, ByRef intTimerMatchedCount As Integer) As String
                                                        strError = nsX10CP290Methods.compareX10TimersToX10Db(objX10DbController, strConnectionString, strProvider, "", -1, intX10TimerCount, intTimerMatchedCount)
                                                        If (strError = "") Then

                                                            strMessage &= vbCrLf & "  Out of " & intX10TimerCount.ToString() & " Timers read from X10 Controller,"
                                                            strMessage &= vbCrLf & "  " & intTimerMatchedCount.ToString() & " X10Db Timers were matched."

                                                            strTryStep = "TimerMatchedCount"
                                                            If (intX10TimerCount = intTimerMatchedCount) Then
                                                                strMessage &= vbCrLf & vbCrLf & "Download completed Successfully!"
                                                            Else
                                                                strMessage &= vbCrLf & vbCrLf & "Problem with Download!"
                                                                strMessage &= vbCrLf & "  TimerCount=" & intX10TimerCount.ToString() & " <> TimerMatchedCount=" & intTimerMatchedCount.ToString() & "."

                                                                strStatus = "downloadEventsToController(): TimerCount=" & intX10TimerCount.ToString() & " <> TimerMatchedCount=" & intTimerMatchedCount.ToString() & "."
                                                            End If

                                                            Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                        Else
                                                            strStatus = "downloadEventsToController(): " & strError
                                                        End If ' END - CP290_nsX10CP290Methods.compareX10TimersToX10Db()

                                                    Else
                                                        strMessage &= vbCrLf & vbCrLf & "Get X10Db Timers Put X10 has Failed!" & vbCrLf
                                                        strMessage &= vbCrLf & strError
                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                        strStatus = "downloadEventsToController(): " & strError
                                                    End If ' END - CP290_nsX10CP290Methods.getX10DbTimersPutX10()

                                                Else
                                                    strStatus = "downloadEventsToController(): " & strError
                                                End If ' END - CP290_nsX10CP290Methods.setX10Time()

                                            Else
                                                strStatus = "downloadEventsToController(): " & strError
                                            End If ' END - CP290_nsX10CP290Methods.downloadX10BaseHousecode()

                                        Else
                                            strStatus = "downloadEventsToController(): " & strError
                                        End If ' END - CP290_nsX10CP290Methods.x10HouseCodeAsStringToBinary()

                                    Else
                                        strStatus = "downloadEventsToController(): " & strError
                                    End If ' END - CP290_nsX10DbMethods.executeNonQueryX10db()

                                Case "CM15A"

                                    strTryStep = "CM15A_DuskDawnResolution"
                                    ' Dusk Dawn Resolution for CM15A X10 Controller must be in Multiples of 8 (ex: 8 or 16 or 32).
                                    If (objX10DbController.DuskDawnResolution = 0) Then
                                        strStatus = "downloadEventsToController(): Missing Controller's Dusk/Dawn Resolution"
                                    Else

                                        strTryStep = "CM15A_nsX10DbMethods.getX10DbUSBPort"
                                        ' nsX10DbMethods.getX10DbUSBPort(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strPort As String, ByVal strHub As String, ByRef objX10DbUSBPort As TrekkerPhotoArt.X10Include.X10DbUSBPort) As String
                                        strError = nsX10DbMethods.getX10DbUSBPort(strConnectionString, strProvider, objX10DbController.Port, objX10DbController.Hub, objX10DbUSBPort)
                                        If (strError = "") Then

                                            strTryStep = "CM15A_USBPortCheck"
                                            If (objX10DbUSBPort Is Nothing) Then
                                                strStatus = "downloadEventsToController(): getX10DbUSBPort(): USB Port=""" & objX10DbController.Port & """ Hub=""" & objX10DbController.Hub & """ not found in X10Db."
                                            Else

                                                strTryStep = "CM15A_TransceiverHouseCodeMap"
                                                If (objX10DbController.TransceiverHouseCodeMap.status = "") Then

                                                    strTryStep = "CM15A_nsX10DbMethods.executeNonQueryX10db"
                                                    strMessage &= vbCrLf & "Update to X10 Db Controllers table:"
                                                    strMessage &= vbCrLf & "  Monitored House Code: " & objX10DbController.HouseCode
                                                    strMessage &= vbCrLf & "  Transceiver House Codes: " & objX10DbController.TransceiverHouseCodes
                                                    strMessage &= vbCrLf & "  Dusk/Dawn Resolution: " & objX10DbController.DuskDawnResolution.ToString()
                                                    sqlString = "UPDATE Controllers SET HouseCode='" & objX10DbController.HouseCode & "',TransceiverHouseCodes='" & objX10DbController.TransceiverHouseCodes & "',DuskDawnResolution=" & objX10DbController.DuskDawnResolution.ToString() & " WHERE ControllerID=" & objX10DbController.ControllerID.ToString() & ";"
                                                    ' nsX10DbMethods.executeNonQueryX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal sqlString As String, ByRef intRowsAffected As Integer) As String
                                                    strError = nsX10DbMethods.executeNonQueryX10db(strConnectionString, strProvider, sqlString, intRowsAffected)
                                                    If (strError = "" And intRowsAffected > 0) Then

                                                        strMessage &= vbCrLf & "Set CM15A Clock to:"
                                                        strMessage &= vbCrLf & "  " & objDateTimeNow.ToString("dddd, MMMM dd, yyyy") & "  " & nsStringMethods.addLeadingZeros(objDateTimeNow.Hour, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Minute, 2) & ":" & nsStringMethods.addLeadingZeros(objDateTimeNow.Second, 2) & vbCrLf & "  (DayOfWeek=" & objDateTimeNow.DayOfWeek & " DayOfYear=" & objDateTimeNow.DayOfYear & ") "
                                                        strMessage &= vbCrLf & "    With:" & vbCrLf & "      Purge Timers"
                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                        strTryStep = "CM15A_nsX10CM15AMethods.setX10Time"
                                                        ' setX10TimeClass nsX10CM15AMethods.setX10Time(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, System.DateTime dtmNow, string strTimerPurgeFlagYN, string strBatteryTimerClearFlagYN, string strMonitoredStatusClearFlagYN)
                                                        objSetX10TimeClass = nsX10CM15AMethods.setX10Time(objX10DbController, objX10DbUSBPort, objDateTimeNow, "Y", "N", "N")
                                                        If (objSetX10TimeClass.status = "") Then

                                                            strTryStep = "CM15A_nsX10CM15AMethods.getX10ControllerStatus"
                                                            strMessage &= vbCrLf & "Get CM15A Controller Status:"
                                                            ' getX10ControllerStatusClass nsX10CM15AMethods.getX10ControllerStatus(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort)
                                                            objGetX10ControllerStatusClass = nsX10CM15AMethods.getX10ControllerStatus(objX10DbController, objX10DbUSBPort)
                                                            If (objGetX10ControllerStatusClass.status = "") Then

                                                                If (objGetX10ControllerStatusClass.currentTimeHours = 12) Then
                                                                    ' PM
                                                                    strAMPM = "PM"
                                                                    intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                                ElseIf (objGetX10ControllerStatusClass.currentTimeHours > 12) Then
                                                                    ' PM
                                                                    strAMPM = "PM"
                                                                    intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours - 12
                                                                ElseIf (objGetX10ControllerStatusClass.currentTimeHours = 0) Then
                                                                    ' AM
                                                                    strAMPM = "AM"
                                                                    intHourAMPM = 12
                                                                Else
                                                                    ' AM
                                                                    strAMPM = "AM"
                                                                    intHourAMPM = objGetX10ControllerStatusClass.currentTimeHours
                                                                End If

                                                                strMessage &= vbCrLf & "  Controller Status: OK"
                                                                strMessage &= vbCrLf & "  Time: " & objGetX10ControllerStatusClass.currentTimeDayOfWeek & ", " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeMinutes.ToString, 2) & ":" & nsStringMethods.addLeadingZeros(objGetX10ControllerStatusClass.currentTimeSeconds.ToString, 2) & " " & strAMPM
                                                                strMessage &= vbCrLf & "  Year Day Date: " & objGetX10ControllerStatusClass.objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")
                                                                strMessage &= vbCrLf & "  Monitored House Code: " & objGetX10ControllerStatusClass.monitoredHouseCode

                                                                strMessage &= vbCrLf & vbCrLf & "Download to Controller... Please wait......."
                                                                Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                                strTryStep = "CM15A_nsX10CM15AMethods.putToX10Memory"
                                                                ' putToX10MemoryClass putToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, double dblLatitude, double dblLongitude, string strScheduleName, int intScheduleID, string strX10DbConnectionString, string strX10DbProvider, bool bClearOnly)
                                                                objPutToX10MemoryClass = nsX10CM15AMethods.putToX10Memory(objX10DbController, objX10DbUSBPort, CType(X10ManagerDesktop.latitude, Double), CType(X10ManagerDesktop.longitude, Double), "", -1, strConnectionString, strProvider, False)
                                                                If (objPutToX10MemoryClass.status = "") Then

                                                                    strMessage &= vbCrLf & "Success Loading Timers and Macros to Controller Memory!"
                                                                    strMessage &= vbCrLf & "  Memory Version:"
                                                                    strMessage &= vbCrLf & "    " & objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp.ToLongDateString() & " " & objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp.ToLocalTime().ToString("HH:mm:ss") & " (UTC" & System.TimeZoneInfo.Local.GetUtcOffset(objPutToX10MemoryClass.objX10MemoryVersionStampClass.dtmVersionStamp).TotalHours.ToString() & ")"

                                                                    strMessage &= vbCrLf & "  Daylight Savings:"
                                                                    objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objPutToX10MemoryClass.objX10DuskDawnClass.dayOfYearDaylightSavingsTurnForward)
                                                                    strMessage &= vbCrLf & "    Turn Forward: " & objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                                                    objDayOfYearDate = New System.DateTime(System.DateTime.Now.Year, 1, 1).AddDays(objPutToX10MemoryClass.objX10DuskDawnClass.dayOfYearDaylightSavingsTurnBackward)
                                                                    strMessage &= vbCrLf & "    Turn Backward: " & objDayOfYearDate.ToString("dddd, MMMM dd, yyyy")

                                                                    strMessage &= vbCrLf & "  Dusk Dawn Resolution: " + objPutToX10MemoryClass.objX10DuskDawnClass.duskDawnResolution.ToString() & " days"
                                                                    If (objPutToX10MemoryClass.objX10DuskDawnClass.startOfDuskDawnTableMemoryAddress = 0) Then
                                                                        strMessage &= vbCrLf & "    ERROR: startOfDuskDawnTableMemoryAddress not set."
                                                                    Else
                                                                        strMessage &= vbCrLf & "    Number of Dusk/Dawn table entries: " & objPutToX10MemoryClass.objX10DuskDawnClass.objX10DuskDawnTableEntryClasses.Count.ToString()
                                                                    End If

                                                                    strMessage &= vbCrLf & "  Transceive on Housecodes: " & objPutToX10MemoryClass.objX10TransceiverSetupClass.TransceiverHouseCodes
                                                                    strMessage &= vbCrLf & "  Timer Initiators count: " & objPutToX10MemoryClass.objX10InitiatorsClass.objX10TimerInitiatorsClass.Count
                                                                    strMessage &= vbCrLf & "            Macros count: " & objPutToX10MemoryClass.objX10InitiatorsClass.timerInitiatorMacroBlockCount
                                                                    strMessage &= vbCrLf & "  Macro Initiators count: " & objPutToX10MemoryClass.objX10InitiatorsClass.objX10MacroInitiatorsClass.Count
                                                                    strMessage &= vbCrLf & "            Macros count: " & objPutToX10MemoryClass.objX10InitiatorsClass.macroInitiatorMacroBlockCount

                                                                    strMessage &= vbCrLf & vbCrLf & "Verify... Please wait......."
                                                                    Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                                    strMemoryOutputFilename = X10ManagerDesktop.backupDirectoryPath & "putTimersAndMacrosToX10Memory_" & objX10DbController.ControllerType & "_" & objX10DbController.ControllerName.Replace(" ", "") & ".txt"

                                                                    strTryStep = "CM15A_nsX10CM15AMethods.verifyPutToX10Memory"
                                                                    ' verifyPutToX10MemoryClass verifyPutToX10Memory(TrekkerPhotoArt.X10Include.X10DbController objX10DbController, TrekkerPhotoArt.X10Include.X10DbUSBPort objX10DbUSBPort, ref putToX10MemoryClass objPutToX10MemoryClass, bool bClearOnly, string strFilename)
                                                                    objVerifyPutToX10MemoryClass = nsX10CM15AMethods.verifyPutToX10Memory(objX10DbController, objX10DbUSBPort, objPutToX10MemoryClass, False, strMemoryOutputFilename)
                                                                    If (objVerifyPutToX10MemoryClass.status = "") Then

                                                                        strMessage &= vbCrLf & vbCrLf & "Controller Memory loacations have matched!" & vbCrLf
                                                                        strMessage &= vbCrLf & "Controller Memory Annotations found in file:" & vbCrLf & strMemoryOutputFilename
                                                                        strMessage &= vbCrLf & vbCrLf & "Download completed Successfully!"
                                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                                    Else

                                                                        strMessage &= vbCrLf & vbCrLf & "Controller Memory loacations have NOT matched!" & vbCrLf
                                                                        strMessage &= vbCrLf & objVerifyPutToX10MemoryClass.status
                                                                        Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                                        strStatus = "downloadEventsToController(): " & objVerifyPutToX10MemoryClass.status
                                                                    End If ' END - CM15A_nsX10CM15AMethods.verifyPutToX10Memory()

                                                                Else

                                                                    strMessage &= vbCrLf & vbCrLf & "Download Events to Controller has Failed!" & vbCrLf
                                                                    strMessage &= vbCrLf & objPutToX10MemoryClass.status
                                                                    Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                                                    strStatus = "downloadEventsToController(): " & objPutToX10MemoryClass.status
                                                                End If ' END - CM15A_nsX10CM15AMethods.putToX10Memory()

                                                                strTryStep = "CM15A_formControllerEdit"
                                                                ' Refresh DataSet on Form formControllerEdit if it's active.
                                                                If objFormCollection.OfType(Of formControllerEdit).Any Then

                                                                    objFormControllerEdit = objFormCollection.Item("formControllerEdit")

                                                                    strTryStep = "CM15A_formControllerEdit_GetControllersDataSet"
                                                                    ' formControllerEdit_GetControllersDataSet() As String
                                                                    strError = objFormControllerEdit.formControllerEdit_GetControllersDataSet()
                                                                    If (strError = "") Then
                                                                        objFormControllerEdit.Activate()
                                                                    Else
                                                                        strStatus = "downloadEventsToController(): " & strError
                                                                    End If ' END - CM15A_formControllerEdit_GetControllersDataSet()

                                                                End If ' END - CM15A_formControllerEdit

                                                            Else
                                                                strStatus = "downloadEventsToController(): " & objGetX10ControllerStatusClass.status
                                                            End If ' END - CM15A_nsX10CM15AMethods.getX10ControllerStatus()

                                                        Else
                                                            strStatus = "downloadEventsToController(): " & objSetX10TimeClass.status
                                                        End If ' END - CM15A_nsX10CM15AMethods.setX10Time()

                                                    Else
                                                        If (strStatus <> "") Then
                                                            strStatus = "downloadEventsToController(): " & strError
                                                        Else
                                                            strStatus = "downloadEventsToController(): executeNonQueryX10db(): No rows were affected for X10 Db Controllers table Update of TransceiverHouseCodes."
                                                        End If
                                                    End If ' END - CM15A_nsX10DbMethods.executeNonQueryX10db(UpdateControllersTable)

                                                Else
                                                    strStatus = "downloadEventsToController(): Problem with Controller's selected Transceiver House Code(s): " & objX10DbController.TransceiverHouseCodeMap.status
                                                End If ' END - CM15A_TransceiverHouseCodeMap

                                            End If ' END - CM15A_USBPortCheck

                                        Else
                                            strStatus = "downloadEventsToController(): " & strError
                                        End If ' END - CM15A_nsX10DbMethods.getX10DbUSBPort()

                                    End If ' END - CM15A_DuskDawnResolution

                                Case "WM100"

                                    strMessage &= vbCrLf & "No Events have been downloaded!"
                                    Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                                Case Else
                                    strStatus = "downloadEventsToController(): Unknown Controller Type: """ & objX10DbController.ControllerType & """"
                            End Select ' END  - ControllerType

                        Else

                            strMessage &= vbCrLf & vbCrLf & "No Events were found for Controller """ & objX10DbController.ControllerName & """."
                            strMessage &= vbCrLf & "  This can be caused by No Active Schedules with Events"
                            strMessage &= vbCrLf & "  using Scenes that include Modules attached to this Controller."
                            strMessage &= vbCrLf & vbCrLf & "No Events have been downloaded!"
                            Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                        End If ' END - TimersCompiled

                    Else
                        strStatus = "downloadEventsToController(): " & strError
                    End If ' END - nsX10DbMethods.compileTimersFromX10DbEventsPlaceInX10Db()

                Else

                    strMessage &= vbCrLf & vbCrLf & "Controller """ & objX10DbController.ControllerName & """ is not Active."
                    strMessage &= vbCrLf & vbCrLf & "No Events have been downloaded!"
                    Call formConsoleMessages.DisplayMessage(strMessage, "Download Events to Controller")

                End If ' END - ControllerActive

            End If ' END - StatusOK

        Catch ex As Exception

            If (ex.InnerException Is Nothing) Then
                strError = "downloadEventsToController(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & sqlString
            Else
                strError = "downloadEventsToController(" & strTryStep & "): Exception: " & ex.Message.ToString() & vbCrLf & "InnerException: " & ex.InnerException.ToString & vbCrLf & sqlString
            End If

            If (strStatus = "") Then
                strStatus = strError
            Else
                strStatus &= vbCrLf & strError
            End If

        Finally
            objDayOfYearDate = Nothing
            objVerifyPutToX10MemoryClass = Nothing
            objPutToX10MemoryClass = Nothing
            objGetX10ControllerStatusClass = Nothing
            objSetX10TimeClass = Nothing
            objX10DbUSBPort = Nothing
            objPutX10TransceiverSetupClass = Nothing
            objDateTimeNow = Nothing
            objTimeZone = Nothing
            objFormCollection = Nothing
            objFormControllerEdit = Nothing
        End Try

        Return strStatus

    End Function ' END - downloadEventsToController()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formControllerDownload_DownloadButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerDownload_DownloadButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim intRowIndex As Integer = 0
        Dim objDataGridViewRow As System.Windows.Forms.DataGridViewRow = Nothing

        Dim intColumnControllerSelect As Integer = 0    ' Column that contains Selected Controller [0|1].
        Dim intColumnControllerID As Integer = 4    ' Column that contains ControllerID.

        Dim intControllerID As Integer = -1
        Dim objX10DbController As TrekkerPhotoArt.X10Include.X10DbController = Nothing

        Dim bPutX10DbSunTimes As Boolean = True

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormConsoleMessages As formConsoleMessages = Nothing

        Dim strMessage As String = ""

        Try

            strTryStep = "Rows.Count"
            If (formControllerDownloadControllersDataGridView.Rows.Count > 0) Then

                strTryStep = "CloseFormConsoleMessages"
                If objFormCollection.OfType(Of formConsoleMessages).Any Then
                    objFormConsoleMessages = New formConsoleMessages
                    objFormConsoleMessages = objFormCollection.Item("formConsoleMessages")
                    objFormConsoleMessages.Close()
                    objFormConsoleMessages = Nothing
                End If

                strTryStep = "ConnectionString"
                strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                formControllerDownload_StatusLabel.Text = "Start Controller Download: Please Wait.."
                formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Green
                Me.Refresh()

                strTryStep = "ForNextFormControllerDownloadControllersDataGridViewRows"
                For intRowIndex = 0 To formControllerDownloadControllersDataGridView.RowCount - 1 Step 1

                    strTryStep = "NewObjectDataGridViewRow"
                    objDataGridViewRow = New System.Windows.Forms.DataGridViewRow

                    strTryStep = "GetDataGridViewRow"
                    objDataGridViewRow = formControllerDownloadControllersDataGridView.Rows(intRowIndex)

                    strTryStep = "ControllerSelected"
                    If objDataGridViewRow.Cells.Item(intColumnControllerSelect).Value Then

                        intControllerID = CType(objDataGridViewRow.Cells.Item(intColumnControllerID).Value, Integer)

                        strTryStep = "nsX10DbMethods.getX10DbController"
                        ' nsX10DbMethods.getX10DbController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intControllerID As Integer, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController) As String
                        strError = nsX10DbMethods.getX10DbController(strConnectionString, strProvider, intControllerID, objX10DbController)
                        If (strError = "") Then

                            strTryStep = "downloadEventsToController"
                            ' downloadEventsToController(ByVal strConnectionString As String, ByVal strProvider As String, ByVal bPutX10DbSunTimes As Boolean, ByRef objX10DbController As TrekkerPhotoArt.X10Include.X10DbController, ByRef strMessage As String) As String
                            strError = downloadEventsToController(strConnectionString, strProvider, bPutX10DbSunTimes, objX10DbController, strMessage)
                            If (strError = "") Then

                                ' Only need to do this once.
                                bPutX10DbSunTimes = False

                            Else
                                strStatus = "formControllerDownload_DownloadButton_Click(): " & strError
                                Windows.Forms.MessageBox.Show(strStatus, "formControllerDownload_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formControllerDownload_DownloadButton.Visible = False
                                formControllerDownload_StatusLabel.Text = "Fail"
                                formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formControllerDownload_CancelButton.Text() = "Cancel"
                                Exit For
                            End If ' END - downloadEventsToController()

                        Else
                            strStatus = "formControllerDownload_DownloadButton_Click(): " & strError
                            Windows.Forms.MessageBox.Show(strStatus, "formControllerDownload_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formControllerDownload_DownloadButton.Visible = False
                            formControllerDownload_StatusLabel.Text = "Fail"
                            formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formControllerDownload_CancelButton.Text() = "Cancel"
                            Exit For
                        End If ' END - nsX10DbMethods.getX10DbController()

                    End If ' END - ControllerSelected

                    objDataGridViewRow = Nothing
                Next ' END - ForNextFormControllerDownloadControllersDataGridViewRows

                If (strStatus = "") Then
                    formControllerDownload_StatusLabel.Text = "Success with Downloads"
                    formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Green
                    formControllerDownload_CancelButton.Text() = "Done"
                Else
                    formControllerDownload_StatusLabel.Text = "Problem with Downloads"
                    formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formControllerDownload_CancelButton.Text() = "Cancel"
                End If

            Else
                strStatus = "formControllerDownload_DownloadButton_Click(): No Controllers found for Events to Download."
                Windows.Forms.MessageBox.Show(strStatus, "formControllerDownload_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formControllerDownload_DownloadButton.Visible = False
                formControllerDownload_StatusLabel.Text = "Fail"
                formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
                formControllerDownload_CancelButton.Text() = "Cancel"
            End If ' END - Rows.Count

        Catch ex As Exception
            strStatus = "formControllerDownload_DownloadButton_Click(): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formControllerDownload_DownloadButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formControllerDownload_DownloadButton.Visible = False
            formControllerDownload_StatusLabel.Text = "Fail"
            formControllerDownload_StatusLabel.ForeColor = System.Drawing.Color.Red
            formControllerDownload_CancelButton.Text() = "Cancel"
        Finally
            objDataGridViewRow = Nothing
            objFormCollection = Nothing
            objFormConsoleMessages = Nothing
            objX10DbController = Nothing
        End Try

    End Sub ' END - formControllerDownload_DownloadButton_Click()

    Private Sub formFileSettings_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formControllerDownload_CancelButton.Click

        Me.Close()

    End Sub ' END - formFileSettings_CancelButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formControllerDownload_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationControllerDownload" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formControllerDownload_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(630, 330)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationControllerDownload Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationControllerDownload.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationControllerDownload.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception
            strStatus = "formControllerDownload_FormRestore(): Exception: " & ex.Message
        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formControllerDownload_FormRestore()

    '=====================================================================================
    ' Function formControllerDownload_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationControllerDownload" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formControllerDownload_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationControllerDownload = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationControllerDownload = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception
            strStatus = "formControllerDownload_FormSave(): Exception: " & ex.Message
        End Try

        Return strStatus

    End Function ' END - formControllerDownload_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formControllerDownload