﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class formScheduleEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.formScheduleEditDataGridView = New System.Windows.Forms.DataGridView()
        Me.formScheduleEdit_BringToFrontLabel = New System.Windows.Forms.Label()
        CType(Me.formScheduleEditDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'formScheduleEditDataGridView
        '
        Me.formScheduleEditDataGridView.AllowUserToAddRows = False
        Me.formScheduleEditDataGridView.AllowUserToDeleteRows = False
        Me.formScheduleEditDataGridView.AllowUserToResizeRows = False
        Me.formScheduleEditDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formScheduleEditDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formScheduleEditDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.formScheduleEditDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.formScheduleEditDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.formScheduleEditDataGridView.Name = "formScheduleEditDataGridView"
        Me.formScheduleEditDataGridView.ReadOnly = True
        Me.formScheduleEditDataGridView.ShowCellToolTips = False
        Me.formScheduleEditDataGridView.ShowEditingIcon = False
        Me.formScheduleEditDataGridView.Size = New System.Drawing.Size(675, 358)
        Me.formScheduleEditDataGridView.TabIndex = 2
        '
        'formScheduleEdit_BringToFrontLabel
        '
        Me.formScheduleEdit_BringToFrontLabel.AutoSize = True
        Me.formScheduleEdit_BringToFrontLabel.Location = New System.Drawing.Point(12, 9)
        Me.formScheduleEdit_BringToFrontLabel.Name = "formScheduleEdit_BringToFrontLabel"
        Me.formScheduleEdit_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formScheduleEdit_BringToFrontLabel.TabIndex = 3
        Me.formScheduleEdit_BringToFrontLabel.Text = "Y | N"
        Me.formScheduleEdit_BringToFrontLabel.Visible = False
        '
        'formScheduleEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(675, 358)
        Me.Controls.Add(Me.formScheduleEdit_BringToFrontLabel)
        Me.Controls.Add(Me.formScheduleEditDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formScheduleEdit"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Schedule Edit"
        CType(Me.formScheduleEditDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formScheduleEditDataGridView As DataGridView
    Friend WithEvents formScheduleEdit_BringToFrontLabel As Label
End Class
