﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formModuleAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formModuleAddUpdate))
        Me.formModuleAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formModuleAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formModuleAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formModuleAddUpdateNameLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateIDLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateNameTextBox = New System.Windows.Forms.TextBox()
        Me.formModuleAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.formModuleAddUpdateDescriptionLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateHouseCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formModuleAddUpdateHouseCodeLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateModuleCodeComboBox = New System.Windows.Forms.ComboBox()
        Me.formModuleAddUpdateModuleCodeLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateDimmerLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateDimmerCheckBox = New System.Windows.Forms.CheckBox()
        Me.formModuleAddUpdateControllersComboBox = New System.Windows.Forms.ComboBox()
        Me.formModuleAddUpdateControllersLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateOperationsGroupBox = New System.Windows.Forms.GroupBox()
        Me.formModuleAddUpdateOnOffLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateOnOffComboBox = New System.Windows.Forms.ComboBox()
        Me.formModuleAddUpdate_TestButton = New System.Windows.Forms.Button()
        Me.formModuleAddUpdateExtendedCommandsCheckBox = New System.Windows.Forms.CheckBox()
        Me.formModuleAddUpdateExtendedCommandsLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateControllerActiveLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateControllerActiveLabelText = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateEnabledCheckBox = New System.Windows.Forms.CheckBox()
        Me.formModuleAddUpdateControlLightsCheckBox = New System.Windows.Forms.CheckBox()
        Me.formModuleAddUpdateControlLightsLabel = New System.Windows.Forms.Label()
        Me.formModuleAddUpdateOperationsGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'formModuleAddUpdate_CancelButton
        '
        Me.formModuleAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formModuleAddUpdate_CancelButton.Location = New System.Drawing.Point(379, 280)
        Me.formModuleAddUpdate_CancelButton.Name = "formModuleAddUpdate_CancelButton"
        Me.formModuleAddUpdate_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleAddUpdate_CancelButton.TabIndex = 0
        Me.formModuleAddUpdate_CancelButton.Text = "Cancel"
        Me.formModuleAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdate_DeleteButton
        '
        Me.formModuleAddUpdate_DeleteButton.Location = New System.Drawing.Point(359, 42)
        Me.formModuleAddUpdate_DeleteButton.Name = "formModuleAddUpdate_DeleteButton"
        Me.formModuleAddUpdate_DeleteButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleAddUpdate_DeleteButton.TabIndex = 1
        Me.formModuleAddUpdate_DeleteButton.Text = "Delete"
        Me.formModuleAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdate_AddUpdateButton
        '
        Me.formModuleAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(59, 280)
        Me.formModuleAddUpdate_AddUpdateButton.Name = "formModuleAddUpdate_AddUpdateButton"
        Me.formModuleAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(86, 23)
        Me.formModuleAddUpdate_AddUpdateButton.TabIndex = 2
        Me.formModuleAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formModuleAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdateNameLabel
        '
        Me.formModuleAddUpdateNameLabel.AutoSize = True
        Me.formModuleAddUpdateNameLabel.Location = New System.Drawing.Point(79, 19)
        Me.formModuleAddUpdateNameLabel.Name = "formModuleAddUpdateNameLabel"
        Me.formModuleAddUpdateNameLabel.Size = New System.Drawing.Size(38, 13)
        Me.formModuleAddUpdateNameLabel.TabIndex = 3
        Me.formModuleAddUpdateNameLabel.Text = "Name:"
        '
        'formModuleAddUpdateIDLabel
        '
        Me.formModuleAddUpdateIDLabel.AutoSize = True
        Me.formModuleAddUpdateIDLabel.Location = New System.Drawing.Point(94, 47)
        Me.formModuleAddUpdateIDLabel.Name = "formModuleAddUpdateIDLabel"
        Me.formModuleAddUpdateIDLabel.Size = New System.Drawing.Size(21, 13)
        Me.formModuleAddUpdateIDLabel.TabIndex = 4
        Me.formModuleAddUpdateIDLabel.Text = "ID:"
        '
        'formModuleAddUpdateIDLabelText
        '
        Me.formModuleAddUpdateIDLabelText.AutoSize = True
        Me.formModuleAddUpdateIDLabelText.Location = New System.Drawing.Point(121, 47)
        Me.formModuleAddUpdateIDLabelText.Name = "formModuleAddUpdateIDLabelText"
        Me.formModuleAddUpdateIDLabelText.Size = New System.Drawing.Size(174, 13)
        Me.formModuleAddUpdateIDLabelText.TabIndex = 5
        Me.formModuleAddUpdateIDLabelText.Text = "formModuleAddUpdateIDLabelText"
        '
        'formModuleAddUpdateNameTextBox
        '
        Me.formModuleAddUpdateNameTextBox.Location = New System.Drawing.Point(123, 16)
        Me.formModuleAddUpdateNameTextBox.MaxLength = 40
        Me.formModuleAddUpdateNameTextBox.Name = "formModuleAddUpdateNameTextBox"
        Me.formModuleAddUpdateNameTextBox.Size = New System.Drawing.Size(311, 20)
        Me.formModuleAddUpdateNameTextBox.TabIndex = 6
        Me.formModuleAddUpdateNameTextBox.Text = "   "
        '
        'formModuleAddUpdate_StatusLabel
        '
        Me.formModuleAddUpdate_StatusLabel.AutoSize = True
        Me.formModuleAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formModuleAddUpdate_StatusLabel.Location = New System.Drawing.Point(151, 283)
        Me.formModuleAddUpdate_StatusLabel.Name = "formModuleAddUpdate_StatusLabel"
        Me.formModuleAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formModuleAddUpdate_StatusLabel.TabIndex = 7
        Me.formModuleAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formModuleAddUpdateDescriptionTextBox
        '
        Me.formModuleAddUpdateDescriptionTextBox.Location = New System.Drawing.Point(124, 71)
        Me.formModuleAddUpdateDescriptionTextBox.MaxLength = 100
        Me.formModuleAddUpdateDescriptionTextBox.Name = "formModuleAddUpdateDescriptionTextBox"
        Me.formModuleAddUpdateDescriptionTextBox.Size = New System.Drawing.Size(310, 20)
        Me.formModuleAddUpdateDescriptionTextBox.TabIndex = 19
        '
        'formModuleAddUpdateDescriptionLabel
        '
        Me.formModuleAddUpdateDescriptionLabel.AutoSize = True
        Me.formModuleAddUpdateDescriptionLabel.Location = New System.Drawing.Point(55, 74)
        Me.formModuleAddUpdateDescriptionLabel.Name = "formModuleAddUpdateDescriptionLabel"
        Me.formModuleAddUpdateDescriptionLabel.Size = New System.Drawing.Size(63, 13)
        Me.formModuleAddUpdateDescriptionLabel.TabIndex = 18
        Me.formModuleAddUpdateDescriptionLabel.Text = "Description:"
        '
        'formModuleAddUpdateHouseCodeComboBox
        '
        Me.formModuleAddUpdateHouseCodeComboBox.FormattingEnabled = True
        Me.formModuleAddUpdateHouseCodeComboBox.Location = New System.Drawing.Point(123, 154)
        Me.formModuleAddUpdateHouseCodeComboBox.Name = "formModuleAddUpdateHouseCodeComboBox"
        Me.formModuleAddUpdateHouseCodeComboBox.Size = New System.Drawing.Size(127, 21)
        Me.formModuleAddUpdateHouseCodeComboBox.TabIndex = 23
        '
        'formModuleAddUpdateHouseCodeLabel
        '
        Me.formModuleAddUpdateHouseCodeLabel.AutoSize = True
        Me.formModuleAddUpdateHouseCodeLabel.Location = New System.Drawing.Point(48, 157)
        Me.formModuleAddUpdateHouseCodeLabel.Name = "formModuleAddUpdateHouseCodeLabel"
        Me.formModuleAddUpdateHouseCodeLabel.Size = New System.Drawing.Size(69, 13)
        Me.formModuleAddUpdateHouseCodeLabel.TabIndex = 22
        Me.formModuleAddUpdateHouseCodeLabel.Text = "House Code:"
        '
        'formModuleAddUpdateModuleCodeComboBox
        '
        Me.formModuleAddUpdateModuleCodeComboBox.FormattingEnabled = True
        Me.formModuleAddUpdateModuleCodeComboBox.Location = New System.Drawing.Point(123, 181)
        Me.formModuleAddUpdateModuleCodeComboBox.Name = "formModuleAddUpdateModuleCodeComboBox"
        Me.formModuleAddUpdateModuleCodeComboBox.Size = New System.Drawing.Size(127, 21)
        Me.formModuleAddUpdateModuleCodeComboBox.TabIndex = 25
        '
        'formModuleAddUpdateModuleCodeLabel
        '
        Me.formModuleAddUpdateModuleCodeLabel.AutoSize = True
        Me.formModuleAddUpdateModuleCodeLabel.Location = New System.Drawing.Point(44, 184)
        Me.formModuleAddUpdateModuleCodeLabel.Name = "formModuleAddUpdateModuleCodeLabel"
        Me.formModuleAddUpdateModuleCodeLabel.Size = New System.Drawing.Size(73, 13)
        Me.formModuleAddUpdateModuleCodeLabel.TabIndex = 24
        Me.formModuleAddUpdateModuleCodeLabel.Text = "Module Code:"
        '
        'formModuleAddUpdateDimmerLabel
        '
        Me.formModuleAddUpdateDimmerLabel.AutoSize = True
        Me.formModuleAddUpdateDimmerLabel.Location = New System.Drawing.Point(72, 210)
        Me.formModuleAddUpdateDimmerLabel.Name = "formModuleAddUpdateDimmerLabel"
        Me.formModuleAddUpdateDimmerLabel.Size = New System.Drawing.Size(45, 13)
        Me.formModuleAddUpdateDimmerLabel.TabIndex = 26
        Me.formModuleAddUpdateDimmerLabel.Text = "Dimmer:"
        '
        'formModuleAddUpdateDimmerCheckBox
        '
        Me.formModuleAddUpdateDimmerCheckBox.AutoSize = True
        Me.formModuleAddUpdateDimmerCheckBox.Location = New System.Drawing.Point(123, 210)
        Me.formModuleAddUpdateDimmerCheckBox.Name = "formModuleAddUpdateDimmerCheckBox"
        Me.formModuleAddUpdateDimmerCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.formModuleAddUpdateDimmerCheckBox.TabIndex = 27
        Me.formModuleAddUpdateDimmerCheckBox.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdateControllersComboBox
        '
        Me.formModuleAddUpdateControllersComboBox.FormattingEnabled = True
        Me.formModuleAddUpdateControllersComboBox.Location = New System.Drawing.Point(124, 97)
        Me.formModuleAddUpdateControllersComboBox.Name = "formModuleAddUpdateControllersComboBox"
        Me.formModuleAddUpdateControllersComboBox.Size = New System.Drawing.Size(310, 21)
        Me.formModuleAddUpdateControllersComboBox.TabIndex = 29
        '
        'formModuleAddUpdateControllersLabel
        '
        Me.formModuleAddUpdateControllersLabel.AutoSize = True
        Me.formModuleAddUpdateControllersLabel.Location = New System.Drawing.Point(61, 100)
        Me.formModuleAddUpdateControllersLabel.Name = "formModuleAddUpdateControllersLabel"
        Me.formModuleAddUpdateControllersLabel.Size = New System.Drawing.Size(54, 13)
        Me.formModuleAddUpdateControllersLabel.TabIndex = 28
        Me.formModuleAddUpdateControllersLabel.Text = "Controller:"
        '
        'formModuleAddUpdateOperationsGroupBox
        '
        Me.formModuleAddUpdateOperationsGroupBox.BackColor = System.Drawing.SystemColors.Control
        Me.formModuleAddUpdateOperationsGroupBox.Controls.Add(Me.formModuleAddUpdateOnOffLabel)
        Me.formModuleAddUpdateOperationsGroupBox.Controls.Add(Me.formModuleAddUpdateOnOffComboBox)
        Me.formModuleAddUpdateOperationsGroupBox.Controls.Add(Me.formModuleAddUpdate_TestButton)
        Me.formModuleAddUpdateOperationsGroupBox.Location = New System.Drawing.Point(40, 309)
        Me.formModuleAddUpdateOperationsGroupBox.Name = "formModuleAddUpdateOperationsGroupBox"
        Me.formModuleAddUpdateOperationsGroupBox.Size = New System.Drawing.Size(431, 60)
        Me.formModuleAddUpdateOperationsGroupBox.TabIndex = 30
        Me.formModuleAddUpdateOperationsGroupBox.TabStop = False
        '
        'formModuleAddUpdateOnOffLabel
        '
        Me.formModuleAddUpdateOnOffLabel.AutoSize = True
        Me.formModuleAddUpdateOnOffLabel.Location = New System.Drawing.Point(276, 25)
        Me.formModuleAddUpdateOnOffLabel.Name = "formModuleAddUpdateOnOffLabel"
        Me.formModuleAddUpdateOnOffLabel.Size = New System.Drawing.Size(43, 13)
        Me.formModuleAddUpdateOnOffLabel.TabIndex = 2
        Me.formModuleAddUpdateOnOffLabel.Text = "On/Off:"
        '
        'formModuleAddUpdateOnOffComboBox
        '
        Me.formModuleAddUpdateOnOffComboBox.FormattingEnabled = True
        Me.formModuleAddUpdateOnOffComboBox.Location = New System.Drawing.Point(325, 22)
        Me.formModuleAddUpdateOnOffComboBox.Name = "formModuleAddUpdateOnOffComboBox"
        Me.formModuleAddUpdateOnOffComboBox.Size = New System.Drawing.Size(89, 21)
        Me.formModuleAddUpdateOnOffComboBox.TabIndex = 1
        '
        'formModuleAddUpdate_TestButton
        '
        Me.formModuleAddUpdate_TestButton.Location = New System.Drawing.Point(20, 20)
        Me.formModuleAddUpdate_TestButton.Name = "formModuleAddUpdate_TestButton"
        Me.formModuleAddUpdate_TestButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleAddUpdate_TestButton.TabIndex = 0
        Me.formModuleAddUpdate_TestButton.Text = "Test"
        Me.formModuleAddUpdate_TestButton.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdateExtendedCommandsCheckBox
        '
        Me.formModuleAddUpdateExtendedCommandsCheckBox.AutoSize = True
        Me.formModuleAddUpdateExtendedCommandsCheckBox.Location = New System.Drawing.Point(123, 250)
        Me.formModuleAddUpdateExtendedCommandsCheckBox.Name = "formModuleAddUpdateExtendedCommandsCheckBox"
        Me.formModuleAddUpdateExtendedCommandsCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.formModuleAddUpdateExtendedCommandsCheckBox.TabIndex = 32
        Me.formModuleAddUpdateExtendedCommandsCheckBox.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdateExtendedCommandsLabel
        '
        Me.formModuleAddUpdateExtendedCommandsLabel.AutoSize = True
        Me.formModuleAddUpdateExtendedCommandsLabel.Location = New System.Drawing.Point(7, 251)
        Me.formModuleAddUpdateExtendedCommandsLabel.Name = "formModuleAddUpdateExtendedCommandsLabel"
        Me.formModuleAddUpdateExtendedCommandsLabel.Size = New System.Drawing.Size(110, 13)
        Me.formModuleAddUpdateExtendedCommandsLabel.TabIndex = 31
        Me.formModuleAddUpdateExtendedCommandsLabel.Text = "Extended Commands:"
        '
        'formModuleAddUpdateControllerActiveLabel
        '
        Me.formModuleAddUpdateControllerActiveLabel.AutoSize = True
        Me.formModuleAddUpdateControllerActiveLabel.Location = New System.Drawing.Point(28, 128)
        Me.formModuleAddUpdateControllerActiveLabel.Name = "formModuleAddUpdateControllerActiveLabel"
        Me.formModuleAddUpdateControllerActiveLabel.Size = New System.Drawing.Size(87, 13)
        Me.formModuleAddUpdateControllerActiveLabel.TabIndex = 33
        Me.formModuleAddUpdateControllerActiveLabel.Text = "Controller Active:"
        '
        'formModuleAddUpdateControllerActiveLabelText
        '
        Me.formModuleAddUpdateControllerActiveLabelText.AutoSize = True
        Me.formModuleAddUpdateControllerActiveLabelText.Location = New System.Drawing.Point(123, 128)
        Me.formModuleAddUpdateControllerActiveLabelText.Name = "formModuleAddUpdateControllerActiveLabelText"
        Me.formModuleAddUpdateControllerActiveLabelText.Size = New System.Drawing.Size(237, 13)
        Me.formModuleAddUpdateControllerActiveLabelText.TabIndex = 34
        Me.formModuleAddUpdateControllerActiveLabelText.Text = "formModuleAddUpdateControllerActiveLabelText"
        '
        'formModuleAddUpdateEnabledCheckBox
        '
        Me.formModuleAddUpdateEnabledCheckBox.AutoSize = True
        Me.formModuleAddUpdateEnabledCheckBox.Location = New System.Drawing.Point(440, 18)
        Me.formModuleAddUpdateEnabledCheckBox.Name = "formModuleAddUpdateEnabledCheckBox"
        Me.formModuleAddUpdateEnabledCheckBox.Size = New System.Drawing.Size(65, 17)
        Me.formModuleAddUpdateEnabledCheckBox.TabIndex = 63
        Me.formModuleAddUpdateEnabledCheckBox.Text = "Enabled"
        Me.formModuleAddUpdateEnabledCheckBox.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdateControlLightsCheckBox
        '
        Me.formModuleAddUpdateControlLightsCheckBox.AutoSize = True
        Me.formModuleAddUpdateControlLightsCheckBox.Location = New System.Drawing.Point(123, 230)
        Me.formModuleAddUpdateControlLightsCheckBox.Name = "formModuleAddUpdateControlLightsCheckBox"
        Me.formModuleAddUpdateControlLightsCheckBox.Size = New System.Drawing.Size(15, 14)
        Me.formModuleAddUpdateControlLightsCheckBox.TabIndex = 65
        Me.formModuleAddUpdateControlLightsCheckBox.UseVisualStyleBackColor = True
        '
        'formModuleAddUpdateControlLightsLabel
        '
        Me.formModuleAddUpdateControlLightsLabel.AutoSize = True
        Me.formModuleAddUpdateControlLightsLabel.Location = New System.Drawing.Point(41, 230)
        Me.formModuleAddUpdateControlLightsLabel.Name = "formModuleAddUpdateControlLightsLabel"
        Me.formModuleAddUpdateControlLightsLabel.Size = New System.Drawing.Size(74, 13)
        Me.formModuleAddUpdateControlLightsLabel.TabIndex = 64
        Me.formModuleAddUpdateControlLightsLabel.Text = "Control Lights:"
        '
        'formModuleAddUpdate
        '
        Me.AcceptButton = Me.formModuleAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formModuleAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(510, 387)
        Me.Controls.Add(Me.formModuleAddUpdateControlLightsCheckBox)
        Me.Controls.Add(Me.formModuleAddUpdateControlLightsLabel)
        Me.Controls.Add(Me.formModuleAddUpdateEnabledCheckBox)
        Me.Controls.Add(Me.formModuleAddUpdateControllerActiveLabelText)
        Me.Controls.Add(Me.formModuleAddUpdateControllerActiveLabel)
        Me.Controls.Add(Me.formModuleAddUpdateExtendedCommandsCheckBox)
        Me.Controls.Add(Me.formModuleAddUpdateExtendedCommandsLabel)
        Me.Controls.Add(Me.formModuleAddUpdateOperationsGroupBox)
        Me.Controls.Add(Me.formModuleAddUpdateControllersComboBox)
        Me.Controls.Add(Me.formModuleAddUpdateControllersLabel)
        Me.Controls.Add(Me.formModuleAddUpdateDimmerCheckBox)
        Me.Controls.Add(Me.formModuleAddUpdateDimmerLabel)
        Me.Controls.Add(Me.formModuleAddUpdateModuleCodeComboBox)
        Me.Controls.Add(Me.formModuleAddUpdateModuleCodeLabel)
        Me.Controls.Add(Me.formModuleAddUpdateHouseCodeComboBox)
        Me.Controls.Add(Me.formModuleAddUpdateHouseCodeLabel)
        Me.Controls.Add(Me.formModuleAddUpdateDescriptionTextBox)
        Me.Controls.Add(Me.formModuleAddUpdateDescriptionLabel)
        Me.Controls.Add(Me.formModuleAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formModuleAddUpdateNameTextBox)
        Me.Controls.Add(Me.formModuleAddUpdateIDLabelText)
        Me.Controls.Add(Me.formModuleAddUpdateIDLabel)
        Me.Controls.Add(Me.formModuleAddUpdateNameLabel)
        Me.Controls.Add(Me.formModuleAddUpdate_AddUpdateButton)
        Me.Controls.Add(Me.formModuleAddUpdate_DeleteButton)
        Me.Controls.Add(Me.formModuleAddUpdate_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formModuleAddUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Module Add / Update"
        Me.formModuleAddUpdateOperationsGroupBox.ResumeLayout(False)
        Me.formModuleAddUpdateOperationsGroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formModuleAddUpdate_CancelButton As Button
    Friend WithEvents formModuleAddUpdate_DeleteButton As Button
    Friend WithEvents formModuleAddUpdate_AddUpdateButton As Button
    Friend WithEvents formModuleAddUpdateNameLabel As Label
    Friend WithEvents formModuleAddUpdateIDLabel As Label
    Friend WithEvents formModuleAddUpdateIDLabelText As Label
    Friend WithEvents formModuleAddUpdateNameTextBox As TextBox
    Friend WithEvents formModuleAddUpdate_StatusLabel As Label
    Friend WithEvents formModuleAddUpdateDescriptionTextBox As TextBox
    Friend WithEvents formModuleAddUpdateDescriptionLabel As Label
    Friend WithEvents formModuleAddUpdateHouseCodeComboBox As ComboBox
    Friend WithEvents formModuleAddUpdateHouseCodeLabel As Label
    Friend WithEvents formModuleAddUpdateModuleCodeComboBox As ComboBox
    Friend WithEvents formModuleAddUpdateModuleCodeLabel As Label
    Friend WithEvents formModuleAddUpdateDimmerLabel As Label
    Friend WithEvents formModuleAddUpdateDimmerCheckBox As CheckBox
    Friend WithEvents formModuleAddUpdateControllersComboBox As ComboBox
    Friend WithEvents formModuleAddUpdateControllersLabel As Label
    Friend WithEvents formModuleAddUpdateOperationsGroupBox As GroupBox
    Friend WithEvents formModuleAddUpdate_TestButton As Button
    Friend WithEvents formModuleAddUpdateOnOffLabel As Label
    Friend WithEvents formModuleAddUpdateOnOffComboBox As ComboBox
    Friend WithEvents formModuleAddUpdateExtendedCommandsCheckBox As CheckBox
    Friend WithEvents formModuleAddUpdateExtendedCommandsLabel As Label
    Friend WithEvents formModuleAddUpdateControllerActiveLabel As Label
    Friend WithEvents formModuleAddUpdateControllerActiveLabelText As Label
    Friend WithEvents formModuleAddUpdateEnabledCheckBox As CheckBox
    Friend WithEvents formModuleAddUpdateControlLightsCheckBox As CheckBox
    Friend WithEvents formModuleAddUpdateControlLightsLabel As Label
End Class
