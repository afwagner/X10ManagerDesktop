﻿
' Name: formFileBackup.vb
' By: Alan Wagner
' Date: June 2020

Public Class formFileBackup

#Region "X10ManagerDesktopFileBackupMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Try

            Me.BringToFront()

            formFileBackup_StatusLabel.Text = ""

            strTryStep = "formFileBackup_FormRestore"
            ' formFileBackup_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formFileBackup_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                formFileBackupLocationLabel.Text() = X10ManagerDesktop.backupDirectoryPath
                formFileBackup_CancelButton.Select()

            Else
                Windows.Forms.MessageBox.Show("Main(formFileBackup): " & strStatus, "Main(formFileBackup)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - formFileBackup_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formFileBackup): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formFileBackup)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try

    End Sub ' END Sub - Main(formFileBackup)

    Private Sub formFileBackup_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formFileBackup_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formFileBackup_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formFileBackup_FormClosingHandler(): " & strStatus, "formFileBackup_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formFileImport_FormSave()

    End Sub ' END Sub - formFileBackup_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopFileBackupMainMethods

#Region "formMethods"

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formFileBackup_BackupButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileBackup_BackupButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""
        Dim strMessage As String = ""
        Dim strOperationMessage As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim objOpenForms As System.Windows.Forms.FormCollection = System.Windows.Forms.Application.OpenForms
        Dim objForm As System.Windows.Forms.Form = Nothing
        Dim objOpenFormsList As System.Collections.Generic.List(Of System.Windows.Forms.Form) = Nothing
        Dim bProceedWithBackupQuestion As Boolean = True
        Dim bProceedWithBackup As Boolean = True

        Try

            strTryStep = "ConnectionStrings"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "OpenFormsCount"
            If (objOpenForms.Count > 0) Then

                strTryStep = "NewObjectOpenFormsList"
                objOpenFormsList = New System.Collections.Generic.List(Of System.Windows.Forms.Form)

                strTryStep = "CheckForOpenForms"
                For Each objForm In objOpenForms

                    If (Microsoft.VisualBasic.InStr(1, objForm.Name.ToString(), "AddUpdate", vbTextCompare) > 1 Or Microsoft.VisualBasic.InStr(1, objForm.Name.ToString(), "Messages", vbTextCompare) > 1) Then

                        objOpenFormsList.Add(objForm)

                    End If

                Next ' END - CheckForOpenForms

            End If ' END - OpenFormsCount

            strTryStep = "FormsToClose?"
            If (Not objOpenFormsList Is Nothing AndAlso objOpenFormsList.Count > 0) Then

                strTryStep = "ProceedAndOpenFormsQuestion"
                If (Windows.Forms.MessageBox.Show("There is unsaved work." & vbCrLf & "Close Opened Forms and proceed with Backup?", "Close", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Warning) = Windows.Forms.DialogResult.No) Then

                    ' Stop the Restore.
                    bProceedWithBackup = False

                Else

                    strTryStep = "CloseEachOpenForm"
                    If (objOpenFormsList.Count > 0) Then
                        For Each objForm In objOpenFormsList
                            strTryStep = "CloseForm"
                            strMessage &= vbCrLf & "  Close Form: " & objForm.Name.ToString()
                            objForm.Close()
                        Next
                        strMessage &= vbCrLf
                    End If

                End If ' END - ProceedAndOpenFormsQuestion

            End If ' END - FormsToClose?

            strTryStep = "bProceedWithBackup"
            If bProceedWithBackup Then

                formFileBackup_StatusLabel.Text = "Start Backup: Please Wait.."
                formFileBackup_StatusLabel.ForeColor = System.Drawing.Color.Green
                Me.Refresh()

                strTryStep = "nsX10DbMethods.getX10DbTableContents"
                ' nsX10DbMethods.getX10DbTableContents(ByVal strX10DbConnectionString As String, ByVal strX10DbProvider As String, ByVal strDestinationDirectoryPath As String, ByRef strMessage As String) As String
                strStatus = nsX10DbMethods.getX10DbTableContents(strConnectionString, strProvider, formFileBackupLocationLabel.Text(), strOperationMessage)
                If (strStatus = "") Then

                    strMessage &= strOperationMessage & vbCrLf & vbCrLf & "Success!"
                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                    Call formConsoleMessages.DisplayMessage(strMessage, "Backup Database and Settings")

                    formFileBackup_BackupButton.Visible = False
                    formFileBackup_StatusLabel.Text = "Success"
                    formFileBackup_StatusLabel.ForeColor = System.Drawing.Color.Green
                    formFileBackup_CancelButton.Text() = "Done"

                Else

                    strMessage &= strOperationMessage & vbCrLf & vbCrLf & "Fail!"
                    ' formConsoleMessages.DisplayMessage(ByVal strMessage As String, ByVal strTitle As String)
                    Call formConsoleMessages.DisplayMessage(strMessage, "Backup Database and Settings")

                    formFileBackup_BackupButton.Visible = False
                    formFileBackup_StatusLabel.Text = "Fail"
                    formFileBackup_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formFileBackup_CancelButton.Text() = "Cancel"

                End If ' END - nsX10DbMethods.getX10DbTableContents()

            End If ' END - bProceedWithBackup

        Catch ex As Exception
            strStatus = "formFileBackup_BackupButton_Click(): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formFileBackup_BackupButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formFileBackup_BackupButton.Visible = False
            formFileBackup_StatusLabel.Text = "Fail"
            formFileBackup_StatusLabel.ForeColor = System.Drawing.Color.Red
            formFileBackup_CancelButton.Text() = "Cancel"
        Finally
            objOpenForms = Nothing
            objForm = Nothing
            objOpenFormsList = Nothing
        End Try

    End Sub ' END - formFileBackup_BackupButton_Click()

    Private Sub formFileBackup_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileBackup_CancelButton.Click

        Me.Close()

    End Sub ' END - formFileBackup_CancelButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formFileBackup_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationFileBackup" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formFileBackup_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(425, 325)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationFileBackup Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationFileBackup.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationFileBackup.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formFileBackup_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formFileBackup_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formFileBackup_FormRestore()

    '=====================================================================================
    ' Function formFileBackup_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationFileBackup" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formFileBackup_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationFileBackup = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationFileBackup = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formFileBackup_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formFileBackup_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formFileBackup_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formFileBackup