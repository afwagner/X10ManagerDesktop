﻿
' Name: formEventAddUpdate.vb
' By: Alan Wagner
' Date: March 2020

Public Class formEventAddUpdate

#Region "X10ManagerDesktopEventAddUpdateMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods
        Dim nsStringMethods As New TrekkerPhotoArt.X10Include.StringMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim objX10DbEvent As TrekkerPhotoArt.X10Include.X10DbEvent = Nothing
        Dim intEventID As Integer = -1
        Dim intScheduleID As Integer = -1

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim intHour As Integer = -1
        Dim intHourAMPM As Integer = -1
        Dim strAMPM As String = ""
        Dim intMinute As Integer = -1

        Try

            strTryStep = "formEventAddUpdateCallingFormLabelText.Visible"
            formEventAddUpdateCallingFormLabelText.Visible = False

            strTryStep = "formEventAddUpdateScheduleIDLabelText.Visible"
            formEventAddUpdateScheduleIDLabelText.Visible = False

            strTryStep = "formEventAddUpdate_FormRestore"
            ' formEventAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formEventAddUpdate_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "formEventAddUpdateIDLabelText"
                If (formEventAddUpdateIDLabelText.Text() = "" Or formEventAddUpdateIDLabelText.Text() = "-1") Then
                    strTryStep = "AddEvent"

                    strTryStep = "formEventAddUpdateScheduleIDLabelText.Text()"
                    If (formEventAddUpdateScheduleIDLabelText.Text() = "") Then
                        Windows.Forms.MessageBox.Show("Missing ScheduleID from calling Form """ & formEventAddUpdateCallingFormLabelText.Text() & """.", "Main(formEventAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Me.Close()
                    Else

                        formEventAddUpdateIDLabelText.Text() = ""

                        formEventAddUpdateScheduleLabel.Visible = True
                        formEventAddUpdateScheduleLabelText.Visible = True

                        ' Set the caption bar text of the form.
                        Me.Text = "Add Event"
                        Me.BringToFront()

                        formEventAddUpdate_AddUpdateButton.Text() = "Add"
                        formEventAddUpdate_AddUpdateButton.Select()
                        formEventAddUpdate_StatusLabel.Visible = True
                        formEventAddUpdate_StatusLabel.Text = ""

                        formEventAddUpdate_CancelButton.Text() = "Cancel"

                        formEventAddUpdate_DeleteButton.Visible = False
                        formEventAddUpdate_DeleteButton.Text() = "Delete"

                        formEventAddUpdateSceneMacroPanel.Visible = True
                        formEventAddUpdateSceneRadioButton.Visible = True
                        formEventAddUpdateSceneRadioButton.Enabled = True
                        formEventAddUpdateSceneRadioButton.Checked = True
                        formEventAddUpdateMacroRadioButton.Visible = True
                        formEventAddUpdateMacroRadioButton.Enabled = True
                        formEventAddUpdateMacroRadioButton.Checked = False

                        strTryStep = "generateScenesComboBox_Add"
                        formEventAddUpdateScenesMacrosLabel.Visible = True
                        formEventAddUpdateScenesMacrosLabel.Text() = "Scene:"
                        ' generateScenesComboBox(ByVal intSceneID As Integer) As String
                        strStatus = generateScenesComboBox(-1)
                        If (strStatus = "") Then
                            formEventAddUpdateScenesMacrosComboBox.Visible = True
                        Else
                            formEventAddUpdateScenesMacrosComboBox.Visible = False
                            Windows.Forms.MessageBox.Show(strStatus, "Main(formEventAddUpdate-Add)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formEventAddUpdate_StatusLabel.Text = "Fail"
                            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formEventAddUpdate_CancelButton.Text() = "Cancel"
                        End If

                        formEventAddUpdateEventEnabledCheckBox.Visible = True
                        formEventAddUpdateEventEnabledCheckBox.Enabled = True
                        formEventAddUpdateEventEnabledCheckBox.Checked = True

                        formEventAddUpdateStartDateLabel.Visible = True
                        formEventAddUpdateStopDateLabel.Visible = True
                        formEventAddUpdateStartDateDateTimePicker.Visible = True
                        formEventAddUpdateStartDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 1, 1)
                        formEventAddUpdateStopDateDateTimePicker.Visible = True
                        formEventAddUpdateStopDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 12, 31)

                        formEventAddUpdateTimeLabel.Visible = True
                        formEventAddUpdateSpecificTimeRadioButton.Visible = True
                        formEventAddUpdateSpecificTimeRadioButton.Enabled = True
                        formEventAddUpdateSpecificTimeRadioButton.Checked = True

                        formEventAddUpdateSpecificTimeDateTimePicker.Value = System.DateTime.Now()
                        formEventAddUpdateSpecificTimeDateTimePicker.Enabled = True
                        formEventAddUpdateSpecificTimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
                        formEventAddUpdateSpecificTimeDateTimePicker.CustomFormat = "hh:mm tt"
                        formEventAddUpdateSpecificTimeDateTimePicker.ShowUpDown = True
                        formEventAddUpdateSpecificTimeDateTimePicker.Visible = True

                        formEventAddUpdateSpecificTimeLabelFormat.Visible = True

                        formEventAddUpdateAfterSunriseByRadioButton.Visible = True
                        formEventAddUpdateAfterSunriseByRadioButton.Enabled = True
                        formEventAddUpdateAfterSunriseByRadioButton.Checked = False
                        formEventAddUpdateSunriseMinutesTextBox.Visible = True
                        formEventAddUpdateSunriseMinutesTextBox.Enabled = False
                        formEventAddUpdateSunriseMinutesTextBox.Text() = ""
                        formEventAddUpdateSunriseMinutesLabel.Visible = True
                        formEventAddUpdateSunriseMinutesLabel.Enabled = False

                        formEventAddUpdateAfterSunsetByRadioButton.Visible = True
                        formEventAddUpdateAfterSunsetByRadioButton.Enabled = True
                        formEventAddUpdateAfterSunsetByRadioButton.Checked = False
                        formEventAddUpdateSunsetMinutesTextBox.Visible = True
                        formEventAddUpdateSunsetMinutesTextBox.Enabled = False
                        formEventAddUpdateSunsetMinutesTextBox.Text() = ""
                        formEventAddUpdateSunsetMinutesLabel.Visible = True
                        formEventAddUpdateSunsetMinutesLabel.Enabled = False

                        formEventAddUpdateSecurityVarationsCheckBox.Visible = True
                        formEventAddUpdateSecurityVarationsCheckBox.Checked = False

                        formEventAddUpdateDayLabel.Visible = True
                        formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = False
                        formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = False

                        formEventAddUpdateTodayRadioButton.Visible = True
                        formEventAddUpdateTodayRadioButton.Enabled = True
                        formEventAddUpdateTodayRadioButton.Checked = True

                        formEventAddUpdateTomorrowRadioButton.Visible = True
                        formEventAddUpdateTomorrowRadioButton.Enabled = True
                        formEventAddUpdateTomorrowRadioButton.Checked = False

                        formEventAddUpdateWeekendsRadioButton.Visible = True
                        formEventAddUpdateWeekendsRadioButton.Enabled = True
                        formEventAddUpdateWeekendsRadioButton.Checked = False

                        formEventAddUpdateWeekdaysRadioButton.Visible = True
                        formEventAddUpdateWeekdaysRadioButton.Enabled = True
                        formEventAddUpdateWeekdaysRadioButton.Checked = False

                        formEventAddUpdateEveryDayRadioButton.Visible = True
                        formEventAddUpdateEveryDayRadioButton.Enabled = True
                        formEventAddUpdateEveryDayRadioButton.Checked = False

                        formEventAddUpdateSelectedDayRadioButton.Visible = True
                        formEventAddUpdateSelectedDayRadioButton.Enabled = True
                        formEventAddUpdateSelectedDayRadioButton.Checked = False

                        formEventAddUpdateMonCheckBox.Visible = False
                        formEventAddUpdateMonCheckBox.Enabled = False
                        formEventAddUpdateMonCheckBox.Checked = False
                        formEventAddUpdateTueCheckBox.Visible = False
                        formEventAddUpdateTueCheckBox.Enabled = False
                        formEventAddUpdateTueCheckBox.Checked = False
                        formEventAddUpdateWedCheckBox.Visible = False
                        formEventAddUpdateWedCheckBox.Enabled = False
                        formEventAddUpdateWedCheckBox.Checked = False
                        formEventAddUpdateThuCheckBox.Visible = False
                        formEventAddUpdateThuCheckBox.Enabled = False
                        formEventAddUpdateThuCheckBox.Checked = False
                        formEventAddUpdateFriCheckBox.Visible = False
                        formEventAddUpdateFriCheckBox.Enabled = False
                        formEventAddUpdateFriCheckBox.Checked = False
                        formEventAddUpdateSatCheckBox.Visible = False
                        formEventAddUpdateSatCheckBox.Enabled = False
                        formEventAddUpdateSatCheckBox.Checked = False
                        formEventAddUpdateSunCheckBox.Visible = False
                        formEventAddUpdateSunCheckBox.Enabled = False
                        formEventAddUpdateSunCheckBox.Checked = False

                    End If ' END - formEventAddUpdateScheduleIDLabelText.Text()

                Else
                    strTryStep = "UpdateEvent"

                    ' Set the caption bar text of the form.
                    Me.Text = "Update Event"
                    Me.BringToFront()

                    formEventAddUpdate_AddUpdateButton.Text() = "Update"
                    formEventAddUpdate_AddUpdateButton.Select()
                    formEventAddUpdate_StatusLabel.Visible = True
                    formEventAddUpdate_StatusLabel.Text = ""

                    formEventAddUpdate_CancelButton.Text() = "Done"

                    formEventAddUpdate_DeleteButton.Visible = True
                    formEventAddUpdate_DeleteButton.Text() = "Delete"

                    strTryStep = "ConnectionStrings"
                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    strTryStep = "EventID"
                    intEventID = CType(formEventAddUpdateIDLabelText.Text(), Integer)

                    strTryStep = "nsX10DbMethods.getX10DbEvent"
                    ' nsX10DbMethods.getX10DbEvent(ByVal strConnectionString As String, ByVal strProvider As String, ByVal intEventID As Integer, ByRef objX10DbEvent As TrekkerPhotoArt.X10Include.X10DbEvent) As String
                    strStatus = nsX10DbMethods.getX10DbEvent(strConnectionString, strProvider, intEventID, objX10DbEvent)
                    If (strStatus = "") Then

                        formEventAddUpdateIDLabelText.Text() = objX10DbEvent.EventID.ToString()

                        formEventAddUpdateScheduleLabel.Visible = True
                        formEventAddUpdateScheduleLabelText.Visible = True

                        formEventAddUpdateSceneMacroPanel.Visible = True
                        formEventAddUpdateSceneRadioButton.Visible = True
                        formEventAddUpdateSceneRadioButton.Enabled = True
                        formEventAddUpdateMacroRadioButton.Visible = True
                        formEventAddUpdateMacroRadioButton.Enabled = True

                        formEventAddUpdateScenesMacrosLabel.Visible = True

                        If (objX10DbEvent.MacroInitiatorID > -1) Then

                            formEventAddUpdateSceneRadioButton.Checked = False
                            formEventAddUpdateMacroRadioButton.Checked = True

                            strTryStep = "generateMacroInitiatorsComboBox"
                            formEventAddUpdateScenesMacrosLabel.Text() = "Macro:"
                            ' generateMacroInitiatorsComboBox(ByVal intMacroInitiatorID As Integer) As String
                            strStatus = generateMacroInitiatorsComboBox(objX10DbEvent.MacroInitiatorID)
                            If (strStatus = "") Then
                                formEventAddUpdateScenesMacrosComboBox.Visible = True
                            Else
                                formEventAddUpdateScenesMacrosComboBox.Visible = False
                                Windows.Forms.MessageBox.Show(strStatus, "Main(formEventAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formEventAddUpdate_StatusLabel.Text = "Fail"
                                formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formEventAddUpdate_CancelButton.Text() = "Cancel"
                            End If

                        Else

                            formEventAddUpdateSceneRadioButton.Checked = True
                            formEventAddUpdateMacroRadioButton.Checked = False

                            strTryStep = "generateScenesComboBox"
                            formEventAddUpdateScenesMacrosLabel.Text() = "Scene:"
                            ' generateScenesComboBox(ByVal intSceneID As Integer) As String
                            strStatus = generateScenesComboBox(objX10DbEvent.SceneID)
                            If (strStatus = "") Then
                                formEventAddUpdateScenesMacrosComboBox.Visible = True
                            Else
                                formEventAddUpdateScenesMacrosComboBox.Visible = False
                                Windows.Forms.MessageBox.Show(strStatus, "Main(formEventAddUpdate-Update)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                formEventAddUpdate_StatusLabel.Text = "Fail"
                                formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                                formEventAddUpdate_CancelButton.Text() = "Cancel"
                            End If

                        End If

                        strTryStep = "formEventAddUpdateEventEnabledCheckBox"
                        formEventAddUpdateEventEnabledCheckBox.Visible = True
                        formEventAddUpdateEventEnabledCheckBox.Enabled = True
                        If (objX10DbEvent.Enabled = 1) Then
                            formEventAddUpdateEventEnabledCheckBox.Checked = True
                        Else
                            formEventAddUpdateEventEnabledCheckBox.Checked = False
                        End If


                        formEventAddUpdateStartDateLabel.Visible = True
                        formEventAddUpdateStopDateLabel.Visible = True
                        formEventAddUpdateStartDateDateTimePicker.Visible = True
                        If (objX10DbEvent.StartDate = Nothing) Then
                            formEventAddUpdateStartDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 1, 1)
                        Else
                            formEventAddUpdateStartDateDateTimePicker.Value = objX10DbEvent.StartDate
                        End If

                        formEventAddUpdateStopDateDateTimePicker.Visible = True
                        If (objX10DbEvent.StopDate = Nothing) Then
                            formEventAddUpdateStopDateDateTimePicker.Value = New System.DateTime(System.DateTime.Now.Year, 12, 31)
                        Else
                            formEventAddUpdateStopDateDateTimePicker.Value = objX10DbEvent.StopDate
                        End If


                        formEventAddUpdateTimeLabel.Visible = True

                        formEventAddUpdateSpecificTimeRadioButton.Visible = True
                        formEventAddUpdateSpecificTimeRadioButton.Enabled = True
                        formEventAddUpdateSpecificTimeRadioButton.Checked = True

                        formEventAddUpdateSpecificTimeLabelFormat.Visible = True
                        formEventAddUpdateSpecificTimeLabelFormat.Enabled = True

                        formEventAddUpdateAfterSunriseByRadioButton.Visible = True
                        formEventAddUpdateAfterSunriseByRadioButton.Enabled = True
                        formEventAddUpdateAfterSunriseByRadioButton.Checked = False
                        formEventAddUpdateSunriseMinutesTextBox.Visible = True
                        formEventAddUpdateSunriseMinutesTextBox.Enabled = False
                        formEventAddUpdateSunriseMinutesTextBox.Text() = ""
                        formEventAddUpdateSunriseMinutesLabel.Visible = True
                        formEventAddUpdateSunriseMinutesLabel.Enabled = False

                        formEventAddUpdateAfterSunsetByRadioButton.Visible = True
                        formEventAddUpdateAfterSunsetByRadioButton.Enabled = True
                        formEventAddUpdateAfterSunsetByRadioButton.Checked = False
                        formEventAddUpdateSunsetMinutesTextBox.Visible = True
                        formEventAddUpdateSunsetMinutesTextBox.Enabled = False
                        formEventAddUpdateSunsetMinutesTextBox.Text() = ""
                        formEventAddUpdateSunsetMinutesLabel.Visible = True
                        formEventAddUpdateSunsetMinutesLabel.Enabled = False

                        strTryStep = "Time"
                        Select Case objX10DbEvent.TOD
                            Case 0
                                ' Specific Time

                                If (objX10DbEvent.STime > -1) Then

                                    intHour = objX10DbEvent.STime \ 60

                                    If (intHour = 12) Then
                                        ' PM
                                        strAMPM = "PM"
                                        intHourAMPM = intHour
                                    ElseIf (intHour > 12) Then
                                        ' PM
                                        strAMPM = "PM"
                                        intHourAMPM = intHour - 12
                                    ElseIf (intHour = 0) Then
                                        ' AM
                                        strAMPM = "AM"
                                        intHourAMPM = 12
                                    Else
                                        ' AM
                                        strAMPM = "AM"
                                        intHourAMPM = intHour
                                    End If

                                    intMinute = objX10DbEvent.STime Mod 60

                                    formEventAddUpdateSpecificTimeDateTimePicker.Value = System.Convert.ToDateTime(System.DateTime.Today.ToShortDateString() & " " & nsStringMethods.addLeadingZeros(intHourAMPM.ToString(), 2) & ":" & nsStringMethods.addLeadingZeros(intMinute.ToString(), 2) & " " & strAMPM)

                                Else
                                    intHour = -1
                                    intHourAMPM = -1
                                    strAMPM = ""
                                    intMinute = -1
                                    formEventAddUpdateSpecificTimeDateTimePicker.Value = System.DateTime.Now()
                                End If

                                formEventAddUpdateSpecificTimeRadioButton.Checked = True
                                formEventAddUpdateSpecificTimeDateTimePicker.Enabled = True
                                formEventAddUpdateSpecificTimeLabelFormat.Enabled = True

                            Case 1
                                ' Sunrise Minutes

                                formEventAddUpdateSpecificTimeRadioButton.Checked = False
                                formEventAddUpdateSpecificTimeDateTimePicker.Value = System.DateTime.Now()
                                formEventAddUpdateSpecificTimeDateTimePicker.Enabled = False
                                formEventAddUpdateSpecificTimeLabelFormat.Enabled = False

                                formEventAddUpdateAfterSunriseByRadioButton.Enabled = True
                                formEventAddUpdateAfterSunriseByRadioButton.Checked = True
                                formEventAddUpdateSunriseMinutesTextBox.Enabled = True

                                If (objX10DbEvent.ARise = 0) Then
                                    formEventAddUpdateSunriseMinutesTextBox.Text() = "0"
                                ElseIf (objX10DbEvent.ARise < 0) Then
                                    formEventAddUpdateSunriseMinutesTextBox.Text() = "-" & System.Math.Abs(objX10DbEvent.ARise).ToString()
                                Else
                                    formEventAddUpdateSunriseMinutesTextBox.Text() = "+" & objX10DbEvent.ARise.ToString()
                                End If

                                formEventAddUpdateSunriseMinutesLabel.Enabled = True

                            Case 2
                                ' Sunset Minutes

                                formEventAddUpdateSpecificTimeRadioButton.Checked = False
                                formEventAddUpdateSpecificTimeDateTimePicker.Value = System.DateTime.Now()
                                formEventAddUpdateSpecificTimeDateTimePicker.Enabled = False
                                formEventAddUpdateSpecificTimeLabelFormat.Enabled = False

                                formEventAddUpdateAfterSunsetByRadioButton.Enabled = True
                                formEventAddUpdateAfterSunsetByRadioButton.Checked = True
                                formEventAddUpdateSunsetMinutesTextBox.Enabled = True

                                If (objX10DbEvent.ASet = 0) Then
                                    formEventAddUpdateSunsetMinutesTextBox.Text() = "0"
                                ElseIf (objX10DbEvent.ASet < 0) Then
                                    formEventAddUpdateSunsetMinutesTextBox.Text() = "-" & System.Math.Abs(objX10DbEvent.ASet).ToString()
                                Else
                                    formEventAddUpdateSunsetMinutesTextBox.Text() = "+" & objX10DbEvent.ASet.ToString()
                                End If

                                formEventAddUpdateSunsetMinutesLabel.Enabled = True

                            Case Else
                                ' No Time - Probably an Add
                                formEventAddUpdateSpecificTimeRadioButton.Checked = True
                                formEventAddUpdateSpecificTimeDateTimePicker.Value = System.DateTime.Now()
                                formEventAddUpdateSpecificTimeDateTimePicker.Enabled = True
                                formEventAddUpdateSpecificTimeLabelFormat.Enabled = True
                        End Select ' END - Time

                        formEventAddUpdateSpecificTimeDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom
                        formEventAddUpdateSpecificTimeDateTimePicker.CustomFormat = "hh:mm tt"
                        formEventAddUpdateSpecificTimeDateTimePicker.ShowUpDown = True
                        formEventAddUpdateSpecificTimeDateTimePicker.Visible = True

                        strTryStep = "Security"
                        formEventAddUpdateSecurityVarationsCheckBox.Visible = True
                        Select Case objX10DbEvent.Sec
                            Case 0
                                formEventAddUpdateSecurityVarationsCheckBox.Checked = False
                            Case 1
                                formEventAddUpdateSecurityVarationsCheckBox.Checked = True
                        End Select

                        formEventAddUpdateDayLabel.Visible = True
                        formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = False
                        formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = False

                        formEventAddUpdateTodayRadioButton.Visible = True
                        formEventAddUpdateTodayRadioButton.Enabled = True
                        formEventAddUpdateTodayRadioButton.Checked = True

                        formEventAddUpdateTomorrowRadioButton.Visible = True
                        formEventAddUpdateTomorrowRadioButton.Enabled = True
                        formEventAddUpdateTomorrowRadioButton.Checked = False

                        formEventAddUpdateWeekendsRadioButton.Visible = True
                        formEventAddUpdateWeekendsRadioButton.Enabled = True
                        formEventAddUpdateWeekendsRadioButton.Checked = False

                        formEventAddUpdateWeekdaysRadioButton.Visible = True
                        formEventAddUpdateWeekdaysRadioButton.Enabled = True
                        formEventAddUpdateWeekdaysRadioButton.Checked = False

                        formEventAddUpdateEveryDayRadioButton.Visible = True
                        formEventAddUpdateEveryDayRadioButton.Enabled = True
                        formEventAddUpdateEveryDayRadioButton.Checked = False

                        formEventAddUpdateSelectedDayRadioButton.Visible = True
                        formEventAddUpdateSelectedDayRadioButton.Enabled = True
                        formEventAddUpdateSelectedDayRadioButton.Checked = False

                        formEventAddUpdateMonCheckBox.Visible = False
                        formEventAddUpdateMonCheckBox.Enabled = False
                        formEventAddUpdateMonCheckBox.Checked = False
                        formEventAddUpdateTueCheckBox.Visible = False
                        formEventAddUpdateTueCheckBox.Enabled = False
                        formEventAddUpdateTueCheckBox.Checked = False
                        formEventAddUpdateWedCheckBox.Visible = False
                        formEventAddUpdateWedCheckBox.Enabled = False
                        formEventAddUpdateWedCheckBox.Checked = False
                        formEventAddUpdateThuCheckBox.Visible = False
                        formEventAddUpdateThuCheckBox.Enabled = False
                        formEventAddUpdateThuCheckBox.Checked = False
                        formEventAddUpdateFriCheckBox.Visible = False
                        formEventAddUpdateFriCheckBox.Enabled = False
                        formEventAddUpdateFriCheckBox.Checked = False
                        formEventAddUpdateSatCheckBox.Visible = False
                        formEventAddUpdateSatCheckBox.Enabled = False
                        formEventAddUpdateSatCheckBox.Checked = False
                        formEventAddUpdateSunCheckBox.Visible = False
                        formEventAddUpdateSunCheckBox.Enabled = False
                        formEventAddUpdateSunCheckBox.Checked = False

                        strTryStep = "Days"
                        Select Case objX10DbEvent.DOW
                            Case 0
                                ' Today

                                formEventAddUpdateTodayRadioButton.Checked = True
                                formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = True
                                formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = True

                            Case 1
                                ' Tomorrow

                                formEventAddUpdateTomorrowRadioButton.Checked = True
                                formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = True
                                formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = True

                            Case 2
                                ' All Days
                                ' Su Mo Tu We Th Fr Sa

                                formEventAddUpdateEveryDayRadioButton.Checked = True

                                formEventAddUpdateMonCheckBox.Visible = True
                                formEventAddUpdateMonCheckBox.Checked = True
                                formEventAddUpdateTueCheckBox.Visible = True
                                formEventAddUpdateTueCheckBox.Checked = True
                                formEventAddUpdateWedCheckBox.Visible = True
                                formEventAddUpdateWedCheckBox.Checked = True
                                formEventAddUpdateThuCheckBox.Visible = True
                                formEventAddUpdateThuCheckBox.Checked = True
                                formEventAddUpdateFriCheckBox.Visible = True
                                formEventAddUpdateFriCheckBox.Checked = True
                                formEventAddUpdateSatCheckBox.Visible = True
                                formEventAddUpdateSatCheckBox.Checked = True
                                formEventAddUpdateSunCheckBox.Visible = True
                                formEventAddUpdateSunCheckBox.Checked = True

                            Case 3
                                ' Specific Day(s) as A mask of days

                                formEventAddUpdateSelectedDayRadioButton.Checked = True

                                formEventAddUpdateMonCheckBox.Visible = True
                                formEventAddUpdateMonCheckBox.Enabled = True
                                formEventAddUpdateTueCheckBox.Visible = True
                                formEventAddUpdateTueCheckBox.Enabled = True
                                formEventAddUpdateWedCheckBox.Visible = True
                                formEventAddUpdateWedCheckBox.Enabled = True
                                formEventAddUpdateThuCheckBox.Visible = True
                                formEventAddUpdateThuCheckBox.Enabled = True
                                formEventAddUpdateFriCheckBox.Visible = True
                                formEventAddUpdateFriCheckBox.Enabled = True
                                formEventAddUpdateSatCheckBox.Visible = True
                                formEventAddUpdateSatCheckBox.Enabled = True
                                formEventAddUpdateSunCheckBox.Visible = True
                                formEventAddUpdateSunCheckBox.Enabled = True

                                Call checkBoxDays(objX10DbEvent.SDay)

                            Case 4
                                ' Weekends

                                formEventAddUpdateWeekendsRadioButton.Visible = True
                                formEventAddUpdateWeekendsRadioButton.Enabled = True
                                formEventAddUpdateWeekendsRadioButton.Checked = True

                            Case 5
                                ' Weekdays

                                formEventAddUpdateWeekdaysRadioButton.Visible = True
                                formEventAddUpdateWeekdaysRadioButton.Enabled = True
                                formEventAddUpdateWeekdaysRadioButton.Checked = True

                        End Select

                    Else
                        Windows.Forms.MessageBox.Show("Problem getting existing Event from X10 db." & vbCrLf & strStatus, "Main(formEventAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formEventAddUpdate_StatusLabel.Text = "Fail"
                        formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formEventAddUpdate_CancelButton.Text() = "Cancel"
                    End If ' END - nsX10DbMethods.getX10DbEvent()

                End If ' END - formEventAddUpdateIDLabelText

            Else
                Windows.Forms.MessageBox.Show("Main(formEventAddUpdate): " & strStatus, "Main(formEventAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formEventAddUpdate_StatusLabel.Text = "Fail"
                formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formEventAddUpdate_CancelButton.Text() = "Cancel"
            End If ' END - formEventAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formEventAddUpdate): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formEventAddUpdate)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objX10DbEvent = Nothing
        End Try

    End Sub ' END Sub - Main(formEventAddUpdate)

    Private Sub formEventAddUpdate_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formEventAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formEventAddUpdate_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formEventAddUpdate_FormClosingHandler(): " & strStatus, "formEventAddUpdate_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formEventeAddUpdate_FormSave()

    End Sub ' END Sub - formEventAddUpdate_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopEventAddUpdateMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function generateScenesComboBox()
    ' Alan Wagner
    '
    Private Function generateScenesComboBox(ByVal intSceneID As Integer) As String
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""
        Dim objDataTableScenes As New System.Data.DataTable

        Dim objDataRowViewSceneMacro As System.Data.DataRowView = Nothing
        Dim intSelectedIndex As Integer = 0

        Try

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "OleDbDataAdapter"
            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()

                sqlString = "SELECT SceneID, SceneName AS [Scene] " &
                        "FROM Scenes " &
                        "WHERE SceneID>-1 " &
                        "UNION " &
                        "SELECT SceneID, 'Select Scene...' AS [Scene] " &
                        "FROM Scenes " &
                        "WHERE SceneID=-1 " &
                        "ORDER BY SceneID ASC;"

                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableScenes)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            strTryStep = "DataSource"
            formEventAddUpdateScenesMacrosComboBox.DataSource = Nothing

            strTryStep = "formEventAddUpdateScenesMacrosComboBox"
            With formEventAddUpdateScenesMacrosComboBox
                .DisplayMember = "Scene"
                .ValueMember = "SceneID"
                .DataSource = objDataTableScenes
            End With

            strTryStep = "SceneID"
            If (intSceneID = -1) Then
                formEventAddUpdateScenesMacrosComboBox.SelectedIndex = 0
            Else
                formEventAddUpdateScenesMacrosComboBox.SelectedIndex = formEventAddUpdateScenesMacrosComboBox.FindString(intSceneID.ToString)

                For intSelectedIndex = 0 To formEventAddUpdateScenesMacrosComboBox.Items.Count - 1

                    objDataRowViewSceneMacro = formEventAddUpdateScenesMacrosComboBox.Items(intSelectedIndex)

                    If (intSceneID = CType(objDataRowViewSceneMacro.Row("SceneID").ToString(), Integer)) Then
                        formEventAddUpdateScenesMacrosComboBox.SelectedIndex = intSelectedIndex
                        Exit For
                    End If

                Next

            End If

        Catch ex As Exception
            strStatus = "generateScenesComboBox(" & strTryStep & "): Exception: " & ex.Message
        Finally
            objDataRowViewSceneMacro = Nothing
            objDataTableScenes = Nothing
        End Try

        Return strStatus

    End Function ' END - generateScenesComboBox()

    '=====================================================================================
    ' Function generateMacroInitiatorsComboBox()
    ' Alan Wagner
    '
    Private Function generateMacroInitiatorsComboBox(ByVal intMacroInitiatorID As Integer) As String
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim sqlString As String = ""
        Dim objDataTableMacros As New System.Data.DataTable

        Dim objDataRowViewSceneMacro As System.Data.DataRowView = Nothing
        Dim intSelectedIndex As Integer = 0

        Try

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "OleDbDataAdapter"
            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(strConnectionString)
                objConnection.Open()

                sqlString = "SELECT MacroInitiatorID, name AS [Macro] " &
                        "FROM MacroInitiators " &
                        "WHERE MacroInitiatorID>-1 " &
                        "UNION " &
                        "SELECT MacroInitiatorID, 'Select Macro...' AS [Macro] " &
                        "FROM MacroInitiators " &
                        "WHERE MacroInitiatorID=-1 " &
                        "ORDER BY MacroInitiatorID ASC;"

                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)
                objOleDbDataAdapter.Fill(objDataTableMacros)
                objConnection.Close()
                objOleDbDataAdapter = Nothing
            End Using

            strTryStep = "DataSource"
            formEventAddUpdateScenesMacrosComboBox.DataSource = Nothing

            strTryStep = "formEventAddUpdateScenesMacrosComboBox"
            With formEventAddUpdateScenesMacrosComboBox
                .DisplayMember = "Macro"
                .ValueMember = "MacroInitiatorID"
                .DataSource = objDataTableMacros
            End With

            strTryStep = "MacroInitiatorID"
            If (intMacroInitiatorID = -1) Then
                formEventAddUpdateScenesMacrosComboBox.SelectedIndex = 0
            Else
                formEventAddUpdateScenesMacrosComboBox.SelectedIndex = formEventAddUpdateScenesMacrosComboBox.FindString(intMacroInitiatorID.ToString)

                For intSelectedIndex = 0 To formEventAddUpdateScenesMacrosComboBox.Items.Count - 1

                    objDataRowViewSceneMacro = formEventAddUpdateScenesMacrosComboBox.Items(intSelectedIndex)

                    If (intMacroInitiatorID = CType(objDataRowViewSceneMacro.Row("MacroInitiatorID").ToString(), Integer)) Then
                        formEventAddUpdateScenesMacrosComboBox.SelectedIndex = intSelectedIndex
                        Exit For
                    End If

                Next

            End If

        Catch ex As Exception
            strStatus = "generateMacroInitiatorsComboBox(" & strTryStep & "): Exception: " & ex.Message
        Finally
            objDataRowViewSceneMacro = Nothing
            objDataTableMacros = Nothing
        End Try

        Return strStatus

    End Function ' END - generateMacroInitiatorsComboBox()

    '=====================================================================================
    ' Function checkBoxDays()
    '
    ' Bit Mapped day codes.
    ' D7 D6  D5  D4  D3  D2  D1  D0
    '  0 Sun Sat Fri Thu Wed Tue Mon
    '
    Private Sub checkBoxDays(ByVal intDayCode As Integer)

        ' Sunday
        ' &H40 = 64 = &B01000000
        If ((intDayCode And &H40) = &H40) Then
            formEventAddUpdateSunCheckBox.Checked = True
        Else
            formEventAddUpdateSunCheckBox.Checked = False
        End If

        ' Monday
        ' &H1 = 1 = &B0001
        If ((intDayCode And &H1) = &H1) Then
            formEventAddUpdateMonCheckBox.Checked = True
        Else
            formEventAddUpdateMonCheckBox.Checked = False
        End If

        ' Tuesday
        ' &H2 = 2 = &B0010
        If ((intDayCode And &H2) = &H2) Then
            formEventAddUpdateTueCheckBox.Checked = True
        Else
            formEventAddUpdateTueCheckBox.Checked = False
        End If

        ' Wednesday
        ' &H4 = 4 = &B0100
        If ((intDayCode And &H4) = &H4) Then
            formEventAddUpdateWedCheckBox.Checked = True
        Else
            formEventAddUpdateWedCheckBox.Checked = False
        End If

        ' Thursday
        ' &H8 = 8 = &B1000
        If ((intDayCode And &H8) = &H8) Then
            formEventAddUpdateThuCheckBox.Checked = True
        Else
            formEventAddUpdateThuCheckBox.Checked = False
        End If

        ' Friday
        ' &H10 = 16 = &B00010000
        If ((intDayCode And &H10) = &H10) Then
            formEventAddUpdateFriCheckBox.Checked = True
        Else
            formEventAddUpdateFriCheckBox.Checked = False
        End If

        ' Saturday
        ' &H20 = 32 = &B00100000
        If ((intDayCode And &H20) = &H20) Then
            formEventAddUpdateSatCheckBox.Checked = True
        Else
            formEventAddUpdateSatCheckBox.Checked = False
        End If

    End Sub ' END - checkBoxDays()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formEventAddUpdate_AddUpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdate_AddUpdateButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objDataRowViewSceneMacro As System.Data.DataRowView = Nothing

        Dim objX10DbEvent As TrekkerPhotoArt.X10Include.X10DbEvent = Nothing

        Dim intDays As Integer = -1

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormScheduleAddUpdate As formScheduleAddUpdate = Nothing

        Try

            strTryStep = "ConnectionString"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString

            strTryStep = "ProviderName"
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "NewObjectX10DbEvent"
            objX10DbEvent = New TrekkerPhotoArt.X10Include.X10DbEvent

            strTryStep = "ScheduleID"
            objX10DbEvent.ScheduleID = CType(formEventAddUpdateScheduleIDLabelText.Text(), Integer)

            strTryStep = "EventID"
            If (formEventAddUpdateIDLabelText.Text() = "" Or formEventAddUpdateIDLabelText.Text() = "-1") Then
                ' Add Event
                objX10DbEvent.EventID = -1
            Else
                ' Update Event
                objX10DbEvent.EventID = CType(formEventAddUpdateIDLabelText.Text(), Integer)
            End If

            strTryStep = "DataRowViewSceneMacro"
            objDataRowViewSceneMacro = formEventAddUpdateScenesMacrosComboBox.SelectedItem

            strTryStep = "AddUpdateSceneOrMacro"
            If (formEventAddUpdateSceneRadioButton.Checked) Then
                ' Add/Update Scene

                strTryStep = "IsSceneSelected"
                If (objDataRowViewSceneMacro.Row("SceneID").ToString() = "-1") Then
                    ' No
                    objX10DbEvent.SceneID = -1
                    strStatus = "Missing Scene."
                Else
                    ' Yes
                    strTryStep = "SceneID"
                    objX10DbEvent.SceneID = CType(objDataRowViewSceneMacro.Row("SceneID").ToString(), Integer)
                End If

                objX10DbEvent.MacroInitiatorID = -1

            Else
                ' Add/Update Macro

                objX10DbEvent.SceneID = -1

                strTryStep = "IsMacroSelected"
                If (objDataRowViewSceneMacro.Row("MacroInitiatorID").ToString() = "-1") Then
                    ' No
                    objX10DbEvent.MacroInitiatorID = -1
                    strStatus = "Missing Macro."
                Else
                    ' Yes
                    strTryStep = "MacroInitiatorID"
                    objX10DbEvent.MacroInitiatorID = CType(objDataRowViewSceneMacro.Row("MacroInitiatorID").ToString(), Integer)
                End If

            End If ' END - AddUpdateSceneOrMacro

            strTryStep = "RadioButtonTime"
            If formEventAddUpdateSpecificTimeRadioButton.Checked Then
                ' Specific Time
                ' HH:MM AM/PM
                strTryStep = "RadioButtonTime_SpecificTime"

                objX10DbEvent.TOD = 0
                objX10DbEvent.STime = (formEventAddUpdateSpecificTimeDateTimePicker.Value.TimeOfDay.Hours * 60) + formEventAddUpdateSpecificTimeDateTimePicker.Value.TimeOfDay.Minutes
                objX10DbEvent.ARise = 0
                objX10DbEvent.ASet = 0

            ElseIf formEventAddUpdateAfterSunriseByRadioButton.Checked Then
                ' Sunrise Minutes
                strTryStep = "RadioButtonTime_SunriseMinutes"

                If (formEventAddUpdateSunriseMinutesTextBox.Text() = "") Then
                    strStatus = "Missing Sunrise Minutes."
                Else

                    objX10DbEvent.TOD = 1
                    objX10DbEvent.STime = 0
                    objX10DbEvent.ARise = CType(formEventAddUpdateSunriseMinutesTextBox.Text(), Integer)
                    objX10DbEvent.ASet = 0

                End If

            ElseIf formEventAddUpdateAfterSunsetByRadioButton.Checked Then
                ' Sunset Minutes
                strTryStep = "RadioButtonTime_SunsetMinutes"

                If (formEventAddUpdateSunsetMinutesTextBox.Text() = "") Then
                    strStatus = "Missing Sunset Minutes."
                Else

                    objX10DbEvent.TOD = 2
                    objX10DbEvent.STime = 0
                    objX10DbEvent.ARise = 0
                    objX10DbEvent.ASet = CType(formEventAddUpdateSunsetMinutesTextBox.Text(), Integer)

                End If

            End If

            strTryStep = "RadioButtonDays"
            If formEventAddUpdateTodayRadioButton.Checked Then
                ' Today
                strTryStep = "RadioButtonDays_Today"

                objX10DbEvent.DOW = 0
                objX10DbEvent.SDay = 0

            ElseIf formEventAddUpdateTomorrowRadioButton.Checked Then
                ' Tomorrow
                strTryStep = "RadioButtonDays_Tomorrow"

                objX10DbEvent.DOW = 1
                objX10DbEvent.SDay = 0

            ElseIf formEventAddUpdateEveryDayRadioButton.Checked Then
                ' All Days
                ' Su Mo Tu We Th Fr Sa
                strTryStep = "RadioButtonDays_AllDays"

                objX10DbEvent.DOW = 2
                objX10DbEvent.SDay = 0

            ElseIf formEventAddUpdateSelectedDayRadioButton.Checked Then
                ' Specific Day(s) as A mask of days
                strTryStep = "RadioButtonDays_AMaskOfDays"

                If (formEventAddUpdateMonCheckBox.Checked Or formEventAddUpdateTueCheckBox.Checked Or formEventAddUpdateWedCheckBox.Checked Or formEventAddUpdateThuCheckBox.Checked Or formEventAddUpdateFriCheckBox.Checked Or formEventAddUpdateSatCheckBox.Checked Or formEventAddUpdateSunCheckBox.Checked) Then

                    objX10DbEvent.DOW = 3

                    objX10DbEvent.SDay = 0

                    If formEventAddUpdateMonCheckBox.Checked Then
                        ' nsX10DbMethods.DayOfWeekEnumToDayCode(ByVal objDayOfWeek As System.DayOfWeek) As Integer
                        objX10DbEvent.SDay = nsX10DbMethods.DayOfWeekEnumToDayCode(System.DayOfWeek.Monday)
                    End If

                    If formEventAddUpdateTueCheckBox.Checked Then
                        ' nsX10DbMethods.DayOfWeekEnumToDayCode(ByVal objDayOfWeek As System.DayOfWeek) As Integer
                        objX10DbEvent.SDay = objX10DbEvent.SDay Or nsX10DbMethods.DayOfWeekEnumToDayCode(System.DayOfWeek.Tuesday)
                    End If

                    If formEventAddUpdateWedCheckBox.Checked Then
                        ' nsX10DbMethods.DayOfWeekEnumToDayCode(ByVal objDayOfWeek As System.DayOfWeek) As Integer
                        objX10DbEvent.SDay = objX10DbEvent.SDay Or nsX10DbMethods.DayOfWeekEnumToDayCode(System.DayOfWeek.Wednesday)
                    End If

                    If formEventAddUpdateThuCheckBox.Checked Then
                        ' nsX10DbMethods.DayOfWeekEnumToDayCode(ByVal objDayOfWeek As System.DayOfWeek) As Integer
                        objX10DbEvent.SDay = objX10DbEvent.SDay Or nsX10DbMethods.DayOfWeekEnumToDayCode(System.DayOfWeek.Thursday)
                    End If

                    If formEventAddUpdateFriCheckBox.Checked Then
                        ' nsX10DbMethods.DayOfWeekEnumToDayCode(ByVal objDayOfWeek As System.DayOfWeek) As Integer
                        objX10DbEvent.SDay = objX10DbEvent.SDay Or nsX10DbMethods.DayOfWeekEnumToDayCode(System.DayOfWeek.Friday)
                    End If

                    If formEventAddUpdateSatCheckBox.Checked Then
                        ' nsX10DbMethods.DayOfWeekEnumToDayCode(ByVal objDayOfWeek As System.DayOfWeek) As Integer
                        objX10DbEvent.SDay = objX10DbEvent.SDay Or nsX10DbMethods.DayOfWeekEnumToDayCode(System.DayOfWeek.Saturday)
                    End If

                    If formEventAddUpdateSunCheckBox.Checked Then
                        ' nsX10DbMethods.DayOfWeekEnumToDayCode(ByVal objDayOfWeek As System.DayOfWeek) As Integer
                        objX10DbEvent.SDay = objX10DbEvent.SDay Or nsX10DbMethods.DayOfWeekEnumToDayCode(System.DayOfWeek.Sunday)
                    End If

                Else
                    strStatus = "Missing Selected Day(s)."
                End If

            ElseIf formEventAddUpdateWeekendsRadioButton.Checked Then
                ' Weekends
                ' Su -- -- -- -- -- Sa
                strTryStep = "RadioButtonDays_Weekends"

                objX10DbEvent.DOW = 4
                objX10DbEvent.SDay = 0

            ElseIf formEventAddUpdateWeekdaysRadioButton.Checked Then
                ' Weekdays
                ' -- Mo Tu We Th Fr --
                strTryStep = "RadioButtonDays_Weekdays"

                objX10DbEvent.DOW = 5
                objX10DbEvent.SDay = 0

            End If

            strTryStep = "WasSomethingMissing"
            If (strStatus = "") Then

                strTryStep = "formEventAddUpdateEventEnabledCheckBox"
                If formEventAddUpdateEventEnabledCheckBox.Checked Then
                    objX10DbEvent.Enabled = 1
                Else
                    objX10DbEvent.Enabled = 0
                End If

                strTryStep = "StartDate"
                objX10DbEvent.StartDate = formEventAddUpdateStartDateDateTimePicker.Value
                objX10DbEvent.StopDate = formEventAddUpdateStopDateDateTimePicker.Value

                strTryStep = "formEventAddUpdateSecurityVarationsCheckBox"
                If formEventAddUpdateSecurityVarationsCheckBox.Checked Then
                    objX10DbEvent.Sec = 1
                Else
                    objX10DbEvent.Sec = 0
                End If

                strTryStep = "nsX10DbMethods.addUpdateEventToX10db"
                ' nsX10DbMethods.addUpdateEventToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strGuid As String, ByRef objX10DbEvent As TrekkerPhotoArt.X10Include.X10DbEvent, ByRef intRowsAffected As Integer) As String
                strStatus = nsX10DbMethods.addUpdateEventToX10db(strConnectionString, strProvider, X10ManagerDesktop.pubGuid, objX10DbEvent, intRowsAffected)
                If (strStatus = "") Then

                    strTryStep = "RowsAffected"
                    If (intRowsAffected > 0) Then
                        formEventAddUpdateIDLabelText.Text() = objX10DbEvent.EventID.ToString()

                        If (formEventAddUpdate_AddUpdateButton.Text() = "Add") Then
                            formEventAddUpdate_AddUpdateButton.Text() = "Update"
                            formEventAddUpdate_StatusLabel.Text = "Successfully Added"
                            formEventAddUpdate_DeleteButton.Visible = True
                        Else
                            formEventAddUpdate_StatusLabel.Text = "Successfully Updated"
                        End If

                        formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                        formEventAddUpdate_CancelButton.Text() = "Done"


                        ' Refresh Events DataSet on Calling Form formScheduleAddUpdate if it's active.
                        strTryStep = "RefreshEventsDataSetOnCallingFormScheduleAddUpdate"
                        For Each objFormScheduleAddUpdate In objFormCollection.OfType(Of formScheduleAddUpdate)

                            If (objFormScheduleAddUpdate.formScheduleAddUpdateIDLabelText.Text() = objX10DbEvent.ScheduleID.ToString()) Then

                                objFormScheduleAddUpdate.formScheduleAddUpdate_BringToFrontLabel.Text() = "N"

                                ' formScheduleAddUpdate_GetEventsDataSet() As String
                                strStatus = objFormScheduleAddUpdate.formScheduleAddUpdate_GetEventsDataSet(objX10DbEvent.ScheduleID)
                                If (strStatus = "") Then
                                    objFormScheduleAddUpdate.Activate()
                                Else
                                    Windows.Forms.MessageBox.Show("formEventAddUpdate_AddUpdateButton_Click(): " & strStatus, "formEventAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                End If ' END - formScheduleAddUpdate_GetEventsDataSet()

                                Exit For
                            End If

                        Next ' END - RefreshEventsDataSetOnCallingFormScheduleAddUpdate


                        Me.BringToFront()

                    Else
                        formEventAddUpdate_StatusLabel.Text = "Fail"
                        formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formEventAddUpdate_CancelButton.Text() = "Cancel"
                        If (formEventAddUpdate_AddUpdateButton.Text() = "Add") Then
                            Windows.Forms.MessageBox.Show("Problem adding Event to X10 Db.", "formEventAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        Else
                            Windows.Forms.MessageBox.Show("Problem modifying Event to X10 Db.", "formEventAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If
                    End If

                Else
                    formEventAddUpdate_StatusLabel.Text = "Fail"
                    formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formEventAddUpdate_CancelButton.Text() = "Cancel"
                    If (formEventAddUpdate_AddUpdateButton.Text() = "Add") Then
                        Windows.Forms.MessageBox.Show("Problem adding Event to X10 Db." & vbCrLf & strStatus, "formEventAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    Else
                        Windows.Forms.MessageBox.Show("Problem modifying Event to X10 Db." & vbCrLf & strStatus, "formEventAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If
                End If ' END - nsX10DbMethods.addUpdateEventToX10db()

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formEventAddUpdate_StatusLabel.Text = "Fail"
                formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            End If ' END - WasSomethingMissing

        Catch ex As Exception
            strStatus = "formEventAddUpdate_AddUpdateButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdate_AddUpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormScheduleAddUpdate = Nothing
            objDataRowViewSceneMacro = Nothing
            objX10DbEvent = Nothing
            Me.BringToFront()
        End Try

    End Sub ' END - formEventAddUpdate_AddUpdateButton_Click()

    Private Sub formEventAddUpdate_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdate_CancelButton.Click

        Me.Close()

    End Sub ' END - formEventAddUpdate_CancelButton_Click()

    Private Sub formEventAddUpdate_DeleteButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdate_DeleteButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = 0

        Dim objX10DbEvent As TrekkerPhotoArt.X10Include.X10DbEvent = Nothing

        Dim objFormCollection = System.Windows.Forms.Application.OpenForms
        Dim objFormScheduleAddUpdate As formScheduleAddUpdate = Nothing

        Try

            If (formEventAddUpdateIDLabelText.Text() = "") Then
                Windows.Forms.MessageBox.Show("Missing EventID", "formEventAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            Else

                If Windows.Forms.MessageBox.Show("Confirm removal of Event ID " & formEventAddUpdateIDLabelText.Text() & " ?", "Confirm", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Stop) = Windows.Forms.DialogResult.Yes Then

                    objX10DbEvent = New TrekkerPhotoArt.X10Include.X10DbEvent

                    objX10DbEvent.EventID = CType(formEventAddUpdateIDLabelText.Text(), Integer)
                    objX10DbEvent.ScheduleID = CType(formEventAddUpdateScheduleIDLabelText.Text(), Integer)
                    objX10DbEvent.SceneID = -1
                    objX10DbEvent.MacroInitiatorID = -1
                    objX10DbEvent.SDay = -1
                    objX10DbEvent.DOW = -1
                    objX10DbEvent.STime = -1
                    objX10DbEvent.ARise = -1
                    objX10DbEvent.ASet = -1
                    objX10DbEvent.TOD = -1
                    objX10DbEvent.Sec = -1

                    strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
                    strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

                    ' nsX10DbMethods.removeX10EventFromX10Db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbEvent As TrekkerPhotoArt.X10Include.X10DbEvent, ByRef intRowsAffected As Integer) As String
                    strStatus = nsX10DbMethods.removeX10EventFromX10Db(strConnectionString, strProvider, objX10DbEvent, intRowsAffected)
                    If (strStatus = "") Then

                        If (intRowsAffected > 0) Then

                            formEventAddUpdateIDLabelText.Text() = ""
                            formEventAddUpdate_AddUpdateButton.Text() = "Add"
                            formEventAddUpdate_StatusLabel.Text = "Successfully Deleted"
                            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Green
                            formEventAddUpdate_CancelButton.Text() = "Done"
                            formEventAddUpdate_DeleteButton.Visible = False


                            ' Refresh Events DataSet on Calling Form formScheduleAddUpdate if it's active.
                            For Each objFormScheduleAddUpdate In objFormCollection.OfType(Of formScheduleAddUpdate)

                                If (objFormScheduleAddUpdate.formScheduleAddUpdateIDLabelText.Text() = objX10DbEvent.ScheduleID.ToString()) Then

                                    objFormScheduleAddUpdate.formScheduleAddUpdate_BringToFrontLabel.Text() = "N"

                                    ' The row has been deleted.
                                    X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormScheduleAddUpdateEvents = -1
                                    X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormScheduleAddUpdateEvents = -1

                                    ' formScheduleAddUpdate_GetEventsDataSet() As String
                                    strStatus = objFormScheduleAddUpdate.formScheduleAddUpdate_GetEventsDataSet(objX10DbEvent.ScheduleID)
                                    If (strStatus = "") Then
                                        objFormScheduleAddUpdate.Activate()
                                    Else
                                        Windows.Forms.MessageBox.Show("formEventAddUpdate_DeleteButton_Click(): " & strStatus, "formEventAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                                    End If ' END - formScheduleAddUpdate_GetEventsDataSet()

                                    Exit For
                                End If

                            Next


                            Me.BringToFront()

                        Else
                            formEventAddUpdate_StatusLabel.Text = "Fail"
                            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formEventAddUpdate_CancelButton.Text() = "Cancel"
                            Windows.Forms.MessageBox.Show("Problem removing Event from X10 Db.", "formEventAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        End If ' END - RowsAffected

                    Else
                        formEventAddUpdate_StatusLabel.Text = "Fail"
                        formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formEventAddUpdate_CancelButton.Text() = "Cancel"
                        Windows.Forms.MessageBox.Show("Problem removing Event from X10 Db." & vbCrLf & strStatus, "formEventAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    End If ' END - nsX10DbMethods.addUpdateScheduleToX10db()

                End If ' END - Confirm removal of Schedule?

            End If ' END - Is there a ScheduleID?

        Catch ex As Exception
            strStatus = "formEventAddUpdate_DeleteButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdate_DeleteButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objFormCollection = Nothing
            objFormScheduleAddUpdate = Nothing
            objX10DbEvent = Nothing
            Me.BringToFront()
        End Try

    End Sub ' END - formEventAddUpdate_DeleteButton_Click()


    Private Sub formEventAddUpdateSceneRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateSceneRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateSceneRadioButton.Checked = True
            formEventAddUpdateMacroRadioButton.Checked = False

            formEventAddUpdateScenesMacrosLabel.Visible = True
            formEventAddUpdateScenesMacrosLabel.Text() = "Scene:"

            ' generateScenesComboBox(ByVal intSceneID As Integer) As String
            strStatus = generateScenesComboBox(-1)
            If (strStatus = "") Then
                formEventAddUpdateScenesMacrosComboBox.Visible = True
            Else
                formEventAddUpdateScenesMacrosComboBox.Visible = False
                Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateSceneRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formEventAddUpdate_StatusLabel.Text = "Fail"
                formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formEventAddUpdate_CancelButton.Text() = "Cancel"
            End If

        Catch ex As Exception
            strStatus = "formEventAddUpdateSceneRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateSceneRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateSceneRadioButton_Click()

    Private Sub formEventAddUpdateMacroRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateMacroRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateSceneRadioButton.Checked = False
            formEventAddUpdateMacroRadioButton.Checked = True

            formEventAddUpdateScenesMacrosLabel.Visible = True
            formEventAddUpdateScenesMacrosLabel.Text() = "Macro:"

            ' generateMacroInitiatorsComboBox(ByVal intMacroInitiatorID As Integer) As String
            strStatus = generateMacroInitiatorsComboBox(-1)
            If (strStatus = "") Then
                formEventAddUpdateScenesMacrosComboBox.Visible = True
            Else
                formEventAddUpdateScenesMacrosComboBox.Visible = False
                Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateMacroRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formEventAddUpdate_StatusLabel.Text = "Fail"
                formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
                formEventAddUpdate_CancelButton.Text() = "Cancel"
            End If

        Catch ex As Exception
            strStatus = "formEventAddUpdateMacroRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateMacroRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateMacroRadioButton_Click()

    Private Sub formEventAddUpdateSpecificTimeRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateSpecificTimeRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateSpecificTimeRadioButton.Checked = True
            formEventAddUpdateSpecificTimeDateTimePicker.Enabled = True
            'formEventAddUpdateSpecificTimeMaskedTextBox.Text = ""
            formEventAddUpdateSpecificTimeLabelFormat.Enabled = True

            formEventAddUpdateAfterSunriseByRadioButton.Checked = False
            formEventAddUpdateSunriseMinutesTextBox.Enabled = False
            'formEventAddUpdateSunriseMinutesTextBox.Text() = ""
            formEventAddUpdateSunriseMinutesLabel.Enabled = False

            formEventAddUpdateAfterSunsetByRadioButton.Checked = False
            formEventAddUpdateSunsetMinutesTextBox.Enabled = False
            'formEventAddUpdateSunsetMinutesTextBox.Text() = ""
            formEventAddUpdateSunsetMinutesLabel.Enabled = False

        Catch ex As Exception
            strStatus = "formEventAddUpdateSpecificTimeRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateSpecificTimeRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateSpecificTimeRadioButton_Click()

    Private Sub formEventAddUpdateAfterSunriseByRadioButtonn_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateAfterSunriseByRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateSpecificTimeRadioButton.Checked = False
            formEventAddUpdateSpecificTimeDateTimePicker.Enabled = False
            'formEventAddUpdateSpecificTimeMaskedTextBox.Text = ""
            formEventAddUpdateSpecificTimeLabelFormat.Enabled = False

            formEventAddUpdateAfterSunriseByRadioButton.Checked = True
            formEventAddUpdateSunriseMinutesTextBox.Enabled = True
            'formEventAddUpdateSunriseMinutesTextBox.Text() = ""
            formEventAddUpdateSunriseMinutesLabel.Enabled = True

            formEventAddUpdateAfterSunsetByRadioButton.Checked = False
            formEventAddUpdateSunsetMinutesTextBox.Enabled = False
            'formEventAddUpdateSunsetMinutesTextBox.Text() = ""
            formEventAddUpdateSunsetMinutesLabel.Enabled = False

        Catch ex As Exception
            strStatus = "formEventAddUpdateAfterSunriseByRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateAfterSunriseByRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateAfterSunriseByRadioButton_Click()

    Private Sub formEventAddUpdateAfterSunsetByRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateAfterSunsetByRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateSpecificTimeRadioButton.Checked = False
            formEventAddUpdateSpecificTimeDateTimePicker.Enabled = False
            'formEventAddUpdateSpecificTimeMaskedTextBox.Text = ""
            formEventAddUpdateSpecificTimeLabelFormat.Enabled = False

            formEventAddUpdateAfterSunriseByRadioButton.Checked = False
            formEventAddUpdateSunriseMinutesTextBox.Enabled = False
            'formEventAddUpdateSunriseMinutesTextBox.Text() = ""
            formEventAddUpdateSunriseMinutesLabel.Enabled = False

            formEventAddUpdateAfterSunsetByRadioButton.Checked = True
            formEventAddUpdateSunsetMinutesTextBox.Enabled = True
            'formEventAddUpdateSunsetMinutesTextBox.Text() = ""
            formEventAddUpdateSunsetMinutesLabel.Enabled = True

        Catch ex As Exception
            strStatus = "formEventAddUpdateAfterSunsetByRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateAfterSunsetByRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateAfterSunsetByRadioButton_Click()


    Private Sub formEventAddUpdateTodayRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateTodayRadioButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim objDateTimeNow As System.DateTime = System.DateTime.Now()

        Try
            formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = True
            formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = True
            formEventAddUpdateTodayRadioButton.Checked = True
            formEventAddUpdateTomorrowRadioButton.Checked = False
            formEventAddUpdateWeekendsRadioButton.Checked = False
            formEventAddUpdateWeekdaysRadioButton.Checked = False
            formEventAddUpdateEveryDayRadioButton.Checked = False
            formEventAddUpdateSelectedDayRadioButton.Checked = False
            formEventAddUpdateMonCheckBox.Visible = False
            formEventAddUpdateMonCheckBox.Enabled = False
            formEventAddUpdateMonCheckBox.Checked = False
            formEventAddUpdateTueCheckBox.Visible = False
            formEventAddUpdateTueCheckBox.Enabled = False
            formEventAddUpdateTueCheckBox.Checked = False
            formEventAddUpdateWedCheckBox.Visible = False
            formEventAddUpdateWedCheckBox.Enabled = False
            formEventAddUpdateWedCheckBox.Checked = False
            formEventAddUpdateThuCheckBox.Visible = False
            formEventAddUpdateThuCheckBox.Enabled = False
            formEventAddUpdateThuCheckBox.Checked = False
            formEventAddUpdateFriCheckBox.Visible = False
            formEventAddUpdateFriCheckBox.Enabled = False
            formEventAddUpdateFriCheckBox.Checked = False
            formEventAddUpdateSatCheckBox.Visible = False
            formEventAddUpdateSatCheckBox.Enabled = False
            formEventAddUpdateSatCheckBox.Checked = False
            formEventAddUpdateSunCheckBox.Visible = False
            formEventAddUpdateSunCheckBox.Enabled = False
            formEventAddUpdateSunCheckBox.Checked = False

        Catch ex As Exception
            strStatus = "formEventAddUpdateTodayRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateTodayRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDateTimeNow = Nothing
        End Try

    End Sub ' END - formEventAddUpdateTodayRadioButton_Click()

    Private Sub formEventAddUpdateTomorrowRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateTomorrowRadioButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""

        Dim objDateTimeNow As System.DateTime = System.DateTime.Now()

        Try

            formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = True
            formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = True
            formEventAddUpdateTodayRadioButton.Checked = False
            formEventAddUpdateTomorrowRadioButton.Checked = True
            formEventAddUpdateWeekendsRadioButton.Checked = False
            formEventAddUpdateWeekdaysRadioButton.Checked = False
            formEventAddUpdateEveryDayRadioButton.Checked = False
            formEventAddUpdateSelectedDayRadioButton.Checked = False
            formEventAddUpdateMonCheckBox.Visible = False
            formEventAddUpdateMonCheckBox.Enabled = False
            formEventAddUpdateMonCheckBox.Checked = False
            formEventAddUpdateTueCheckBox.Visible = False
            formEventAddUpdateTueCheckBox.Enabled = False
            formEventAddUpdateTueCheckBox.Checked = False
            formEventAddUpdateWedCheckBox.Visible = False
            formEventAddUpdateWedCheckBox.Enabled = False
            formEventAddUpdateWedCheckBox.Checked = False
            formEventAddUpdateThuCheckBox.Visible = False
            formEventAddUpdateThuCheckBox.Enabled = False
            formEventAddUpdateThuCheckBox.Checked = False
            formEventAddUpdateFriCheckBox.Visible = False
            formEventAddUpdateFriCheckBox.Enabled = False
            formEventAddUpdateFriCheckBox.Checked = False
            formEventAddUpdateSatCheckBox.Visible = False
            formEventAddUpdateSatCheckBox.Enabled = False
            formEventAddUpdateSatCheckBox.Checked = False
            formEventAddUpdateSunCheckBox.Visible = False
            formEventAddUpdateSunCheckBox.Enabled = False
            formEventAddUpdateSunCheckBox.Checked = False

        Catch ex As Exception
            strStatus = "formEventAddUpdateTomorrowRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateTomorrowRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        Finally
            objDateTimeNow = Nothing
        End Try

    End Sub ' END - formEventAddUpdateTomorrowRadioButton_Click()

    Private Sub formEventAddUpdateWeekendsRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateWeekendsRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = False
            formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = False
            formEventAddUpdateTodayRadioButton.Checked = False
            formEventAddUpdateTomorrowRadioButton.Checked = False
            formEventAddUpdateWeekendsRadioButton.Checked = True
            formEventAddUpdateWeekdaysRadioButton.Checked = False
            formEventAddUpdateEveryDayRadioButton.Checked = False
            formEventAddUpdateSelectedDayRadioButton.Checked = False
            formEventAddUpdateMonCheckBox.Visible = True
            formEventAddUpdateMonCheckBox.Enabled = False
            formEventAddUpdateMonCheckBox.Checked = False
            formEventAddUpdateTueCheckBox.Visible = True
            formEventAddUpdateTueCheckBox.Enabled = False
            formEventAddUpdateTueCheckBox.Checked = False
            formEventAddUpdateWedCheckBox.Visible = True
            formEventAddUpdateWedCheckBox.Enabled = False
            formEventAddUpdateWedCheckBox.Checked = False
            formEventAddUpdateThuCheckBox.Visible = True
            formEventAddUpdateThuCheckBox.Enabled = False
            formEventAddUpdateThuCheckBox.Checked = False
            formEventAddUpdateFriCheckBox.Visible = True
            formEventAddUpdateFriCheckBox.Enabled = False
            formEventAddUpdateFriCheckBox.Checked = False
            formEventAddUpdateSatCheckBox.Visible = True
            formEventAddUpdateSatCheckBox.Enabled = False
            formEventAddUpdateSatCheckBox.Checked = True
            formEventAddUpdateSunCheckBox.Visible = True
            formEventAddUpdateSunCheckBox.Enabled = False
            formEventAddUpdateSunCheckBox.Checked = True

        Catch ex As Exception
            strStatus = "formEventAddUpdateWeekendsRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateWeekendsRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateWeekendsRadioButton_Click()

    Private Sub formEventAddUpdateWeekdaysRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateWeekdaysRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = False
            formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = False
            formEventAddUpdateTodayRadioButton.Checked = False
            formEventAddUpdateTomorrowRadioButton.Checked = False
            formEventAddUpdateWeekendsRadioButton.Checked = False
            formEventAddUpdateWeekdaysRadioButton.Checked = True
            formEventAddUpdateEveryDayRadioButton.Checked = False
            formEventAddUpdateSelectedDayRadioButton.Checked = False
            formEventAddUpdateMonCheckBox.Visible = True
            formEventAddUpdateMonCheckBox.Enabled = False
            formEventAddUpdateMonCheckBox.Checked = True
            formEventAddUpdateTueCheckBox.Visible = True
            formEventAddUpdateTueCheckBox.Enabled = False
            formEventAddUpdateTueCheckBox.Checked = True
            formEventAddUpdateWedCheckBox.Visible = True
            formEventAddUpdateWedCheckBox.Enabled = False
            formEventAddUpdateWedCheckBox.Checked = True
            formEventAddUpdateThuCheckBox.Visible = True
            formEventAddUpdateThuCheckBox.Enabled = False
            formEventAddUpdateThuCheckBox.Checked = True
            formEventAddUpdateFriCheckBox.Visible = True
            formEventAddUpdateFriCheckBox.Enabled = False
            formEventAddUpdateFriCheckBox.Checked = True
            formEventAddUpdateSatCheckBox.Visible = True
            formEventAddUpdateSatCheckBox.Enabled = False
            formEventAddUpdateSatCheckBox.Checked = False
            formEventAddUpdateSunCheckBox.Visible = True
            formEventAddUpdateSunCheckBox.Enabled = False
            formEventAddUpdateSunCheckBox.Checked = False

        Catch ex As Exception
            strStatus = "formEventAddUpdateWeekdaysRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateWeekdaysRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateWeekdaysRadioButton_Click()

    Private Sub formEventAddUpdateEveryDayRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateEveryDayRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = False
            formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = False
            formEventAddUpdateTodayRadioButton.Checked = False
            formEventAddUpdateTomorrowRadioButton.Checked = False
            formEventAddUpdateWeekendsRadioButton.Checked = False
            formEventAddUpdateWeekdaysRadioButton.Checked = False
            formEventAddUpdateEveryDayRadioButton.Checked = True
            formEventAddUpdateSelectedDayRadioButton.Checked = False
            formEventAddUpdateMonCheckBox.Visible = True
            formEventAddUpdateMonCheckBox.Enabled = False
            formEventAddUpdateMonCheckBox.Checked = True
            formEventAddUpdateTueCheckBox.Visible = True
            formEventAddUpdateTueCheckBox.Enabled = False
            formEventAddUpdateTueCheckBox.Checked = True
            formEventAddUpdateWedCheckBox.Visible = True
            formEventAddUpdateWedCheckBox.Enabled = False
            formEventAddUpdateWedCheckBox.Checked = True
            formEventAddUpdateThuCheckBox.Visible = True
            formEventAddUpdateThuCheckBox.Enabled = False
            formEventAddUpdateThuCheckBox.Checked = True
            formEventAddUpdateFriCheckBox.Visible = True
            formEventAddUpdateFriCheckBox.Enabled = False
            formEventAddUpdateFriCheckBox.Checked = True
            formEventAddUpdateSatCheckBox.Visible = True
            formEventAddUpdateSatCheckBox.Enabled = False
            formEventAddUpdateSatCheckBox.Checked = True
            formEventAddUpdateSunCheckBox.Visible = True
            formEventAddUpdateSunCheckBox.Enabled = False
            formEventAddUpdateSunCheckBox.Checked = True

        Catch ex As Exception
            strStatus = "formEventAddUpdateEveryDayRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateEveryDayRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateEveryDayRadioButton_Click()

    Private Sub formEventAddUpdateSelectedDayRadioButton_Click(sender As System.Object, e As System.EventArgs) Handles formEventAddUpdateSelectedDayRadioButton.Click
        Dim strStatus As String = ""

        Try

            formEventAddUpdateDayDeterminedMessageLine1LabelText.Visible = False
            formEventAddUpdateDayDeterminedMessageLine2LabelText.Visible = False
            formEventAddUpdateTodayRadioButton.Checked = False
            formEventAddUpdateTomorrowRadioButton.Checked = False
            formEventAddUpdateWeekendsRadioButton.Checked = False
            formEventAddUpdateWeekdaysRadioButton.Checked = False
            formEventAddUpdateEveryDayRadioButton.Checked = False
            formEventAddUpdateSelectedDayRadioButton.Checked = True
            formEventAddUpdateMonCheckBox.Visible = True
            formEventAddUpdateMonCheckBox.Enabled = True
            formEventAddUpdateMonCheckBox.Checked = False
            formEventAddUpdateTueCheckBox.Visible = True
            formEventAddUpdateTueCheckBox.Enabled = True
            formEventAddUpdateTueCheckBox.Checked = False
            formEventAddUpdateWedCheckBox.Visible = True
            formEventAddUpdateWedCheckBox.Enabled = True
            formEventAddUpdateWedCheckBox.Checked = False
            formEventAddUpdateThuCheckBox.Visible = True
            formEventAddUpdateThuCheckBox.Enabled = True
            formEventAddUpdateThuCheckBox.Checked = False
            formEventAddUpdateFriCheckBox.Visible = True
            formEventAddUpdateFriCheckBox.Enabled = True
            formEventAddUpdateFriCheckBox.Checked = False
            formEventAddUpdateSatCheckBox.Visible = True
            formEventAddUpdateSatCheckBox.Enabled = True
            formEventAddUpdateSatCheckBox.Checked = False
            formEventAddUpdateSunCheckBox.Visible = True
            formEventAddUpdateSunCheckBox.Enabled = True
            formEventAddUpdateSunCheckBox.Checked = False

        Catch ex As Exception
            strStatus = "formEventAddUpdateSelectedDayRadioButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formEventAddUpdateSelectedDayRadioButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formEventAddUpdate_StatusLabel.Text = "Fail"
            formEventAddUpdate_StatusLabel.ForeColor = System.Drawing.Color.Red
            formEventAddUpdate_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formEventAddUpdateSelectedDayRadioButton_Click()


#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formEventAddUpdate_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationEventAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formEventAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(445, 565)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationEventAddUpdate Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationEventAddUpdate.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationEventAddUpdate.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formEventAddUpdate_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formEventAddUpdate_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formEventAddUpdate_FormRestore()

    '=====================================================================================
    ' Function formEventAddUpdate_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationEventAddUpdate" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formEventAddUpdate_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationEventAddUpdate = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationEventAddUpdate = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formEventAddUpdate_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formEventAddUpdate_FormSave(): Exception: " & ex.Message
            End If

        End Try

        Return strStatus

    End Function ' END - formEventAddUpdate_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class