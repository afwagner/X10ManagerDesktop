﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formModuleExport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formModuleExport))
        Me.formModuleExport_BrowseButton = New System.Windows.Forms.Button()
        Me.formModuleExportExportFileLabelExample = New System.Windows.Forms.Label()
        Me.formModuleExportExportFileTextBox = New System.Windows.Forms.TextBox()
        Me.formModuleExportExportFileLabel = New System.Windows.Forms.Label()
        Me.formModuleExport_StatusLabel = New System.Windows.Forms.Label()
        Me.formModuleExport_ExportButton = New System.Windows.Forms.Button()
        Me.formModuleExport_CancelButton = New System.Windows.Forms.Button()
        Me.formModuleExport_SaveFileDialog = New System.Windows.Forms.SaveFileDialog()
        Me.formModuleExportFileLabel03 = New System.Windows.Forms.Label()
        Me.formModuleExportFileLabel01 = New System.Windows.Forms.Label()
        Me.formModuleExportFileLabel02 = New System.Windows.Forms.Label()
        Me.formModuleExportFileLabel08 = New System.Windows.Forms.Label()
        Me.formModuleExportFileLabel07 = New System.Windows.Forms.Label()
        Me.formModuleExportFileLabel06 = New System.Windows.Forms.Label()
        Me.formModuleExportFileLabel04 = New System.Windows.Forms.Label()
        Me.formModuleExportFileLabel05 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'formModuleExport_BrowseButton
        '
        Me.formModuleExport_BrowseButton.Location = New System.Drawing.Point(22, 194)
        Me.formModuleExport_BrowseButton.Name = "formModuleExport_BrowseButton"
        Me.formModuleExport_BrowseButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleExport_BrowseButton.TabIndex = 28
        Me.formModuleExport_BrowseButton.Text = "Browse"
        Me.formModuleExport_BrowseButton.UseVisualStyleBackColor = True
        '
        'formModuleExportExportFileLabelExample
        '
        Me.formModuleExportExportFileLabelExample.AutoSize = True
        Me.formModuleExportExportFileLabelExample.Location = New System.Drawing.Point(119, 199)
        Me.formModuleExportExportFileLabelExample.Name = "formModuleExportExportFileLabelExample"
        Me.formModuleExportExportFileLabelExample.Size = New System.Drawing.Size(182, 13)
        Me.formModuleExportExportFileLabelExample.TabIndex = 27
        Me.formModuleExportExportFileLabelExample.Text = "ex: Documents\X10Db_Modules.csv"
        '
        'formModuleExportExportFileTextBox
        '
        Me.formModuleExportExportFileTextBox.Location = New System.Drawing.Point(106, 175)
        Me.formModuleExportExportFileTextBox.Name = "formModuleExportExportFileTextBox"
        Me.formModuleExportExportFileTextBox.Size = New System.Drawing.Size(594, 20)
        Me.formModuleExportExportFileTextBox.TabIndex = 26
        '
        'formModuleExportExportFileLabel
        '
        Me.formModuleExportExportFileLabel.AutoSize = True
        Me.formModuleExportExportFileLabel.Location = New System.Drawing.Point(39, 178)
        Me.formModuleExportExportFileLabel.Name = "formModuleExportExportFileLabel"
        Me.formModuleExportExportFileLabel.Size = New System.Drawing.Size(59, 13)
        Me.formModuleExportExportFileLabel.TabIndex = 25
        Me.formModuleExportExportFileLabel.Text = "Export File:"
        '
        'formModuleExport_StatusLabel
        '
        Me.formModuleExport_StatusLabel.AutoSize = True
        Me.formModuleExport_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formModuleExport_StatusLabel.Location = New System.Drawing.Point(103, 259)
        Me.formModuleExport_StatusLabel.Name = "formModuleExport_StatusLabel"
        Me.formModuleExport_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formModuleExport_StatusLabel.TabIndex = 24
        Me.formModuleExport_StatusLabel.Text = "Success | Fail"
        '
        'formModuleExport_ExportButton
        '
        Me.formModuleExport_ExportButton.Location = New System.Drawing.Point(22, 256)
        Me.formModuleExport_ExportButton.Name = "formModuleExport_ExportButton"
        Me.formModuleExport_ExportButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleExport_ExportButton.TabIndex = 23
        Me.formModuleExport_ExportButton.Text = "Export"
        Me.formModuleExport_ExportButton.UseVisualStyleBackColor = True
        '
        'formModuleExport_CancelButton
        '
        Me.formModuleExport_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formModuleExport_CancelButton.Location = New System.Drawing.Point(625, 253)
        Me.formModuleExport_CancelButton.Name = "formModuleExport_CancelButton"
        Me.formModuleExport_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formModuleExport_CancelButton.TabIndex = 22
        Me.formModuleExport_CancelButton.Text = "Cancel"
        Me.formModuleExport_CancelButton.UseMnemonic = False
        Me.formModuleExport_CancelButton.UseVisualStyleBackColor = True
        '
        'formModuleExport_SaveFileDialog
        '
        Me.formModuleExport_SaveFileDialog.FileName = "X10Db_Modules.csv"
        '
        'formModuleExportFileLabel03
        '
        Me.formModuleExportFileLabel03.AutoSize = True
        Me.formModuleExportFileLabel03.Location = New System.Drawing.Point(27, 44)
        Me.formModuleExportFileLabel03.Name = "formModuleExportFileLabel03"
        Me.formModuleExportFileLabel03.Size = New System.Drawing.Size(300, 13)
        Me.formModuleExportFileLabel03.TabIndex = 37
        Me.formModuleExportFileLabel03.Text = """.csv"" Extension for file name.  Example: X10Db_Modules.csv"
        '
        'formModuleExportFileLabel01
        '
        Me.formModuleExportFileLabel01.AutoSize = True
        Me.formModuleExportFileLabel01.Location = New System.Drawing.Point(12, 18)
        Me.formModuleExportFileLabel01.Name = "formModuleExportFileLabel01"
        Me.formModuleExportFileLabel01.Size = New System.Drawing.Size(118, 13)
        Me.formModuleExportFileLabel01.TabIndex = 36
        Me.formModuleExportFileLabel01.Text = "CSV Export File Format:"
        '
        'formModuleExportFileLabel02
        '
        Me.formModuleExportFileLabel02.AutoSize = True
        Me.formModuleExportFileLabel02.Location = New System.Drawing.Point(27, 31)
        Me.formModuleExportFileLabel02.Name = "formModuleExportFileLabel02"
        Me.formModuleExportFileLabel02.Size = New System.Drawing.Size(237, 13)
        Me.formModuleExportFileLabel02.TabIndex = 35
        Me.formModuleExportFileLabel02.Text = "Comma Delimited, each Cell with Double Quotes."
        '
        'formModuleExportFileLabel08
        '
        Me.formModuleExportFileLabel08.AutoSize = True
        Me.formModuleExportFileLabel08.Location = New System.Drawing.Point(12, 134)
        Me.formModuleExportFileLabel08.Name = "formModuleExportFileLabel08"
        Me.formModuleExportFileLabel08.Size = New System.Drawing.Size(526, 13)
        Me.formModuleExportFileLabel08.TabIndex = 34
        Me.formModuleExportFileLabel08.Text = """Test CP290"",""J16"",""Den Test Dimmer Module"",""Dimmer LED Test Light in Dimmer Modu" &
    "le"",""Y"",""Y"",""Y"",""N"""
        '
        'formModuleExportFileLabel07
        '
        Me.formModuleExportFileLabel07.AutoSize = True
        Me.formModuleExportFileLabel07.Location = New System.Drawing.Point(12, 121)
        Me.formModuleExportFileLabel07.Name = "formModuleExportFileLabel07"
        Me.formModuleExportFileLabel07.Size = New System.Drawing.Size(394, 13)
        Me.formModuleExportFileLabel07.TabIndex = 33
        Me.formModuleExportFileLabel07.Text = """House Lighting CP290"",""J1"",""OutGar"",""Outside Garage Lights"",""Y"",""N"",""Y"",""N"""
        '
        'formModuleExportFileLabel06
        '
        Me.formModuleExportFileLabel06.AutoSize = True
        Me.formModuleExportFileLabel06.Location = New System.Drawing.Point(12, 108)
        Me.formModuleExportFileLabel06.Name = "formModuleExportFileLabel06"
        Me.formModuleExportFileLabel06.Size = New System.Drawing.Size(106, 13)
        Me.formModuleExportFileLabel06.TabIndex = 32
        Me.formModuleExportFileLabel06.Text = "Data Row Examples:"
        '
        'formModuleExportFileLabel04
        '
        Me.formModuleExportFileLabel04.AutoSize = True
        Me.formModuleExportFileLabel04.Location = New System.Drawing.Point(13, 71)
        Me.formModuleExportFileLabel04.Name = "formModuleExportFileLabel04"
        Me.formModuleExportFileLabel04.Size = New System.Drawing.Size(70, 13)
        Me.formModuleExportFileLabel04.TabIndex = 31
        Me.formModuleExportFileLabel04.Text = "Header Row:"
        '
        'formModuleExportFileLabel05
        '
        Me.formModuleExportFileLabel05.AutoSize = True
        Me.formModuleExportFileLabel05.Location = New System.Drawing.Point(13, 84)
        Me.formModuleExportFileLabel05.Name = "formModuleExportFileLabel05"
        Me.formModuleExportFileLabel05.Size = New System.Drawing.Size(687, 13)
        Me.formModuleExportFileLabel05.TabIndex = 30
        Me.formModuleExportFileLabel05.Text = """ControllerName"",""UnitCode"",""UnitName"",""UnitDescription"",""UnitEnabledYN"",""UnitDim" &
    "merYN"",""UnitLightingYN"",""UnitExtendedCommandsYN"""
        '
        'formModuleExport
        '
        Me.AcceptButton = Me.formModuleExport_ExportButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formModuleExport_CancelButton
        Me.ClientSize = New System.Drawing.Size(715, 292)
        Me.Controls.Add(Me.formModuleExportFileLabel03)
        Me.Controls.Add(Me.formModuleExportFileLabel01)
        Me.Controls.Add(Me.formModuleExportFileLabel02)
        Me.Controls.Add(Me.formModuleExportFileLabel08)
        Me.Controls.Add(Me.formModuleExportFileLabel07)
        Me.Controls.Add(Me.formModuleExportFileLabel06)
        Me.Controls.Add(Me.formModuleExportFileLabel04)
        Me.Controls.Add(Me.formModuleExportFileLabel05)
        Me.Controls.Add(Me.formModuleExport_BrowseButton)
        Me.Controls.Add(Me.formModuleExportExportFileLabelExample)
        Me.Controls.Add(Me.formModuleExportExportFileTextBox)
        Me.Controls.Add(Me.formModuleExportExportFileLabel)
        Me.Controls.Add(Me.formModuleExport_StatusLabel)
        Me.Controls.Add(Me.formModuleExport_ExportButton)
        Me.Controls.Add(Me.formModuleExport_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formModuleExport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Module Export"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formModuleExport_BrowseButton As Button
    Friend WithEvents formModuleExportExportFileLabelExample As Label
    Friend WithEvents formModuleExportExportFileTextBox As TextBox
    Friend WithEvents formModuleExportExportFileLabel As Label
    Friend WithEvents formModuleExport_StatusLabel As Label
    Friend WithEvents formModuleExport_ExportButton As Button
    Friend WithEvents formModuleExport_CancelButton As Button
    Friend WithEvents formModuleExport_SaveFileDialog As SaveFileDialog
    Friend WithEvents formModuleExportFileLabel03 As Label
    Friend WithEvents formModuleExportFileLabel01 As Label
    Friend WithEvents formModuleExportFileLabel02 As Label
    Friend WithEvents formModuleExportFileLabel08 As Label
    Friend WithEvents formModuleExportFileLabel07 As Label
    Friend WithEvents formModuleExportFileLabel06 As Label
    Friend WithEvents formModuleExportFileLabel04 As Label
    Friend WithEvents formModuleExportFileLabel05 As Label
End Class
