﻿Imports System.Configuration

' Name: formFileSettings.vb
' By: Alan Wagner
' Date: March 2020

Public Class formFileSettings

#Region "X10ManagerDesktopFileSettingsMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim strInstallerAssemblyLocation As String = ""
        Dim strInstallerAssemblyLocationDrive As String = ""
        Dim strInstallerAssemblyLocationExecutable As String = ""
        Dim bInstallerAssemblyLocationFound As Boolean = False

        Try

            Me.BringToFront()

            formFileSettingsX10DbConnectionStringTextBox.Text() = ""
            formFileSettingsLongitudeTextBox.Text() = ""
            formFileSettingsLatitudeTextBox.Text() = ""
            formFileSettingsBackupDirectoryPathTextBox.Text() = ""

            formFileSettings_UpdateButton.Visible = False

            formFileSettings_StatusLabel.Text = ""
            formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Black
            formFileSettings_CancelButton.Text() = "Cancel"
            formFileSettings_CancelButton.Select()

            strTryStep = "formFileSettings_FormRestore"
            ' formFileSettings_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formFileSettings_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                strTryStep = "X10DbConnectionString"
                If (Not My.Settings.X10DbConnectionString Is Nothing) Then
                    formFileSettingsX10DbConnectionStringTextBox.Text() = My.Settings.X10DbConnectionString.ToString()
                Else
                    strStatus = "X10ManagerDesktop.exe.config is missing X10DbConnectionString Connection String setting."
                End If ' END - X10DbConnectionString

                strTryStep = "verifyProgramExit"
                Select Case X10ManagerDesktop.verifyProgramExit
                    Case 0
                        formFileSettingsVerifyOnProgramExitCheckBox.Checked = False
                    Case 1
                        formFileSettingsVerifyOnProgramExitCheckBox.Checked = True
                End Select

                strTryStep = "showAdvancedInformation"
                Select Case X10ManagerDesktop.showAdvancedInformation
                    Case 0
                        formFileSettingsShowAdvancedInformationCheckBox.Checked = False
                    Case 1
                        formFileSettingsShowAdvancedInformationCheckBox.Checked = True
                End Select

                strTryStep = "longitude"
                If (Not X10ManagerDesktop.longitude Is Nothing) Then
                    formFileSettingsLongitudeTextBox.Text() = X10ManagerDesktop.longitude.ToString()
                Else
                    If (strStatus = "") Then
                        strStatus = "X10ManagerDesktop is missing longitude Global/Public setting."
                    Else
                        strStatus &= vbCrLf & "X10ManagerDesktop is missing longitude Global/Public setting."
                    End If
                End If ' END - longitude

                strTryStep = "latitude"
                If (Not X10ManagerDesktop.latitude Is Nothing) Then
                    formFileSettingsLatitudeTextBox.Text() = X10ManagerDesktop.latitude.ToString()
                Else
                    If (strStatus = "") Then
                        strStatus = "X10ManagerDesktop is missing latitude Global/Public setting."
                    Else
                        strStatus &= vbCrLf & "X10ManagerDesktop is missing latitude Global/Public setting."
                    End If
                End If 'END - latitude

                strTryStep = "backupDirectoryPath"
                If (Not X10ManagerDesktop.backupDirectoryPath Is Nothing) Then
                    formFileSettingsBackupDirectoryPathTextBox.Text() = X10ManagerDesktop.backupDirectoryPath.ToString()
                Else
                    If (strStatus = "") Then
                        strStatus = "X10ManagerDesktop is missing backupDirectoryPath Global/Public setting."
                    Else
                        strStatus &= vbCrLf & "X10ManagerDesktop is missing backupDirectoryPath Global/Public setting."
                    End If
                End If 'END - backupDirectoryPath

                strTryStep = "nsX10DbMethods.getInstallerAssemblyLocation"
                ' nsX10DbMethods.getInstallerAssemblyLocation(ByVal strInstallerAssemblyString As String, ByRef strInstallerAssemblyLocation As String, ByRef strInstallerAssemblyLocationDrive As String, ByRef strInstallerAssemblyLocationExecutable As String, ByRef bInstallerAssemblyLocationFound As Boolean) As String
                strStatus = nsX10DbMethods.getInstallerAssemblyLocation("trekkerphotoart.com|X10ManagerDesktop_Installer|X10ManagerDesktop.exe", strInstallerAssemblyLocation, strInstallerAssemblyLocationDrive, strInstallerAssemblyLocationExecutable, bInstallerAssemblyLocationFound)
                If (strStatus = "") Then

                    If Not bInstallerAssemblyLocationFound Then
                        strInstallerAssemblyLocationDrive = "C:"
                    End If

                    strTryStep = "formFileSettingsBackupDirectoryPathLabelExample"
                    ' X10Include.vb
                    '   TrekkerPhotoArt.X10Include.X10ManagerDirectory = "X10Manager"
                    '   TrekkerPhotoArt.X10Include.X10DbBackupDirectory = "X10DbBackup"
                    ' ex: "ex: C:\X10Manager\X10DbBackup\"
                    formFileSettingsBackupDirectoryPathLabelExample.Text() = "ex: " & strInstallerAssemblyLocationDrive & "\" & nsX10DbMethods.getX10ManagerDirectory() & "\" & nsX10DbMethods.getX10DbBackupDirectory() & "\"

                    strTryStep = "formFileSettingsX10DbConnectionStringExampleLabel"
                    ' X10Include.vb
                    '   TrekkerPhotoArt.X10Include.X10ManagerDirectory = "X10Manager"
                    ' X10Include.vb
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerDbProviderFactory As String = "System.Data.OleDb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDb As String = "X10Db.accdb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDbProvider = "Microsoft.ACE.OLEDB.12.0"
                    '   ex: "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\X10Manager\X10Db.accdb;"
                    ' X10Include.vb
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerDbProviderFactory As String = "System.Data.OleDb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDb As String = "X10Db.mdb"
                    '   TrekkerPhotoArt.X10Include.X10DbMethods.X10ManagerAccessDbProvider = "Microsoft.Jet.OLEDB.4.0"
                    '   ex: "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\X10Manager\X10Db.mdb;"
                    formFileSettingsX10DbConnectionStringExampleLabel.Text() = "ex: Provider=" & nsX10DbMethods.getX10ManagerAccessDbProvider() & ";Data Source=""" & strInstallerAssemblyLocationDrive & "\" & nsX10DbMethods.getX10ManagerDirectory() & "\" & nsX10DbMethods.getX10ManagerAccessDb & """"

                Else
                    Windows.Forms.MessageBox.Show(strStatus, "Main(formFileSettings)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                    formFileSettings_UpdateButton.Visible = False
                    formFileSettings_StatusLabel.Text = "Fail"
                    formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                    formFileSettings_CancelButton.Text() = "Cancel"
                End If ' END - nsX10DbMethods.getInstallerAssemblyLocation()

                strTryStep = "X10ManagerDesktop.formFileSettingsUpdatedFlag"
                    If X10ManagerDesktop.formFileSettingsUpdatedFlag Then
                        Windows.Forms.MessageBox.Show("X10ManagerDesktop will need restarting to allow previous setting changes to be seen before new setting changes can be made.", "Main(formFileSettings)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formFileSettings_UpdateButton.Visible = False
                        formFileSettings_StatusLabel.Text = "Fail"
                        formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formFileSettings_CancelButton.Text() = "Cancel"
                    Else
                        formFileSettings_UpdateButton.Visible = True
                    End If

                    If (strStatus <> "") Then
                        Windows.Forms.MessageBox.Show(strStatus, "Main(formFileSettings)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formFileSettings_UpdateButton.Visible = False
                        formFileSettings_StatusLabel.Text = "Fail"
                        formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formFileSettings_CancelButton.Text() = "Cancel"
                    End If

                Else
                    Windows.Forms.MessageBox.Show("Main(formFileSettings): " & strStatus, "Main(formFileSettings)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formFileSettings_UpdateButton.Visible = False
                formFileSettings_StatusLabel.Text = "Fail"
                formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                formFileSettings_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdate_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formFileSettings): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formFileSettings)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formFileSettings_UpdateButton.Visible = False
            formFileSettings_StatusLabel.Text = "Fail"
            formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
            formFileSettings_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END Sub - Main(formFileSettings)

    Private Sub formFileSettings_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formMain_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formFileSettings_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formFileSettings_FormClosingHandler(): " & strStatus, "formFileSettings_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formFileSettings_FormSave()

    End Sub ' END Sub - formFileSettings_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopFileSettingsMainMethods

#Region "formMethods"

    '=====================================================================================
    ' Function setConnectionStringXML()
    ' Alan Wagner
    '
    ' strConfigurationName
    ' ex: "TrekkerPhotoArt.My.MySettings.X10DbConnectionString"
    '
    ' strConfigurationConnectionString
    ' ex: "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=&quot;C:\X10ManagerDesktop\X10Db.mdb&quot;"
    '
    ' <?xml version="1.0" encoding="utf-8"?>
    ' <configuration>
    '  <connectionStrings>
    '   <add name="TrekkerPhotoArt.My.MySettings.X10DbConnectionString"
    '     connectionString="Provider=Microsoft.Jet.OLEDB.4.0;Data Source=&quot;C:\X10ManagerDesktop\X10Db.mdb&quot;"
    '     providerName="System.Data.OleDb" />
    '  </connectionStrings>
    ' </configuration>
    ' 
    Private Function setConnectionStringXML(ByVal strConfigurationName As String, ByVal strConfigurationConnectionString As String) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConfigurationFile As String = ""

        Try

            strTryStep = "ConfigurationFile"
            ' System.Windows.Forms.Application.ExecutablePath.ToString()
            '   At Project runtime: "D:\X10Manager\X10ManagerDesktopProject\X10ManagerDesktop\X10ManagerDesktop\bin\x86\Debug\X10ManagerDesktop.exe"
            '   At Installed runtime: "C:\Program Files (x86)\trekkerphotoart.com\X10ManagerDesktop_Installer\X10ManagerDesktop.exe"
            ' ex: "C:\Program Files (x86)\trekkerphotoart.com\X10ManagerDesktop_Installer\X10ManagerDesktop.exe.config"
            strConfigurationFile = System.Windows.Forms.Application.ExecutablePath.ToString().Replace(".EXE", ".exe") & ".config"

            ' setConnectionStringXML(ByVal strConfigurationFile As String, ByVal strConfigurationName As String, ByVal strConfigurationConnectionString As String) As String
            strError = nsX10DbMethods.setConnectionStringXML(strConfigurationFile, strConfigurationName, strConfigurationConnectionString)
            If (strError <> "") Then
                strStatus = "setConnectionStringXML(): " & strError
            End If

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "setConnectionStringXML(" & strTryStep & "): Name=" & strConfigurationName & " ConnectionString=" & strConfigurationConnectionString & ": Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "setConnectionStringXML(" & strTryStep & "): Name=" & strConfigurationName & " ConnectionString=" & strConfigurationConnectionString & ": Exception: " & ex.Message
            End If
        End Try

        Return strStatus

    End Function ' END - setConnectionStringXML()

    '=====================================================================================
    ' Function setAppSettingXML()
    ' Alan Wagner
    '
    ' <?xml version="1.0" encoding="utf-8"?>
    ' <configuration>
    '  <applicationSettings>
    '   <TrekkerPhotoArt.My.MySettings>
    '    <setting name="longitude" serializeAs="String">
    '     <value>-88.201175</value>
    '    </setting>
    '    <setting name="latitude" serializeAs="String">
    '     <value>43.031488</value>
    '    </setting>
    '   </TrekkerPhotoArt.My.MySettings>
    '  </applicationSettings>
    ' </configuration>
    ' 
    Private Function setAppSettingXML(ByVal strName As String, ByVal strValue As String) As String
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim strConfigurationFile As String = ""
        Dim objXMLDocument As System.Xml.XmlDocument = Nothing
        Dim objNodes As System.Xml.XmlNodeList

        Try

            strTryStep = "ConfigurationFile"
            ' System.Windows.Forms.Application.ExecutablePath.ToString()
            '   At Project runtime: "D:\Lighthou\X10Manager\X10ManagerDesktopProject\X10ManagerDesktop\X10ManagerDesktop\bin\x86\Debug\X10ManagerDesktop.EXE"
            '   At Installed runtime: "C:\Program Files (x86)\trekkerphotoart.com\X10ManagerDesktop_Installer\X10ManagerDesktop.EXE"
            ' ex: "C:\Program Files (x86)\trekkerphotoart.com\X10ManagerDesktop_Installer\X10ManagerDesktop.exe.config"
            strConfigurationFile = System.Windows.Forms.Application.ExecutablePath.ToString().Replace(".EXE", ".exe") & ".config"

            strTryStep = "NewObjectXMLDocument"
            objXMLDocument = New System.Xml.XmlDocument

            strTryStep = "Load"
            ' Connect to Application Configuration.
            '
            ' VirtualStore is used when the user doesn't have permissions to write into the requested program folder.
            ' So the simpliest solution Is to give your users permission, either to the program folder or run the Program as an Administrator.
            '
            ' At Project runtime: D:\Lighthou\X10Manager\X10ManagerDesktopProject\X10ManagerDesktop\X10ManagerDesktop\bin\x86\Debug\X10ManagerDesktop.exe.config
            ' At Installed runtime: C:\Users\afwagner\AppData\Local\VirtualStore\Program Files (x86)\trekkerphotoart.com\X10ManagerDesktop_Installer\X10ManagerDesktop.exe.config
            'objXMLDocument.Load(System.AppDomain.CurrentDomain.SetupInformation.ConfigurationFile)
            '
            ' At Project runtime: D:\Lighthou\X10Manager\X10ManagerDesktopProject\X10ManagerDesktop\X10ManagerDesktop\bin\x86\Debug\X10ManagerDesktop.exe.config
            ' At Installed runtime: C:\Program Files (x86)\trekkerphotoart.com\X10ManagerDesktop_Installer\X10ManagerDesktop.exe.config
            ' Finds "X10ManagerDesktop.exe.config"
            objXMLDocument.Load(strConfigurationFile)

            strTryStep = "SelectNodes"
            objNodes = CType(objXMLDocument.SelectNodes("/configuration/applicationSettings/TrekkerPhotoArt.My.MySettings/setting[@name=""" & strName & """]/value"), System.Xml.XmlNodeList)

            strTryStep = "InnerText"
            objNodes(0).InnerText = strValue

            strTryStep = "Save"
            ' Save the configuration file.
            'objXMLDocument.Save(System.AppDomain.CurrentDomain.SetupInformation.ConfigurationFile)
            objXMLDocument.Save(strConfigurationFile)

        Catch ex As Exception
            strStatus = "setAppSettingXML(" & strTryStep & "): Name=" & strName & " Value=" & strValue & ": Exception: " & ex.Message
        Finally
            objNodes = Nothing
            objXMLDocument = Nothing
        End Try

        Return strStatus

    End Function ' END - setAppSettingXML()

    '=====================================================================================
    ' Function setGetX10DbSettings()
    ' Alan Wagner
    '
    Private Function setGetX10DbSettings(ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""
        Dim intRowsAffected As Integer = -1

        Try

            strTryStep = "ConnectionStrings"
            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strTryStep = "nsX10DbMethods.updateSettingsToX10db"
            ' nsX10DbMethods.updateSettingsToX10db(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting, ByRef intRowsAffected As Integer) As String
            strError = nsX10DbMethods.updateSettingsToX10db(strConnectionString, strProvider, objX10DbSetting, intRowsAffected)
            If (strError = "") Then

                If (intRowsAffected > 0) Then

                    strTryStep = "nsX10DbMethods.getX10DbSettings"
                    ' nsX10DbMethods.getX10DbSettings(ByVal strConnectionString As String, ByVal strProvider As String, ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
                    strError = nsX10DbMethods.getX10DbSettings(strConnectionString, strProvider, objX10DbSetting)
                    If (strError <> "") Then
                        strStatus = "setGetX10DbSettings(): " & strError
                    End If ' END - nsX10DbMethods.getX10DbSettings()

                Else
                    strStatus = "setGetX10DbSettings(): updateSettingsToX10db(): Settings were not updated."
                End If

            Else
                strStatus = "setGetX10DbSettings(): " & strError
            End If ' END - nsX10DbMethods.updateSettingsToX10db()

        Catch ex As Exception
            If (strStatus = "") Then
                strStatus = "setGetX10DbSettings(" & strTryStep & "): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "setGetX10DbSettings(" & strTryStep & "): Exception: " & ex.Message
            End If
        End Try

        Return strStatus

    End Function ' END - setGetX10DbSettings()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formFileSettings_BrowseButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileSettings_BrowseButton.Click

        formFileSettings_StatusLabel.Text = ""
        formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Black

        If (formFileSettings_FolderBrowserDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then
            formFileSettingsBackupDirectoryPathTextBox.Text = formFileSettings_FolderBrowserDialog.SelectedPath
        End If

    End Sub ' END - formFileSettings_BrowseButton_Click()

    Private Sub formFileSettings_ResetButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileSettings_ResetButton.Click
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strExecutingAssemblyVersion As String = ""
        Dim strLocalAppData As String = ""
        Dim strUserProfile As String = ""
        Dim strApplicationDataPath As String = ""

        Dim arrDirectoryEntries As String() = Nothing
        Dim strDirectoryEntry As String = ""

        Dim strMessage As String = ""

        Try

            strTryStep = "MessageBoxButtons"
            If (Windows.Forms.MessageBox.Show("Reset Your Program Window Layouts?", "Reset", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes) Then

                strTryStep = "GetExecutingAssembly"
                ' C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.exe_StrongName_gw2fuaq4lrkel1fn1penavpzc11etqwf\5.0.7611.12663
                ' C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\5.0.7611.12845
                ' ex: "5.0.7611.12663"
                strExecutingAssemblyVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()

                '==================================================
                strTryStep = "GetEnvironmentVariableLOCALAPPDATA"
                ' LOCALAPPDATA=C:\Users\afwagner\AppData\Local
                strLocalAppData = System.Environment.GetEnvironmentVariable("LOCALAPPDATA")

                strTryStep = "ApplicationDataPathLOCALAPPDATA"
                ' C:\Users\afwagner\AppData\Local\trekkerphotoart.com
                strApplicationDataPath = strLocalAppData & "\trekkerphotoart.com"

                strTryStep = "ExistsLOCALAPPDATA"
                If (System.IO.Directory.Exists(strApplicationDataPath)) Then

                    strTryStep = "GetDirectoriesLOCALAPPDATA"
                    ' C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.exe_StrongName_gw2fuaq4lrkel1fn1penavpzc11etqwf\5.0.7611.12663
                    ' C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\5.0.7611.12845
                    arrDirectoryEntries = System.IO.Directory.GetDirectories(strApplicationDataPath)

                    strTryStep = "DirectoryEntriesCountLOCALAPPDATA"
                    If (arrDirectoryEntries.Count > 0) Then

                        strTryStep = "ForEachLOCALAPPDATA"
                        For Each strDirectoryEntry In arrDirectoryEntries

                            strTryStep = "ContainsLOCALAPPDATA"
                            If (strDirectoryEntry.Contains("\X10ManagerDesktop.") And strDirectoryEntry.Contains("\" & strExecutingAssemblyVersion)) Then

                                strTryStep = "DeleteLOCALAPPDATA"
                                System.IO.Directory.Delete(strDirectoryEntry, True)

                            End If ' END - ContainsLOCALAPPDATA

                        Next ' END - ForEachLOCALAPPDATA

                    End If ' END - DirectoryEntriesCountLOCALAPPDATA

                End If ' END - ExistsLOCALAPPDATA

                '==================================================
                strTryStep = "GetEnvironmentVariableUSERPROFILE"
                ' USERPROFILE=C:\Users\afwagner
                strUserProfile = System.Environment.GetEnvironmentVariable("USERPROFILE")

                strTryStep = "ApplicationDataPathROAMING"
                ' C:\Users\afwagner\AppData\Roaming\trekkerphotoart.com
                strApplicationDataPath = strUserProfile & "\AppData\Roaming\trekkerphotoart.com"

                strTryStep = "ExistsROAMING"
                If (System.IO.Directory.Exists(strApplicationDataPath)) Then

                    strTryStep = "GetDirectoriesROAMING"
                    ' C:\Users\afwagner\AppData\Roaming\trekkerphotoart.com\X10ManagerDesktop.exe_StrongName_gw2fuaq4lrkel1fn1penavpzc11etqwf\5.0.7611.12663
                    ' C:\Users\afwagner\AppData\Roaming\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\5.0.7611.12845
                    arrDirectoryEntries = System.IO.Directory.GetDirectories(strApplicationDataPath)

                    strTryStep = "DirectoryEntriesCountROAMING"
                    If (arrDirectoryEntries.Count > 0) Then

                        strTryStep = "ForEachROAMING"
                        For Each strDirectoryEntry In arrDirectoryEntries

                            strTryStep = "ContainsROAMING"
                            If (strDirectoryEntry.Contains("\X10ManagerDesktop.") And strDirectoryEntry.Contains("\" & strExecutingAssemblyVersion)) Then

                                strTryStep = "DeleteROAMING"
                                System.IO.Directory.Delete(strDirectoryEntry, True)

                            End If ' END - ContainsROAMING

                        Next ' END - ForEachROAMING

                    End If ' END - DirectoryEntriesCountROAMING

                End If ' END - ExistsROAMING

                '==================================================
                strTryStep = "Reset"
                My.Settings.Reset()

                strTryStep = "saveFormsOnExit"
                X10ManagerDesktop.saveFormsOnExit = False

                formFileSettings_StatusLabel.Text = "Success Reseting Your Program Window Layouts"
                formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Green
                formFileSettings_CancelButton.Text() = "Done"

            End If ' END - MessageBoxButtons

        Catch ex As Exception
            strStatus = "formFileSettings_ResetButton_Click(): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formFileSettings_ResetButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formFileSettings_UpdateButton.Visible = False
            formFileSettings_StatusLabel.Text = "Fail"
            formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
            formFileSettings_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formFileSettings_ResetButton_Click()

    Private Sub formFileSettings_UpdateButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileSettings_UpdateButton.Click
        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting = Nothing
        Dim bUpdateX10DbSettings As Boolean = False

        Dim bShowAdvancedInformationCheckBoxChanged As Boolean = True
        Dim bConnectionStringsUpdated As Boolean = False
        Dim bSettingsUpdated As Boolean = False

        Dim objIdentity As System.Security.Principal.WindowsIdentity = Nothing
        Dim objPrincipal As System.Security.Principal.WindowsPrincipal = Nothing

        Dim strDestinationDirectoryFullPath As String = ""
        Dim strBackupDirectoryPath As String = ""

        Try

            formFileSettings_StatusLabel.Text = ""
            formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Black

            strTryStep = "formFileSettings_CancelButton.Select"
            formFileSettings_CancelButton.Select()

            strTryStep = "NewObjectX10DbSetting"
            objX10DbSetting = New TrekkerPhotoArt.X10Include.X10DbSetting

            strTryStep = "GetGlobalSettings"
            objX10DbSetting.longitude = X10ManagerDesktop.longitude
            objX10DbSetting.latitude = X10ManagerDesktop.latitude
            objX10DbSetting.backupDirectoryPath = X10ManagerDesktop.backupDirectoryPath

            strTryStep = "WindowsIdentity"
            objIdentity = System.Security.Principal.WindowsIdentity.GetCurrent()

            strTryStep = "WindowsPrincipal"
            objPrincipal = New System.Security.Principal.WindowsPrincipal(objIdentity)

            strTryStep = "X10DbConnectionStringExists"
            If (formFileSettingsX10DbConnectionStringTextBox.Text() = "") Then
                strStatus = "Missing X10DbConnectionString."
            End If

            strTryStep = "longitudeExists"
            If (formFileSettingsLongitudeTextBox.Text() = "") Then
                If (strStatus = "") Then
                    strStatus = "Missing Longitude."
                Else
                    strStatus &= vbCrLf & "Missing Longitude."
                End If
            Else
                ' Further Checks?

                If (Not Microsoft.VisualBasic.Information.IsNumeric(formFileSettingsLongitudeTextBox.Text())) Then
                    If (strStatus = "") Then
                        strStatus = "Longitude must be a positive or negative decimal number."
                    Else
                        strStatus &= vbCrLf & "Longitude must be a positive or negative decimal number."
                    End If
                End If

            End If ' END - longitudeExists

            strTryStep = "latitudeExists"
            If (formFileSettingsLatitudeTextBox.Text() = "") Then
                If (strStatus = "") Then
                    strStatus = "Missing Latitude."
                Else
                    strStatus &= vbCrLf & "Missing Latitude."
                End If
            Else
                ' Further Checks?

                If (Not Microsoft.VisualBasic.Information.IsNumeric(formFileSettingsLatitudeTextBox.Text())) Then
                    If (strStatus = "") Then
                        strStatus = "Latitude must be a positive or negative decimal number."
                    Else
                        strStatus &= vbCrLf & "Latitude must be a positive or negative decimal number."
                    End If
                End If

            End If ' END - latitudeExists

            strTryStep = "backupDirectoryPathExists"
            If (formFileSettingsBackupDirectoryPathTextBox.Text() = "") Then
                If (strStatus = "") Then
                    strStatus = "Missing Backup Directory Path."
                Else
                    strStatus &= vbCrLf & "Missing Backup Directory Path."
                End If
            Else

                ' Does Directory Exist?

                strDestinationDirectoryFullPath = System.IO.Path.GetFullPath(formFileSettingsBackupDirectoryPathTextBox.Text())

                If (Not System.IO.Directory.Exists(strDestinationDirectoryFullPath)) Then

                    If (Windows.Forms.MessageBox.Show("Backup directory does not exist:" & vbCrLf & """" & strDestinationDirectoryFullPath & """" & vbCrLf & "Create it?", "formFileSettings_UpdateButton_Click()", Windows.Forms.MessageBoxButtons.YesNo, Windows.Forms.MessageBoxIcon.Error) = Windows.Forms.DialogResult.Yes) Then
                        System.IO.Directory.CreateDirectory(strDestinationDirectoryFullPath)
                    Else
                        If (strStatus = "") Then
                            strStatus = "Backup Directory does not exist:" & vbCrLf & """" & strDestinationDirectoryFullPath & """"
                        Else
                            strStatus &= vbCrLf & "Backup Directory does not exist:" & vbCrLf & """" & strDestinationDirectoryFullPath & """"
                        End If
                    End If

                End If

            End If ' END - backupDirectoryPathExists

            strTryStep = "StatusOK"
            If (strStatus = "") Then

                strTryStep = "formFileSettingsX10DbConnectionStringTextBoxChanged"
                If (formFileSettingsX10DbConnectionStringTextBox.Text() <> My.Settings.X10DbConnectionString.ToString()) Then

                    ' Check for elevated Administrator?
                    strTryStep = "WindowsBuiltInRole"
                    If objPrincipal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator) Then

                        strTryStep = "setConnectionStringXML"
                        ' strConfigurationConnectionString ex: "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=&amp;quot;C:\X10ManagerDesktop\X10Db.mdb&amp;quot;"
                        ' setConnectionStringXML(ByVal strConfigurationName As String, ByVal strConfigurationConnectionString As String) As String
                        strError = setConnectionStringXML("TrekkerPhotoArt.My.MySettings.X10DbConnectionString", formFileSettingsX10DbConnectionStringTextBox.Text())
                        If (strError = "") Then
                            bSettingsUpdated = True
                            bConnectionStringsUpdated = True
                        Else
                            strStatus = "formFileSettings_UpdateButton_Click(): " & strError
                            Windows.Forms.MessageBox.Show(strStatus, "formFileSettings_UpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                            formFileSettings_UpdateButton.Visible = False
                            formFileSettings_StatusLabel.Text = "Fail"
                            formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                            formFileSettings_CancelButton.Text() = "Cancel"
                        End If

                    Else
                        strStatus = "X10ManagerDesktop must be run As Administrator to change X10DbConnectionString setting."
                        Windows.Forms.MessageBox.Show(strStatus, "formFileSettings_UpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formFileSettings_UpdateButton.Visible = False
                        formFileSettings_StatusLabel.Text = "Fail"
                        formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formFileSettings_CancelButton.Text() = "Cancel"
                        formFileSettingsX10DbConnectionStringTextBox.Text() = My.Settings.X10DbConnectionString.ToString()
                    End If ' END - WindowsBuiltInRole

                End If  ' END - formFileSettingsX10DbConnectionStringTextBoxChanged

                strTryStep = "formFileSettingsVerifyOnProgramExitCheckBoxChanged"
                If formFileSettingsVerifyOnProgramExitCheckBox.Checked Then
                    If (X10ManagerDesktop.verifyProgramExit = 0) Then
                        objX10DbSetting.verifyProgramExit = 1
                        bUpdateX10DbSettings = True
                    End If
                Else
                    If (X10ManagerDesktop.verifyProgramExit = 1) Then
                        objX10DbSetting.verifyProgramExit = 0
                        bUpdateX10DbSettings = True
                    End If
                End If

                strTryStep = "formFileSettingsShowAdvancedInformationCheckBoxChanged"
                If formFileSettingsShowAdvancedInformationCheckBox.Checked Then
                    If (X10ManagerDesktop.showAdvancedInformation = 0) Then
                        objX10DbSetting.showAdvancedInformation = 1
                        bShowAdvancedInformationCheckBoxChanged = True
                        bUpdateX10DbSettings = True
                    End If
                Else
                    If (X10ManagerDesktop.showAdvancedInformation = 1) Then
                        objX10DbSetting.showAdvancedInformation = 0
                        bShowAdvancedInformationCheckBoxChanged = True
                        bUpdateX10DbSettings = True
                    End If
                End If

                strTryStep = "formFileSettingsLongitudeTextBoxChanged"
                If (formFileSettingsLongitudeTextBox.Text() <> X10ManagerDesktop.longitude.ToString() And strStatus = "") Then

                    objX10DbSetting.longitude = formFileSettingsLongitudeTextBox.Text()

                    bUpdateX10DbSettings = True

                End If ' END - formFileSettingsLongitudeTextBoxChanged

                strTryStep = "formFileSettingsLatitudeTextBoxChanged"
                If (formFileSettingsLatitudeTextBox.Text() <> X10ManagerDesktop.latitude.ToString() And strStatus = "") Then

                    objX10DbSetting.latitude = formFileSettingsLatitudeTextBox.Text()

                    bUpdateX10DbSettings = True

                End If ' END - formFileSettingsLatitudeTextBoxChanged

                strTryStep = "formFileSettingsBackupDirectoryPathTextBox"
                strBackupDirectoryPath = formFileSettingsBackupDirectoryPathTextBox.Text().Trim()
                If (strBackupDirectoryPath = "") Then
                    objX10DbSetting.backupDirectoryPath = ""
                Else

                    ' ex: "D:\Lighthou\X10Manager\X10DbBackup\"
                    If (Microsoft.VisualBasic.InStrRev(strBackupDirectoryPath, "\", -1, vbTextCompare) = strBackupDirectoryPath.Length()) Then
                        objX10DbSetting.backupDirectoryPath = strBackupDirectoryPath
                    Else
                        objX10DbSetting.backupDirectoryPath = strBackupDirectoryPath & "\"
                    End If

                End If
                If ((objX10DbSetting.backupDirectoryPath.ToString() <> X10ManagerDesktop.backupDirectoryPath.ToString() Or strBackupDirectoryPath <> X10ManagerDesktop.backupDirectoryPath.ToString()) And strStatus = "") Then
                    bUpdateX10DbSettings = True
                End If ' END - formFileSettingsLatitudeTextBoxChanged

                strTryStep = "bUpdateX10DbSettings"
                If (bUpdateX10DbSettings And strStatus = "") Then

                    strTryStep = "setGetX10DbSettings"
                    ' setGetX10DbSettings(ByRef objX10DbSetting As TrekkerPhotoArt.X10Include.X10DbSetting) As String
                    strError = setGetX10DbSettings(objX10DbSetting)
                    If (strError = "") Then
                        bSettingsUpdated = True

                        strTryStep = "UpdateGlobalSettings"
                        X10ManagerDesktop.verifyProgramExit = objX10DbSetting.verifyProgramExit
                        X10ManagerDesktop.showAdvancedInformation = objX10DbSetting.showAdvancedInformation
                        X10ManagerDesktop.longitude = objX10DbSetting.longitude
                        X10ManagerDesktop.latitude = objX10DbSetting.latitude
                        X10ManagerDesktop.backupDirectoryPath = objX10DbSetting.backupDirectoryPath

                        strTryStep = "RefreshOpenForms"
                        If bShowAdvancedInformationCheckBoxChanged Then
                            X10ManagerDesktop.RefreshOpenForms()
                        End If

                    Else
                        strStatus = "formFileSettings_UpdateButton_Click(): " & strError
                        Windows.Forms.MessageBox.Show(strStatus, "formFileSettings_UpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                        formFileSettings_UpdateButton.Visible = False
                        formFileSettings_StatusLabel.Text = "Fail"
                        formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                        formFileSettings_CancelButton.Text() = "Cancel"
                    End If ' END - setGetX10DbSettings()

                End If ' END - bUpdateX10DbSettings

                strTryStep = "bSettingsUpdated"
                If bSettingsUpdated Then

                    formFileSettings_UpdateButton.Visible = False
                    formFileSettings_StatusLabel.Text = "Success"
                    formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Green
                    formFileSettings_CancelButton.Text() = "Done"

                    formFileSettingsBackupDirectoryPathTextBox.Text() = objX10DbSetting.backupDirectoryPath.ToString()

                    strTryStep = "bConnectionStringsUpdated"
                    If bConnectionStringsUpdated Then

                        strTryStep = "X10ManagerDesktop.formFileSettingsUpdatedFlag"
                        X10ManagerDesktop.formFileSettingsUpdatedFlag = True

                        Windows.Forms.MessageBox.Show("X10ManagerDesktop will need restarting for new Connection String settings to take effect.", "formFileSettings_UpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Warning)

                    End If ' END - bConnectionStringsUpdated

                Else
                    formFileSettings_StatusLabel.Text = "No Settings were changed"
                    formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Black
                End If ' END - bSettingsUpdated

            Else
                Windows.Forms.MessageBox.Show(strStatus, "formFileSettings_UpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formFileSettings_StatusLabel.Text = "Fail"
                formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
                formFileSettings_CancelButton.Text() = "Cancel"
            End If ' END - StatusOK

        Catch ex As Exception
            strStatus = "formFileSettings_UpdateButton_Click(): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formFileSettings_UpdateButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formFileSettings_UpdateButton.Visible = False
            formFileSettings_StatusLabel.Text = "Fail"
            formFileSettings_StatusLabel.ForeColor = System.Drawing.Color.Red
            formFileSettings_CancelButton.Text() = "Cancel"
        Finally
            objIdentity = Nothing
            objPrincipal = Nothing
            objX10DbSetting = Nothing
        End Try

    End Sub ' END - formFileSettings_UpdateButton_Click()

    Private Sub formFileSettings_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formFileSettings_CancelButton.Click

        Me.Close()

    End Sub ' END - formFileSettings_CancelButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formFileSettings_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationFileSettings" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formFileSettings_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(610, 440)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationFileSettings Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationFileSettings.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationFileSettings.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception
            strStatus = "formFileSettings_FormRestore(): Exception: " & ex.Message
        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formFileSettings_FormRestore()

    '=====================================================================================
    ' Function formFileSettings_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationFileSettings" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formFileSettings_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationFileSettings = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationFileSettings = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception
            strStatus = "formFileSettings_FormSave(): Exception: " & ex.Message
        End Try

        Return strStatus

    End Function ' END - formFileSettings_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formFileSettings