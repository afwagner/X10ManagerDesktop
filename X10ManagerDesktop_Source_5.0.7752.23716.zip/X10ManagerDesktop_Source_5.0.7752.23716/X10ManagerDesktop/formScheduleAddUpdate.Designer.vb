﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formScheduleAddUpdate
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formScheduleAddUpdate))
        Me.formScheduleAddUpdate_CancelButton = New System.Windows.Forms.Button()
        Me.formScheduleAddUpdate_AddUpdateButton = New System.Windows.Forms.Button()
        Me.formScheduleAddUpdate_DeleteButton = New System.Windows.Forms.Button()
        Me.formScheduleAddUpdateNameLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateIDLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateIDLabelText = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateNameTextBox = New System.Windows.Forms.TextBox()
        Me.formScheduleAddUpdate_StatusLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateDescriptionTextBox = New System.Windows.Forms.TextBox()
        Me.formScheduleAddUpdateDescriptionLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateSunriseTimeLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateSunsetTimeLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateEventsLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateEventsDataGridView = New System.Windows.Forms.DataGridView()
        Me.formScheduleAddUpdateActiveCheckBox = New System.Windows.Forms.CheckBox()
        Me.formScheduleAddUpdate_BringToFrontLabel = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateSunriseTimeLabelText = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateSunsetTimeLabelText = New System.Windows.Forms.Label()
        Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation = New System.Windows.Forms.Label()
        CType(Me.formScheduleAddUpdateEventsDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'formScheduleAddUpdate_CancelButton
        '
        Me.formScheduleAddUpdate_CancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formScheduleAddUpdate_CancelButton.Location = New System.Drawing.Point(516, 467)
        Me.formScheduleAddUpdate_CancelButton.Name = "formScheduleAddUpdate_CancelButton"
        Me.formScheduleAddUpdate_CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.formScheduleAddUpdate_CancelButton.TabIndex = 0
        Me.formScheduleAddUpdate_CancelButton.Text = "Cancel"
        Me.formScheduleAddUpdate_CancelButton.UseVisualStyleBackColor = True
        '
        'formScheduleAddUpdate_AddUpdateButton
        '
        Me.formScheduleAddUpdate_AddUpdateButton.Location = New System.Drawing.Point(57, 467)
        Me.formScheduleAddUpdate_AddUpdateButton.Name = "formScheduleAddUpdate_AddUpdateButton"
        Me.formScheduleAddUpdate_AddUpdateButton.Size = New System.Drawing.Size(86, 23)
        Me.formScheduleAddUpdate_AddUpdateButton.TabIndex = 1
        Me.formScheduleAddUpdate_AddUpdateButton.Text = "Add / Update"
        Me.formScheduleAddUpdate_AddUpdateButton.UseVisualStyleBackColor = True
        '
        'formScheduleAddUpdate_DeleteButton
        '
        Me.formScheduleAddUpdate_DeleteButton.Location = New System.Drawing.Point(481, 39)
        Me.formScheduleAddUpdate_DeleteButton.Name = "formScheduleAddUpdate_DeleteButton"
        Me.formScheduleAddUpdate_DeleteButton.Size = New System.Drawing.Size(79, 23)
        Me.formScheduleAddUpdate_DeleteButton.TabIndex = 2
        Me.formScheduleAddUpdate_DeleteButton.Text = "Delete"
        Me.formScheduleAddUpdate_DeleteButton.UseVisualStyleBackColor = True
        '
        'formScheduleAddUpdateNameLabel
        '
        Me.formScheduleAddUpdateNameLabel.AutoSize = True
        Me.formScheduleAddUpdateNameLabel.Location = New System.Drawing.Point(37, 15)
        Me.formScheduleAddUpdateNameLabel.Name = "formScheduleAddUpdateNameLabel"
        Me.formScheduleAddUpdateNameLabel.Size = New System.Drawing.Size(38, 13)
        Me.formScheduleAddUpdateNameLabel.TabIndex = 3
        Me.formScheduleAddUpdateNameLabel.Text = "Name:"
        '
        'formScheduleAddUpdateIDLabel
        '
        Me.formScheduleAddUpdateIDLabel.AutoSize = True
        Me.formScheduleAddUpdateIDLabel.Location = New System.Drawing.Point(51, 44)
        Me.formScheduleAddUpdateIDLabel.Name = "formScheduleAddUpdateIDLabel"
        Me.formScheduleAddUpdateIDLabel.Size = New System.Drawing.Size(21, 13)
        Me.formScheduleAddUpdateIDLabel.TabIndex = 4
        Me.formScheduleAddUpdateIDLabel.Text = "ID:"
        '
        'formScheduleAddUpdateIDLabelText
        '
        Me.formScheduleAddUpdateIDLabelText.AutoSize = True
        Me.formScheduleAddUpdateIDLabelText.Location = New System.Drawing.Point(78, 44)
        Me.formScheduleAddUpdateIDLabelText.Name = "formScheduleAddUpdateIDLabelText"
        Me.formScheduleAddUpdateIDLabelText.Size = New System.Drawing.Size(184, 13)
        Me.formScheduleAddUpdateIDLabelText.TabIndex = 5
        Me.formScheduleAddUpdateIDLabelText.Text = "formScheduleAddUpdateIDLabelText"
        '
        'formScheduleAddUpdateNameTextBox
        '
        Me.formScheduleAddUpdateNameTextBox.Location = New System.Drawing.Point(81, 12)
        Me.formScheduleAddUpdateNameTextBox.MaxLength = 40
        Me.formScheduleAddUpdateNameTextBox.Name = "formScheduleAddUpdateNameTextBox"
        Me.formScheduleAddUpdateNameTextBox.Size = New System.Drawing.Size(382, 20)
        Me.formScheduleAddUpdateNameTextBox.TabIndex = 6
        Me.formScheduleAddUpdateNameTextBox.Text = "formScheduleAddUpdateNameTextBox"
        '
        'formScheduleAddUpdate_StatusLabel
        '
        Me.formScheduleAddUpdate_StatusLabel.AutoSize = True
        Me.formScheduleAddUpdate_StatusLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formScheduleAddUpdate_StatusLabel.Location = New System.Drawing.Point(149, 470)
        Me.formScheduleAddUpdate_StatusLabel.Name = "formScheduleAddUpdate_StatusLabel"
        Me.formScheduleAddUpdate_StatusLabel.Size = New System.Drawing.Size(108, 17)
        Me.formScheduleAddUpdate_StatusLabel.TabIndex = 7
        Me.formScheduleAddUpdate_StatusLabel.Text = "Success | Fail"
        '
        'formScheduleAddUpdateDescriptionTextBox
        '
        Me.formScheduleAddUpdateDescriptionTextBox.Location = New System.Drawing.Point(81, 68)
        Me.formScheduleAddUpdateDescriptionTextBox.MaxLength = 100
        Me.formScheduleAddUpdateDescriptionTextBox.Name = "formScheduleAddUpdateDescriptionTextBox"
        Me.formScheduleAddUpdateDescriptionTextBox.Size = New System.Drawing.Size(479, 20)
        Me.formScheduleAddUpdateDescriptionTextBox.TabIndex = 19
        '
        'formScheduleAddUpdateDescriptionLabel
        '
        Me.formScheduleAddUpdateDescriptionLabel.AutoSize = True
        Me.formScheduleAddUpdateDescriptionLabel.Location = New System.Drawing.Point(12, 71)
        Me.formScheduleAddUpdateDescriptionLabel.Name = "formScheduleAddUpdateDescriptionLabel"
        Me.formScheduleAddUpdateDescriptionLabel.Size = New System.Drawing.Size(63, 13)
        Me.formScheduleAddUpdateDescriptionLabel.TabIndex = 18
        Me.formScheduleAddUpdateDescriptionLabel.Text = "Description:"
        '
        'formScheduleAddUpdateSunriseTimeLabel
        '
        Me.formScheduleAddUpdateSunriseTimeLabel.AutoSize = True
        Me.formScheduleAddUpdateSunriseTimeLabel.Location = New System.Drawing.Point(4, 99)
        Me.formScheduleAddUpdateSunriseTimeLabel.Name = "formScheduleAddUpdateSunriseTimeLabel"
        Me.formScheduleAddUpdateSunriseTimeLabel.Size = New System.Drawing.Size(71, 13)
        Me.formScheduleAddUpdateSunriseTimeLabel.TabIndex = 21
        Me.formScheduleAddUpdateSunriseTimeLabel.Text = "Sunrise Time:"
        '
        'formScheduleAddUpdateSunsetTimeLabel
        '
        Me.formScheduleAddUpdateSunsetTimeLabel.AutoSize = True
        Me.formScheduleAddUpdateSunsetTimeLabel.Location = New System.Drawing.Point(6, 125)
        Me.formScheduleAddUpdateSunsetTimeLabel.Name = "formScheduleAddUpdateSunsetTimeLabel"
        Me.formScheduleAddUpdateSunsetTimeLabel.Size = New System.Drawing.Size(69, 13)
        Me.formScheduleAddUpdateSunsetTimeLabel.TabIndex = 22
        Me.formScheduleAddUpdateSunsetTimeLabel.Text = "Sunset Time:"
        '
        'formScheduleAddUpdateEventsLabel
        '
        Me.formScheduleAddUpdateEventsLabel.AutoSize = True
        Me.formScheduleAddUpdateEventsLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.formScheduleAddUpdateEventsLabel.Location = New System.Drawing.Point(6, 163)
        Me.formScheduleAddUpdateEventsLabel.Name = "formScheduleAddUpdateEventsLabel"
        Me.formScheduleAddUpdateEventsLabel.Size = New System.Drawing.Size(51, 17)
        Me.formScheduleAddUpdateEventsLabel.TabIndex = 40
        Me.formScheduleAddUpdateEventsLabel.Text = "Events"
        '
        'formScheduleAddUpdateEventsDataGridView
        '
        Me.formScheduleAddUpdateEventsDataGridView.AllowDrop = True
        Me.formScheduleAddUpdateEventsDataGridView.AllowUserToAddRows = False
        Me.formScheduleAddUpdateEventsDataGridView.AllowUserToDeleteRows = False
        Me.formScheduleAddUpdateEventsDataGridView.AllowUserToResizeColumns = False
        Me.formScheduleAddUpdateEventsDataGridView.AllowUserToResizeRows = False
        Me.formScheduleAddUpdateEventsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formScheduleAddUpdateEventsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formScheduleAddUpdateEventsDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.formScheduleAddUpdateEventsDataGridView.Location = New System.Drawing.Point(0, 183)
        Me.formScheduleAddUpdateEventsDataGridView.Name = "formScheduleAddUpdateEventsDataGridView"
        Me.formScheduleAddUpdateEventsDataGridView.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        Me.formScheduleAddUpdateEventsDataGridView.ShowCellToolTips = False
        Me.formScheduleAddUpdateEventsDataGridView.ShowEditingIcon = False
        Me.formScheduleAddUpdateEventsDataGridView.Size = New System.Drawing.Size(655, 263)
        Me.formScheduleAddUpdateEventsDataGridView.TabIndex = 39
        '
        'formScheduleAddUpdateActiveCheckBox
        '
        Me.formScheduleAddUpdateActiveCheckBox.AutoSize = True
        Me.formScheduleAddUpdateActiveCheckBox.Location = New System.Drawing.Point(481, 14)
        Me.formScheduleAddUpdateActiveCheckBox.Name = "formScheduleAddUpdateActiveCheckBox"
        Me.formScheduleAddUpdateActiveCheckBox.Size = New System.Drawing.Size(56, 17)
        Me.formScheduleAddUpdateActiveCheckBox.TabIndex = 41
        Me.formScheduleAddUpdateActiveCheckBox.Text = "Active"
        Me.formScheduleAddUpdateActiveCheckBox.UseVisualStyleBackColor = True
        '
        'formScheduleAddUpdate_BringToFrontLabel
        '
        Me.formScheduleAddUpdate_BringToFrontLabel.AutoSize = True
        Me.formScheduleAddUpdate_BringToFrontLabel.Location = New System.Drawing.Point(6, 195)
        Me.formScheduleAddUpdate_BringToFrontLabel.Name = "formScheduleAddUpdate_BringToFrontLabel"
        Me.formScheduleAddUpdate_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formScheduleAddUpdate_BringToFrontLabel.TabIndex = 42
        Me.formScheduleAddUpdate_BringToFrontLabel.Text = "Y | N"
        Me.formScheduleAddUpdate_BringToFrontLabel.Visible = False
        '
        'formScheduleAddUpdateSunriseTimeLabelText
        '
        Me.formScheduleAddUpdateSunriseTimeLabelText.AutoSize = True
        Me.formScheduleAddUpdateSunriseTimeLabelText.Location = New System.Drawing.Point(76, 99)
        Me.formScheduleAddUpdateSunriseTimeLabelText.Name = "formScheduleAddUpdateSunriseTimeLabelText"
        Me.formScheduleAddUpdateSunriseTimeLabelText.Size = New System.Drawing.Size(231, 13)
        Me.formScheduleAddUpdateSunriseTimeLabelText.TabIndex = 43
        Me.formScheduleAddUpdateSunriseTimeLabelText.Text = "formScheduleAddUpdateSunriseTimeLabelText"
        '
        'formScheduleAddUpdateSunsetTimeLabelText
        '
        Me.formScheduleAddUpdateSunsetTimeLabelText.AutoSize = True
        Me.formScheduleAddUpdateSunsetTimeLabelText.Location = New System.Drawing.Point(76, 125)
        Me.formScheduleAddUpdateSunsetTimeLabelText.Name = "formScheduleAddUpdateSunsetTimeLabelText"
        Me.formScheduleAddUpdateSunsetTimeLabelText.Size = New System.Drawing.Size(229, 13)
        Me.formScheduleAddUpdateSunsetTimeLabelText.TabIndex = 44
        Me.formScheduleAddUpdateSunsetTimeLabelText.Text = "formScheduleAddUpdateSunsetTimeLabelText"
        '
        'formScheduleAddUpdateSunriseSunsetTimeLabelInformation
        '
        Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation.AutoSize = True
        Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Location = New System.Drawing.Point(141, 112)
        Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Name = "formScheduleAddUpdateSunriseSunsetTimeLabelInformation"
        Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Size = New System.Drawing.Size(363, 13)
        Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation.TabIndex = 45
        Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation.Text = "Add/Update sets Sunrise/Sunset times (also reset by Controller downloads)."
        '
        'formScheduleAddUpdate
        '
        Me.AcceptButton = Me.formScheduleAddUpdate_AddUpdateButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formScheduleAddUpdate_CancelButton
        Me.ClientSize = New System.Drawing.Size(655, 512)
        Me.Controls.Add(Me.formScheduleAddUpdateSunriseSunsetTimeLabelInformation)
        Me.Controls.Add(Me.formScheduleAddUpdateSunsetTimeLabelText)
        Me.Controls.Add(Me.formScheduleAddUpdateSunriseTimeLabelText)
        Me.Controls.Add(Me.formScheduleAddUpdate_BringToFrontLabel)
        Me.Controls.Add(Me.formScheduleAddUpdateActiveCheckBox)
        Me.Controls.Add(Me.formScheduleAddUpdateEventsLabel)
        Me.Controls.Add(Me.formScheduleAddUpdateEventsDataGridView)
        Me.Controls.Add(Me.formScheduleAddUpdateSunsetTimeLabel)
        Me.Controls.Add(Me.formScheduleAddUpdateSunriseTimeLabel)
        Me.Controls.Add(Me.formScheduleAddUpdateDescriptionTextBox)
        Me.Controls.Add(Me.formScheduleAddUpdateDescriptionLabel)
        Me.Controls.Add(Me.formScheduleAddUpdate_StatusLabel)
        Me.Controls.Add(Me.formScheduleAddUpdateNameTextBox)
        Me.Controls.Add(Me.formScheduleAddUpdateIDLabelText)
        Me.Controls.Add(Me.formScheduleAddUpdateIDLabel)
        Me.Controls.Add(Me.formScheduleAddUpdateNameLabel)
        Me.Controls.Add(Me.formScheduleAddUpdate_DeleteButton)
        Me.Controls.Add(Me.formScheduleAddUpdate_AddUpdateButton)
        Me.Controls.Add(Me.formScheduleAddUpdate_CancelButton)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formScheduleAddUpdate"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Schedule Add / Update"
        CType(Me.formScheduleAddUpdateEventsDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formScheduleAddUpdate_CancelButton As Button
    Friend WithEvents formScheduleAddUpdate_AddUpdateButton As Button
    Friend WithEvents formScheduleAddUpdate_DeleteButton As Button
    Friend WithEvents formScheduleAddUpdateNameLabel As Label
    Friend WithEvents formScheduleAddUpdateIDLabel As Label
    Friend WithEvents formScheduleAddUpdateIDLabelText As Label
    Friend WithEvents formScheduleAddUpdateNameTextBox As TextBox
    Friend WithEvents formScheduleAddUpdate_StatusLabel As Label
    Friend WithEvents formScheduleAddUpdateDescriptionTextBox As TextBox
    Friend WithEvents formScheduleAddUpdateDescriptionLabel As Label
    Friend WithEvents formScheduleAddUpdateSunriseTimeLabel As Label
    Friend WithEvents formScheduleAddUpdateSunsetTimeLabel As Label
    Friend WithEvents formScheduleAddUpdateEventsLabel As Label
    Friend WithEvents formScheduleAddUpdateEventsDataGridView As DataGridView
    Friend WithEvents formScheduleAddUpdateActiveCheckBox As CheckBox
    Friend WithEvents formScheduleAddUpdate_BringToFrontLabel As Label
    Friend WithEvents formScheduleAddUpdateSunriseTimeLabelText As Label
    Friend WithEvents formScheduleAddUpdateSunsetTimeLabelText As Label
    Friend WithEvents formScheduleAddUpdateSunriseSunsetTimeLabelInformation As Label
End Class
