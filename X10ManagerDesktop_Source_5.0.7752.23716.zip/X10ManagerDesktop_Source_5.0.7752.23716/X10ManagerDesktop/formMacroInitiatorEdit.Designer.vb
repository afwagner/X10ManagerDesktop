﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formMacroInitiatorEdit
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.formMacroInitiatorEditDataGridView = New System.Windows.Forms.DataGridView()
        Me.formMacroInitiatorEdit_BringToFrontLabel = New System.Windows.Forms.Label()
        CType(Me.formMacroInitiatorEditDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'formMacroInitiatorEditDataGridView
        '
        Me.formMacroInitiatorEditDataGridView.AllowUserToAddRows = False
        Me.formMacroInitiatorEditDataGridView.AllowUserToDeleteRows = False
        Me.formMacroInitiatorEditDataGridView.AllowUserToResizeRows = False
        Me.formMacroInitiatorEditDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells
        Me.formMacroInitiatorEditDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.formMacroInitiatorEditDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.formMacroInitiatorEditDataGridView.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.formMacroInitiatorEditDataGridView.Location = New System.Drawing.Point(0, 0)
        Me.formMacroInitiatorEditDataGridView.Name = "formMacroInitiatorEditDataGridView"
        Me.formMacroInitiatorEditDataGridView.ReadOnly = True
        Me.formMacroInitiatorEditDataGridView.ShowCellToolTips = False
        Me.formMacroInitiatorEditDataGridView.ShowEditingIcon = False
        Me.formMacroInitiatorEditDataGridView.Size = New System.Drawing.Size(674, 356)
        Me.formMacroInitiatorEditDataGridView.TabIndex = 2
        '
        'formMacroInitiatorEdit_BringToFrontLabel
        '
        Me.formMacroInitiatorEdit_BringToFrontLabel.AutoSize = True
        Me.formMacroInitiatorEdit_BringToFrontLabel.Location = New System.Drawing.Point(12, 9)
        Me.formMacroInitiatorEdit_BringToFrontLabel.Name = "formMacroInitiatorEdit_BringToFrontLabel"
        Me.formMacroInitiatorEdit_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formMacroInitiatorEdit_BringToFrontLabel.TabIndex = 3
        Me.formMacroInitiatorEdit_BringToFrontLabel.Text = "Y | N"
        Me.formMacroInitiatorEdit_BringToFrontLabel.Visible = False
        '
        'formMacroInitiatorEdit
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(674, 356)
        Me.Controls.Add(Me.formMacroInitiatorEdit_BringToFrontLabel)
        Me.Controls.Add(Me.formMacroInitiatorEditDataGridView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formMacroInitiatorEdit"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Macro Initiator Edit"
        CType(Me.formMacroInitiatorEditDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formMacroInitiatorEditDataGridView As DataGridView
    Friend WithEvents formMacroInitiatorEdit_BringToFrontLabel As Label
End Class
