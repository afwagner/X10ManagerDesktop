﻿' Name: formModuleExport.vb
' By: Alan Wagner
' Date: November 2020

Public Class formModuleExport

#Region "X10ManagerDesktopModuleExportMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""
        Dim strTryStep As String = ""

        Dim strInstallerAssemblyLocation As String = ""
        Dim strInstallerAssemblyLocationDrive As String = ""
        Dim strInstallerAssemblyLocationExecutable As String = ""
        Dim bInstallerAssemblyLocationFound As Boolean = False

        Try

            Me.BringToFront()

            formModuleExport_ExportButton.Visible = False

            formModuleExport_StatusLabel.Text = ""
            formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Black
            formModuleExport_CancelButton.Text() = "Cancel"
            formModuleExport_CancelButton.Select()

            strTryStep = "formModuleExport_FormRestore"
            ' formModuleExport_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formModuleExport_FormRestore(objSender, objEventArgs)
            If (strStatus <> "") Then
                Windows.Forms.MessageBox.Show("Main(formModuleExport): " & strStatus, "Main(formModuleExport)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formModuleExport_ExportButton.Visible = False
                formModuleExport_StatusLabel.Text = "Fail"
                formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Red
                formModuleExport_CancelButton.Text() = "Cancel"
            End If ' END - formControllerAddUpdate_FormRestore()

        Catch ex As Exception

            If (ex.InnerException Is Nothing) Then
                strError = "Main(formModuleExport): Exception: TryStep=" & strTryStep & ": " & ex.Message.ToString()
            Else
                strError = "Main(formModuleExport): Exception: TryStep=" & strTryStep & ": " & ex.Message.ToString() & vbCrLf & "InnerException: " & ex.InnerException.ToString
            End If

            If (strStatus = "") Then
                strStatus = strError
            Else
                strStatus &= vbCrLf & strError
            End If

            Windows.Forms.MessageBox.Show(strStatus, "Main(formModuleExport)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleExport_ExportButton.Visible = False
            formModuleExport_StatusLabel.Text = "Fail"
            formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleExport_CancelButton.Text() = "Cancel"

        End Try

    End Sub ' END Sub - Main(formModuleExport)

    Private Sub formModuleExport_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formModuleExport_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formModuleExport_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formModuleExport_FormClosingHandler(): " & strStatus, "formModuleExport_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formFileSettings_FormSave()

    End Sub ' END Sub - formModuleExport_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopModuleExportMainMethods

#Region "formMethods"

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formModuleExport_BrowseButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleExport_BrowseButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim intRecordCount As Integer = 0
        Dim intModulesAddedCount As Integer = 0
        Dim intModulesUpdatedCount As Integer = 0
        Dim strModulesAddedList As String = ""
        Dim strModulesUpdatedList As String = ""

        Dim strMessage As String = ""

        Try

            formModuleExport_ExportButton.Visible = False
            formModuleExport_StatusLabel.Text = ""
            formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Black

            formModuleExport_SaveFileDialog.Filter = "CSV files (*.csv)|*.csv"

            If (formModuleExport_SaveFileDialog.ShowDialog() = System.Windows.Forms.DialogResult.OK) Then

                formModuleExportExportFileTextBox.Text = formModuleExport_SaveFileDialog.FileName()

                formModuleExport_ExportButton.Visible = True
                formModuleExport_StatusLabel.Text = "Click ""Export"" button to continue."
                formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Green

            End If ' END - DialogResult

        Catch ex As Exception
            strStatus = "formModuleExport_BrowseButton_Click(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formModuleExport_BrowseButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleExport_ExportButton.Visible = False
            formModuleExport_StatusLabel.Text = "Fail"
            formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleExport_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formModuleExport_BrowseButton_Click()

    Private Sub formModuleExport_ExportButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleExport_ExportButton.Click
        Dim nsX10DbMethods As New TrekkerPhotoArt.X10Include.X10DbMethods

        Dim strStatus As String = ""
        Dim strError As String = ""

        Dim strConnectionString As String = ""
        Dim strProvider As String = ""

        Dim intRecordCount As Integer = 0

        Dim strMessage As String = ""

        Try

            ' Header Row:
            ' "ControllerName","UnitCode","UnitName","UnitDescription","UnitEnabledYN","UnitDimmerYN","UnitLightingYN","UnitExtendedCommandsYN"
            '
            ' Example Record Rows:
            ' "House Lighting CP290","J1","OutGar","Outside Garage Lights","Y","N","Y","N"
            ' "Test CP290","J16","Den Test Dimmer Module","Dimmer LED Test Light in Dimmer Module","Y","Y","Y","N"

            strConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString
            strProvider = System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ProviderName

            strMessage &= vbCrLf & vbCrLf & "Exporting to file """ & formModuleExportExportFileTextBox.Text & """"
            strMessage &= vbCrLf & "Please wait......."
            Call formConsoleMessages.DisplayMessage(strMessage, "Module Export to File")

            ' nsX10DbMethods.exportModulesFromX10dbToCSVFile(ByVal strConnectionString As String, ByVal strProvider As String, ByVal strFilename As String, ByRef intRecordCount As Integer) As String
            strError = nsX10DbMethods.exportModulesFromX10dbToCSVFile(strConnectionString, strProvider, formModuleExportExportFileTextBox.Text, intRecordCount)
            If (strError = "") Then

                strMessage &= vbCrLf & vbCrLf & "RecordCount=" & intRecordCount.ToString()
                strMessage &= vbCrLf & "Successful Export!"
                Call formConsoleMessages.DisplayMessage(strMessage, "Module Export to File")

                formModuleExport_StatusLabel.Text = "Successful Export!"
                formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Green
                formModuleExport_CancelButton.Text() = "Done"

            Else
                strStatus = "formModuleExport_ExportButton_Click(): " & strError

                strMessage &= vbCrLf & vbCrLf & "Problem with Export!"
                strMessage &= vbCrLf & strStatus
                Call formConsoleMessages.DisplayMessage(strMessage, "Module Export to File")

                Windows.Forms.MessageBox.Show(strStatus, "formModuleExport_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                formModuleExport_ExportButton.Visible = False
                formModuleExport_StatusLabel.Text = "Fail"
                formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Red
                formModuleExport_CancelButton.Text() = "Cancel"
            End If ' END - nsX10DbMethods.exportModulesFromX10dbToCSVFile()

        Catch ex As Exception
            strStatus = "formModuleExport_ExportButton_Click(): Exception: " & ex.Message

            strMessage &= vbCrLf & vbCrLf & strStatus
            Call formConsoleMessages.DisplayMessage(strMessage, "Module Export to File")

            Windows.Forms.MessageBox.Show(strStatus, "formModuleExport_ExportButton_Click()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            formModuleExport_ExportButton.Visible = False
            formModuleExport_StatusLabel.Text = "Fail"
            formModuleExport_StatusLabel.ForeColor = System.Drawing.Color.Red
            formModuleExport_CancelButton.Text() = "Cancel"
        End Try

    End Sub ' END - formModuleExport_ExportButton_Click()

    Private Sub formModuleExport_CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles formModuleExport_CancelButton.Click

        Me.Close()

    End Sub ' END - formModuleExport_CancelButton_Click()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formModuleExport_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleExport" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formModuleExport_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                objSize = New System.Drawing.Size(735, 335)

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationModuleExport Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationModuleExport.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationModuleExport.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Size = objSize

            End If

        Catch ex As Exception
            strStatus = "formModuleExport_FormRestore(): Exception: " & ex.Message
        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formModuleExport_FormRestore()

    '=====================================================================================
    ' Function formModuleExport_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationModuleExport" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formModuleExport_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationModuleExport = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationModuleExport = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception
            strStatus = "formModuleExport_FormSave(): Exception: " & ex.Message
        End Try

        Return strStatus

    End Function ' END - formModuleExport_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class ' END - formModuleExport