﻿
' Name: formSceneEdit.vb
' By: Alan Wagner
' Date: March 2020

Public Class formSceneEdit

#Region "X10ManagerDesktopSceneEditMainMethods"

    Private Sub Main(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) Handles MyBase.Load
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Try

            strTryStep = "formSceneEdit_BringToFrontLabel"
            If (formSceneEdit_BringToFrontLabel.Text() = "Y") Then
                Me.BringToFront()
            Else
                formSceneEdit_BringToFrontLabel.Text() = "Y"
            End If

            strTryStep = "formSceneEdit_FormRestore"
            ' formSceneAddUpdate_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
            strStatus = formSceneEdit_FormRestore(objSender, objEventArgs)
            If (strStatus = "") Then

                ' formSceneEdit_GetScenesDataSet() As String
                strStatus = formSceneEdit_GetScenesDataSet()
                If (strStatus <> "") Then
                    Windows.Forms.MessageBox.Show("Main(formSceneEdit): " & strStatus, "Main(formSceneEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
                End If ' END - formSceneEdit_GetScenesDataSet()

            Else
                Windows.Forms.MessageBox.Show("Main(formSceneEdit): " & strStatus, "Main(formSceneEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
            End If ' END - formSceneEdit_FormRestore()

        Catch ex As Exception
            strStatus = "Main(formSceneEdit): Exception: TryStep=" & strTryStep & ": " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "Main(formSceneEdit)", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End Try

    End Sub ' END Sub - Main(formSceneEdit)

    Private Sub formSceneEdit_FormClosingHandler(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Dim strStatus As String = ""

        ' formSceneEdit_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        strStatus = formSceneEdit_FormSave(objSender, objFormClosingEventArgs)
        If (strStatus <> "") Then
            Windows.Forms.MessageBox.Show("formSceneEdit_FormClosingHandler(): " & strStatus, "formSceneEdit_FormClosingHandler()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        End If ' END - formSceneEdit_FormSave()

    End Sub ' END Sub - formSceneEdit_FormClosingHandler()

#End Region ' END Region - X10ManagerDesktopSceneEditMainMethods

#Region "formMethods"

    '=====================================================================================
    ' formSceneEdit_GetScenesDataSet()
    ' Alan Wagner
    '
    ' vb.net set current row datagridview
    '
    ' https://stackoverflow.com/questions/22304743/data-grid-view-programmatically-setting-the-select-row-index-doesnt-set-the-c
    ' Data Grid View…programmatically setting the select row index doesn't set the CurrentRow.Index to the same?
    '
    ' https://stackoverflow.com/questions/2442419/how-to-save-position-after-reload-datagridview
    ' How to save position after reload DataGridView 
    '
    Public Function formSceneEdit_GetScenesDataSet() As String
        Dim strStatus As String = ""
        Dim strTryStep As String = ""

        Dim intCurrentCellRowIndex As Integer = -1
        Dim intFirstDisplayedCellRowIndex As Integer = -1

        Dim objDataSetScenes As New System.Data.DataSet
        Dim sqlString As String = ""

        Dim intColumnID As Integer = 5    ' Column that contains SceneID.

        Dim bShowAdvancedInformation As Boolean = False

        Try

            strTryStep = "bShowAdvancedInformation"
            Select Case X10ManagerDesktop.showAdvancedInformation
                Case 0
                    bShowAdvancedInformation = False
                Case 1
                    bShowAdvancedInformation = True
            End Select

            strTryStep = "sqlStringDataSetScenes"
            sqlString = "SELECT 'Edit' AS [AddEdit], SceneName AS [Name], SceneDescription AS [Description], SceneHouseCodeLetter AS HouseCode,SWITCH (SceneRestrictHouseCode=0,'N',SceneRestrictHouseCode=1,'Y') AS CurrentHouseCodeOnly, SceneID AS [ID] " &
                        "FROM Scenes " &
                        "WHERE SceneID > -1 " &
                        "UNION " &
                        "SELECT 'Add' AS [AddEdit], '' AS [Name], '' AS [Description], '' AS HouseCode, '' AS CurrentHouseCodeOnly, SceneID AS [ID] " &
                        "FROM Scenes " &
                        "WHERE SceneID = -1 " &
                        "ORDER BY [AddEdit], [Name] ASC;"

            strTryStep = "UsingConnection"
            ' X10 Manager database is found at "\X10Manager\X10Db.mdb"
            Using objConnection As New System.Data.OleDb.OleDbConnection(System.Configuration.ConfigurationManager.ConnectionStrings("TrekkerPhotoArt.My.MySettings.X10DbConnectionString").ConnectionString)

                strTryStep = "Open"
                objConnection.Open()

                strTryStep = "OleDbDataAdapter"
                Dim objOleDbDataAdapter As New System.Data.OleDb.OleDbDataAdapter(sqlString, objConnection)

                strTryStep = "Fill"
                objOleDbDataAdapter.Fill(objDataSetScenes)

                strTryStep = "Close"
                objConnection.Close()
                objOleDbDataAdapter = Nothing

            End Using

            strTryStep = "TablesDataSetScenes"
            formSceneEditDataGridView.DataSource = objDataSetScenes.Tables(0)

            strTryStep = "SelectCaseShowAdvancedInformation"
            Select Case bShowAdvancedInformation
                Case True
                    strTryStep = "IDVisibleTrue"
                    formSceneEditDataGridView.Columns(intColumnID).Visible = True
                Case False
                    strTryStep = "IDVisibleFalse"
                    formSceneEditDataGridView.Columns(intColumnID).Visible = False
            End Select

            strTryStep = "DataGridViewCurrentCellRowIndexFormSceneEdit"
            intCurrentCellRowIndex = X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormSceneEdit

            strTryStep = "DataGridViewFirstDisplayedCellRowIndexFormSceneEdit"
            intFirstDisplayedCellRowIndex = X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormSceneEdit

            strTryStep = "CheckForRestoreCursorPostion"
            If (intCurrentCellRowIndex > -1 And intFirstDisplayedCellRowIndex > -1) Then
                formSceneEditDataGridView.FirstDisplayedScrollingRowIndex = intFirstDisplayedCellRowIndex
                formSceneEditDataGridView.CurrentCell = formSceneEditDataGridView.Rows(intCurrentCellRowIndex).Cells(0) ' Always restore to the first column.
            End If

        Catch ex As Exception
            strStatus = "formSceneEdit_GetScenesDataSet(): Exception: TryStep=" & strTryStep & ": " & ex.Message
        Finally
            objDataSetScenes = Nothing
        End Try

        Return strStatus

    End Function ' END - formSceneEdit_GetScenesDataSet()

#End Region ' END Region - formMethods

#Region "formControlMethods"

    Private Sub formSceneEditDataGridView_CellClick(ByVal objSender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles formSceneEditDataGridView.CellClick
        Dim strStatus As String = ""

        Dim strIDText As String = ""
        Dim bActiveFormFound = False
        Dim objFormCollection = System.Windows.Forms.Application.OpenForms

        Dim objFormSceneAddUpdate As formSceneAddUpdate = Nothing

        Dim objLocation As System.Drawing.Point = Nothing

        Dim intColumnID As Integer = 5    ' Column that contains SceneID.
        Dim intCurrentRow As Integer = -1

        Try

            ' Save current Cursor Position.
            X10ManagerDesktop.DataGridViewCurrentCellRowIndexFormSceneEdit = formSceneEditDataGridView.CurrentCell.RowIndex
            X10ManagerDesktop.DataGridViewFirstDisplayedCellRowIndexFormSceneEdit = formSceneEditDataGridView.FirstDisplayedCell.RowIndex

            intCurrentRow = formSceneEditDataGridView.CurrentRow.Index

            ' Including e.RowIndex >= 0 stops this from responding when Header Row is clicked.
            If (intCurrentRow >= 0 And e.RowIndex >= 0) Then
                ' Item(column, row)

                ' Get SceneID
                strIDText = formSceneEditDataGridView.Item(intColumnID, intCurrentRow).Value.ToString()

                If objFormCollection.OfType(Of formSceneAddUpdate).Any Then

                    If (strIDText = "-1") Then
                        ' Looking for already open Add form.

                        For Each objFormSceneAddUpdate In objFormCollection.OfType(Of formSceneAddUpdate)
                            If (objFormSceneAddUpdate.formSceneAddUpdateIDLabelText.Text() = "") Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    Else

                        For Each objFormSceneAddUpdate In objFormCollection.OfType(Of formSceneAddUpdate)
                            If (objFormSceneAddUpdate.formSceneAddUpdateIDLabelText.Text() = strIDText) Then
                                bActiveFormFound = True
                                Exit For
                            End If
                        Next

                    End If

                End If

                If bActiveFormFound Then
                    objFormSceneAddUpdate.Activate()
                Else

                    objFormSceneAddUpdate = Nothing
                    objFormSceneAddUpdate = New formSceneAddUpdate

                    objFormSceneAddUpdate.formSceneAddUpdateIDLabelText.Text() = strIDText

                    ' Opens as seperate form.
                    objFormSceneAddUpdate.TopLevel = True

                    ' Get form X10ManagerDesktop's Screen Location (System.Drawing.Point(x, y))
                    objLocation = Parent.Location

                    ' Set additional offset
                    objLocation.Offset(50, 100)

                    ' Set default Location for new form to be Shown.
                    objFormSceneAddUpdate.Location = objLocation

                    objFormSceneAddUpdate.Show()

                End If

                objFormSceneAddUpdate.BringToFront()

            End If

        Catch ex As Exception
            strStatus = "formSceneEditDataGridView_CellClick(): Exception: " & ex.Message
            Windows.Forms.MessageBox.Show(strStatus, "formSceneEditDataGridView_CellClick()", Windows.Forms.MessageBoxButtons.OK, Windows.Forms.MessageBoxIcon.Error)
        Finally
            objLocation = Nothing
            objFormSceneAddUpdate = Nothing
            objFormCollection = Nothing
        End Try


    End Sub ' END - formSceneEditDataGridView_CellClick()

#End Region ' END Region - formControlMethods

#Region "formSaveRestoreMethods"

    '=====================================================================================
    ' Function formSceneEdit_FormRestore()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Restore Form information from the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationSceneEdit" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the Form.Load event.
    '
    Private Function formSceneEdit_FormRestore(ByVal objSender As System.Object, ByVal objEventArgs As System.EventArgs) As String
        Dim strStatus As String = ""

        Dim strInitialLocationSize As String = ""
        Dim arrInitialLocationSize() As String = Nothing

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Try

            ' The conditional just allows your users to override the re-locate: if they hold the SHIFT key down while opening your application,
            ' it will ignore the saved location And size info, And appear at the top left in the default size you specify in the designer.
            ' This allows them to recover if they manage to lose it completely! 
            If ((Control.ModifierKeys And Keys.Shift) = 0) Then

                ' Get form's initial location as set by calling Method (System.Drawing.Point(x, y).
                objLocation = Me.Location

                ' Set additional offset
                objLocation.Offset(1, 25)

                objSize = New System.Drawing.Size(660, 380)
                'objSize = Me.Size

                ' If you didn't set a  "Value" in the "Settings" page, it will fail the basic check,
                ' and the location and size will not be changed the first time the application runs - it will appear at the  top left corner in the size you set in the designer.

                If (Not My.Settings.FormInitialLocationSceneEdit Is Nothing) Then

                    ' strInitialLocationSize = Properties.Settings.Default.FormInitialLocationSceneEdit.Trim;
                    strInitialLocationSize = My.Settings.FormInitialLocationSceneEdit.Trim

                    If (strInitialLocationSize.Length > 0) Then

                        arrInitialLocationSize = strInitialLocationSize.Split(",")

                        If (arrInitialLocationSize.Length >= 2) Then
                            objLocation = New System.Drawing.Point(Integer.Parse(arrInitialLocationSize(0)), Integer.Parse(arrInitialLocationSize(1)))
                        End If

                        If (arrInitialLocationSize.Length >= 4) Then
                            objSize = New System.Drawing.Size(Integer.Parse(arrInitialLocationSize(2)), Integer.Parse(arrInitialLocationSize(3)))
                        End If

                    End If

                End If

                Me.Location = objLocation
                Me.Size = objSize

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formSceneEdit_FormRestore(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formSceneEdit_FormRestore(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
            arrInitialLocationSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formSceneEdit_FormRestore()

    '=====================================================================================
    ' Function formSceneEdit_FormSave()
    ' Alan Wagner
    '
    ' Save and restore your form size and location
    ' https://www.codeproject.com/Tips/543631/Save-and-restore-your-form-size-and-location
    '
    ' Saves Form information to the Application config file: X10ManagerDesktop\App.config
    '
    ' A Name entry is needed in Project - Properties - Settings:
    '   "FormInitialLocationSceneEdit" - leave it as "string" and "User" (you could enter a "Value", but it really isn't needed).
    '
    ' Settings are saved per User in "user.config".  "user.config" is created at runtime in the User's Local Profile.
    ' An example location for "user.config":
    '  " C:\Users\afwagner\AppData\Local\trekkerphotoart.com\X10ManagerDesktop.vshost._StrongName_plj5yyxs1ls5pqyxsd21bxabevr3z22q\1.0.7383.30361\user.config"
    '
    ' In Visual Studio Designer - Properties, set the Form StartPosition to Manual.
    ' This keeps Windows from first locating the form In it's idea of a good place, and then moving it to the selected/saved location.
    '
    ' Triggered by the FormClosing event.
    '
    Private Function formSceneEdit_FormSave(ByVal objSender As System.Object, ByVal objFormClosingEventArgs As System.Windows.Forms.FormClosingEventArgs) As String
        Dim strStatus As String = ""

        Dim objLocation As System.Drawing.Point = Nothing
        Dim objSize As System.Drawing.Size = Nothing

        Dim strInitialLocationSize As String = ""

        Try

            ' This provides an override for the user to not save the information by holding down the SHIFT key when they close the application.
            If ((Control.ModifierKeys And Keys.Shift) = 0 And X10ManagerDesktop.saveFormsOnExit) Then

                objLocation = New System.Drawing.Point
                objLocation = Me.Location

                objSize = New System.Drawing.Size
                objSize = Me.Size

                ' If the form window is not completely within the Desktop Boundries.
                If (Not Me.WindowState = System.Windows.Forms.FormWindowState.Normal) Then

                    objLocation = Me.RestoreBounds.Location
                    objSize = Me.RestoreBounds.Size

                End If

                strInitialLocationSize = String.Join(",", objLocation.X, objLocation.Y, objSize.Width, objSize.Height)

                ' C#
                ' Properties.Settings.Default.FormInitialLocationSceneEdit = strInitialLocationSize;
                ' Properties.Settings.Default.Save();

                My.Settings.FormInitialLocationSceneEdit = strInitialLocationSize
                My.Settings.Save()

            End If

        Catch ex As Exception

            If (strStatus = "") Then
                strStatus = "formSceneEdit_FormSave(): Exception: " & ex.Message
            Else
                strStatus &= vbCrLf & "formSceneEdit_FormSave(): Exception: " & ex.Message
            End If

        Finally
            objLocation = Nothing
            objSize = Nothing
        End Try

        Return strStatus

    End Function ' END - formSceneEdit_FormSave()

#End Region ' END Region - formSaveRestoreMethods

End Class