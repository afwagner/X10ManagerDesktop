﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class formConsoleMessages
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(formConsoleMessages))
        Me.formConsoleMessagesRichTextBox = New System.Windows.Forms.RichTextBox()
        Me.formConsoleMessages_BringToFrontLabel = New System.Windows.Forms.Label()
        Me.formConsoleMessages_CloseButton = New System.Windows.Forms.Button()
        Me.formConsoleMessages_CopyToClipboardButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'formConsoleMessagesRichTextBox
        '
        Me.formConsoleMessagesRichTextBox.Location = New System.Drawing.Point(3, 3)
        Me.formConsoleMessagesRichTextBox.Name = "formConsoleMessagesRichTextBox"
        Me.formConsoleMessagesRichTextBox.Size = New System.Drawing.Size(453, 371)
        Me.formConsoleMessagesRichTextBox.TabIndex = 0
        Me.formConsoleMessagesRichTextBox.Text = ""
        '
        'formConsoleMessages_BringToFrontLabel
        '
        Me.formConsoleMessages_BringToFrontLabel.AutoSize = True
        Me.formConsoleMessages_BringToFrontLabel.Location = New System.Drawing.Point(22, 24)
        Me.formConsoleMessages_BringToFrontLabel.Name = "formConsoleMessages_BringToFrontLabel"
        Me.formConsoleMessages_BringToFrontLabel.Size = New System.Drawing.Size(30, 13)
        Me.formConsoleMessages_BringToFrontLabel.TabIndex = 3
        Me.formConsoleMessages_BringToFrontLabel.Text = "Y | N"
        Me.formConsoleMessages_BringToFrontLabel.Visible = False
        '
        'formConsoleMessages_CloseButton
        '
        Me.formConsoleMessages_CloseButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.formConsoleMessages_CloseButton.Location = New System.Drawing.Point(381, 376)
        Me.formConsoleMessages_CloseButton.Name = "formConsoleMessages_CloseButton"
        Me.formConsoleMessages_CloseButton.Size = New System.Drawing.Size(75, 23)
        Me.formConsoleMessages_CloseButton.TabIndex = 4
        Me.formConsoleMessages_CloseButton.Text = "Close"
        Me.formConsoleMessages_CloseButton.UseVisualStyleBackColor = True
        '
        'formConsoleMessages_CopyToClipboardButton
        '
        Me.formConsoleMessages_CopyToClipboardButton.Location = New System.Drawing.Point(3, 376)
        Me.formConsoleMessages_CopyToClipboardButton.Name = "formConsoleMessages_CopyToClipboardButton"
        Me.formConsoleMessages_CopyToClipboardButton.Size = New System.Drawing.Size(131, 23)
        Me.formConsoleMessages_CopyToClipboardButton.TabIndex = 5
        Me.formConsoleMessages_CopyToClipboardButton.Text = "Copy To Clipboard"
        Me.formConsoleMessages_CopyToClipboardButton.UseVisualStyleBackColor = True
        '
        'formConsoleMessages
        '
        Me.AcceptButton = Me.formConsoleMessages_CloseButton
        Me.AutoScaleDimensions = New System.Drawing.SizeF(96.0!, 96.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.CancelButton = Me.formConsoleMessages_CloseButton
        Me.ClientSize = New System.Drawing.Size(460, 407)
        Me.Controls.Add(Me.formConsoleMessages_CopyToClipboardButton)
        Me.Controls.Add(Me.formConsoleMessages_CloseButton)
        Me.Controls.Add(Me.formConsoleMessages_BringToFrontLabel)
        Me.Controls.Add(Me.formConsoleMessagesRichTextBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "formConsoleMessages"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "formConsoleMessages"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents formConsoleMessagesRichTextBox As RichTextBox
    Friend WithEvents formConsoleMessages_BringToFrontLabel As Label
    Friend WithEvents formConsoleMessages_CloseButton As Button
    Friend WithEvents formConsoleMessages_CopyToClipboardButton As Button
End Class
